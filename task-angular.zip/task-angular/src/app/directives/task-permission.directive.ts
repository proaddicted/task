import { Directive, ElementRef, Input, OnInit, TemplateRef, ViewContainerRef } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'app/core/user/user.service';
import { User } from 'app/core/user/user.types';
import { RestApiService } from 'app/services/rest-api.service';

@Directive({
  selector: '[appTaskPermission]'
})
export class TaskPermissionDirective implements OnInit{

   /**
   * This Dirctive Will Be Used for Custom Permission Checking For Task Section
   * 
   * PermissionId Input
   * access->1
   * insert->2
   * update->3
   * view->4
   * list->5
   * delete->6
   * 
   * accessType Input
   * 
   * none->0
   * self->1
   * Hierchy->2
   * My Branch->3
   * My Department->4
   * All->5
   * 
   * @author Prosanta Mitra <pro.addicted@gmail.com>
   * @copyright Copyright (c) 2023, Prosanta Mitra
  */
   item: any = {}
   actionName: any = '';
   permissionId: any;
   permissionColumns: any = '';
   permissionPageUrl: any = '';
   elseTemplate:any = '';
 
   @Input() set appTaskPermission(id: number){
     this.permissionId = id;
   }
   @Input() set appTaskPermissionName(name: string){
     this.actionName = name;
   }
   @Input() set appTaskPermissionItem(item: any){
     this.item = item;
   }
   @Input() set appTaskPermissionColumns(columns: any){
     this.permissionColumns = columns;
   }
   @Input() set appTaskPermissionPage(page: any){
     this.permissionPageUrl = page;
   }

   @Input()set appTaskPermissionElse(ref: TemplateRef<any>){
      this.elseTemplate = ref;
   }
   
   user: User;
   access: number;
 
   constructor(
     private _restApiService: RestApiService,
     private _userService: UserService,
     private router: Router,
     private el: ElementRef,
     private templateRef: TemplateRef<any>,
     private viewContainerRef: ViewContainerRef
     ) { 
    
   }
   ngOnInit(): void {
    this._userService.user$
    .pipe()
    .subscribe((user: User) => {
        
        this.user = user;
  });
  let page_url = this.permissionPageUrl != '' ? this.permissionPageUrl : this.router.url;

  
  console.log('task pernissoon page url',page_url);
  // if(this.item != null && this.item.employees)
  // {
  //   console.log('this.item.employees',this.item.employees)
  //   console.log('this.user.employee_info',this.user.employee_info.hierarchy_users)
  //   var b_col = this.item.employees.map(x => x.id);
  //   console.log('b_col',b_col);
  //   console.log('output',this.user.employee_info.hierarchy_users.filter(x => b_col.includes(x)));
  // }
  
  if(this.user.is_superadmin == 0) //Change to 0 After Test
  {
      this._restApiService.checkPageAccess(page_url,this.permissionId).subscribe((res:any)=>{
        this.access = res;
        
      });

      
        if(this.actionName == 'add')
          {
            if(this.access > 0)
            {
              this.viewContainerRef.createEmbeddedView(this.templateRef)
            }
            else
            {
              this.viewContainerRef.clear();
            }
        }
        else if (this.actionName == 'update' || this.actionName == 'delete') 
        {
          if(this.access > 0)
          {
            
            if(this.item != null && this.item.employees && this.item.employees.length)
            {
              let users = this.item.employees.map(x => x.id);
  
              if(this.access == 1) /* Self */
              {
                if(users.includes(this.user.id) || this.item[this.permissionColumns] == this.user.id)
                  this.viewContainerRef.createEmbeddedView(this.templateRef)
                else
                {
                  this.viewContainerRef.clear();
                  if(this.elseTemplate)
                  {
                    this.viewContainerRef.createEmbeddedView(this.elseTemplate)
                  }
                }
              }
              else if(this.access == 2) /* Heirarchy */
              {
                if(this.user.employee_info.hierarchy_users.filter(x => users.includes(x)).length || this.user.employee_info.hierarchy_users.includes(this.item[this.permissionColumns]))
                  this.viewContainerRef.createEmbeddedView(this.templateRef)
                else
                {
                  this.viewContainerRef.clear();
                  if(this.elseTemplate)
                  {
                    this.viewContainerRef.createEmbeddedView(this.elseTemplate)
                  }
                }
              }
              else if(this.access == 3) /* Branch */
              {
                if(this.user.employee_info.branch_users.filter(x => users.includes(x)).length || this.user.employee_info.branch_users.includes(this.item[this.permissionColumns]))
                  this.viewContainerRef.createEmbeddedView(this.templateRef)
                else
                {
                  this.viewContainerRef.clear();
                  if(this.elseTemplate)
                  {
                    this.viewContainerRef.createEmbeddedView(this.elseTemplate)
                  }
                }
              }
              else if(this.access == 4) /* Department */
              {
                if(this.user.employee_info.department_users.filter(x => users.includes(x)).length  || this.user.employee_info.department_users.includes(this.item[this.permissionColumns]))
                  this.viewContainerRef.createEmbeddedView(this.templateRef)
                else
                {
                  this.viewContainerRef.clear();
                  if(this.elseTemplate)
                  {
                    this.viewContainerRef.createEmbeddedView(this.elseTemplate)
                  }
                }
              }
              else if(this.access == 5) /* All */
              {
                this.viewContainerRef.createEmbeddedView(this.templateRef)
              }
            }
            
            
            
          }
          else
          {
            this.viewContainerRef.clear();
            if(this.elseTemplate)
            {
              this.viewContainerRef.createEmbeddedView(this.elseTemplate)
            }
            
          }
        }
        else if(this.actionName == 'bulk_update' || this.actionName == 'bulk_delete')
        {
          if(this.access == 5)
          {
            this.viewContainerRef.createEmbeddedView(this.templateRef);
          }
          else
            this.viewContainerRef.clear();
        }
        else 
        {
          
        }
     
      // console.log('this.access ',this.access );
      // console.log('this.item.employees',this.item.employees.map(x => x.id));
      // console.log('this.item.employees.includes(this.user.id)',this.item.employees.map(x => x.id).includes(this.user.id));

      //console.log('output',arr1.filter(x => arr2.includes(x)));
      
     
  }
  else
  {
    this.viewContainerRef.createEmbeddedView(this.templateRef);
  }
   }

}
