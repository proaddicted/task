import { TaskPermissionDirective } from './task-permission.directive';

describe('TaskPermissionDirective', () => {
  it('should create an instance', () => {
    const directive = new TaskPermissionDirective();
    expect(directive).toBeTruthy();
  });
});
