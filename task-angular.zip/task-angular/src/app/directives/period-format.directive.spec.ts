import { PeriodFormatDirective } from './period-format.directive';

describe('PeriodFormatDirective', () => {
  it('should create an instance', () => {
    const directive = new PeriodFormatDirective();
    expect(directive).toBeTruthy();
  });
});
