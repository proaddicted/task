import { Directive, ElementRef, Input, OnInit, TemplateRef, ViewContainerRef } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'app/core/user/user.service';
import { User } from 'app/core/user/user.types';
import { RestApiService } from 'app/services/rest-api.service';

@Directive({
  selector: '[appPermission]'
})
export class PermissionDirective implements OnInit{

  /**
   * This Dirctive Will Be Used for Custom Permission Checking 
   * 
   * PermissionId Input
   * 
   * access->1
   * insert->2
   * update->3
   * view->4
   * list->5
   * delete->6
   * 
   * accessType Input
   * 
   * none->0
   * self->1
   * Hierchy->2
   * My Branch->3
   * My Department->4
   * All->5
   * 
   * @author Prosanta Mitra <pro.addicted@gmail.com>
   * @copyright Copyright (c) 2023, Prosanta Mitra
  */

  item: any = {}
  actionName: any = '';
  permissionId: any;
  permissionColumns: any = '';
  permissionPageUrl: any = '';

  @Input() set appPermission(id: number){
    this.permissionId = id;
  }
  @Input() set appPermissionName(name: string){
    this.actionName = name;
  }
  @Input() set appPermissionItem(item: any){
    this.item = item;
  }
  @Input() set appPermissionColumns(columns: any){
    this.permissionColumns = columns;
  }
  @Input() set appPermissionPage(page: any){
    this.permissionPageUrl = page;
  }
  
  user: User;
  access: number;

  constructor(
    private _restApiService: RestApiService,
    private _userService: UserService,
    private router: Router,
    private el: ElementRef,
    private templateRef: TemplateRef<any>,
    private viewContainerRef: ViewContainerRef
    ) { 
   
  }

  ngOnInit(): void {
    this._userService.user$
      .pipe()
      .subscribe((user: User) => {
          
          this.user = user;
    });
    let page_url = this.permissionPageUrl != '' ? this.permissionPageUrl : this.router.url;

    // console.log('this.this.user <<>>',this.user);
    // console.log('branch matched',this.user.employee_info.branch_users.includes(this.item[this.permissionColumns]));
    // console.log('this.permissionColumns',this.permissionColumns);
    // console.log('this.item[this.permissionColumns]',this.item);
    //console.log('page_url',page_url);
    if(this.user.is_superadmin == 0) //Change to 0 After Test
    {
        this._restApiService.checkPageAccess(page_url,this.permissionId).subscribe((res:any)=>{
          this.access = res;
          
        });
        
        if(this.actionName == 'add')
        {
          if(this.access > 0)
          {
            this.viewContainerRef.createEmbeddedView(this.templateRef)
          }
          else
          {
            this.viewContainerRef.clear();
          }
        }
        else if (this.actionName == 'update' || this.actionName == 'delete') 
        {
          if(this.access > 0)
          {
           
            if(this.access == 1) /* Self */
            {
              if(this.item[this.permissionColumns] == this.user.id)
                this.viewContainerRef.createEmbeddedView(this.templateRef)
              else
                this.viewContainerRef.clear();
            }
            else if(this.access == 2) /* Heirarchy */
            {
              if(this.user.employee_info.hierarchy_users.includes(this.item[this.permissionColumns]))
                this.viewContainerRef.createEmbeddedView(this.templateRef)
              else
                this.viewContainerRef.clear();
            }
            else if(this.access == 3) /* Branch */
            {
              if(this.user.employee_info.branch_users.includes(this.item[this.permissionColumns]))
                this.viewContainerRef.createEmbeddedView(this.templateRef)
              else
                this.viewContainerRef.clear();
            }
            else if(this.access == 4) /* Department */
            {
              if(this.user.employee_info.department_users.includes(this.item[this.permissionColumns]))
                this.viewContainerRef.createEmbeddedView(this.templateRef)
              else
                this.viewContainerRef.clear();
            }
            else if(this.access == 5) /* All */
            {
              this.viewContainerRef.createEmbeddedView(this.templateRef)
            }
           
            
          }
          else
          {
            this.viewContainerRef.clear();
          }
        }
        else if(this.actionName == 'bulk_update' || this.actionName == 'bulk_delete')
        {
          if(this.access == 5)
          {
            this.viewContainerRef.createEmbeddedView(this.templateRef);
          }
          else
            this.viewContainerRef.clear();
        }
        else 
        {
          
        }
    }
    else
    {
      this.viewContainerRef.createEmbeddedView(this.templateRef);
    }
  }

  checkColumn(): boolean{
    const columns = this.permissionColumns.split(',');
            
    columns.forEach((val,ind)=>{
      if(this.item[val] == this.user.id)
      {
          console.log('aaa>');
          return true;
      }
      else
      {
         return false;
      }
    });

    return false;
  }

}
