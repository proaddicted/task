import { Pipe, PipeTransform } from '@angular/core';
import dayjs, { Dayjs } from 'dayjs/esm';

@Pipe({
  name: 'customDate'
})
export class CustomDatePipe implements PipeTransform {

  transform(items:any[], arg1?:Date, arg2?:string): unknown {
    if(!arg1){

      return items;
  
      }else{
        let a = items.filter(
          m => dayjs(m[arg2]).format("YYYY-MM-DD") == dayjs(arg1).format("YYYY-MM-DD")
        )
        return a;
      }
  }

}
