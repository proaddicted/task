import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'showHide'
})
export class ShowHidePipe implements PipeTransform {

  transform(items: Array<any>, num: number): Array<any> {
      return items.filter((item,index) => index < num);
  }

}
