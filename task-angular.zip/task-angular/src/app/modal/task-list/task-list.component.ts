import { HttpClient } from '@angular/common/http';
import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { UserService } from 'app/core/user/user.service';
import { RestApiService } from 'app/services/rest-api.service';
import { ToastrService } from 'ngx-toastr';
import { TaskViewComponent } from '../task-view/task-view.component';
import { Subject, takeUntil } from 'rxjs';


@Component({
  selector: 'app-task-list',
  templateUrl: './task-list.component.html',
  styleUrls: ['./task-list.component.scss']
})
export class TaskListComponent implements OnInit,OnDestroy{

  private _unsubscribeAll: Subject<any> = new Subject<any>();

  constructor( private restApiService:RestApiService,
    private _formBuilder:FormBuilder,  
    private cdr: ChangeDetectorRef,
    private toastrService: ToastrService,
    private _matDialog:MatDialog,
    private _userService: UserService,
    private _httpClient: HttpClient,
    public dialogRef: MatDialogRef<TaskListComponent>,
    @Inject(MAT_DIALOG_DATA) public data){
    }

    ngOnInit(): void {
      
    }
    viewTask(item){
      const dialogRef = this._matDialog.open(TaskViewComponent, {
          data: {
            item:item,
          },
          width:'auto',
          height: 'auto'
      });
  
      dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(result => {
      
          if(result && result != null)
          {
  
            
          }
        },
      errRes=>{});
    }
    fetchType(type)
    {
      return  type
        .split("-")
        .filter(x => x.length > 0)
        .map((x) => (x.charAt(0).toUpperCase() + x.slice(1)))
        .join(" ");
    }
    customNum:any = [];
    //---------Multi Show Hide-------//
    showItem(val,i){
        this.customNum[i] = val
    }

    hideItem(val,i){
      this.customNum[i] = val;
    } 
    ngOnDestroy(): void {
      this._unsubscribeAll.next(null);
      this._unsubscribeAll.complete();
    }

}
