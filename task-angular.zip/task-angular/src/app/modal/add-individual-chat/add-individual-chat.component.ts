import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RestApiService } from 'app/services/rest-api.service';
import { Subject, map, takeUntil } from 'rxjs';
import { User } from 'app/core/user/user.types';
import { UserService } from 'app/core/user/user.service';
import { HttpClient } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';
import { ChatService } from 'app/modules/apps/chat/chat.service';

@Component({
  selector: 'app-add-individual-chat',
  templateUrl: './add-individual-chat.component.html',
  styleUrls: ['./add-individual-chat.component.scss']
})
export class AddIndividualChatComponent implements OnInit,OnDestroy{

  private _unsubscribeAll: Subject<any> = new Subject<any>();
  isLoading:boolean = false;
  form: FormGroup; 
  chatgroups: any;
  
  constructor(
    private restApiService:RestApiService,
    private _formBuilder:FormBuilder,  
    private _userService: UserService,
    private cdr: ChangeDetectorRef,
    public dialogRef: MatDialogRef<AddIndividualChatComponent>,
    private _httpClient: HttpClient,
    private toastrService:ToastrService,
    private _chatService: ChatService,
    @Inject(MAT_DIALOG_DATA,) public data
  ) {
   }
   ngOnInit(): void {
    this.form = this._formBuilder.group({
      user:[null,Validators.required]
    });

    this._chatService.chatgroups$
    .pipe(takeUntil(this._unsubscribeAll))
    .subscribe((chatgroups: any[]) => {
        this.chatgroups =  chatgroups;

       
    });
   }

   isSubmitting:boolean = false; //23/09/2024
   onSubmit(data){
    this.isSubmitting = true; //23/09/2024
      this._httpClient.post<any>(`chat_group`,{users:[data.user],type:'individual',private_user_id:data.user})
        .pipe(map(res => {
                if (res) {
                    if(res.success)
                        this.toastrService.success(res.message, 'Success');
                    else
                        this.toastrService.error(res.message,'Update Failed');   

                    return res;
                
                }

        })).subscribe( res => { 
                if(res.success)
                {
                  
                    this.chatgroups.unshift(res.data);
                    this._chatService._chatgroups.next(this.chatgroups);
                    this.form.reset();
                    this.dialogRef.close(res.data);
                }
                this.isSubmitting = false;   //23/09/2024
        });
    }
   
   cancelForm(){
      this.form.reset();
      this.dialogRef.close(null);
   }
   ngOnDestroy(): void {
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
   }
}
