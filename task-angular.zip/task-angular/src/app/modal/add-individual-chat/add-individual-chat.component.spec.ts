import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddIndividualChatComponent } from './add-individual-chat.component';

describe('AddIndividualChatComponent', () => {
  let component: AddIndividualChatComponent;
  let fixture: ComponentFixture<AddIndividualChatComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddIndividualChatComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddIndividualChatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
