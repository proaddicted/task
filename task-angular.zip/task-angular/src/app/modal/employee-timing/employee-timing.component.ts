import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RestApiService } from 'app/services/rest-api.service';
import { Subject, takeUntil } from 'rxjs';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-employee-timing',
  templateUrl: './employee-timing.component.html',
  styleUrls: ['./employee-timing.component.scss']
})
export class EmployeeTimingComponent implements OnDestroy,OnInit{

  isLoading = false; 
  form: FormGroup;  
  return_id:any;
  action:string;
  types: any[] = [];
  days:any[] = [];
  weeks:any[];
  private _unsubscribeAll: Subject<any> = new Subject<any>();

  constructor(
    private _restApiService:RestApiService,
    private _formBuilder:FormBuilder,  
    private cdr: ChangeDetectorRef,
  
    public dialogRef: MatDialogRef<EmployeeTimingComponent>,
    public toastrService: ToastrService,
    @Inject(MAT_DIALOG_DATA) public data
    ) {
      this.types = [
        {id:0, name:'Working'},
        {id:1, name:'Holiday'},
        {id:2, name:'Alternate Holiday'},
        {id:3, name:'Custom Holiday'}
      ];

      this.weeks = [
        {id:1, name:'1st'},
        {id:2, name:'2nd'},
        {id:3, name:'3rd'},
        {id:4, name:'4th'},
        {id:5, name:'5th'}
      ];

      this.days = [
        {id:1, name:'Monday'},
        {id:2, name:'Tuesday'},
        {id:3, name:'Wednessday'},
        {id:4, name:'Thursday'},
        {id:5, name:'Friday'},
        {id:6, name:'Saturday'},
        {id:7, name:'Sunday'}
      ];
    }

    ngOnInit(): void {
      
      this.form = this._formBuilder.group({

          shift_id : null,
          is_overridden : false,
          timing: this._formBuilder.array([])
      });

      if(this.data.timings.length > 0)
      {
        let shift_id, is_overridden;
        this.data.timings.forEach(x => {
          shift_id = x.shift_id;
          is_overridden = x.is_overridden;
        });
        
        this.form.patchValue({
          shift_id:shift_id,
          is_overridden : is_overridden
        })

        this.setTimings(this.data.timings);
      }
      else
      {
        for (let index = 1; index <= 7; index++) {
       
          this.addTiming(index);
        }
      }
    }
    setTimings(timings)
    {
        
      this.form.get('timing').markAsUntouched();
      (this.form.controls['timing'] as FormArray).clear();

      timings.forEach(x => {

      
        this.timings.push(this._formBuilder.group({id:x.id,max_in:x.max_in,in:x.in,out:x.out,lunch:x.lunch,grace:x.grace,type:x.type,day:x.day,week:[x.display_week]}));
      
      })
    }
  
    get timings() {
      return this.form.get('timing') as FormArray;
    }
    addTiming(num){
      this.timings.push(this._formBuilder.group({id:null,shift_id:null,is_overridden:0,in:'',out:'',lunch:'',grace:'',max_in:'',type:null,day:num , week:null}));
    }
    dayById(num){
      let dayBy = {};
      
      this.days.forEach(x => {
        dayBy[x.id] = x.name;
      });


      return dayBy[num];
      
    }
    onShiftChange(event){
      this.form.get('timing').markAsUntouched();
      (this.form.controls['timing'] as FormArray).clear();

      event.shift_timing.forEach(x => {

        this.timings.push(this._formBuilder.group({id:0,in:x.in,out:x.out,lunch:x.lunch,max_in:x.max_in,grace:x.grace,type:x.type,day:x.day,week:[x.display_week]}));
      
      })
    }
    
    isSubmitting:boolean = false; //23/09/2024
    onSubmit(data){
      this.isSubmitting = true; //23/09/2024
      console.log('data',data);
        this._restApiService.store(`employee_timing_update/${this.data.employee.id}`,data).pipe(
            takeUntil(this._unsubscribeAll)
        ).subscribe( res => { 
            console.log("Submit Success: " + res);
            if(res.success)
            {
                this.form.reset();
                this.dialogRef.close(res.data);
            }  
            this.isSubmitting = false;   //23/09/2024   
        });
    }
    cancelForm(){
      this.form.reset();
      this.dialogRef.close(null);
    }
    ngOnDestroy(): void {
      this._unsubscribeAll.next(null);
      this._unsubscribeAll.complete();
    }

}
