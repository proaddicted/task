import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeTimingComponent } from './employee-timing.component';

describe('EmployeeTimingComponent', () => {
  let component: EmployeeTimingComponent;
  let fixture: ComponentFixture<EmployeeTimingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmployeeTimingComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EmployeeTimingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
