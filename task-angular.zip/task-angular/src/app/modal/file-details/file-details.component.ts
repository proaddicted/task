import { FormBuilder, FormGroup } from '@angular/forms';
import { UserService } from 'app/core/user/user.service';
import { RestApiService } from 'app/services/rest-api.service';
import { Subject, forkJoin, map, mergeMap, switchMap, takeUntil } from 'rxjs';
import { AssignUserComponent } from '../assign-user/assign-user.component';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatTabChangeEvent } from '@angular/material/tabs';

import { HttpClient } from '@angular/common/http';
import { Component, OnDestroy, OnInit, ChangeDetectorRef, Directive, ViewChild,Inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import dayjs, { Dayjs } from 'dayjs/esm';
import { MatDialog } from '@angular/material/dialog';
import { DocumentViewerComponent } from '../document-viewer/document-viewer.component';
@Component({
  selector: 'app-file-details',
  templateUrl: './file-details.component.html',
  styleUrls: ['./file-details.component.scss']
})
export class FileDetailsComponent {
  private _unsubscribeAll: Subject<any> = new Subject<any>();
  isLoading:boolean = true;
  form: FormGroup; 

  all_files:any=[];
  file_list_data: any=[]; 
  is_superadmin:any;
  user_selected:boolean = false;
  // private _matDialog: any;
  
  constructor(
    private restApiService:RestApiService,
    private _formBuilder:FormBuilder,  
    private _userService: UserService,
    private cdr: ChangeDetectorRef,
    private http: HttpClient,
    private _matDialog: MatDialog,
    public dialogRef: MatDialogRef<AssignUserComponent>,
    @Inject(MAT_DIALOG_DATA,) public data
  ) {
   }

   ngOnInit(): void {
    console.log('passed data',this.data);

    /*****this function get the serached/list data ********/
        // const url= this._restApiService.excel_export('file_request',file_request.search, file_request.filter, file_request.sort,file_request.pageIndex, file_request.pageSize,file_request.identifier);//making url for send filterized data

          this.http.get(`get_file_array?file_ids=${this.data.files}`).subscribe(res => {
            console.log('response>>>>>>',res);
            // let response=res;

            this.all_files=res;
            console.log('all_files>>>>>>',this.all_files.data);

            this.isLoading=false;
            // this.counts=true;

        }, err => {
            console.log(err);
        });
  }



  onTabChange(files_data)
  {
    console.log('files_data>>>>>',files_data);
    this.file_list_data=files_data;
  }

  //for file size
  formatFileSize(sizeInBytes: number): string {
    const sizeInKB = sizeInBytes / 1024;
    if (sizeInKB >= 1024) {
      const sizeInMB = sizeInKB / 1024;
      return `${sizeInMB.toFixed(2)} MB`;
    } else {
      return `${sizeInKB.toFixed(2)} KB`;
    }
  }

  fileView(item){
    const dialogRef = this._matDialog.open(DocumentViewerComponent, {
        data: {
            file:item
        },
        width:'850px',
        height: '750px'
    });

    dialogRef.afterClosed().subscribe(result => {

        
    },
    errRes=>{});
}

  //for total file size
  formatTotalFileSize(files) {
      let sizeInBytes:any;
      sizeInBytes=0;
      files.forEach((value) => {
        if(!isNaN(parseInt(value.file_size)))
        {
          sizeInBytes=sizeInBytes+parseInt(value.file_size);
        }
      });
      sizeInBytes= BigInt(sizeInBytes).toString();
    const sizeInKB = sizeInBytes / 1024;

    if (sizeInKB < 1024) {
      return sizeInKB + ' KB';
    } 
    else if (sizeInKB < 1024 * 1024) {
      // Convert to MB
      const mbValue = sizeInKB / 1024;
      return mbValue.toFixed(2) + ' MB';
    } else {
      // Convert to GB
      const gbValue = sizeInKB / (1024 * 1024);
      return gbValue.toFixed(2) + ' GB';
    }
  }

  selectedIndex:number = 0;
  filterType:any = null;

  public tabChanged(tabChangeEvent: MatTabChangeEvent): void {
    if(tabChangeEvent.index == 0)
      this.filterType = null;

    this.selectedIndex = tabChangeEvent.index;
    console.log('tabChangeEvent',tabChangeEvent);
  }

  fileDownload(item){
    const salt = (new Date()).getTime();
    return this.http.post(`filedownload?salt=${salt}`,item, {responseType:'blob'}).subscribe(res => {
        var FileSaver = require('file-saver');
        const blob = new Blob([res]);
        FileSaver.saveAs(blob, item.file_name);
        
    }, err => {
        console.log(err);
    });
  }

  viewTasks(type){
    this.selectedIndex = 1;
    this.filterType = type;
  }
}
