import { Component, OnInit,Inject,Output,EventEmitter } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { forEach } from 'lodash';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { saveAs } from 'file-saver';
import { DocumentViewerComponent } from 'app/modal/document-viewer/document-viewer.component'; //09/09/2024

@Component({
  selector: 'app-file-list',
  templateUrl: './file-list.component.html',
  styleUrls: ['./file-list.component.scss']
})
export class FileListComponent implements OnInit{

  files:any [];
  form_header:any [];

  constructor(
    private http: HttpClient,
    private _matDialog: MatDialog,
    public dialogRef: MatDialogRef<FileListComponent>,
    @Inject(MAT_DIALOG_DATA) public data){
      
  }
  
  ngOnInit(): void {
    this.files = this.data.files;
    this.form_header = this.data.form_header;

  }

  fileDownload(item){
    const salt = (new Date()).getTime();
    return this.http.post(`filedownload?salt=${salt}`,item, {responseType:'blob'}).subscribe(res => {
        var FileSaver = require('file-saver');
        const blob = new Blob([res]);
        FileSaver.saveAs(blob, item.file_name);
        
        
    }, err => {
        console.log(err);
    });
  } 

   //09/09/2024
   fileView(item){
    const dialogRef = this._matDialog.open(DocumentViewerComponent, {
        data: {
            file:item
        },
        width:'850px',
        height: '750px'
    });
    dialogRef.afterClosed().subscribe(result => {
    },
    errRes=>{});
  }

}
