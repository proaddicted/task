import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RestApiService } from 'app/services/rest-api.service';
import { Subject, takeUntil } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { FuseConfirmationService } from '@fuse/services/confirmation';
import { trigger, state, style, transition, animate } from '@angular/animations';

@Component({
  selector: 'app-show-rating',
  templateUrl: './show-rating.component.html',
  styleUrls: ['./show-rating.component.scss'],
  animations: [
    // the fade-in/fade-out animation.
    trigger('simpleFadeAnimation', [

      // the "in" style determines the "resting" state of the element when it is visible.
      state('in', style({opacity: 1})),

      // fade in when created. this could also be written as transition('void => *')
      transition(':enter', [
        style({opacity: 0}),
        animate(600)
      ]),

      // fade out when destroyed. this could also be written as transition('void => *')
      transition(':leave',
        animate(400, style({opacity: 0})))
    ])
  ]
})
export class ShowRatingComponent implements OnInit,OnDestroy {
  private _unsubscribeAll: Subject<any> = new Subject<any>();
  isLoading:boolean = false;
  form: FormGroup; 
  call_logs:any[]=[];
  called_id:any;
  rating_width:any='';
  user_info:any;
  show_number_filed:boolean=false;
  view_type:string='visibility_off';
  iconColor:string='#0000ff';
  constructor( private _restApiService:RestApiService,
    private _formBuilder:FormBuilder,  
    private cdr: ChangeDetectorRef,
    private _httpClient:HttpClient,
    private _fuseConfirmationService:FuseConfirmationService,
    public dialogRef: MatDialogRef<ShowRatingComponent>,
    @Inject(MAT_DIALOG_DATA) public data){}

    ngOnInit(): void {
      this.call_logs.push(this.data.call_log);
      if(this.data.identifier=='agent-rating')
        this.rating_width='-7rem';
      else
        this.rating_width='-3rem';
      // console.log('this.data',this.data)
      // this.isLoading = true;
      // this.form = this._formBuilder.group({
        
      //   ratings:['', Validators.required],
      //   remarks:['', Validators.required],
      //   call_log_id:this.data.calllog_id
      // });
      // this.form.controls['ratings'].setValue(0);
      // this.isLoading = false;
    }

    cancelForm(){
      this.dialogRef.close(null);
    }
    ngOnDestroy(): void {
      this._unsubscribeAll.next(null);
      this._unsubscribeAll.complete();
    }
}
