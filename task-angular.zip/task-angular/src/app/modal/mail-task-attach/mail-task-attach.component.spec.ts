import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MailTaskAttachComponent } from './mail-task-attach.component';

describe('MailTaskAttachComponent', () => {
  let component: MailTaskAttachComponent;
  let fixture: ComponentFixture<MailTaskAttachComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MailTaskAttachComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MailTaskAttachComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
