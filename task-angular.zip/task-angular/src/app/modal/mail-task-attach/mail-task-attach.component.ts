import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { AbstractControl, FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { RestApiService } from 'app/services/rest-api.service';
import { Subject, merge, takeUntil } from 'rxjs';
import { UserService } from 'app/core/user/user.service';
import { User } from 'app/core/user/user.types';
import { HttpClient } from '@angular/common/http';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import dayjs, { Dayjs } from 'dayjs/esm';
import { TaskTagComponent } from '../task-tag/task-tag.component';

@Component({
  selector: 'app-mail-task-attach',
  templateUrl: './mail-task-attach.component.html',
  styleUrls: ['./mail-task-attach.component.scss']
})
export class MailTaskAttachComponent implements OnDestroy,OnInit{
  fetch_all_tickets:any=[]
  all_tickets:any=[];
  selected_task:any;
  private _unsubscribeAll: Subject<any> = new Subject<any>();
  constructor(
    private _restApiService:RestApiService,
    private _formBuilder:FormBuilder,  
    private cdr: ChangeDetectorRef,
    private _userService:UserService,
    private _httpClient:HttpClient,
    private _matDialog: MatDialog,
    public dialogRef: MatDialogRef<MailTaskAttachComponent>,
    @Inject(MAT_DIALOG_DATA,) public data
  ) {
   }
  ngOnInit(): void {
        /********for all task fetch 29/07/2024*********** */
        this._httpClient.get(`get_all_tasks`).subscribe(res => {
          this.fetch_all_tickets=res;
          this.all_tickets=this.fetch_all_tickets.data;
      }, err => {
          console.log(err);
      });
      /***********END********* */
  }
   //30/07/2024
   showTaskModal(all_tickets)
   {
       console.log('all_tickets>>>>><<<<<',all_tickets);
       const dialogRef = this._matDialog.open(TaskTagComponent, {
           data: {
               data:all_tickets
           },
           width:'1500px',
           height: '1000px'
       });
       dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(result => {
         this.selected_task=result.id;
         console.log('bichi>>>', this.selected_task);

        //  this.form.patchValue({
        //    main_id:result.id
        //  })
       },
       errRes=>{});
   }
   cancelForm(){
    this.dialogRef.close(null);
  }
  saveTask(selected_task){
    
     this._httpClient.get(`comment_task_attach/${this.data.mail_id}?task_id=${selected_task}`).subscribe(res => {

        this.dialogRef.close(null);

      }, err => {
          console.log(err);
      });
    
  }
  ngOnDestroy(): void {
    
  }

}
