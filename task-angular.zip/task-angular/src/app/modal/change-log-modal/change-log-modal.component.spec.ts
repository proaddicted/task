import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangeLogModalComponent } from './change-log-modal.component';

describe('ChangeLogModalComponent', () => {
  let component: ChangeLogModalComponent;
  let fixture: ComponentFixture<ChangeLogModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChangeLogModalComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ChangeLogModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
