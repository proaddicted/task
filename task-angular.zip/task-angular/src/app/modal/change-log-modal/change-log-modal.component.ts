import {Component, Inject, OnInit} from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import {Subject} from 'rxjs';

@Component({
  selector: 'app-change-log-modal',
  templateUrl: './change-log-modal.component.html',
  styleUrls: ['./change-log-modal.component.scss']
})
export class ChangeLogModalComponent implements OnInit{

  private _unsubscribeAll: Subject<any> = new Subject<any>();

  constructor( 
    private _matDialog: MatDialog,
    public dialogRef: MatDialogRef<ChangeLogModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data){}
  
  change_log_items:any=[];
  column_name:string;

  ngOnInit(): void {   

    this.column_name = this.data.column_name;

    if(this.data.change_log.length){

      if(this.column_name && this.column_name != null)
      {
          this.data.change_log.forEach((element: { column_name: string; }) => {

            if(element.column_name == this.column_name)
              this.change_log_items.push(element)
          });
      }
      else
      {
        this.change_log_items = this.data.change_log;
      }
     
    }
  }

  statusById(id: any) {

    console.log('this.data.item',this.data.item);
    if(this.data.item.type == 'regular-ticket' || this.data.item.type == 'help-ticket' || this.data.item.type == 'memorized-ticket'){
      var result = this.data.ticket_statuses.find((element: { id: any; }) => element.id == id);
    }else if(this.data.item.type == 'meeting' || this.data.item.type == 'call' || this.data.item.type == 'todo' || this.data.item.type == 'crd' || this.data.item.type == 'department-task' || this.data.item.type == 'ist'){
      var result = this.data.task_statuses.find((element: { id: any; }) => element.id == id);
    }
    return result;
  }

  priorityById(id: any) {
    // console.log('this.data.priority', this.data.priority);
    const result = this.data.priority.find((element: { id: any; }) => element.id == id);
    // console.log('result 2:', result);
    return result;
  }                         

  employeeById(id: any) {
    // console.log('this.data.employee', this.data.employee);
    const result = this.data.employee.find((element: { id: any; }) => element.id == id);
    // console.log('result 3:', result);
    return result;
  }

  employeeByNames(ids) {
    const employeeNames: any[] = [];
    let user_ids=ids.replace(/\[|\]/g, '');
    this.data.employee.forEach(element => {
      if(user_ids.split(',').includes(element.id.toString())){
        employeeNames.push(element.name);
      }
    });
    return employeeNames;
  }

  contactByNames(ids: string | any[]) {
    // console.log('this.data.contact', this.data.contact);
    const results = this.data.contact.filter((element: { id: any; }) => ids.includes(element.id));
    const contactNames = results.map((contact: { full_name: any; }) => contact.full_name);
    // console.log('contactNames', contactNames);
    return contactNames;
  }

  flagByNames(ids: string | any[]) {
    // console.log('this.data.task_flag', this.data.task_flag);
    const results = this.data.task_flag.filter((element: { id: any; }) => ids.includes(element.id));
    const flagNames = results.map((task_flag: { name: any; }) => task_flag.name);
    // console.log('flagNames', flagNames);
    return flagNames;
  }

  referralById(id: any) {
    // console.log('this.data.contact', this.data.contact);
    const result = this.data.contact.find((element: { id: any; }) => element.id == id);
    // console.log('result 2:', result);
    return result;
  }   

  ticketStagesByNames(ids: string | any[]) {
    // console.log('this.data.ticket_stage', this.data.ticket_stage);
    const results = this.data.ticket_stage.filter((element: { id: any; }) => ids.includes(element.id));
    const ticketStagesByNames = results.map((ticket_stage: { name: any; }) => ticket_stage.name);
    // console.log('ticketStagesByNames', ticketStagesByNames);
    return ticketStagesByNames;
  }  

  officerByNames(ids: string | any[]) {
    const results = this.data.officer.filter((element: { id: any; }) => ids.includes(element.id));
    const officerNames = results.map((officer: { full_name: any; }) => officer.full_name);
    return officerNames;
  }

}
