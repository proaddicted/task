import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RestApiService } from 'app/services/rest-api.service';
import { Subject, takeUntil } from 'rxjs';
import { ConfirmPasswordValidator } from 'app/validators/confirm-password.validator';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss']
})
export class ChangePasswordComponent implements OnDestroy,OnInit {

  private _unsubscribeAll: Subject<any> = new Subject<any>();
  isLoading:boolean = false;
  form: FormGroup; 
  constructor(
    private restApiService:RestApiService,
    private _formBuilder:FormBuilder,  
    private cdr: ChangeDetectorRef,
    public dialogRef: MatDialogRef<ChangePasswordComponent>,
    @Inject(MAT_DIALOG_DATA,) public data
  ){

  }
  ngOnInit(): void {
    this.form = this._formBuilder.group({
      password : ['', [Validators.required,Validators.minLength(5)]],
      conf_password:['', [Validators.required,Validators.minLength(5)]]
    },
    {
      validator: ConfirmPasswordValidator("password", "conf_password")
    })
  }

  isSubmitting:boolean = false; //23/09/2024
  onSubmit(data){
    this.isSubmitting = true; //23/09/2024
    this.restApiService.store(this.data.url,data).pipe(
        takeUntil(this._unsubscribeAll)
    ).subscribe( res => { 
        if(res.success)
        {
            this.form.reset();
            this.dialogRef.close(res.data);
            
            
        }  
        this.isSubmitting = false; //23/09/2024

    });
  }
  cancelForm(){
    this.form.reset();
    this.dialogRef.close(null);
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }

}
