import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { AbstractControl, FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { RestApiService } from 'app/services/rest-api.service';
import { Subject, merge, takeUntil } from 'rxjs';
import { UserService } from 'app/core/user/user.service';
import { User } from 'app/core/user/user.types';
import { HttpClient } from '@angular/common/http';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import dayjs, { Dayjs } from 'dayjs/esm';
@Component({
  selector: 'app-task-tag',
  templateUrl: './task-tag.component.html',
  styleUrls: ['./task-tag.component.scss']
})
export class TaskTagComponent  implements OnDestroy,OnInit{

  items:any=[];
  selectedValue:any;
  constructor(
    private _restApiService:RestApiService,
    private _formBuilder:FormBuilder,  
    private cdr: ChangeDetectorRef,
    private _userService:UserService,
    private _httpClient:HttpClient,
    private _matDialog: MatDialog,
    public dialogRef: MatDialogRef<TaskTagComponent>,
    @Inject(MAT_DIALOG_DATA,) public data
  ) {
   }
  ngOnInit(): void {
    this.items=this.data.data;
  }

  selectedTask(item){
    this.dialogRef.close(item);
  }
  ngOnDestroy(): void {
    
  }

}
