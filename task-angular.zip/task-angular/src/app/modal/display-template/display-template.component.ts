import { Component, OnInit,Inject,Output,EventEmitter } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';

@Component({
  selector: 'app-display-template',
  templateUrl: './display-template.component.html',
  styleUrls: ['./display-template.component.scss']
})
export class DisplayTemplateComponent {
  header:any;
  subject:any;
  body:any

  constructor(
    public dialogRef: MatDialogRef<DisplayTemplateComponent>,
    @Inject(MAT_DIALOG_DATA) public data){
      
  }

  ngOnInit(): void {
    console.log('data 000>>',this.data)
    this.subject = this.data.subject;
    this.body = this.data.body;
    this.header = this.data.header;

  }
  closeModal(){
    this.dialogRef.close(null);
  }
}
