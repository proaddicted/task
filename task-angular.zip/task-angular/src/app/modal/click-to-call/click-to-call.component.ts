import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RestApiService } from 'app/services/rest-api.service';
import { Subject, takeUntil } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { FuseConfirmationService } from '@fuse/services/confirmation';
import { trigger, state, style, transition, animate } from '@angular/animations';

@Component({
  selector: 'app-click-to-call',
  templateUrl: './click-to-call.component.html',
  styleUrls: ['./click-to-call.component.scss'],
  animations: [
    // the fade-in/fade-out animation.
    trigger('simpleFadeAnimation', [

      // the "in" style determines the "resting" state of the element when it is visible.
      state('in', style({opacity: 1})),

      // fade in when created. this could also be written as transition('void => *')
      transition(':enter', [
        style({opacity: 0}),
        animate(600)
      ]),

      // fade out when destroyed. this could also be written as transition('void => *')
      transition(':leave',
        animate(400, style({opacity: 0})))
    ])
  ]
})
export class ClickToCallComponent implements OnInit,OnDestroy {

  private _unsubscribeAll: Subject<any> = new Subject<any>();
  isLoading:boolean = false;
  form: FormGroup; 
  users:any[];
  called_id:any;
  user_info:any;
  show_number_filed:boolean=false;
  view_type:string='visibility_off';
  iconColor:string='#0000ff';
  constructor( private _restApiService:RestApiService,
    private _formBuilder:FormBuilder,  
    private cdr: ChangeDetectorRef,
    private _httpClient:HttpClient,
    private _fuseConfirmationService:FuseConfirmationService,
    public dialogRef: MatDialogRef<ClickToCallComponent>,
    @Inject(MAT_DIALOG_DATA) public data){}

    ngOnInit(): void {
        
      this.isLoading = true;
      this.form = this._formBuilder.group({
        customer_number : [''],
        agent_number:['', Validators.required],
        given_number:[null],
        main_id : [null],
        identifier : [null]
      });
      this._httpClient.post('user_info',{}).pipe(takeUntil(this._unsubscribeAll)).subscribe((response:any) => {
        if(response.success)
          this.user_info = response.user;
          this.form.controls['agent_number'].setValue(this.user_info.employee_info.phone);
          console.log('user_info<><><><>',this.user_info)
      }); ;
      
     
      this.users=this.data.fetch_phone_numbers;//26/09/2024
      this.isLoading = false;
    }

    /****************Added by Debargha 23/08/2024************** */
    is_showNumber:boolean=false;
    showNumber(){

      this.show_number_filed=this.show_number_filed?false:true;
      console.log('show_number_filed',this.show_number_filed);
      if(this.show_number_filed)
      {
           this._httpClient.post(`save_inspector_of_phonenumbers?searched_from=common-headers`,this.called_id).subscribe(res => {

            console.log('response',res);
            this.view_type='visibility';
            this.iconColor='#00ff00';
            this.is_showNumber=true;

        }, err => {
            console.log(err);
        });
        
      }
      else
      {
        this.view_type='visibility_off';
        this.iconColor='#0000ff';
        this.is_showNumber=false;
      }
    }
    onNumberChange(event){
      this.called_id=event;
      console.log('event',event)
      if(event !=undefined){
        this.form.controls['customer_number'].setValue(event.phone_no);
        // this.form.controls['agent_number'].setValue(this.user_info.employee_info.phone);
        console.log('user_info<><><><>',this.user_info)
      }
      else
      {
        // this.form.controls['agent_number'].setValue('');
        this.is_showNumber=false;
        this.view_type='visibility_off';
        this.iconColor='#0000ff';
      }
    }

    onSubmit(data){
      this._restApiService.store(`knowlarity_place_call`,data).pipe(
        takeUntil(this._unsubscribeAll)
      ).subscribe( res => { 
            if(res.success)
            {
              this.form.reset();
              this.dialogRef.close(res.data);
            }
  
      });
    }

    cancelForm(){
      this.form.reset();
      this.dialogRef.close(null);
    }
    ngOnDestroy(): void {
      this._unsubscribeAll.next(null);
      this._unsubscribeAll.complete();
    }

}
