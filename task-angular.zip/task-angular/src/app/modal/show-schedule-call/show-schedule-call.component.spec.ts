import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowScheduleCallComponent } from './show-schedule-call.component';

describe('ShowScheduleCallComponent', () => {
  let component: ShowScheduleCallComponent;
  let fixture: ComponentFixture<ShowScheduleCallComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowScheduleCallComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShowScheduleCallComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
