import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RestApiService } from 'app/services/rest-api.service';
import { Subject, takeUntil } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { FuseConfirmationService } from '@fuse/services/confirmation';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { TicketSelectViewComponent } from '../ticket-select-view/ticket-select-view.component';

@Component({
  selector: 'app-call-move',
  templateUrl: './call-move.component.html',
  styleUrls: ['./call-move.component.scss'],
  animations: [
    // the fade-in/fade-out animation.
    trigger('simpleFadeAnimation', [

      // the "in" style determines the "resting" state of the element when it is visible.
      state('in', style({opacity: 1})),

      // fade in when created. this could also be written as transition('void => *')
      transition(':enter', [
        style({opacity: 0}),
        animate(600)
      ]),

      // fade out when destroyed. this could also be written as transition('void => *')
      transition(':leave',
        animate(400, style({opacity: 0})))
    ])
  ]
})
export class CallMoveComponent  implements OnInit,OnDestroy{
  private _unsubscribeAll: Subject<any> = new Subject<any>();
  isLoading:boolean = false;
  form: FormGroup; 
  users:any[];
  called_id:any;
  user_info:any;
  show_number_filed:boolean=false;
  view_type:string='visibility_off';
  iconColor:string='#0000ff';
  selected_company:any=0;
  move_to:any[]=[
    {'value':'task','lable':'Task'},
    {'value':'invoice','lable':'Invoice'},
  ];
  allcompanies:any[]=[];
  constructor( private _restApiService:RestApiService,
    private _formBuilder:FormBuilder,  
    private cdr: ChangeDetectorRef,
    private _httpClient:HttpClient,
    private _matDialog: MatDialog,
    private _fuseConfirmationService:FuseConfirmationService,
    public dialogRef: MatDialogRef<CallMoveComponent>,
    @Inject(MAT_DIALOG_DATA) public data){}

    ngOnInit(): void {
      this.data.tickets=[];
      this.data.invoices=[]
      console.log('this.data',this.data)
      this.isLoading = true;
      this.form = this._formBuilder.group({
        task_id:[0,Validators.required],
        identifier:['',Validators.required],
        invoice_id:[0,Validators.required],
        // company:[companies],
        company_id:null,
        group_id:null,//01/08/2024
        call_log_id:this.data.calllog_id
      });
      // this.form.controls['ratings'].setValue(0);
      this.isLoading = false;
      this._httpClient.get<any>('knowlarity_getlist').subscribe((res:any)=>{
            if(res.success)
            {
                this.data.groups=res.data.groups;
                this.allcompanies=res.data.companies;
                this.data.companies=res.data.companies;


                // this._restApiService._task_getlist.next(res.data);
                console.log('res.data',res.data)
            }
      });
      
    }

    //01/08/2024
    onGroupChange(event){
      if(event && event != null)
        {
          this.data.companies = this.allcompanies.filter(item => item.group_id == event.id);
        }
        else
        this.data.companies = this.allcompanies;

        console.log('this.data.companies',this.data.companies);
      
    }

    onIdentifierChange(event)
    {
      console.log('event',event);
      if(event.value=='invoice')
      {
        this.data.tickets=[];
        this._httpClient.get<any>(`fetch_sahaj_invoice/${this.selected_company}`).pipe(
          takeUntil(this._unsubscribeAll)
          ).subscribe( res => {
            if(res.success)
            {
              if(res.data.length)
              {
                this.data.invoices = res.data;
                console.log('this.data.invoices',this.data.invoices);
              }
             
            }
        });
      }
      else
      {
        this.data.invoices =[];
        this._httpClient.get<any>(`get_task_by_company/${this.selected_company}`).pipe(
          takeUntil(this._unsubscribeAll)
          ).subscribe( res => {
            if(res.success)
            {
                
              if(res.data.length)
              {
                this.data.tickets = res.data;
                console.log('this.data.tickets',this.data.tickets);
              }
             
            }
        });
      } 
    }

    onCompanyChange(event)
    {
      console.log('event',event);
      let company_id = [];
      this.selected_company=event.id
    }

    showTicketsModal(items,identifier){
    
      const dialogRef = this._matDialog.open(TicketSelectViewComponent, {
          data: {
            tickets:items,
            identifier:identifier
          },
  
          width:'auto',
          height: 'auto'
      });
  
      dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(result => {
      
          if(result && result != null)
          {
            console.log('resul',result);
            this.form.controls['task_id'].setValue(result.id);
          }
         
        },
      errRes=>{});
      
    }

    isSubmitting:boolean = false; //23/09/2024
    onSubmit(data){
      this.isSubmitting = true; //23/09/2024
      this._restApiService.store(`knowlarity_call_move`,data).pipe(
        takeUntil(this._unsubscribeAll)
      ).subscribe( res => { 
            if(res.success)
            {
              this.form.reset();
              this.dialogRef.close(res.data);
            }
            this.isSubmitting = false; //23/09/2024
      });
    }

    cancelForm(){
      this.form.reset();
      this.dialogRef.close(null);
    }
    ngOnDestroy(): void {
      this._unsubscribeAll.next(null);
      this._unsubscribeAll.complete();
    }
}
