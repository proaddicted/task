import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RestApiService } from 'app/services/rest-api.service';
import { Subject, takeUntil } from 'rxjs';

@Component({
  selector: 'app-contact-add',
  templateUrl: './contact-add.component.html',
  styleUrls: ['./contact-add.component.scss']
})
export class ContactAddComponent implements OnDestroy,OnInit {
  private _unsubscribeAll: Subject<any> = new Subject<any>();
  isLoading:boolean = false;
  form: FormGroup; 

  
  constructor(
    private restApiService:RestApiService,
    private _formBuilder:FormBuilder,  
    private cdr: ChangeDetectorRef,
    public dialogRef: MatDialogRef<ContactAddComponent>,
    @Inject(MAT_DIALOG_DATA,) public data
  ) {
   }

   ngOnInit(): void {
    this.form = this._formBuilder.group({
      is_new:false,
      fname:[''],
      lname:[''],
      email: ['' ,[Validators.email]],
      phone : [''],
      contact_id: [null,[Validators.required]],
      type:['individual',[Validators.required]],
      status:[true],
      hide_email:[true],
      hide_phone:[true]
    })

    this.form.get('is_new').valueChanges
        .subscribe(value => {

          if(value) {
            
            this.form.get('fname').setValidators(Validators.required);
            this.form.get('lname').setValidators(Validators.required);
            this.form.get('phone').setValidators(Validators.required);
            this.form.get('contact_id').clearValidators();
            this.form.get('contact_id').updateValueAndValidity();
          
          } else {
            this.form.get('fname').clearValidators();
            this.form.get('fname').updateValueAndValidity();

            this.form.get('lname').clearValidators();
            this.form.get('lname').updateValueAndValidity();

            this.form.get('phone').clearValidators();
            this.form.get('phone').updateValueAndValidity();

            this.form.get('contact_id').setValidators(Validators.required);
          }
          this.cdr.detectChanges();
        }
    );
   }

   isSubmitting:boolean = false; //23/09/2024
   onSubmit(formData){
    this.isSubmitting = true; //23/09/2024
      this.restApiService.store(`quick_add_contact/${this.data.company_id}`,formData).pipe(
          takeUntil(this._unsubscribeAll)
        ).subscribe( res => { 
            console.log("Submit Success: " + res);
            if(res.success)
            {
              this.form.reset();
              this.dialogRef.close(res.data);  
            }  
            this.isSubmitting = false;   //23/09/2024  
      });
   }
   cancelForm(){
    this.form.reset();
    this.dialogRef.close(null);
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }
}
