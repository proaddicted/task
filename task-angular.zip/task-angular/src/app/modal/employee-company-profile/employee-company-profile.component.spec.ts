import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeCompanyProfileComponent } from './employee-company-profile.component';

describe('EmployeeCompanyProfileComponent', () => {
  let component: EmployeeCompanyProfileComponent;
  let fixture: ComponentFixture<EmployeeCompanyProfileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmployeeCompanyProfileComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EmployeeCompanyProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
