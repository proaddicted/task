import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RestApiService } from 'app/services/rest-api.service';
import { Subject, takeUntil } from 'rxjs';
import * as moment from 'moment';
import dayjs, { Dayjs } from 'dayjs/esm';
import { DateAdapter } from '@angular/material/core';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-employee-company-profile',
  templateUrl: './employee-company-profile.component.html',
  styleUrls: ['./employee-company-profile.component.scss']
})
export class EmployeeCompanyProfileComponent implements OnInit,OnDestroy{
  private _unsubscribeAll: Subject<any> = new Subject<any>();
  isLoading:boolean = false;
  form: FormGroup; 
  constructor(
    private _restApiService:RestApiService,
    private _formBuilder:FormBuilder,  
    private cdr: ChangeDetectorRef,
    private dateAdapter: DateAdapter<Date>,
    public dialogRef: MatDialogRef<EmployeeCompanyProfileComponent>,
    public toastrService: ToastrService,
    @Inject(MAT_DIALOG_DATA) public data
  ) {
      this.dateAdapter.setLocale('en-GB');
    }
   ngOnInit(): void {
     console.log('data',this.data);
     
     this.form = this._formBuilder.group({
        companyprofile: this._formBuilder.array([]),
     })

     if(this.data.company_profiles.length)
      this.setCompanyProfiles(this.data.company_profiles);
     else
      this.addCompanyProfile();

   }
   get companyprofiles() {
    return this.form.get('companyprofile') as FormArray;
   }
   setCompanyProfiles(companyprofiles)
  {
      
    this.form.get('companyprofile').markAsUntouched();
    (this.form.controls['companyprofile'] as FormArray).clear();
    let control = <FormArray>this.form.controls.companyprofile;
    companyprofiles.forEach(x => {
      
      control.push(this._formBuilder.group({
        id:x.id,
        start_date:x.start_date != null ? dayjs(x.start_date).format("YYYY-MM-DD"): null,
        end_date:x.end_date != null ? dayjs(x.end_date).format("YYYY-MM-DD"): null,
        branch_id:x.branch_id,
        department_id:x.department_id,
        designation_id:x.designation_id,
        manager_id:x.manager_id,
        hr_manager_id:x.hr_manager_id,
        status:x.status
      }));
    })
   }
   addCompanyProfile() {
    this.companyprofiles.push(this._formBuilder.group({
      id:null,
      start_date:null,
      end_date:null,
      branch_id:null,
      department_id:null,
      designation_id:null,
      manager_id:null,
      hr_manager_id:null,
      status:true
    }));
 
   }
   deleteCompanyProfile(index) {
    this.companyprofiles.removeAt(index);
   }
   changeStartDate(event: MatDatepickerInputEvent<Date>,index){
    const faControl = (<FormArray>this.form.controls['companyprofile']).at(index);
    faControl['controls'].start_date.setValue(dayjs(event.value).format("YYYY-MM-DD"));
   }
   changeEndDate(event: MatDatepickerInputEvent<Date>,index){
    const faControl = (<FormArray>this.form.controls['companyprofile']).at(index);
    faControl['controls'].end_date.setValue(dayjs(event.value).format("YYYY-MM-DD"));
   }

   isSubmitting:boolean = false; //23/09/2024
   onSubmit(data){
    this.isSubmitting = true; //23/09/2024
      this._restApiService.store(`employee_company_profile_update/${this.data.employee.id}`,data).pipe(
          takeUntil(this._unsubscribeAll)
      ).subscribe( res => { 
          console.log("Submit Success: " + res);
          if(res.success)
          {
              this.form.reset();
              this.dialogRef.close(res.data);
          }  
          this.isSubmitting = false;   //23/09/2024    
      });
   }
   cancelForm(){
    this.form.reset();
    this.dialogRef.close(null);
  }
  onChangeManager(event,index){
    const faControl = (<FormArray>this.form.controls['companyprofile']).at(index);
    if(event.id == this.data.employee.id)
    {
      this.toastrService.error("Manager Can't Be Same As Employee", 'Operation Failed')
      faControl['controls'].manager_id.setValue(null);
    }

  }
  onChangeHR(event,index){
    const faControl = (<FormArray>this.form.controls['companyprofile']).at(index);
    if(event.id == this.data.employee.id)
    {
      this.toastrService.error("Manager Can't Be Same As Employee", 'Operation Failed')
      faControl['controls'].hr_manager_id.setValue(null);
    }
  }
  ngOnDestroy(): void {
  this._unsubscribeAll.next(null);
  this._unsubscribeAll.complete();
  }
}
