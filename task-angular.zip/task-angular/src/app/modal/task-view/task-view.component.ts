import { AfterViewInit, ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RestApiService } from 'app/services/rest-api.service';
import { Subject, takeUntil } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { DocumentViewerComponent } from '../document-viewer/document-viewer.component';
import { Router } from '@angular/router';

@Component({
  selector: 'app-task-view',
  templateUrl: './task-view.component.html',
  styleUrls: ['./task-view.component.scss']
})
export class TaskViewComponent implements OnInit,OnDestroy,AfterViewInit{

  private _unsubscribeAll: Subject<any> = new Subject<any>();
  isLoading:boolean = false;
  //isLoading:boolean = false
  task: any = {};
  employee: any;

  constructor( private restApiService:RestApiService,
    private _formBuilder:FormBuilder,  
    private cdr: ChangeDetectorRef,
    private _httpClient: HttpClient,
    private _matDialog: MatDialog,
    private router: Router,
    public dialogRef: MatDialogRef<TaskViewComponent>,
    @Inject(MAT_DIALOG_DATA) public data){}

    ngOnInit(): void {
      this.isLoading = true;
      this._httpClient.get<any>(`task/${this.data.item.id}`).pipe(
        takeUntil(this._unsubscribeAll)
      ).subscribe(res =>{

          if(res.success)
          {
            this.task = res.data;
            
            if(this.task.employees.length)
            {
              this.task.employees.forEach(element => {
                if(element.pivot.type == 'supervisor')
                {
                  this.employee = element;
                }
              });
            }
            
            this.isLoading = false;
            this.cdr.detectChanges();
          }

      });
    }
    ngAfterViewInit() {
     
    }
    fetchType(type)
    {
      return  type
        .split("-")
        .filter(x => x.length > 0)
        .map((x) => (x.charAt(0).toUpperCase() + x.slice(1)))
        .join(" ");
    }
    fileDownload(item){
        const salt = (new Date()).getTime();
        return this._httpClient.post(`filedownload?salt=${salt}`,item, {responseType:'blob'}).subscribe(res => {
            var FileSaver = require('file-saver');
            const blob = new Blob([res]);
            FileSaver.saveAs(blob, item.file_name);
            
            
        }, err => {
            console.log(err);
        });
    }
    fileView(item){
        const dialogRef = this._matDialog.open(DocumentViewerComponent, {
            data: {
                file:item
            },
            width:'850px',
            height: '750px'
        });

        dialogRef.afterClosed().subscribe(result => {

            
        },
        errRes=>{});
    }
    detailGo(item){
      this.dialogRef.close(null);
      this.router.navigateByUrl('/apps/task-manager/regular-ticket/regular-ticket-view/'+item.id);
    }
    cancelForm(){
      this.dialogRef.close(null);
    }
    ngOnDestroy(): void {
      this._unsubscribeAll.next(null);
      this._unsubscribeAll.complete();
    }

}
