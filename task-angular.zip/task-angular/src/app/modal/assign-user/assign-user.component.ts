import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { RestApiService } from 'app/services/rest-api.service';
import { Subject, takeUntil } from 'rxjs';
import { User } from 'app/core/user/user.types';
import { UserService } from 'app/core/user/user.service';

@Component({
  selector: 'app-assign-user',
  templateUrl: './assign-user.component.html',
  styleUrls: ['./assign-user.component.scss']
})
export class AssignUserComponent implements OnInit,OnDestroy{

  private _unsubscribeAll: Subject<any> = new Subject<any>();
  isLoading:boolean = false;
  form: FormGroup; 
  is_superadmin:any;
  user_selected:boolean = false;
  
  constructor(
    private restApiService:RestApiService,
    private _formBuilder:FormBuilder,  
    private _userService: UserService,
    private cdr: ChangeDetectorRef,
    public dialogRef: MatDialogRef<AssignUserComponent>,
    @Inject(MAT_DIALOG_DATA,) public data
  ) {
   }
  ngOnInit(): void {
    console.log('passed data',this.data);
    this._userService.user$.subscribe((user: User)=>{
      this.is_superadmin = user.is_superadmin;
    })

    this.form = this._formBuilder.group({
      userid:null,
      is_new:false,
      name:[this.data.type == 'contact' ? this.data.contact.full_name: this.data.employee.full_name],
      email: [this.data.type == 'contact' ? this.data.contact.email :this.data.employee.email, [Validators.required, Validators.email]],
      password : ['', [Validators.minLength(5)]],
      role_id : [''],
      is_superadmin:[''],
      status:[true],
      image:new FormControl(''),//16/07/2024
    })

    this.form.get('is_new').valueChanges
    .subscribe(value => {

      if(value) {
        
        this.form.get('password').setValidators(Validators.required)
       
      } else {
        this.form.get('password').clearValidators();
        this.form.get('password').updateValueAndValidity();
      }
      this.cdr.detectChanges();
    }
);
  }
  addFile(event){
    
    if(event != null)
      this.form.controls['image'].setValue(event);//16/07/2024
   }

  isSubmitting:boolean = false; //23/09/2024
  onSubmit(data){
    this.isSubmitting = true; //23/09/2024
    console.log('submitted data',data);
    this.restApiService.store(this.data.url,data).pipe(
        takeUntil(this._unsubscribeAll)
    ).subscribe( res => { 
        console.log("Submit Success: " + res);
        if(res.success)
        {
            this.form.reset();
            this.dialogRef.close(res.data); 
        }  
        this.isSubmitting = false;   //23/09/2024
    });
  }

  onUserChange(user){
    this.user_selected = true;
    console.log('event',user);
    let role_arr  = [];
    if(user.roles.length > 0)
    {
        user.roles.forEach(element => {
        
            role_arr.push(element.id);
            
        });
    }
    this.form.patchValue({
      userid:user.id,
      name:user.name,
      email:user.email,
      password:user.password,
      status:user.status,
      role_id: role_arr,
      is_superadmin:user.is_superadmin
    })
  }

  cancelForm(){
    this.form.reset();
    this.dialogRef.close(null);
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }
}
