import { Component , OnDestroy, OnInit, ChangeDetectorRef, Directive, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDatepicker, MatDatepickerInputEvent } from '@angular/material/datepicker';
import { ActivatedRoute, Router } from '@angular/router';
import { FuseConfirmationService } from '@fuse/services/confirmation';
import { RestApiService } from 'app/services/rest-api.service';
import { Subject, takeUntil, tap } from 'rxjs';
import dayjs, { Dayjs } from 'dayjs/esm';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'environments/environment';
import {default as _rollupMoment, Moment} from 'moment';
import * as _moment from 'moment';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { NgxMatDatetimeInput, NgxMatDatetimePicker } from '@angular-material-components/datetime-picker';
import { MatDialogRef, MatDialog, } from '@angular/material/dialog'; //09/09/2024
import { DocumentViewerComponent } from 'app/modal/document-viewer/document-viewer.component'; //09/09/2024

const moment = _rollupMoment || _moment;
@Component({
  selector: 'app-add-regular-ticket',
  templateUrl: './add-regular-ticket.component.html',
  styleUrls: ['./add-regular-ticket.component.scss']
})
export class AddRegularTicketComponent implements OnInit,OnDestroy {
  restApiURL : any = "task"; 
  isLoading = false; 
  form: FormGroup;  
  return_id:any;
  action:string;
  employees:any[];
  groups:any[];
  companies:any[];
  allcompanies:any[];
  services:any[];
  contacts:any[];
  descriptions:any[];
  priorities:any[];
  check_lists:any[];
  states:any ;
  env:any = environment;
  is_superadmin: any;
  tinyInit: any;
  fileShow:boolean = false;
  moreShow:boolean = false;
  checklistShow:boolean = false;
  private _unsubscribeAll: Subject<any> = new Subject<any>();

  public simpleSelected =  {
  }
  public AllowParentSelection = true;
  public RestructureWhenChildSameName = false;
  public ShowFilter = true;
  public Disabled = false;
  public FilterPlaceholder = 'Type here to filter services...';
  public MaxDisplayed = 7;
  public defaultTime = [new Date().getHours(), new Date().getMinutes() , new Date().getSeconds()] 
  

  constructor(
    private _restApiService: RestApiService,
    private _formBuilder: FormBuilder,
    private activatedRoute: ActivatedRoute,
    private _fuseConfirmationService: FuseConfirmationService,
    private router: Router,
    public modalRef: MatDialogRef<AddRegularTicketComponent>,
    private dateAdapter: DateAdapter<Date>,
    private cd: ChangeDetectorRef,
    private _matDialog: MatDialog, //09/09/2024
    private _httpClient:HttpClient
  ){
    this.dateAdapter.setLocale('en-GB');
    this.tinyInit = this._restApiService.tinyInit();
  }
  public date: moment.Moment;
  ngOnInit(): void {


    // this.mailsLoading = true;
       this._restApiService.getlist('task').pipe(
         takeUntil(this._unsubscribeAll)
       ).subscribe( res => {
           if(res.success)
           {
            console.log('haio rappa >>>>>>>',res)
            this.employees = res.data.employees;
            this.companies = res.data.companies;
            this.allcompanies = res.data.companies;
            this.groups = res.data.groups;
            this.priorities = res.data.ticket_priorities;
            this.check_lists = res.data.check_lists;
            this.services = this.process(res.data.services); 
            res.data.custom_templates.forEach(element => {
               if(element.identifier == 'description')
                this.descriptions.push(element);
              
             });
           }
               
       });

    //this.date = new Date(2021,9,4,5,6,7);
    this.descriptions = [];

    this.form = this._formBuilder.group({
      group_id: null,
      company : [null,Validators.required],
      contact : [null],
      employee:[null,Validators.required],
      supervisor:null,
      manager:null,
      service:null,
      files: this._formBuilder.array([]),
      check_list: this._formBuilder.array([]),
      description_id:null,
      description:null,
      start_date:null,
      received_date:null,
      due_date:[null,Validators.required],
      ecd:null,
      standard_time:null,
      priority:null,
      start_period:[null], //13/09/2024
      end_period:[null], //13/09/2024
      referral_id:null,
      type:'regular-ticket',


    });
  
      this.form.controls['start_date'].setValue(new Date());
      this.form.controls['received_date'].setValue(new Date());

  }

  clearDueDate(event) {
      event.stopPropagation();
      this.form.controls.due_date.setValue(null);
  }
  /*****************Mutli Level Service*************/
  private process(data): any {
    let result = [];
    result = data.map((item) => {
      return this.toTreeNode(item);
    });
    return result;
  }

  private toTreeNode(node, parent = null) {
    //console.log(node, parent);
    if (node && node.children) {
      node.children.map(item => {
        return this.toTreeNode(item, node);
      });
    }
    return node;
  }
  onSelectionChange(event){
    
    //When Multiple and Multilevel
    // let services = [];
    // if(event != null && event.length)
    // {
    //   event.forEach(element => {
    //     services.push(element.id);
    //   });
    //   this.form.controls.service.setValue(services);
    // }
    //When only Multilevel
    if(event && event != null)
    {
      console.log('service eve',event);
      this.form.controls.service.setValue(event.id);
    }
  
  }
  clearService(){
    this.simpleSelected = {};
    this.form.controls.service.setValue(null);
  }
 /*****************End Mutli Level Service*************/
  contactLoading:boolean = false;
  onCompanyChange(event)
  {
    console.log('event',event);
    let company_id = [];

    if(!event.length)
    {
      this.contacts = [];
      return true;
    }
    if(event.length)
    {
      event.forEach(element => {
        company_id.push(element.id);
      });
    }
    this.contactLoading = true;
    this._httpClient.post<any>(`get_contacts_by_company?page_url=${this.router.url}`, {company_id:company_id}).pipe(
      takeUntil(this._unsubscribeAll)
    ).subscribe( res => {
      if(res.success)
      {
          
        if(res.data.length)
        {
          this.contacts = res.data;
        }
        this.contactLoading = false;
      }
          
  });
              
  }
  onGroupChange(event){

    if(event && event != null)
    {
        this.companies = this.allcompanies.filter(item => item.group_id == event.id);

        console.log('this.allcompanies',this.allcompanies);
        console.log('event',event);
    }
    else
      this.companies = this.allcompanies;
    
  }

  showDescription:boolean = false;
  onDescriptionChange(event)
  {
    this.showDescription = true;
    if(event != null)
    {
      this.form.controls['description'].setValue(event.body);
    }
    else
    {
      this.form.controls['description'].setValue(null);
    }
  }

  setStartMonthAndYear(normalizedMonthAndYear: Moment, datepicker: MatDatepicker<Moment>) {
    const ctrlValue = this.form.controls['start_period'].value;
    ctrlValue.month(normalizedMonthAndYear.month());
    ctrlValue.year(normalizedMonthAndYear.year());
    this.form.controls['start_period'].setValue(ctrlValue);
  
    // console.log('date>>>>>',moment(this.form.controls['start_period'].value, 'M/Y').format('MM-YYYY'))
    datepicker.close();
  }
  setEndMonthAndYear(normalizedMonthAndYear: Moment, datepicker: MatDatepicker<Moment>) {
    const ctrlValue = this.form.controls['end_period'].value;
    ctrlValue.month(normalizedMonthAndYear.month());
    ctrlValue.year(normalizedMonthAndYear.year());
    this.form.controls['end_period'].setValue(ctrlValue);
    datepicker.close();
  }
  /*****Checklist Section Code********/
  selectedCheckList:any;
  onCheckListChange(event){

    this.selectedCheckList = event;
    
    if(event.items.length)
    {
      (<FormArray>this.form.get('check_list')).clear();
      event.items.forEach(x => {
        
            this.checklists.push(
                this._formBuilder.group({
                    id:null,
                    description:x.value,
                        
                })    
            );
        })
    }
    else
    {
      (<FormArray>this.form.get('check_list')).clear();
    }
    
  }
  get checklists() {
    return this.form.get('check_list') as FormArray;
  }
  onChecklistRemove(index) {

    this.checklists.removeAt(index);
  

  }
  setCheckList(items)
  {
    (<FormArray>this.form.get('check_list')).clear();
    items.forEach(x => {
      
          this.checklists.push(
              this._formBuilder.group({
                      id:x.id,
                      description:x.description,
                      
              })    
          );
      })
  }
  /*******File Section Code******/

  files: File[] = [];
  upload_files: File[] = [];
  isUploadLoad:boolean = false;

  onFileSelect(event) {

      this.isUploadLoad = true;

      this.upload_files = [];

      this.files.push(...event.addedFiles);
      this.upload_files.push(...event.addedFiles);

      const formData = new FormData();

      for (var i = 0; i < this.upload_files.length; i++) { 
          formData.append("files[]", this.upload_files[i]);
      }

      this._restApiService.tempFileUpload(`task`,formData).pipe(
          takeUntil(this._unsubscribeAll)
      ).subscribe( res => { 
          if(res.success)
          {
              if(res.data.length > 0)
              {
                  res.data.forEach(x => {
                      
                      this.file_items.push(
                          this._formBuilder.group({
                                  temp_id:x.id,
                                  file_path:x.file_path,
                                  file_name:x.file_name,
                                  file_size:x.file_size,
                                  file_extension:x.file_extension,
                                  full_file_path:x.full_file_path,
                                  file_description:[''],
                                  identifier:x.identifier,
                                  id:[''],
                          })    
                      );
                      
                      
                  })
              }
              this.isUploadLoad = false;

          }

          
      });
      

  }
  onFileRemove(index) {

      this.file_items.removeAt(index);
    

  }
  get file_items() {
    return this.form.get('files') as FormArray;
  }
  setFiles(files){
      (<FormArray>this.form.get('files')).clear();
      files.forEach(x => {
      
          this.file_items.push(
              this._formBuilder.group({
                      id:x.id,
                      file_path:x.file_path,
                      file_name:x.file_name,
                      file_size:x.file_size,
                      file_extension:x.file_extension,
                      file_description:x.file_description,
                      identifier:x.identifier,
                      temp_id:[''],
              })    
          );
      })
  }
  fileDownload(item){
    const salt = (new Date()).getTime();
    return this._httpClient.post(`filedownload?salt=${salt}`,item, {responseType:'blob'}).subscribe(res => {
        var FileSaver = require('file-saver');
        const blob = new Blob([res]);
        FileSaver.saveAs(blob, item.file_name);
        
        
    }, err => {
        console.log(err);
    });
  }

  //09/09/2024
  fileView(item){
    const dialogRef = this._matDialog.open(DocumentViewerComponent, {
        data: {
            file:item
        },
        width:'850px',
        height: '750px'
    });

    dialogRef.afterClosed().subscribe(result => {   
    },
    errRes=>{});
  }

  /*******File Section Code End******/

  isSubmitting:boolean = false;
  onSubmit(data:any,event:any){
    /*******Manupulating Form Data*******/
    if(data.start_period != null)
      data.start_period = data.start_period.format('MM/YYYY');
    if(data.end_period != null)  
      data.end_period = data.end_period.format('MM/YYYY');

    if(data.due_date != null)  
      data.due_date = dayjs(new Date(data.due_date)).format("YYYY-MM-DD HH:mm:ss");
    if(data.ecd != null)  
      data.ecd = dayjs(new Date(data.ecd)).format("YYYY-MM-DD HH:mm:ss");
    if(data.start_date != null)  
      data.start_date = dayjs(new Date(data.start_date)).format("YYYY-MM-DD HH:mm:ss");  
    if(data.received_date != null)  
      data.received_date = dayjs(new Date(data.received_date)).format("YYYY-MM-DD HH:mm:ss");  
    
    console.log('data>>>',data);
     
    this.isSubmitting = true;
     this._restApiService.store(this.restApiURL,data).pipe(
            takeUntil(this._unsubscribeAll)
          ).subscribe( res => { 
            console.log("Submit Success: " + res);
            if(res.success)
            {
                if( event == 'save')
                {
                
                
                  let companies = [];
                  if(res.data.companies.length)
                  {
                    this.onCompanyChange(res.data.companies);
                    res.data.companies.forEach(element => {
                      companies.push(element.id);
                    });
                  }
                  let contacts = [];
                  if(res.data.contacts.length)
                  {
                    res.data.contacts.forEach(element => {
                      contacts.push(element.id);
                    });
                  }
                  let employees = [] , manager:any = null , supervisor:any = null;
                  if(res.data.employees.length)
                  {
                    res.data.employees.forEach(element => {
                      if(element.pivot.type == 'employee')
                        employees.push(element.id);
                      if(element.pivot.type == 'manager')
                        manager  = element.id;  
                      if(element.pivot.type == 'supervisor')
                        supervisor  = element.id;    
                    });
                  }
                  //console.log('Date.parse("March 21, 2012"',new Date(`01/${res.data.start_period}`));
                 //  console.log('new Date(res.data.start_period)',dayjs(new Date(res.data.start_period))) ;
                    this.form.patchValue({
                      company : companies,
                      contact : contacts,
                      employee: employees,
                      supervisor:supervisor,
                      manager:manager,
                      group_id:res.data.group_id,
                      description_id:res.data.description_id,
                      description:res.data.description,
                      standard_time:res.data.standard_time,
                      priority:res.data.priority,
                      start_date:new Date(res.data.start_date),
                      received_date:new Date(res.data.received_date),
                      due_date:new Date(res.data.due_date),
                      ecd:new Date(res.data.ecd),
                      referral_id:res.data.referral_id,
                    });
                    
                    let services = [];
                    res.data.services.forEach(element => {
                      services.push(element.id);
                    });
                    this.form.patchValue({
                      service:services
                    });

                    if(res.data.start_period != null)
                    {
                      let start_period = res.data.start_period.split('/');
                      this.form.patchValue({
                        start_period:moment(new Date( parseInt(start_period[1]),(parseInt(start_period[0]) -1),1))
                      })
                    }
                    if(res.data.end_period != null)
                    {
                      let end_period = res.data.end_period.split('/');
                      this.form.patchValue({
                        end_period:moment(new Date(parseInt(end_period[1]),(parseInt(end_period[0]) -1),1))
                      })
                    }

                    this.simpleSelected = res.data.services;

                    if(res.data.description != null)
                      this.showDescription = true;
                    
                    if(res.data.files.length)
                      this.setFiles(res.data.files);
                    if(res.data.check_lists.length)
                      this.setCheckList(res.data.check_lists);
                  
                  

                    this.action = 'edit';
                    this.return_id = res.data.id;
                    this.router.navigateByUrl('/apps/task-manager/regular-ticket/add-edit-regular-ticket/edit/'+res.data.id);
                }
                else if(event == 'save_add')
                {
                    this.form.reset();  
                    this.action = 'add';
                    this.return_id = 'id';
                    this.router.navigateByUrl('/apps/task-manager/regular-ticket/add-edit-regular-ticket/add/id');
                }
                else if(event == 'save_exit')
                    this.router.navigateByUrl('/apps/task-manager/regular-ticket/regular-ticket-list');
            }
            this.isSubmitting = false;       
            this.modalRef.close(res.data);
        });  
    
  }
  pageReload()
  {
    const dialogRef = this._fuseConfirmationService.open({
          "title": "Reload Page",
          "message": 'Are you sure you want to reload page, all unsaved changes will be lost?',
          "icon": {
            "show": true,
            "name": "heroicons_outline:exclamation",
            "color": "warn"
          },
          "actions": {
          "confirm": {
              "show": true,
              "label": "Okay",
              "color": "primary"
              },
            "cancel": {
              "show": true,
              "label": "Cancel"
            }
          },
          "dismissible": false
    });

    dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(result => {
      if ( result == 'confirmed' )
      {
          
        this.ngOnInit();
          
      }

    });
      
  }

  cancelForm()
  {
    const dialogRef = this._fuseConfirmationService.open({
          "title": "Cancel",
          "message": 'Are you sure you want to navigate?',
          "icon": {
            "show": true,
            "name": "heroicons_outline:exclamation",
            "color": "warn"
          },
          "actions": {
          "confirm": {
              "show": true,
              "label": "Okay",
              "color": "primary"
              },
            "cancel": {
              "show": true,
              "label": "Cancel"
            }
          },
          "dismissible": false
    });

    dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(result => {
      if ( result == 'confirmed' )
      {
          
        this.router.navigateByUrl('/apps/task-manager/regular-ticket/regular-ticket-list');
          
      }

    });
  }
  ngOnDestroy(): void {
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }

}
