import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddRegularTicketComponent } from './add-regular-ticket.component';

describe('AddRegularTicketComponent', () => {
  let component: AddRegularTicketComponent;
  let fixture: ComponentFixture<AddRegularTicketComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddRegularTicketComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddRegularTicketComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
