import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RestApiService } from 'app/services/rest-api.service';
import { Subject, takeUntil } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import dayjs, { Dayjs } from 'dayjs/esm';
import { UserService } from 'app/core/user/user.service';
import { User } from 'app/core/user/user.types';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { TicketSelectViewComponent } from 'app/modal/ticket-select-view/ticket-select-view.component';
import { DocumentViewerComponent } from 'app/modal/document-viewer/document-viewer.component'; //09/09/2024

@Component({
  selector: 'app-to-do',
  templateUrl: './to-do.component.html',
  styleUrls: ['./to-do.component.scss'],
  animations: [
    // the fade-in/fade-out animation.
    trigger('simpleFadeAnimation', [

      // the "in" style determines the "resting" state of the element when it is visible.
      state('in', style({opacity: 1})),

      // fade in when created. this could also be written as transition('void => *')
      transition(':enter', [
        style({opacity: 0}),
        animate(600)
      ]),

      // fade out when destroyed. this could also be written as transition('void => *')
      transition(':leave',
        animate(400, style({opacity: 0})))
    ])
  ]
})
export class ToDoComponent implements OnInit,OnDestroy{

  private _unsubscribeAll: Subject<any> = new Subject<any>();
  isLoading:boolean = false;
  form: FormGroup; 
  user: User;
  allcompanies:any=[];//01/08/2024
  constructor( private restApiService:RestApiService,
    private _formBuilder:FormBuilder,  
    private cdr: ChangeDetectorRef,
    private _userService: UserService,
    private toastrService: ToastrService,
    private router: Router,
    private _matDialog: MatDialog,
    public dialogRef: MatDialogRef<ToDoComponent>,
    private _httpClient: HttpClient,
    @Inject(MAT_DIALOG_DATA) public data){}

    ngOnInit(): void {
      this._userService.user$
          .pipe((takeUntil(this._unsubscribeAll)))
          .subscribe((user: User) => {
              this.user = user;
            
      });
      

      this.form = this._formBuilder.group({
        supervisor:[this.user.id,Validators.required],
        company:[null],
        contact:[null],
        status:0,
        priority:0,
        group_id:null,//01/08/2024
        description:['',Validators.required],
        start_date:new Date(),
        main_id:this.data.mainId,
        parent_id:this.data.parent_id,
        files: this._formBuilder.array([]),
        type:['todo']
      });

      this.allcompanies = this.data.companies;//01/08/2024
      let companies = [];
      if(this.data.maintask && this.data.maintask.companies.length)
      {
        this.data.maintask.companies.forEach(element => {
          companies.push(element.id);
        });

        this.form.controls['company'].setValue(companies);
        this.onCompanyChange(this.data.maintask.companies);
      }
      if(this.data.maintask && this.data.maintask.group_id > 0)
      {
        this.form.controls['group_id'].setValue(this.data.maintask.group_id);
      }
      if(this.data.maintask && this.data.maintask.main_id != null)
      {
        this.form.controls['main_id'].setValue(this.data.maintask.main_id);
      }
    }

     //01/08/2024
     onGroupChange(event){
      if(event && event != null)
        {
          this.data.companies = this.allcompanies.filter(item => item.group_id == event.id);
        }
        else
        this.data.companies = this.allcompanies;
      
    }
    /*******File Section Code******/

    files: File[] = [];
    upload_files: File[] = [];
    isUploadLoad:boolean = false;

    onFileSelect(event) {

        this.isUploadLoad = true;

        this.upload_files = [];

        this.files.push(...event.addedFiles);
        this.upload_files.push(...event.addedFiles);

        const formData = new FormData();

        for (var i = 0; i < this.upload_files.length; i++) { 
            formData.append("files[]", this.upload_files[i]);
        }

        this.restApiService.tempFileUpload(`task`,formData).pipe(
            takeUntil(this._unsubscribeAll)
        ).subscribe( res => { 
            if(res.success)
            {
                if(res.data.length > 0)
                {
                    res.data.forEach(x => {
                        
                        this.file_items.push(
                            this._formBuilder.group({
                                    temp_id:x.id,
                                    file_path:x.file_path,
                                    file_name:x.file_name,
                                    file_size:x.file_size,
                                    file_extension:x.file_extension,
                                    file_description:[''],
                                    identifier:x.identifier,
                                    full_file_path:x.full_file_path,
                                    id:[''],
                            })    
                        );
                        
                        
                    })
                }
                this.isUploadLoad = false;

            }

            
        });
        

    }
    onFileRemove(index) {

        this.file_items.removeAt(index);
      

    }
    get file_items() {
      return this.form.get('files') as FormArray;
    }
    setFiles(files){
        (<FormArray>this.form.get('files')).clear();
        files.forEach(x => {
        
            this.file_items.push(
                this._formBuilder.group({
                        id:x.id,
                        file_path:x.file_path,
                        file_name:x.file_name,
                        file_size:x.file_size,
                        file_extension:x.file_extension,
                        file_description:x.file_description,
                        identifier:x.identifier,
                        temp_id:[''],
                })    
            );
        })
    }
    fileDownload(item){
      const salt = (new Date()).getTime();
      return this._httpClient.post(`filedownload?salt=${salt}`,item, {responseType:'blob'}).subscribe(res => {
          var FileSaver = require('file-saver');
          const blob = new Blob([res]);
          FileSaver.saveAs(blob, item.file_name);
          
          
      }, err => {
          console.log(err);
      });
    }

    //09/09/2024
    fileView(item){
      const dialogRef = this._matDialog.open(DocumentViewerComponent, {
          data: {
              file:item
          },
          width:'850px',
          height: '750px'
      });

      dialogRef.afterClosed().subscribe(result => {   
      },
      errRes=>{});
    }

  /*******File Section Code End******/
    contactLoading:boolean = false;
    contacts:any[]= [];
    tickets:any[]= [];
    onCompanyChange(event)
    {
      console.log('event',event);
      let company_id = [];
      if(event.length)
      {
        event.forEach(element => {
          company_id.push(element.id);
        });
      }
      this.contactLoading = true;
      this._httpClient.post<any>(`get_contacts_by_company?page_url=${this.router.url}`, {company_id:company_id}).pipe(
        takeUntil(this._unsubscribeAll)
        ).subscribe( res => {
          if(res.success)
          {
              
            if(res.data.length)
            {
              this.contacts = res.data;
            }
            this.contactLoading = false;
          }
              
      });

      if(!this.data.mainId && company_id.length)
        {
          
          this.contactLoading = true;
  
          this._httpClient.get<any>(`get_task_by_company/${company_id[0]}`).pipe(
            takeUntil(this._unsubscribeAll)
            ).subscribe( res => {
              if(res.success)
              {
                  
                if(res.data.length)
                {
                  this.tickets = res.data;
                }
                this.contactLoading = false;
              }
                  
          });
        }
                
    }

    showTicketsModal(ticktes){
    
      const dialogRef = this._matDialog.open(TicketSelectViewComponent, {
          data: {
            tickets:ticktes
          },
  
          width:'auto',
          height: 'auto'
      });
  
      dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(result => {
      
          if(result && result != null)
          {
            console.log('resul',result);
            this.form.controls['main_id'].setValue(result.id);
           
          }
         
        },
      errRes=>{});
      
    }
    
    isSubmitting:boolean = false; //23/09/2024
    onSubmit(data)
    {
      this.isSubmitting = true; //23/09/2024
      if(data.start_date != null)  
        data.start_date = dayjs(new Date(data.start_date)).format("YYYY-MM-DD HH:mm:ss");
     
      this.restApiService.store(`task`,data).pipe(takeUntil(this._unsubscribeAll)).subscribe(res =>{
        if(res.success)
         {
           this.dialogRef.close(res.data);
         }
         this.isSubmitting = false;  //23/09/2024
     });
    }
    cancelForm(){
      this.form.reset();
      this.dialogRef.close(null);
    }
  
    ngOnDestroy(): void {
      this._unsubscribeAll.next(null);
      this._unsubscribeAll.complete();
    }

}
