import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RestApiService } from 'app/services/rest-api.service';
import { Subject, takeUntil } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { FuseConfirmationService } from '@fuse/services/confirmation';
import { trigger, state, style, transition, animate } from '@angular/animations';

@Component({
  selector: 'app-show-activity-remarks',
  templateUrl: './show-activity-remarks.component.html',
  styleUrls: ['./show-activity-remarks.component.scss'],
  animations: [
    // the fade-in/fade-out animation.
    trigger('simpleFadeAnimation', [

      // the "in" style determines the "resting" state of the element when it is visible.
      state('in', style({opacity: 1})),

      // fade in when created. this could also be written as transition('void => *')
      transition(':enter', [
        style({opacity: 0}),
        animate(600)
      ]),

      // fade out when destroyed. this could also be written as transition('void => *')
      transition(':leave',
        animate(400, style({opacity: 0})))
    ])
  ]
})
export class ShowActivityRemarksComponent implements OnInit{
  private _unsubscribeAll: Subject<any> = new Subject<any>();
  
  content:any='';
  constructor( private _restApiService:RestApiService,
    public dialogRef: MatDialogRef<ShowActivityRemarksComponent>,
    @Inject(MAT_DIALOG_DATA) public data){}

    ngOnInit(): void {
      this.content=this.data.content;
    }
    closeModal(){
      this.dialogRef.close(null);
    }

    
}
