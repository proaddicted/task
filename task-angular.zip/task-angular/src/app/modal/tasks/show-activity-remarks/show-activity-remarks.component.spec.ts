import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowActivityRemarksComponent } from './show-activity-remarks.component';

describe('ShowActivityRemarksComponent', () => {
  let component: ShowActivityRemarksComponent;
  let fixture: ComponentFixture<ShowActivityRemarksComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowActivityRemarksComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShowActivityRemarksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
