import { Component, OnInit, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DateAdapter } from '@angular/material/core';
import { UserService } from 'app/core/user/user.service';
import { User } from 'app/core/user/user.types';
import { Subject, takeUntil } from 'rxjs';
import dayjs, { Dayjs } from 'dayjs/esm';
import { HttpClient } from '@angular/common/http';
import { RestApiService } from 'app/services/rest-api.service';
import { environment } from 'environments/environment';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { TicketSelectViewComponent } from 'app/modal/ticket-select-view/ticket-select-view.component';
import { FuseConfirmationService } from '@fuse/services/confirmation';
import { Router } from '@angular/router';
import { MatTable, MatTableDataSource } from '@angular/material/table';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';



@Component({
  selector: 'app-attendance',
  templateUrl: './attendance.component.html',
  styleUrls: ['./attendance.component.scss'],
  animations: [
    // the fade-in/fade-out animation.
    trigger('simpleFadeAnimation', [

      // the "in" style determines the "resting" state of the element when it is visible.
      state('in', style({opacity: 1})),

      // fade in when created. this could also be written as transition('void => *')
      transition(':enter', [
        style({opacity: 0}),
        animate(600)
      ]),

      // fade out when destroyed. this could also be written as transition('void => *')
      transition(':leave',
        animate(400, style({opacity: 0})))
    ])
  ]
})
export class AttendanceComponent implements OnInit {
  restApiURL : any = "daily_attendance_report"; 
  isLoading = false;
  user: any ;
  form: FormGroup; 
  date: any;
  employees:any[];
  services:any[];
  companies:any[];
  expense_types:any;
  hideReason: boolean = false;
  hideCompanyReason: boolean = false;
  tinyInit: any;
  env:any = environment;
  expenseShow:boolean = false;
  fileShow:boolean = false;
  return_id:any;
  action:string;
  attendanceTableColumns: string[] = ['employee', 'company', 'reason','description','status_name','time','given_expense','action'];
  attendanceDataSource: MatTableDataSource<any> = new MatTableDataSource();
  @ViewChild('attendancesMatTable') attendancesMatTable: MatTable<any >;


  public simpleSelected =  {
  }
  private _unsubscribeAll: Subject<any> = new Subject<any>();


  constructor(
    private _restApiService: RestApiService,
    private router: Router,
    private _userService: UserService,
    private _formBuilder: FormBuilder,
    private dateAdapter: DateAdapter<Date>,
    private _httpClient: HttpClient,
    private _matDialog: MatDialog,
    private _fuseConfirmationService: FuseConfirmationService,
    public dialogRef: MatDialogRef<AttendanceComponent>

  ){
    this.dateAdapter.setLocale('en-GB');
    this.tinyInit = this._restApiService.tinyInit();
  }

  ngOnInit(): void {
    this.expense_types = [];

    this._userService.user$
        .pipe((takeUntil(this._unsubscribeAll)))
        .subscribe((user: User) => {
            this.user = user;
           
    });

    this._httpClient.get<any>(`daily_attendance_report_getlist`).pipe(
      takeUntil(this._unsubscribeAll)
    ).subscribe(res=>{
      if(res.success)
      {
        console.log('res.success',res)
        this.employees = res.data.employees;
        this.companies = res.data.companies;
        this.services = res.data.services; 
        res.data.master_types.forEach(element => {
          if(element.identifier == 'expense')
            this.expense_types.push(element);
        });
         
      }
    })


    this.form = this._formBuilder.group({
      time : ['', Validators.required],
      description:['', Validators.required],
      company_id : [null],
      service_id : [null],
      task_id: [null],
      emp_id : [null, Validators.required],
      user_id: [null],
      link : [''],
      date:['', Validators.required],
      reason:[''],
      is_outside : [false],
      type:[null],
      latitude:null,
      longitude:null,
      expense: this._formBuilder.array([]),
      files: this._formBuilder.array([]),
      status : [2]
    });

    this.addExpense();
    this.form.controls['date'].setValue(dayjs(new Date()).format("YYYY-MM-DD"));
    this.date = new Date();
    this.form.controls['user_id'].setValue(this.user.id);

    if(this.user.type == 'employee' && this.user.employee_info != null)
      this.form.controls['emp_id'].setValue(this.user.employee_info.id);
  }

  getTotalTime(){
    
    let minutes = 0, hours = 0;

    // this.attendanceDataSource.data.forEach(x => { 
    //     let hour:any = 0,minute:any = 0;
    //     if(x.time != '')
    //     {
    //       [hour,minute] = x.time.split(":");
    //       minutes += parseInt(hour) * 60;
    //       minutes += parseInt(minute);
    //     }
    // })
    hours = Math.floor(minutes / 60);
    minutes -= hours * 60;
    return `${this.zeroPad(hours,2)}:${this.zeroPad(minutes,2)}`;
    // const result = this.attendanceDataSource.data.reduce( (acc, curr) => {
    //     let hour = 0,minute = 0;
    //     if(curr['time'] != '')
    //     {
    //       [hour,minute] = curr['time'].split(":");
    //       minutes += hour * 60;
    //       minutes += minute;
    //     }
      
    //   return acc;
    // }, {given_expense: 0});
    
    // hours = Math.floor(minutes / 60);
    // minutes -= hours * 60;
    // return result.given_expense;
  }
  zeroPad(num, places) {
    var zero = places - num.toString().length + 1;
    return Array(+(zero > 0 && zero)).join("0") + num;
  }
  /********Clone Expense Section Code*********/
  get expenses() {
    return this.form.get('expense') as FormArray;
  }
  setExpences(expenses)
  {
      
    this.form.get('expense').markAsUntouched();
    (this.form.controls['expense'] as FormArray).clear();
    let control = <FormArray>this.form.controls.expense;
    expenses.forEach(x => {
      
      control.push(this._formBuilder.group({expense_type_id:x.pivot.expense_type_id,given_cost:x.pivot.given_cost}));
    })
  }
  addExpense() {
    this.expenses.push(this._formBuilder.group({expense_type_id:[null],given_cost:['',Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")]}));

   
  }
  deleteExpense(index) {
    this.expenses.removeAt(index);
  }
  /*********End Of Clone Expense Section Code*************/

  /*******File Section Code******/

  files: File[] = [];
  upload_files: File[] = [];
  isUploadLoad:boolean = false;

  onFileSelect(event) {

    this.isUploadLoad = true;

    this.upload_files = [];

    this.files.push(...event.addedFiles);
    this.upload_files.push(...event.addedFiles);

    const formData = new FormData();

    for (var i = 0; i < this.upload_files.length; i++) { 
        formData.append("files[]", this.upload_files[i]);
    }

    console.log('files data',this.upload_files
    );

    this._restApiService.tempFileUpload(`attendance-report`,formData).pipe(
        takeUntil(this._unsubscribeAll)
    ).subscribe( res => { 
        if(res.success)
        {
            if(res.data.length > 0)
            {
                res.data.forEach(x => {
                    
                    this.file_items.push(
                        this._formBuilder.group({
                                temp_id:x.id,
                                file_path:x.file_path,
                                file_name:x.file_name,
                                file_size:x.file_size,
                                file_extension:x.file_extension,
                                file_description:[''],
                                identifier:x.identifier,
                                full_file_path:x.full_file_path,
                                id:[''],
                        })    
                    );
                     
                    
                })
            }
            this.isUploadLoad = false;

        }

        
    });
    

}
  onFileRemove(index) {

      this.file_items.removeAt(index);
    

  }
  get file_items() {
    return this.form.get('files') as FormArray;
  }
  setFiles(files){
      (<FormArray>this.form.get('files')).clear();
      files.forEach(x => {
      
          this.file_items.push(
              this._formBuilder.group({
                      id:x.id,
                      file_path:x.file_path,
                      file_name:x.file_name,
                      file_size:x.file_size,
                      file_extension:x.file_extension,
                      file_description:x.file_description,
                      identifier:x.identifier,
                      temp_id:[''],
              })    
          );
      })
  }
  fileDownload(item){
    const salt = (new Date()).getTime();
    return this._httpClient.post(`filedownload?salt=${salt}`,item, {responseType:'blob'}).subscribe(res => {
        var FileSaver = require('file-saver');
        const blob = new Blob([res]);
        FileSaver.saveAs(blob, item.file_name);
        
        
    }, err => {
        console.log(err);
    });
  }
  /*******File Section Code End******/

  showTicketsModal(ticktes){
    
    const dialogRef = this._matDialog.open(TicketSelectViewComponent, {
        data: {
          tickets:ticktes
        },

        width:'auto',
        height: 'auto'
    });

    dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(result => {
    
        if(result && result != null)
        {
          console.log('resul',result);
          this.form.controls['task_id'].setValue(result.id);
         
        }
       
      },
    errRes=>{});
    
  }

  loadAttendanceData(date = new Date(), emp_id = this.user?.employee_info?.id ){
    let getlist_url = `${this.restApiURL}_getlist?date=${dayjs(date).format("YYYY-MM-DD")}&emp_id=${emp_id}`
   
    this._restApiService.getlistParam(getlist_url).pipe(
      takeUntil(this._unsubscribeAll)
    ).subscribe( res => {
        if(res.success)
        {

          if(res.data.daily_attendance_reports.length)
          {
            
            this.attendanceDataSource.data = res.data.daily_attendance_reports;
          }
          else
          {
            this.attendanceDataSource.data = [];
          }

          
          this.isLoading = false;
        }
            
    });
  }
  
  changeDate(event: MatDatepickerInputEvent<Date>) {
    
    this.form.controls['date'].setValue(dayjs(event.value).format("YYYY-MM-DD"));
    this.loadAttendanceData(event.value);
    this.date = event.value;
  }

  onEmployeeChange(event)
  {
    if(event != null)
    {
      this.form.controls['user_id'].setValue(event.user_id);
      this.loadAttendanceData(this.date,event.id);
    }
      
  }

  tasks:[] = [];
  onCompanyChange(event)
  {
    if(event != null)
    {
      this.hideReason = true;

      this._httpClient.get<any>(`get_task_by_company/${event.id}`).pipe(
        takeUntil(this._unsubscribeAll)
      ).subscribe(res=>{
        if(res.success)
        {
          this.tasks = res.data;
           
        }
      })
    }
    else
    {
      this.hideReason = false;
    }
  }

  clearService(){
    this.simpleSelected = {};
    this.form.controls.service_id.setValue(null);
  }
  onSelectionChange(event){
   
    if(event != null)
      this.form.controls.service_id.setValue(event.id);
  }
  hideCompany(event)
  {
    if(event.target.value != '')
    {
      this.hideCompanyReason = true;
    }
    else
    {
      this.hideCompanyReason = false;
    }
  }

  isSubmitting:boolean = false;

  onSubmit(data:any,event:any){
    this.isSubmitting = true;
    
    this._restApiService.store(this.restApiURL,data).pipe(
      takeUntil(this._unsubscribeAll)
    ).subscribe( res => { 
      console.log("Submit Success: " + res);
      if(res.success)
      {
          if( event == 'save')
          {
          (this.form.controls['expense'] as FormArray).clear();
          (this.form.controls['files'] as FormArray).clear();
          

          this.form.patchValue({
            time : res.data.time,
            description: res.data.description,
            company_id : res.data.company_id,
            service_id : res.data.service_id,
            task_id: res.data.task_id,
            emp_id : res.data.emp_id,
            link : res.data.link,
            date: dayjs(res.data.date).format("YYYY-MM-DD"),
            reason: res.data.reason,
            is_outside : res.data.is_outside,
            
          })

          if(res.data.service != null)
            this.simpleSelected = res.data.service;

          if(res.data.expenses.length)
            this.setExpences(res.data.expenses);
          else
            this.addExpense();

          if(res.data.files.length > 0) 
            this.setFiles(res.data.files);  
            
          this.loadAttendanceData();  

          
          }
          
          
          this.isSubmitting = false;   
            
      }

      this.dialogRef.close(res.data);  

  });
  }


  cancelForm(){
    this.form.reset();
    this.dialogRef.close(null);
  }
  ngOnDestroy(): void {
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }
}
