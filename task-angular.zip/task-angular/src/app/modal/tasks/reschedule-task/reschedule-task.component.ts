import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RestApiService } from 'app/services/rest-api.service';
import { Subject, takeUntil } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import dayjs, { Dayjs } from 'dayjs/esm';
import { UserService } from 'app/core/user/user.service';
import { User } from 'app/core/user/user.types';

@Component({
  selector: 'app-reschedule-task',
  templateUrl: './reschedule-task.component.html',
  styleUrls: ['./reschedule-task.component.scss']
})
export class RescheduleTaskComponent implements OnInit,OnDestroy{
  private _unsubscribeAll: Subject<any> = new Subject<any>();

  isLoading:boolean = false;
  form: FormGroup; 
  user: User;
  task:any;

  constructor( private restApiService:RestApiService,
    private _formBuilder:FormBuilder,  
    private cdr: ChangeDetectorRef,
    private _userService: UserService,
    private toastrService: ToastrService,
    public dialogRef: MatDialogRef<RescheduleTaskComponent>,
    @Inject(MAT_DIALOG_DATA) public data){}


    ngOnInit(): void {


      this._userService.user$
          .pipe((takeUntil(this._unsubscribeAll)))
          .subscribe((user: User) => {
              this.user = user;
            
      });
      this.isLoading = true;
      this.restApiService.show(`task_view`,this.data.item.id).pipe(takeUntil(this._unsubscribeAll)).subscribe(res =>{
        if(res.success)
         {
          this.task = res.data;
          this.isLoading = false;
         }
     });

      this.form = this._formBuilder.group({
      
        description:['',Validators.required],
        start_date:new Date(),
        status:3
       
      });
    }

    isSubmitting:boolean = false; //23/09/2024
    onSubmit(data)
    {
      if(data.start_date != null)  
        data.start_date = dayjs(new Date(data.start_date)).format("YYYY-MM-DD HH:mm:ss");
      this.isSubmitting = true; //23/09/2024
      this.restApiService.update(`reschedule_task/${this.data.item.id}`,data).pipe(takeUntil(this._unsubscribeAll)).subscribe(res =>{
        if(res.success)
         {
           this.dialogRef.close(res.data);
         }
         this.isSubmitting = false;  //23/09/2024
     });
    }

    cancelForm(){
      this.form.reset();
      this.dialogRef.close(null);
    }
  
    ngOnDestroy(): void {
      this._unsubscribeAll.next(null);
      this._unsubscribeAll.complete();
    }
}
