import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RescheduleTaskComponent } from './reschedule-task.component';

describe('RescheduleTaskComponent', () => {
  let component: RescheduleTaskComponent;
  let fixture: ComponentFixture<RescheduleTaskComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RescheduleTaskComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RescheduleTaskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
