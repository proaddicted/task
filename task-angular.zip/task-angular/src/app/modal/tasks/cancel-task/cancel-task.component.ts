import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RestApiService } from 'app/services/rest-api.service';
import { Subject, takeUntil } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import dayjs, { Dayjs } from 'dayjs/esm';
import { UserService } from 'app/core/user/user.service';
import { User } from 'app/core/user/user.types';

@Component({
  selector: 'app-cancel-task',
  templateUrl: './cancel-task.component.html',
  styleUrls: ['./cancel-task.component.scss']
})
export class CancelTaskComponent implements OnInit,OnDestroy{

  private _unsubscribeAll: Subject<any> = new Subject<any>();

  isLoading:boolean = false;
  form: FormGroup; 
  user: User;
  task:any;

  constructor( private restApiService:RestApiService,
    private _formBuilder:FormBuilder,  
    private cdr: ChangeDetectorRef,
    private _userService: UserService,
    private toastrService: ToastrService,
    public dialogRef: MatDialogRef<CancelTaskComponent>,
    @Inject(MAT_DIALOG_DATA) public data){}


    ngOnInit(): void {


      this._userService.user$
          .pipe((takeUntil(this._unsubscribeAll)))
          .subscribe((user: User) => {
              this.user = user;
            
      });
      this.isLoading = true;
      this.restApiService.show(`task_view`,this.data.item.id).pipe(takeUntil(this._unsubscribeAll)).subscribe(res =>{
        if(res.success)
         {
          this.task = res.data;
          this.isLoading = false;
         }
     });

      this.form = this._formBuilder.group({
      
        remarks:['',Validators.required],
        completed_date:new Date(),
        status:1
       
      });
    }

    onSubmit(data)
    {
      if(data.completed_date != null)  
        data.completed_date = dayjs(new Date(data.completed_date)).format("YYYY-MM-DD HH:mm:ss");
     
      this.restApiService.update(`task/${this.data.item.id}`,data).pipe(takeUntil(this._unsubscribeAll)).subscribe(res =>{
        if(res.success)
         {
           this.dialogRef.close(res.data);
         }
     });
    }

    cancelForm(){
      this.form.reset();
      this.dialogRef.close(null);
    }
  
    ngOnDestroy(): void {
      this._unsubscribeAll.next(null);
      this._unsubscribeAll.complete();
    }
}
