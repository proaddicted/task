import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuickSubGroupAddComponent } from './quick-sub-group-add.component';

describe('QuickSubGroupAddComponent', () => {
  let component: QuickSubGroupAddComponent;
  let fixture: ComponentFixture<QuickSubGroupAddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QuickSubGroupAddComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(QuickSubGroupAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
