import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { RestApiService } from 'app/services/rest-api.service';
import { Subject, takeUntil } from 'rxjs';
import { ChatService } from 'app/modules/apps/chat/chat.service';
import { SelectionModel } from '@angular/cdk/collections';
@Component({
  selector: 'app-chat-forward',
  templateUrl: './chat-forward.component.html',
  styleUrls: ['./chat-forward.component.scss']
})
export class ChatForwardComponent implements OnDestroy,OnInit{
    private _unsubscribeAll: Subject<any> = new Subject<any>();
    isLoading:boolean = false;
    form: FormGroup; 

    chatgroups: any[];
    filteredChatGroups: any[];

    constructor(
      private restApiService:RestApiService,
      private _formBuilder:FormBuilder,  
      private cdr: ChangeDetectorRef,
      private _chatService: ChatService,
      public dialogRef: MatDialogRef<ChatForwardComponent>,
      @Inject(MAT_DIALOG_DATA,) public data
    ){

    }
    ngOnInit(): void {
        this.form = this._formBuilder.group({
          parent_id: this.data.item.id,
          parent_type: 2,
          comment : [''],
          group_id:null,
          
        });

        this._chatService.chatgroups$
        .pipe(takeUntil(this._unsubscribeAll))
        .subscribe((chatgroups: any[]) => {
            this.chatgroups = this.filteredChatGroups = chatgroups;

            console.log('this.filteredChatGroups',this.filteredChatGroups);

        });

    }

   
     /**
     * Filter the chats
     *
     * @param query
     */
     filterChatGroups(query: string): void
     {
         // Reset the filter
         if ( !query )
         {
             this.filteredChatGroups = this.chatgroups;
             return;
         }
 
         this.filteredChatGroups = this.chatgroups.filter(chatgroup => chatgroup.display_name.toLowerCase().includes(query.toLowerCase()));


     }
 
    isSubmitting:boolean = false; //23/09/2024
    onSubmit(data){
      this.isSubmitting = true; //23/09/2024
      let mutli_ids = [];

      this.selection.selected.forEach((element: any, key: number) => {
          mutli_ids.push(element.id);
      });

      data.group_id = mutli_ids;

      console.log('firm data',data);
      this.restApiService.store(`forward_chat`,data).pipe(
          takeUntil(this._unsubscribeAll)
        ).subscribe( res => { 
            if(res.success)
            {
                this.form.reset();
                this.dialogRef.close(res.data);   
            }  
            this.isSubmitting = false; //23/09/2024

      });
    }
    cancelForm(){
      this.form.reset();
      this.dialogRef.close(null);
    }
    selection = new SelectionModel<any>(true, []);
    isAllSelected() {
      if(this.filteredChatGroups)
      {
        const numSelected = this.selection.selected.length;
        const numRows = this.filteredChatGroups.length;
        return numSelected === numRows;
      }
        
    }

    
    masterToggle() {
        this.isAllSelected() ?
            this.selection.clear() :
            this.filteredChatGroups.forEach(row => this.selection.select(row));
    }
    
    checkboxLabel(row?: any): string {
        if (!row) {
            return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
        }
    
    }
    ngOnDestroy(): void {
      this._unsubscribeAll.next(null);
      this._unsubscribeAll.complete();
    }
}
