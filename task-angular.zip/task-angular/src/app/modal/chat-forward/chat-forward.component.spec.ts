import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChatForwardComponent } from './chat-forward.component';

describe('ChatForwardComponent', () => {
  let component: ChatForwardComponent;
  let fixture: ComponentFixture<ChatForwardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChatForwardComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ChatForwardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
