import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuickGroupAddComponent } from './quick-group-add.component';

describe('QuickGroupAddComponent', () => {
  let component: QuickGroupAddComponent;
  let fixture: ComponentFixture<QuickGroupAddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QuickGroupAddComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(QuickGroupAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
