import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RestApiService } from 'app/services/rest-api.service';
import { Subject, takeUntil } from 'rxjs';

@Component({
  selector: 'app-quick-group-add',
  templateUrl: './quick-group-add.component.html',
  styleUrls: ['./quick-group-add.component.scss']
})
export class QuickGroupAddComponent implements OnDestroy,OnInit {
    private _unsubscribeAll: Subject<any> = new Subject<any>();
    isLoading:boolean = false;
    form: FormGroup; 

  
    constructor(
      private restApiService:RestApiService,
      private _formBuilder:FormBuilder,  
      private cdr: ChangeDetectorRef,
      public dialogRef: MatDialogRef<QuickGroupAddComponent>,
      @Inject(MAT_DIALOG_DATA,) public data
    ) {
    }
    ngOnInit(): void {
        this.form = this._formBuilder.group({
          name:['',Validators.required],
          emp_id:null,
          status:[true]
        });
    }

    isSubmitting:boolean = false; //23/09/2024
    onSubmit(formData){
      this.isSubmitting = true; //23/09/2024
      this.restApiService.store(`group`,formData).pipe(
          takeUntil(this._unsubscribeAll)
        ).subscribe( res => { 
            if(res.success)
            {
              this.form.reset();
              this.dialogRef.close(res.data);  
            }  
            this.isSubmitting = false; //23/09/2024  
      });
    }
    cancelForm(){
      this.form.reset();
      this.dialogRef.close(null);
    }

    ngOnDestroy(): void {
      this._unsubscribeAll.next(null);
      this._unsubscribeAll.complete();
    }

}
