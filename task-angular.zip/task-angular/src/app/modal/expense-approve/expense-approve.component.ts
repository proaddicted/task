import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RestApiService } from 'app/services/rest-api.service';
import { Subject, takeUntil } from 'rxjs';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-expense-approve',
  templateUrl: './expense-approve.component.html',
  styleUrls: ['./expense-approve.component.scss']
})
export class ExpenseApproveComponent  implements OnDestroy,OnInit {
  private _unsubscribeAll: Subject<any> = new Subject<any>();
  isLoading:boolean = false;
  form: FormGroup; 
  constructor(
    private _restApiService:RestApiService,
    private _formBuilder:FormBuilder,  
    private cdr: ChangeDetectorRef,
  
    public dialogRef: MatDialogRef<ExpenseApproveComponent>,
    public toastrService: ToastrService,
    @Inject(MAT_DIALOG_DATA) public data
  ) {
 
  }
  ngOnInit(): void {
    this.form = this._formBuilder.group({
        column_value: this.data.column_value,
        remarks:null,
        column_name:this.data.column_name,
        expense: this._formBuilder.array([]),
    });

    if(this.data.item.expenses.length)
      this.setExpences(this.data.item.expenses);
  }

  isSubmitting:boolean = false; //23/09/2024
  onSubmit(data){
    this.isSubmitting = true; //23/09/2024
    console.log('data >>',data);
    this._restApiService.update(`daily_attendance_report_change_log/${this.data.item.id}`,data).pipe(
      takeUntil(this._unsubscribeAll)
    ).subscribe( res => { 
          if(res.success)
          {
            this.form.reset();
            this.dialogRef.close(res.data);
          }
          this.isSubmitting = false; //23/09/2024 

    });
  }

  onAmountChange(index:number,event)
  {
    
    const faControl2 = (<FormArray>this.form.controls['expense']).at(index);
  
   

    if(event.target.value > faControl2['controls'].given_cost.value)
    {
      this.toastrService.error("Approved Amount Mismatch" ,"Approved Amount Can't Be Greater Than Requested Amount");
      faControl2['controls'].approved_cost.setValue(faControl2['controls'].given_cost.value);
    }

    let total_given_amount:any = 0 , total_approved_amount:any = 0;

    this.expenses.controls.forEach((element: any, key: number) => {
      total_given_amount += element.value.given_cost;
      total_approved_amount += element.value.approved_cost;
    });
    
    if(this.form.controls['column_value'].value == 3)
    {
      if(total_given_amount == total_approved_amount)
      {
        this.form.controls['column_value'].setValue("2");
      }
    }
    else if(this.form.controls['column_value'].value == 2)
    {
      if(total_given_amount != total_approved_amount)
      {
        console.log('here');

        this.form.controls['column_value'].setValue("3");
      }
    }
      
    
  }

  get expenses() {
    return this.form.get('expense') as FormArray;
  }
  setExpences(expenses)
  {
      
    this.form.get('expense').markAsUntouched();
    (this.form.controls['expense'] as FormArray).clear();
    let control = <FormArray>this.form.controls.expense;
    expenses.forEach(x => {
      
      if(this.data.column_value == 2)
        control.push(this._formBuilder.group({expense_type_id:x.pivot.expense_type_id,given_cost:[x.pivot.given_cost,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],approved_cost:[x.pivot.given_cost,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")]}));
      else
        control.push(this._formBuilder.group({expense_type_id:x.pivot.expense_type_id,given_cost:[x.pivot.given_cost,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],approved_cost:['',Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")]}));

    })
  }
  cancelForm(){
    this.form.reset();
    this.dialogRef.close(null);
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }
}
