import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StatusRemarksComponent } from './status-remarks.component';

describe('StatusRemarksComponent', () => {
  let component: StatusRemarksComponent;
  let fixture: ComponentFixture<StatusRemarksComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StatusRemarksComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StatusRemarksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
