import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RestApiService } from 'app/services/rest-api.service';
import { Subject, takeUntil } from 'rxjs';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-status-remarks',
  templateUrl: './status-remarks.component.html',
  styleUrls: ['./status-remarks.component.scss']
})
export class StatusRemarksComponent implements OnInit,OnDestroy{
  private _unsubscribeAll: Subject<any> = new Subject<any>();
  isLoading:boolean = false;
  form: FormGroup; 
  late_in_reasons:any[];
  coords:any;
  title:any = '';


  constructor( private restApiService:RestApiService,
    private _formBuilder:FormBuilder,  
    private cdr: ChangeDetectorRef,
    private toastrService: ToastrService,
    public dialogRef: MatDialogRef<StatusRemarksComponent>,
    @Inject(MAT_DIALOG_DATA) public data){}

  ngOnInit(): void {
   
    this.title = this.data.column_name
    .split("_")
    .filter(x => x.length > 0)
    .map((x) => (x.charAt(0).toUpperCase() + x.slice(1)))
    .join(" ");

    this.form = this._formBuilder.group({
      remarks:['',Validators.required],
      column_name:[this.data.column_name],
      column_value:[this.data.column_value]
    });
  }

  onSubmit(data){
    this.isLoading = true;
    this.restApiService.store(`${this.data.url}/${this.data.id}`,data).pipe(takeUntil(this._unsubscribeAll)).subscribe(res =>{
       if(res.success)
        {
          this.isLoading = false;
          this.dialogRef.close(res.data);
        }
    });
  }
  cancelForm(){
    this.form.reset();
    this.dialogRef.close(null);
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }
}
