import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { AbstractControl, FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { RestApiService } from 'app/services/rest-api.service';
import { Subject, merge, takeUntil } from 'rxjs';
import { UserService } from 'app/core/user/user.service';
import { User } from 'app/core/user/user.types';
import { HttpClient } from '@angular/common/http';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import dayjs, { Dayjs } from 'dayjs/esm';
import { TaskTagComponent } from '../task-tag/task-tag.component';

@Component({
  selector: 'app-compose-mail',
  templateUrl: './compose-mail.component.html',
  styleUrls: ['./compose-mail.component.scss'],
  animations: [
    // the fade-in/fade-out animation.
    trigger('simpleFadeAnimation', [

      // the "in" style determines the "resting" state of the element when it is visible.
      state('in', style({opacity: 1})),

      // fade in when created. this could also be written as transition('void => *')
      transition(':enter', [
        style({opacity: 0}),
        animate(600)
      ]),

      // fade out when destroyed. this could also be written as transition('void => *')
      transition(':leave',
        animate(400, style({opacity: 0})))
    ])
  ]
})
export class ComposeMailComponent  implements OnDestroy,OnInit  {
    [x: string]: any;

  private _unsubscribeAll: Subject<any> = new Subject<any>();
  isLoading:boolean = false;
  form: FormGroup; 
  isFileShow:boolean = false;
  isScheduleShow:boolean = false;
  ccShow:boolean = false;
  bccShow:boolean = false;
  user:User;
  showTask:boolean = false;//24/07/24
  all_tickets:any=[];
  allcompanies:any=[];
  tickets:any=[];
  quillModules: any = {
      toolbar: [
          ['bold', 'italic', 'underline', 'strike'],
          [{align: []}, {list: 'ordered'}, {list: 'bullet'}],
          [{ 'size': ['small', false, 'large', 'huge'] }],  // custom dropdown
          [{ 'color': [] }, { 'background': [] }],  
          [{ 'font': [] }],
          [{ 'align': [] }],
          ['clean']
      ]
  };
  
  to_users:any[];
  cc_users:any[];
  bcc_users:any[];

  constructor(
    private _restApiService:RestApiService,
    private _formBuilder:FormBuilder,  
    private cdr: ChangeDetectorRef,
    private _userService:UserService,
    private _httpClient:HttpClient,
    private _matDialog: MatDialog,
    public dialogRef: MatDialogRef<ComposeMailComponent>,
    @Inject(MAT_DIALOG_DATA,) public data
  ) {
   }
    ngOnInit(): void {

        this.to_users = this.data.users;
        this.cc_users = this.data.users;
        this.bcc_users = this.data.users;
        this.allcompanies = this.data.companies;

        console.log('this.data.companies',this.data.companies);
        console.log('this.data.groups',this.data.groups);

        this._userService.user$
          .pipe((takeUntil(this._unsubscribeAll)))
          .subscribe((user: User) => {
              this.user = user;
            
        });
        this.form = this._formBuilder.group({
          to:[null,Validators.required],
          cc:null,
          bcc:null,
          company:null,
          group_id:null,


          from_id:[this.user.id,Validators.required],
          main_id:null,
        //   task_id:null,//29/07/2024
          identifier:this.data.identifier,
          subject:['',Validators.required],
          comment:['',Validators.required],
          communication_type:'mail',
          files: this._formBuilder.array([]),
          recursive_type:null,
          recursive_days:['',Validators.pattern("^[0-9]*$")],
          recursive_end_date:[],
          recursive_weeks:null,
          custom_date:this._formBuilder.array([]),
          
        });

        this.getAllTask();//19/09/2024
    
        this.form.get('to').valueChanges
            .subscribe(value => {

                if(value != null)
                {
                    let update_cc_users = [];
                    this.cc_users.forEach(element => {
                        if( !value.includes(element.id))
                            update_cc_users.push(element);
                    });
    
                    this.cc_users = update_cc_users;
                    this.bcc_users = update_cc_users;
                }
              
                this.cdr.detectChanges();
            }
        );
        this.form.get('cc').valueChanges
            .subscribe(value => {

                if(value != null)
                {
                    let update_bcc_users = [];
                    this.bcc_users.forEach(element => {
                        if( !value.includes(element.id))
                        update_bcc_users.push(element);
                    });

                    this.bcc_users = update_bcc_users;
                }
                
                this.cdr.detectChanges();
            }
        );

        this.form.get('recursive_type').valueChanges
        .subscribe(value => {

            if(value > 0 && value == 7)
            {
                this.addDate();
            }
          
            this.cdr.detectChanges();
            
        });
    }

    // task_data:any=[];
    //19/09/2024
    getAllTask(){
         /********for all task fetch 29/07/2024*********** */
        
        this._httpClient.get(`get_all_tasks`).subscribe(res => {
            this.all_tickets= this.tickets =res;
            console.log('this.all_ticket>3>>>',this.all_tickets);
        }, err => {
            console.log(err);
        });
        // return  this.task_data
        /***********END********* */
    }

    onGroupChange(event){
        console.log('selected group',event)
        console.log('allcompanies',this.allcompanies)

        if(event && event != null)
          {
            console.log('enter')
            this.data.companies = this.allcompanies.filter(item => item.group_id == event.id);
          }
          else
          this.data.companies = this.allcompanies;

          console.log('data.companies',this.data.companies)

      }

      onCompanyChange(event){
        console.log('this.all_tickets>>>>',this.all_tickets);
        console.log('this.tickets>>>>',this.tickets);

        console.log('selected company>>>>',event);
        let x=[];
        if(event && event != null && event!=undefined)
          {
            this.tickets.data.forEach((element: any, key: number) => {
               if(element.companies.length>0 && element.companies[0].id == event.id)
               {
                    console.log('element>>>',element);
                    x.push(element);
               }
            });
            this.all_tickets.data=x
            // console.log('this.all_ticket>2>>>',this.all_tickets);
          }
          else  
           this.getAllTask();
          console.log('this.all_ticket>2>>>',this.all_tickets);
      }

    //29/07/2024 \modal\compose-mail\
    toogleTask(){
        this.showTask=this.showTask?false:true;
        console.log('bhowsdike',this.showTask);
    }

    //30/07/2024
    showTaskModal(all_tickets)
    {
        console.log('all_tickets>>>>><<<<<',all_tickets);
        const dialogRef = this._matDialog.open(TaskTagComponent, {
            data: {
                data:all_tickets
            },
            width:'1500px',
            height: '1000px'
        });
        dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(result => {
          console.log('bichi>>>',result);
          this.form.patchValue({
            main_id:result.id
          })
        },
        errRes=>{});
    }

    get custom_dates() {
        return this.form.get('custom_date') as FormArray;
    }
    addDate() {
        this.custom_dates.push(this._formBuilder.group({date:null}));
    }
    deleteDate(index) {
        this.custom_dates.removeAt(index);
    }
    changeDate(event: MatDatepickerInputEvent<Date>) {
        this.form.controls['recursive_end_date'].setValue(dayjs(event.value).format("YYYY-MM-DD"));
    }

    isSubmitting:boolean = false; //23/09/2024
    onSubmit(formData){
        this.isSubmitting = true; //23/09/2024
        this._restApiService.store(`communication`,formData).pipe(
            takeUntil(this._unsubscribeAll)
          ).subscribe( res => { 
             
              if(res.success)
              {
                  this.form.reset();
                  this.to_users = this.data.users;
                  this.cc_users = this.data.users;
                  this.bcc_users = this.data.users;
                  this.dialogRef.close(res.data);
                  
                  
              }  
              this.isSubmitting = false; //23/09/2024

        });
    }
    
    cancelForm(){
      this.form.reset();
      this.dialogRef.close(null);
    }

    
    dropdownLoading:boolean = false;
    addUserPromise = (email) =>{
        return new Promise((resolve,reject) => {
            this.dropdownLoading = true;
            // Simulate backend call.
            this._restApiService.store(`add_user`,{email:email}).pipe(
                takeUntil(this._unsubscribeAll)
              ).subscribe( res => { 
                  
                  if(res.success)
                  {
                    resolve(res.data);
                    
                  }  
                  else
                  {
                    reject(null);
                  }
                
                  this.dropdownLoading = false;

            });
            // setTimeout(() => {
            //     reject(null);
            //    //resolve({ id: 999, name_email: name_email, valid: true });
            //     this.dropdownLoading = false;
            // }, 1000);
        })
    }

    ccdropdownLoading:boolean = false;
    addCCPromise = (email) =>{
        return new Promise((resolve,reject) => {
            this.ccdropdownLoading = true;
            // Simulate backend call.
            this._restApiService.store(`add_user`,{email:email}).pipe(
                takeUntil(this._unsubscribeAll)
              ).subscribe( res => { 
                  
                  if(res.success)
                  {
                    resolve(res.data);
                    
                  }  
                  else
                  {
                    reject(null);
                  }
                
                  this.ccdropdownLoading = false;

            });
           
        })
    }

    bccdropdownLoading:boolean = false;
    addBCCPromise = (email) =>{
        return new Promise((resolve,reject) => {
            this.bccdropdownLoading = true;
            // Simulate backend call.
            this._restApiService.store(`add_user`,{email:email}).pipe(
                takeUntil(this._unsubscribeAll)
              ).subscribe( res => { 
                  
                  if(res.success)
                  {
                    resolve(res.data);
                    
                  }  
                  else
                  {
                    reject(null);
                  }
                
                  this.bccdropdownLoading = false;

            });
           
        })
    }
    /*******File Section Code******/

    files: File[] = [];
    upload_files: File[] = [];
    isUploadLoad:boolean = false;

    onFileSelect(event) {

        this.isUploadLoad = true;

        this.upload_files = [];

        this.files.push(...event.addedFiles);
        this.upload_files.push(...event.addedFiles);

        const formData = new FormData();

        for (var i = 0; i < this.upload_files.length; i++) { 
            formData.append("files[]", this.upload_files[i]);
        }

        console.log('files data',this.upload_files
        );

        this._restApiService.tempFileUpload(`communication`,formData).pipe(
            takeUntil(this._unsubscribeAll)
        ).subscribe( res => { 
            if(res.success)
            {
                if(res.data.length > 0)
                {
                    res.data.forEach(x => {
                        
                        this.file_items.push(
                            this._formBuilder.group({
                                    temp_id:x.id,
                                    file_path:x.file_path,
                                    file_name:x.file_name,
                                    file_size:x.file_size,
                                    file_extension:x.file_extension,
                                    file_description:[''],
                                    identifier:x.identifier,
                                    id:[''],
                            })    
                        );
                        
                        
                    });

                    
                }
                this.isUploadLoad = false;

            }

            
        });
        

    }
    onFileRemove(index) {

        this.file_items.removeAt(index);
        

    }
    get file_items() {
        return this.form.get('files') as FormArray;
    }
    setFiles(files){
        (<FormArray>this.form.get('files')).clear();
        files.forEach(x => {
        
            this.file_items.push(
                this._formBuilder.group({
                        id:x.id,
                        file_path:x.file_path,
                        file_name:x.file_name,
                        file_size:x.file_size,
                        file_extension:x.file_extension,
                        file_description:x.file_description,
                        identifier:x.identifier,
                        temp_id:[''],
                })    
            );
        })
    }
    fileDownload(item){
        const salt = (new Date()).getTime();
        return this._httpClient.post(`filedownload?salt=${salt}`,item, {responseType:'blob'}).subscribe(res => {
            var FileSaver = require('file-saver');
            const blob = new Blob([res]);
            FileSaver.saveAs(blob, item.file_name);
            
            
        }, err => {
            console.log(err);
        });
    }

    ngOnDestroy(): void {
      this._unsubscribeAll.next(null);
      this._unsubscribeAll.complete();
    }

}


