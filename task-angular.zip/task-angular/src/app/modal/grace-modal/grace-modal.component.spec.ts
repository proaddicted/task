import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GraceModalComponent } from './grace-modal.component';

describe('GraceModalComponent', () => {
  let component: GraceModalComponent;
  let fixture: ComponentFixture<GraceModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GraceModalComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GraceModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
