import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RestApiService } from 'app/services/rest-api.service';
import { Subject, takeUntil } from 'rxjs';
import { User } from 'app/core/user/user.types';
import { UserService } from 'app/core/user/user.service';
import {GeolocationService} from '@ng-web-apis/geolocation';
import { ToastrService } from 'ngx-toastr';
import { HttpClient } from '@angular/common/http';
import { trigger, state, style, transition, animate } from '@angular/animations';

@Component({
  selector: 'app-grace-modal',
  templateUrl: './grace-modal.component.html',
  styleUrls: ['./grace-modal.component.scss'],
  animations: [
    // the fade-in/fade-out animation.
    trigger('simpleFadeAnimation', [

      // the "in" style determines the "resting" state of the element when it is visible.
      state('in', style({opacity: 1})),

      // fade in when created. this could also be written as transition('void => *')
      transition(':enter', [
        style({opacity: 0}),
        animate(600)
      ]),

      // fade out when destroyed. this could also be written as transition('void => *')
      transition(':leave',
        animate(400, style({opacity: 0})))
    ])
  ]
})
export class GraceModalComponent implements OnInit,OnDestroy{

  private _unsubscribeAll: Subject<any> = new Subject<any>();
  isLoading:boolean = false;
  form: FormGroup; 
  late_in_reasons:any[];
  coords:any;
  fileShow:boolean = false;

  constructor( private restApiService:RestApiService,
    private _formBuilder:FormBuilder,  
    private _userService: UserService,
    private cdr: ChangeDetectorRef,
    private _httpClient:HttpClient,
    private toastrService: ToastrService,
    private readonly geolocation$: GeolocationService,
    public dialogRef: MatDialogRef<GraceModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data){}
  
  ngOnInit(): void {
    this._userService.user$.subscribe((user: User)=>{
      this.late_in_reasons = user.late_in_reasons;
    });
    this.geolocation$.subscribe(position =>{
          this.coords = position;
    });

    this.form = this._formBuilder.group({
      reason_id:null,
      remarks:['',Validators.required],
      files: this._formBuilder.array([]),
      
    });
  }

  /*******Attendance File Section Code******/

  files: File[] = [];
  upload_files: File[] = [];
  isUploadLoad:boolean = false;

  onFileSelect(event) {

    this.isUploadLoad = true;

    this.upload_files = [];

    this.files.push(...event.addedFiles);
    this.upload_files.push(...event.addedFiles);

    const formData = new FormData();

    for (var i = 0; i < this.upload_files.length; i++) { 
        formData.append("files[]", this.upload_files[i]);
    }

    console.log('files data',this.upload_files
    );

    this.restApiService.tempFileUpload(`daily-attendance`,formData).pipe(
        takeUntil(this._unsubscribeAll)
    ).subscribe( res => { 
        if(res.success)
        {
            if(res.data.length > 0)
            {
                res.data.forEach(x => {
                    
                    this.file_items.push(
                        this._formBuilder.group({
                                temp_id:x.id,
                                file_path:x.file_path,
                                file_name:x.file_name,
                                file_size:x.file_size,
                                file_extension:x.file_extension,
                                file_description:[''],
                                identifier:x.identifier,
                                id:[''],
                        })    
                    );
                    
                    
                })
            }
            this.isUploadLoad = false;

        }

        
    });
    

  }
  onFileRemove(index) {

      this.file_items.removeAt(index);
    

  }
  get file_items() {
    return this.form.get('files') as FormArray;
  }
  setFiles(files){
      (<FormArray>this.form.get('files')).clear();
      files.forEach(x => {
      
          this.file_items.push(
              this._formBuilder.group({
                      id:x.id,
                      file_path:x.file_path,
                      file_name:x.file_name,
                      file_size:x.file_size,
                      file_extension:x.file_extension,
                      file_description:x.file_description,
                      identifier:x.identifier,
                      temp_id:[''],
              })    
          );
      })
  }
  fileDownload(item){
    const salt = (new Date()).getTime();
    return this._httpClient.post(`filedownload?salt=${salt}`,item, {responseType:'blob'}).subscribe(res => {
        var FileSaver = require('file-saver');
        const blob = new Blob([res]);
        FileSaver.saveAs(blob, item.file_name);
        
        
    }, err => {
        console.log(err);
    });
  }

  isSubmitting:boolean = false; //23/09/2024
  onSubmit(data){
    this.isSubmitting = true; //23/09/2024
    if(this.coords != undefined)
    {
      
        data = {
          ...data,
          'longitude':this.coords.coords.longitude,
          'latitude':this.coords.coords.latitude 
        } 
        this.restApiService.store('office_in',data).pipe(takeUntil(this._unsubscribeAll)).subscribe(res =>{
            if(res.success)
            {
              this._userService.user = res.user;
              this.dialogRef.close(res.user);
            }
            this.isSubmitting = false; //23/09/2024 
        });
      
    }
    else
    {
       this.restApiService.store('office_in',data).pipe(takeUntil(this._unsubscribeAll)).subscribe(res =>{
            
            if(res.success)
            {
             
              this._userService.user = res.user;
              this.dialogRef.close(res.user);
            }
       });
     
    }
  }
  cancelForm(){
    this.form.reset();
    this.dialogRef.close(null);
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }

}
