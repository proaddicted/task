import { animate, state, style, transition, trigger } from '@angular/animations';
import { Component, Inject } from '@angular/core';
import { FormArray, FormBuilder, FormGroup } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { RestApiService } from 'app/services/rest-api.service';
import { Subject, takeUntil } from 'rxjs';

@Component({
  selector: 'app-check-list',
  templateUrl: './check-list.component.html',
  styleUrls: ['./check-list.component.scss'],
  animations: [
    trigger('simpleFadeAnimation', [
      state('in', style({opacity: 1})),
      transition(':enter', [
        style({opacity: 0}),
        animate(600)
      ]),
      transition(':leave',
        animate(400, style({opacity: 0})))
    ])
  ]
})
export class CheckListComponent {
  check_lists: any;
  ticketRequestCheckListForm: FormGroup;


  private _unsubscribeAll: Subject<any> = new Subject<any>();
  task_id: string;

  constructor(
    private _formBuilder:FormBuilder,
    private _restApiService: RestApiService,
    public dialogRef: MatDialogRef<CheckListComponent>,
    @Inject(MAT_DIALOG_DATA) public data){}


    ngOnInit(): void {

    this._restApiService.getlist('task').pipe(
      takeUntil(this._unsubscribeAll)
    ).subscribe( res => {
            if(res.success)
            {
              console.log(res)
                this.check_lists = res.data.check_lists;
            }
          });

          this.ticketRequestCheckListForm =  this._formBuilder.group({
            check_list: this._formBuilder.array([]),
          });
      }

      isRequestCheckListSubmit:boolean = false;
      requestCheckList(data){
        this.isRequestCheckListSubmit = true;
        this._restApiService.store(`task_request_check_list/${this.data.id}`,data).pipe(
          takeUntil(this._unsubscribeAll)
        ).subscribe( res => { 
          console.log("Submit Success: " + res);
          if(res.success)
          {
              
            this.ticketRequestCheckListForm.reset();
            this.ticketRequestCheckListForm.get('check_list').markAsUntouched();
            (this.ticketRequestCheckListForm.controls['check_list'] as FormArray).clear();  
              
            this.isRequestCheckListSubmit = false;    
            this.dialogRef.close(res.data);
          }

      });  
      }

      onCheckListChange(event){
        if(event.items.length)
        {
          (<FormArray>this.ticketRequestCheckListForm.get('check_list')).clear();
          event.items.forEach(x => {
            
                this.checklists.push(
                    this._formBuilder.group({
                        id:null,
                        description:x.value,
                    })    
                );
            })
        }
        else
        {
          (<FormArray>this.ticketRequestCheckListForm.get('check_list')).clear();
        }
      }
      get checklists() {
        return this.ticketRequestCheckListForm.get('check_list') as FormArray;
      }
      onChecklistRemove(index) {
        this.checklists.removeAt(index);
      }

      cancelForm(){
        this.ticketRequestCheckListForm.reset();
        this.dialogRef.close(null);
      }
}
