import { Component,Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Subject, takeUntil } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-task-list',
  templateUrl: './user-task-list.component.html',
  styleUrls: ['./user-task-list.component.scss']
})
export class UserTaskListComponent {

  private _unsubscribeAll: Subject<any> = new Subject<any>();
  isLoading:boolean = false;
  form_header:any [];
  tasks: any;

  constructor(
    private router: Router,
    private _httpClient:HttpClient,
    public dialogRef: MatDialogRef<UserTaskListComponent>,
    @Inject(MAT_DIALOG_DATA) public data){}

    ngOnInit(): void {
      this.isLoading = true;
      this.form_header = this.data.form_header;
      // ,this.data.start_date,this.data.end_date
          this._httpClient.get<any>(`tasks_by_id/${this.data.id}?start_date=${this.data.start_date}&end_date=${this.data.end_date}&page_url=${this.router.url}`).pipe(
            takeUntil(this._unsubscribeAll)
        ).subscribe(res =>{
            if(res.success)
            {
              this.tasks = res.data;
              console.log('this.tasks', this.tasks);
              this.isLoading = false;
            }
        });  
    }

    customNum:any = [];
    showItem(val,i){
        this.customNum[i] = val
    }
    hideItem(val,i){
      this.customNum[i] = val;
    }
    viewTask(item){
      this.dialogRef.close(null);
      this.router.navigateByUrl('/apps/task-manager/regular-ticket/regular-ticket-view/'+item.id);
    }
}

