import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RestApiService } from 'app/services/rest-api.service';
import { Subject, takeUntil } from 'rxjs';

@Component({
  selector: 'app-address-update',
  templateUrl: './address-update.component.html',
  styleUrls: ['./address-update.component.scss']
})
export class AddressUpdateComponent implements OnDestroy,OnInit {
  private _unsubscribeAll: Subject<any> = new Subject<any>();
  isLoading:boolean = false;
  form: FormGroup; 

  
  constructor(
    private restApiService:RestApiService,
    private _formBuilder:FormBuilder,  
    private cdr: ChangeDetectorRef,
    public dialogRef: MatDialogRef<AddressUpdateComponent>,
    @Inject(MAT_DIALOG_DATA,) public data
  ) {
   }

   ngOnInit(): void {
    this.form = this._formBuilder.group({
     
      address_type_id:this.data.address_types[0].id,
      address_line1:[''],
      address_line2:[''],
      country_id:null,
      state_id:null,
      city:[''],
      pincode:['',Validators.pattern("^[0-9]*$")],
      gstin_no:[''],
      is_default:true,
      status:true
    })

    if(this.data.address != null)
    {
      this.form.patchValue({
       
        address_type_id:this.data.address.address_type_id,
        address_line1:this.data.address.address_line1,
        address_line2:this.data.address.address_line2,
        country_id:this.data.address.country_id,
        state_id:this.data.address.state_id,
        city:this.data.address.city,
        pincode:this.data.address.pincode,
        gstin_no:this.data.address.gstin_no,
        is_default:this.data.address.is_default,
        status:this.data.address.status
      })
    }
   }
   isSubmitting:boolean = false; //23/09/2024
   onSubmit(formData){
    this.isSubmitting = true; //23/09/2024
    this.restApiService.update(`address_update/${this.data.address.id}`,formData).pipe(
        takeUntil(this._unsubscribeAll)
    ).subscribe( res => { 
        console.log("Submit Success: " + res);
        if(res.success)
        {
            this.form.reset();
            this.dialogRef.close(res.data);
        }  
        this.isSubmitting = false;   //23/09/2024 
    });
   }
   cancelForm(){
      this.form.reset();
      this.dialogRef.close(null);
   }
   ngOnDestroy(): void {
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
   }
}
