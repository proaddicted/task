import { Component, OnDestroy, OnInit, Inject } from '@angular/core';
import { FormBuilder, FormGroup} from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { Router } from '@angular/router';
import { RestApiService } from 'app/services/rest-api.service';
import { Subject, takeUntil } from 'rxjs';
import { UserService } from 'app/core/user/user.service';
import { User } from 'app/core/user/user.types';

@Component({
  selector: 'app-employee-change',
  templateUrl: './employee-change.component.html',
  styleUrls: ['./employee-change.component.scss']
})
export class EmployeeChangeComponent implements OnDestroy,OnInit{
  isLoading = false; 
  user:any;
  form: FormGroup;  
  return_id:any;
  action:string;
  fields: { column_name: string, column_value: any }[];
  employees:any[];
 
  public simpleSelected = {
  }
  private _unsubscribeAll: Subject<any> = new Subject<any>();

  constructor(
    private _restApiService: RestApiService,
    private _formBuilder: FormBuilder,
    private _userService: UserService,
    private router: Router,
    private _matDialog: MatDialog,
    public dialogRef: MatDialogRef<EmployeeChangeComponent>,
    @Inject(MAT_DIALOG_DATA,) public data)
    {

    }
  ngOnInit(): void {
    this.isLoading = true;

    this._userService.user$
      .pipe((takeUntil(this._unsubscribeAll)))
      .subscribe((user: User) => {
          this.user = user;
        
    });

    this.form = this._formBuilder.group({
      task_id: [this.data.task_id],
      column_name:'regular-ticket-employee',
      manager:null,
      supervisor:null,
      employee:[],
    });
  }

  isSubmitting:boolean = false; //23/09/2024
  onSubmit(data){
    this.isSubmitting = true; //23/09/2024
    console.log('data', data);
    this._restApiService.store(`task_change_log/${data.task_id}`, data).pipe(
        takeUntil(this._unsubscribeAll)
      ).subscribe( res => { 

        if(res.success)
        {
          this.dialogRef.close(res.data);
        }  
        this.isSubmitting = false;   //23/09/2024    
      }
    );  
  }

  cancelForm(){
    this.form.reset();
    this.dialogRef.close(null);
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }
}

