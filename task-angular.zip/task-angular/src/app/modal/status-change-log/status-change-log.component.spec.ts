import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StatusChangeLogComponent } from './status-change-log.component';

describe('StatusChangeLogComponent', () => {
  let component: StatusChangeLogComponent;
  let fixture: ComponentFixture<StatusChangeLogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StatusChangeLogComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StatusChangeLogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
