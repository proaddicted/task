import { Component,Inject,OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { RestApiService } from 'app/services/rest-api.service';
import { Subject, takeUntil } from 'rxjs';

@Component({
  selector: 'app-status-change-log',
  templateUrl: './status-change-log.component.html',
  styleUrls: ['./status-change-log.component.scss']
})

export class StatusChangeLogComponent implements OnInit{

  private _unsubscribeAll: Subject<any> = new Subject<any>();
  isLoading:boolean = false;
  statusLogTableColumns: string[] = ['column_name', 'old_value', 'new_value','remarks','updated_by','created_at'];
  statusLogDataSource: any;
  form_header:any [];

  constructor(
    private _restApiService: RestApiService,
    public dialogRef: MatDialogRef<StatusChangeLogComponent>,
    @Inject(MAT_DIALOG_DATA) public data){}
  

  ngOnInit(): void {
       
    this.isLoading = true;
      this._restApiService.show('leave_application_view',this.data.item.id).pipe(
        takeUntil(this._unsubscribeAll)
      ).subscribe(res =>{

          if(res.success)
          {
            this.statusLogDataSource = res.data.status_change_logs;
            this.form_header = this.data.form_header;
            console.log('this.statusLogDataSource',this.statusLogDataSource);
            this.isLoading = false;
          }

      });


  }

  getStatusById(id){
    console.log('this.data.statuses',this.data.statuses)
    var result =  this.data.statuses.find(x => { 
      return x.id == id
    });    
    return result;
  }

  getpaidNonpaidById(id) {
    console.log('this.data.is_paid_nonpaid',this.data.is_paid_nonpaid)
    var result = this.data.is_paid_nonpaid.find(x => {
        return x.id == id
      });
    return result;
  }


}
