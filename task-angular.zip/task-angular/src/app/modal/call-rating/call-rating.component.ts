import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RestApiService } from 'app/services/rest-api.service';
import { Subject, takeUntil } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { FuseConfirmationService } from '@fuse/services/confirmation';
import { trigger, state, style, transition, animate } from '@angular/animations';

@Component({
  selector: 'app-call-rating',
  templateUrl: './call-rating.component.html',
  styleUrls: ['./call-rating.component.scss'],
  animations: [
    // the fade-in/fade-out animation.
    trigger('simpleFadeAnimation', [

      // the "in" style determines the "resting" state of the element when it is visible.
      state('in', style({opacity: 1})),

      // fade in when created. this could also be written as transition('void => *')
      transition(':enter', [
        style({opacity: 0}),
        animate(600)
      ]),

      // fade out when destroyed. this could also be written as transition('void => *')
      transition(':leave',
        animate(400, style({opacity: 0})))
    ])
  ]
})
export class CallRatingComponent  implements OnInit,OnDestroy{
  private _unsubscribeAll: Subject<any> = new Subject<any>();
  isLoading:boolean = false;
  form: FormGroup; 
  users:any[];
  called_id:any;
  user_info:any;
  show_number_filed:boolean=false;
  view_type:string='visibility_off';
  iconColor:string='#0000ff';
  constructor( private _restApiService:RestApiService,
    private _formBuilder:FormBuilder,  
    private cdr: ChangeDetectorRef,
    private _httpClient:HttpClient,
    private _fuseConfirmationService:FuseConfirmationService,
    public dialogRef: MatDialogRef<CallRatingComponent>,
    @Inject(MAT_DIALOG_DATA) public data){}

    ngOnInit(): void {
      console.log('this.data',this.data)
      this.isLoading = true;
      this.form = this._formBuilder.group({
        
        ratings:['', Validators.required],
        remarks:['', Validators.required],
        call_log_id:this.data.calllog_id
      });
      this.form.controls['ratings'].setValue(0);
      this.isLoading = false;
    }

    isSubmitting:boolean = false; //23/09/2024
    onSubmit(data){
      this.isSubmitting = true; //23/09/2024
      this._restApiService.store(`knowlarity_call_rating`,data).pipe(
        takeUntil(this._unsubscribeAll)
      ).subscribe( res => { 
            if(res.success)
            {
              this.form.reset();
              this.dialogRef.close(res.data);
            }
            this.isSubmitting = false; //23/09/2024
  
      });
    }

    cancelForm(){
      this.form.reset();
      this.dialogRef.close(null);
    }
    ngOnDestroy(): void {
      this._unsubscribeAll.next(null);
      this._unsubscribeAll.complete();
    }
}
