import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CallRatingComponent } from './call-rating.component';

describe('CallRatingComponent', () => {
  let component: CallRatingComponent;
  let fixture: ComponentFixture<CallRatingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CallRatingComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CallRatingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
