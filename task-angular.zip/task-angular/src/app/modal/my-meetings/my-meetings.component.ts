import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RestApiService } from 'app/services/rest-api.service';
import { Subject, takeUntil } from 'rxjs';
import {GeolocationService} from '@ng-web-apis/geolocation';
import { HttpClient } from '@angular/common/http';
import { FuseConfirmationService } from '@fuse/services/confirmation';

@Component({
  selector: 'app-my-meetings',
  templateUrl: './my-meetings.component.html',
  styleUrls: ['./my-meetings.component.scss']
})
export class MyMeetingsComponent implements OnInit,OnDestroy{
  private _unsubscribeAll: Subject<any> = new Subject<any>();
  isLoading:boolean = false;
  coords:any;

  constructor( private _restApiService:RestApiService,
    private _formBuilder:FormBuilder,  
    private cdr: ChangeDetectorRef,
    private _httpClient:HttpClient,
    private _fuseConfirmationService:FuseConfirmationService,
    private readonly geolocation$: GeolocationService,
    public dialogRef: MatDialogRef<MyMeetingsComponent>,
    @Inject(MAT_DIALOG_DATA) public data){}
  

  ngOnInit(): void {
    console.log('meetings',this.data.meetings);
    this.geolocation$.subscribe(position =>{
          this.coords = position;
    });
  }
  
  /****************Functions***********************/ 
  isSubmitting:boolean = false;

  officeOut(item,index){

    const dialogRef = this._fuseConfirmationService.open({
          "title": "Office Out",
          "message": 'Are you sure you want to office out?',
          "icon": {
            "show": true,
            "name": "heroicons_outline:exclamation",
            "color": "warn"
          },
          "actions": {
          "confirm": {
              "show": true,
              "label": "Okay",
              "color": "primary"
              },
            "cancel": {
              "show": true,
              "label": "Cancel"
            }
          },
          "dismissible": false
    });

    dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(result => {
        if ( result == 'confirmed' )
        {
            this.isSubmitting = true;
            let data = {
              'task_id':item.id,
              'is_office_out':1,
              'office_out_longitude':this.coords.coords.longitude,
              'office_out_latitude':this.coords.coords.latitude 
            } 
            this._httpClient.post<any>(`meeting_history_update/${item.id}`, data).pipe(
                takeUntil(this._unsubscribeAll)
              ).subscribe( res => {
                if(res.success)
                {
                    this.data.meetings[index].history[0]=res.data;
                    console.log('this.data.meetings',this.data.meetings);
                    this._restApiService._my_meetings.next(this.data.meetings);
                    this.isSubmitting = false;
                }
                    
            });
        
          }



    });
     
  }
  meetingIn(item,index){

      const dialogRef = this._fuseConfirmationService.open({
          "title": "Meeting In",
          "message": 'Are you sure you want to meeting in?',
          "icon": {
            "show": true,
            "name": "heroicons_outline:exclamation",
            "color": "warn"
          },
          "actions": {
          "confirm": {
              "show": true,
              "label": "Okay",
              "color": "primary"
              },
            "cancel": {
              "show": true,
              "label": "Cancel"
            }
          },
          "dismissible": false
    });

    dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(result => {
        if ( result == 'confirmed' )
        {
            this.isSubmitting = true;

            let data = {
                'task_id':item.id,
                'is_meeting_in':1,
                'meeting_in_longitude':this.coords.coords.longitude,
                'meeting_in_latitude':this.coords.coords.latitude 
              } 
              this._httpClient.post<any>(`meeting_history_update/${item.id}`, data).pipe(
                  takeUntil(this._unsubscribeAll)
                ).subscribe( res => {
                  if(res.success)
                  {
                    this.data.meetings[index].history[0]=res.data;
                    console.log('this.data.meetings',this.data.meetings);
                    this._restApiService._my_meetings.next(this.data.meetings);
                    this.isSubmitting = false;

                  
                  }
                      
              });
            
          }



    });
        

  }
  meetingOut(item,index){
    const dialogRef = this._fuseConfirmationService.open({
          "title": "Meeting Out",
          "message": 'Are you sure you want to meeting out?',
          "icon": {
            "show": true,
            "name": "heroicons_outline:exclamation",
            "color": "warn"
          },
          "actions": {
          "confirm": {
              "show": true,
              "label": "Okay",
              "color": "primary"
              },
            "cancel": {
              "show": true,
              "label": "Cancel"
            }
          },
          "dismissible": false
    });

    dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(result => {
        if ( result == 'confirmed' )
        {
          this.isSubmitting = true;

          let data = {
            'task_id':item.id,
            'is_meeting_out':1,
            'meeting_out_longitude':this.coords.coords.longitude,
            'meeting_out_latitude':this.coords.coords.latitude 
          } 
          this._httpClient.post<any>(`meeting_history_update/${item.id}`, data).pipe(
              takeUntil(this._unsubscribeAll)
            ).subscribe( res => {
              if(res.success)
              {
                this.data.meetings[index].history[0]=res.data;
                console.log('this.data.meetings',this.data.meetings);
                this._restApiService._my_meetings.next(this.data.meetings);
                this.isSubmitting = false;

              
              }
                  
          });
        
        }



    });
    

  }
  officeIn(item,index){
    const dialogRef = this._fuseConfirmationService.open({
          "title": "Office Out",
          "message": 'Are you sure you want to office out?',
          "icon": {
            "show": true,
            "name": "heroicons_outline:exclamation",
            "color": "warn"
          },
          "actions": {
          "confirm": {
              "show": true,
              "label": "Okay",
              "color": "primary"
              },
            "cancel": {
              "show": true,
              "label": "Cancel"
            }
          },
          "dismissible": false
    });

    dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(result => {
        if ( result == 'confirmed' )
        {
          this.isSubmitting = true;

          let data = {
            'task_id':item.id,
            'is_office_in':1,
            'office_in_longitude':this.coords.coords.longitude,
            'office_in_latitude':this.coords.coords.latitude 
          } 
          this._httpClient.post<any>(`meeting_history_update/${item.id}`, data).pipe(
              takeUntil(this._unsubscribeAll)
            ).subscribe( res => {
              if(res.success)
              {
                    this.data.meetings[index].history[0]=res.data;
                    console.log('this.data.meetings',this.data.meetings);
                    this._restApiService._my_meetings.next(this.data.meetings);

                    this.isSubmitting = false;

              
              }
                  
          });
        
        }



    });
    
  }


  customNum:any = [];

  showItem(val,i){
      this.customNum[i] = val
  }

  hideItem(val,i){
    this.customNum[i] = val;
  } 
  ngOnDestroy(): void {
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }
}
