import {Component, Inject, OnInit} from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { DailyAttendanceListComponent } from 'app/modules/apps/attendance-manager/daily-attendance/daily-attendance-list/daily-attendance-list.component';
import {Subject} from 'rxjs';


@Component({
  selector: 'app-ist-attendance',
  templateUrl: './ist-attendance.component.html',
  styleUrls: ['./ist-attendance.component.scss']
})
export class IstAttendanceComponent {

  ist_tasks:any = [];
  private _unsubscribeAll: Subject<any> = new Subject<any>();

  constructor( 
    private _matDialog: MatDialog,
    public dialogRef: MatDialogRef<DailyAttendanceListComponent>,
    @Inject(MAT_DIALOG_DATA) public data){}
  
  ngOnInit(): void {   

    console.log('dataaaasss', this.data)

    this.ist_tasks = this.data.item;

  }

}

