import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IstAttendanceComponent } from './ist-attendance.component';

describe('IstAttendanceComponent', () => {
  let component: IstAttendanceComponent;
  let fixture: ComponentFixture<IstAttendanceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IstAttendanceComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(IstAttendanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
