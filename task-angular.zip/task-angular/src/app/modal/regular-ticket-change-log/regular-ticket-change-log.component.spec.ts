import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegularTicketChangeLogComponent } from './regular-ticket-change-log.component';

describe('RegularTicketChangeLogComponent', () => {
  let component: RegularTicketChangeLogComponent;
  let fixture: ComponentFixture<RegularTicketChangeLogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegularTicketChangeLogComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RegularTicketChangeLogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
