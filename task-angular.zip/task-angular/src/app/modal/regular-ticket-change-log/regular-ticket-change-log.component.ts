import {Component, Inject, OnInit} from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import {Subject} from 'rxjs';

@Component({
  selector: 'app-regular-ticket-change-log',
  templateUrl: './regular-ticket-change-log.component.html',
  styleUrls: ['./regular-ticket-change-log.component.scss']
})
export class RegularTicketChangeLogComponent implements OnInit{

  private _unsubscribeAll: Subject<any> = new Subject<any>();

  constructor( 
    private _matDialog: MatDialog,
    public dialogRef: MatDialogRef<RegularTicketChangeLogComponent>,
    @Inject(MAT_DIALOG_DATA) public data){}
  
  change_log_items:any=[];
  column_name:string;

  ngOnInit(): void {   

    this.column_name = this.data.column_name;

    if(this.data.change_log.length){
      this.data.change_log.forEach((element: { column_name: string; }) => {

        if(element.column_name == this.column_name)
          this.change_log_items.push(element)
      });
    }
  }

  statusById(id: any) {
    // console.log('this.data.status', this.data.status);
    const result = this.data.status.find((element: { id: any; }) => element.id == id);
    // console.log('result:', result);
    return result;
  }

  priorityById(id: any) {
    // console.log('this.data.priority', this.data.priority);
    const result = this.data.priority.find((element: { id: any; }) => element.id == id);
    // console.log('result 2:', result);
    return result;
  }                         

  employeeById(id: any) {
    // console.log('this.data.employee', this.data.employee);
    const result = this.data.employee.find((element: { id: any; }) => element.id == id);
    // console.log('result 3:', result);
    return result;
  }

  employeeByNames(ids) {
    const employeeNames: any[] = [];
    let user_ids=ids.replace(/\[|\]/g, '');
    this.data.employee.forEach(element => {
      if(user_ids.split(',').includes(element.id.toString())){
        employeeNames.push(element.name);
      }
    });
    return employeeNames;
  }

  contactByNames(ids: string | any[]) {
    // console.log('this.data.contact', this.data.contact);
    const results = this.data.contact.filter((element: { id: any; }) => ids.includes(element.id));
    const contactNames = results.map((contact: { full_name: any; }) => contact.full_name);
    // console.log('contactNames', contactNames);
    return contactNames;
  }

   

  flagByNames(ids: string | any[]) {
    // console.log('this.data.task_flag', this.data.task_flag);
    const results = this.data.task_flag.filter((element: { id: any; }) => ids.includes(element.id));
    const flagNames = results.map((task_flag: { name: any; }) => task_flag.name);
    // console.log('flagNames', flagNames);
    return flagNames;
  }

  referralById(id: any) {
    // console.log('this.data.contact', this.data.contact);
    const result = this.data.contact.find((element: { id: any; }) => element.id == id);
    // console.log('result 2:', result);
    return result;
  }   

   //13/09/2024
   ticketStagesByNames(ids: string | any[]) {
    // console.log('this.data.ticket_stage', this.data.ticket_stage);
    const results = this.data.ticket_stages.filter((element: { id: any; }) => ids.includes(element.id));
    const ticketStagesByNames = results.map((ticket_stages: { name: any; }) => ticket_stages.name);
    // console.log('ticketStagesByNames', ticketStagesByNames);
    return ticketStagesByNames;
  }  
  officerByNames(ids: string | any[]) {
    const results = this.data.officer.filter((element: { id: any; }) => ids.includes(element.id));
    const officerNames = results.map((officer: { full_name: any; }) => officer.full_name);
    return officerNames;
  }

  purposeById(id: any) {
    const result = this.data.department_purpose.find((element: { id: any; }) => element.id == id);
    return result;
  } 
  
  typeById(id: any) {
    const result = this.data.department_task_type.find((element: { id: any; }) => element.id == id);
    return result;
  } 
  
  modeById(id: any) {
    const result = this.data.department_task_mode.find((element: { id: any; }) => element.id == id);
    return result;
  }  

}
