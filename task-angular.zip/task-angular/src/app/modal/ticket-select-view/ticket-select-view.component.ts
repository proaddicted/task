import { AfterViewInit, ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RestApiService } from 'app/services/rest-api.service';
import { Subject, takeUntil } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-ticket-select-view',
  templateUrl: './ticket-select-view.component.html',
  styleUrls: ['./ticket-select-view.component.scss']
})
export class TicketSelectViewComponent implements OnInit,OnDestroy{
  private _unsubscribeAll: Subject<any> = new Subject<any>();
  isLoading:boolean = false;

  constructor( private restApiService:RestApiService,
    private _formBuilder:FormBuilder,  
    private cdr: ChangeDetectorRef,
    private _httpClient: HttpClient,
    private _matDialog: MatDialog,
    public dialogRef: MatDialogRef<TicketSelectViewComponent>,
    @Inject(MAT_DIALOG_DATA) public data){}

    ngOnInit(): void {
      
    }
    customNum:any[] = [];
    showItem(val,i){
        this.customNum[i] = val
    }

    hideItem(val,i){
      this.customNum[i] = val;
    } 

    selectTicket(item){
      this.dialogRef.close(item);
    }

    cancel(){
      this.dialogRef.close(null);
    }

    ngOnDestroy(): void {
      this._unsubscribeAll.next(null);
      this._unsubscribeAll.complete();
    }
}
