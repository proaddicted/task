import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TicketSelectViewComponent } from './ticket-select-view.component';

describe('TicketSelectViewComponent', () => {
  let component: TicketSelectViewComponent;
  let fixture: ComponentFixture<TicketSelectViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TicketSelectViewComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TicketSelectViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
