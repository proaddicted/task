import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddChatGroupComponent } from './add-chat-group.component';

describe('AddChatGroupComponent', () => {
  let component: AddChatGroupComponent;
  let fixture: ComponentFixture<AddChatGroupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddChatGroupComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddChatGroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
