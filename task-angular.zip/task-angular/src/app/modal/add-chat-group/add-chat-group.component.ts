import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RestApiService } from 'app/services/rest-api.service';
import { Subject, takeUntil } from 'rxjs';
import { User } from 'app/core/user/user.types';
import { UserService } from 'app/core/user/user.service';

@Component({
  selector: 'app-add-chat-group',
  templateUrl: './add-chat-group.component.html',
  styleUrls: ['./add-chat-group.component.scss']
})
export class AddChatGroupComponent implements OnInit,OnDestroy{

  private _unsubscribeAll: Subject<any> = new Subject<any>();
  isLoading:boolean = false;
  form: FormGroup; 

  
  constructor(
    private restApiService:RestApiService,
    private _formBuilder:FormBuilder,  
    private _userService: UserService,
    private cdr: ChangeDetectorRef,
    public dialogRef: MatDialogRef<AddChatGroupComponent>,
    @Inject(MAT_DIALOG_DATA,) public data
  ) {
   }
   ngOnInit(): void {
    this.form = this._formBuilder.group({
      name:['',Validators.required],
      users:null,
      profile:null,
      type:['group',Validators.required]
      
    });
    if(this.data.action  == 'edit' && this.data.item.id > 0)
    {
      let users:any[] = [];

      this.form.patchValue({
          name: this.data.item.name,
          type: this.data.item.type,
          users : users,
      })
    }
   }
   addFile(event){
    
    if(event != null)
      this.form.controls['profile'].setValue(event);
   }

   isSubmitting:boolean = false; //23/09/2024
   onSubmit(data){
    this.isSubmitting = true; //23/09/2024
    console.log('form data',data);
    console.log('this.data.action ',this.data.action );
    if(this.data.action  == 'edit' && this.data.item.id > 0)
    {
      this.restApiService.update(`chat_group/${this.data.item.id}`,data).pipe(
          takeUntil(this._unsubscribeAll)
        ).subscribe( res => { 
          if(res.success)
          {   
            this.form.reset();
            this.dialogRef.close(res.data);
          }
          this.isSubmitting = false;   //23/09/2024
      }); 
    }
    else
    {
      this.restApiService.store('chat_group',data).pipe(
          takeUntil(this._unsubscribeAll)
      ).subscribe( res => { 

          if(res.success)
          {
              this.form.reset();
              this.dialogRef.close(res.data);
          
          }  
      });
    }
   }

   cancelForm(){
      this.form.reset();
      this.dialogRef.close(null);
    }
   ngOnDestroy(): void {
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
   }
}
