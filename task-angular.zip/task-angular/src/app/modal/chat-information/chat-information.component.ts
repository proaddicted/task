import { ChangeDetectorRef, Component, Inject, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { Chat } from 'app/modules/apps/chat/chat.types';
import { ChatService } from 'app/modules/apps/chat/chat.service';
import { Subject, map, takeUntil } from 'rxjs';
import { AbstractControl, FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';



@Component({
  selector: 'app-chat-information',
  templateUrl: './chat-information.component.html',
  styleUrls: ['./chat-information.component.scss']
})
export class ChatInformationComponent implements OnInit 
{



  // first:any;
  // last:any;
  // message:any;
  // i:any;
  // user:any;
  // form: FormGroup;
  
  
  private _unsubscribeAll: Subject<any> = new Subject<any>();
  formArray: FormArray<any>;
  toGroups: any;
  chat: any;
message: any;


  constructor(public dialogRef: MatDialogRef<ChatInformationComponent>,
        private _chatService: ChatService,
        @Inject(MAT_DIALOG_DATA,) public data,
        private _changeDetectorRef: ChangeDetectorRef,
        ){
    
  }
  ngOnInit(): void {
  console.log(this.data);
  }
 
  

}
