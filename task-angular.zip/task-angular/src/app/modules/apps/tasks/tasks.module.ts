import { CUSTOM_ELEMENTS_SCHEMA,NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TasksComponent } from './tasks.component';
import { RouterModule } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { FuseDrawerModule } from '@fuse/components/drawer';
import { MatButtonModule } from '@angular/material/button';
import { MatListModule } from '@angular/material/list';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { SharedModule } from 'app/shared/shared.module';
import {MatMenuModule} from '@angular/material/menu'; 
import { NgxGanttModule } from '@worktile/gantt';
import { GANTT_GLOBAL_CONFIG } from '@worktile/gantt';
import { NgSelectModule } from '@ng-select/ng-select';

@NgModule({
  declarations: [
    TasksComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    MatIconModule,
    MatTooltipModule,
    FuseDrawerModule,
    MatButtonModule,
    MatListModule,
    MatProgressSpinnerModule,
    MatProgressBarModule,
    SharedModule,
    MatMenuModule,
    NgxGanttModule,
    NgSelectModule
  ], 
  providers: [
    {
      provide: GANTT_GLOBAL_CONFIG,
      useValue: {
        dateFormat: {
          yearQuarter: `QQQ 'of' yyyy`,
          month: 'LLLL',
          week:'w',
          year:'yyyy',
          yearMonth: `LLLL yyyy'(week' w ')'`
        }
      }
    },
  ], 
  exports:[TasksComponent],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
})
export class TasksModule { }
