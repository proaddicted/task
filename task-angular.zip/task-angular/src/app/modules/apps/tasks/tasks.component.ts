import { HttpClient, HttpEventType } from '@angular/common/http';
import { Component, OnDestroy, OnInit, ChangeDetectorRef, ChangeDetectionStrategy, Input,Output, EventEmitter } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { FuseConfirmationService } from '@fuse/services/confirmation';
import { GanttDate, GanttGroup, GanttItem,GanttToolbarOptions,GanttViewOptions,GanttViewType } from '@worktile/gantt';
import { AddAttendanceComponent } from 'app/modal/add-attendance/add-attendance.component';
import { StatusRemarksComponent } from 'app/modal/status-remarks/status-remarks.component';
import { TaskViewComponent } from 'app/modal/task-view/task-view.component';
import { AddCallComponent } from 'app/modal/tasks/call/add-call/add-call.component';
import { HeldCallComponent } from 'app/modal/tasks/call/held-call/held-call.component';
import { CancelTaskComponent } from 'app/modal/tasks/cancel-task/cancel-task.component';
import { RequestCrdComponent } from 'app/modal/tasks/crd/request-crd/request-crd.component';
import { ViewCrdComponent } from 'app/modal/tasks/crd/view-crd/view-crd.component';
import { AddDepartmentTaskComponent } from 'app/modal/tasks/department-task/add-department-task/add-department-task.component';
import { HeldDepartmentTaskComponent } from 'app/modal/tasks/department-task/held-department-task/held-department-task.component';
import { AddEmailComponent } from 'app/modal/tasks/email/add-email/add-email.component';
import { AddHelpTaskComponent } from 'app/modal/tasks/help-ask/add-help-task/add-help-task.component';
import { AddMeetingComponent } from 'app/modal/tasks/meeting/add-meeting/add-meeting.component';
import { HeldMeetingComponent } from 'app/modal/tasks/meeting/held-meeting/held-meeting.component';
import { RescheduleTaskComponent } from 'app/modal/tasks/reschedule-task/reschedule-task.component';
import { AddSmsComponent } from 'app/modal/tasks/sms/add-sms/add-sms.component';
import { HeldToDoComponent } from 'app/modal/tasks/to-do/held-to-do/held-to-do.component';
import { ToDoComponent } from 'app/modal/tasks/to-do/to-do.component';
import { RestApiService } from 'app/services/rest-api.service';
import { BehaviorSubject, Observable, Subject, takeUntil } from 'rxjs';

export class Task {
  id: any;

  parentId: number;

  title: string;

  start: Date;

  end: Date;

  progress?: number;
}

@Component({
  selector: 'app-tasks',
  templateUrl: './tasks.component.html',
  styleUrls: ['./tasks.component.scss']
})
export class TasksComponent implements OnInit,OnDestroy{

  
  private _unsubscribeAll: Subject<any> = new Subject<any>();

  @Input('mainId') mainId: any;
  @Input('identifier') identifier: string;
  tasks: any[] = [];
  @Input('getListData') getListData: any;

  @Output() taskAdded = new EventEmitter<any>();


  
  constructor(
    private _restApiService: RestApiService,
    private activatedRoute: ActivatedRoute,
    private _httpClient: HttpClient,
    private _fuseConfirmationService: FuseConfirmationService,
    private _matDialog: MatDialog,
    private _changeDetectorRef: ChangeDetectorRef,

    ){

  }

  // groups: GanttGroup[] = [
  //   { id: '000000', title: 'Group-0' },
  //   { id: '000001', title: 'Group-1' }
  // ];
  // items: GanttItem[] = [
  //   { id: '000000', title: 'Task 0', start: 1627729997, end: 1628421197, group_id: '000000' },
  //   { id: '000001', title: 'Task 1', start: 1617361997, end: 1625483597, group_id: '000001' }
  // ];

  // items: GanttItem[] = [
  //   { id: '000000', title: 'Task 0', start: new Date('2023-11-10 14:25:00').getTime(), end: new Date('2023-11-10 16:25:00').getTime(),expandable: true },
  //   { id: '000001', title: 'Task 1', start: new Date('2023-11-12 11:25:00').getTime(), end: new Date('2023-11-12 14:25:00').getTime(), links: ['000003', '000004', '000000'], expandable: true },
  //   { id: '000002', title: 'Task 2', start: new Date('2023-11-13 09:25:00').getTime(), end: new Date('2023-11-13 11:25:00').getTime() },
  //   { id: '000003', title: 'Task 3', start: new Date('2023-11-14 14:25:00').getTime(), expandable: true },
  //   { id: '000004', title: 'Task 4', start: new Date('2023-11-01 14:25:00').getTime(), expandable: true },
  //   { 
  //     id: '000005', 
  //     title: 'Task 5', 
  //     start: new Date('2023-10-14 14:25:00').getTime(), 
  //     end: new Date('2023-10-14 16:25:00').getTime(),
  //     children: [
  //       { id: '000000-01', title: 'Task 0-1', start: new Date('2023-10-14 15:25:00').getTime(), end: new Date('2023-10-14 15:50:00').getTime() , expandable: true },
  //       { 
  //         id: '000000-02', 
  //         title: 'Task 0-2', 
  //         start: new Date('2023-10-14 15:55:00').getTime(), 
  //         end: new Date('2023-10-14 15:57:00').getTime(),
  //         links:['000000-03', '000000-04'],
  //         children: [
  //           { id: '000000-03', title: 'Task 1-0', start: new Date('2023-10-14 11:25:00').getTime(), end: new Date('2023-10-14 15:50:00').getTime() , expandable: true },
  //           { id: '000000-04', title: 'Task 1-2', start: new Date('2023-10-14 12:25:00').getTime(), end: new Date('2023-10-14 15:50:00').getTime() , expandable: true }
  //         ] , 
  //         expandable: true }
  //     ], 
  //     expandable: true ,origin:"Meeting",links:['000000-01','000000-02']}
  // ];
  items: GanttItem[] = [];
  viewType: GanttViewType = GanttViewType.day;

  viewOptions: GanttViewOptions = {
    dateFormat: {
      yearQuarter: `QQQ 'of' yyyy`,
      month: 'LLLL',
      week:'w',
      year:'yyyy',
      yearMonth: `LLLL yyyy'(week' w ')'`
    },
    start: new GanttDate().startOfYear().startOfWeek({ weekStartsOn: 1 }),
    end: new GanttDate().endOfYear().endOfWeek({ weekStartsOn: 1 }),
    addAmount: 1,
    addUnit: 'month',
    fillDays: 1
  };
//   viewOptions: GanttViewOptions = {
//     start: new GanttDate(new Date('2023-8-1')),
//     end: new GanttDate(new Date('2023-12-30'))
// };
  toolbarOptions: GanttToolbarOptions = {
      viewTypes: [GanttViewType.day, GanttViewType.week, GanttViewType.month , GanttViewType.quarter]
  };

  viewTypes:any[]=[
    {id:GanttViewType.day,name:"Day"},
    {id:GanttViewType.month,name:"Month"},
    {id:GanttViewType.week,name:"Month"},
    {id:GanttViewType.quarter,name:"Quater"},
    {id:GanttViewType.year,name:"Year"},

  ];
  selectedViewType: GanttViewType = GanttViewType.month;
  formattedTasks: Task[] = [];
  taskLoaded:boolean = false;
  task: any;

  ngOnInit(): void {

    this.items = [];

    if(this.mainId > 0)
    {

      this.taskLoaded = true;

      this._httpClient.get<any>(`sub_tasks_by_id/${this.mainId}`).pipe(
          takeUntil(this._unsubscribeAll)
      ).subscribe( res => { 

          if(res.success)
          {
            if(res.data.length)
            {
              res.data.forEach(element => {

                 
              let color;
              if(element.status == 3 )
                color = 'blue';
              else if(element.status == 2 )
                color = 'yellow';
              else if(element.status == 1 )
                color = 'purple';
              else if(element.status == 0 )
                color = 'red';  

              this.items.push({
                id:element.id.toString(),
                title:element.type,
                start : new Date(element.start_date).getTime(),
                end : element.due_date != null ? new Date(element.due_date).getTime(): new Date(element.start_date).getTime(),
                expandable:true,
                description:element.description,
                status:element.status,
                //color: element.status == 3 ? 'blue' :  element.status == 2 ? 'green' :  element.status == 1 ? 'purple': 'red',
                color:color,
                children:this.setChildren(element.children).children,
                links:this.setChildren(element.children).links
              });

              this.tasks.push(element);
            });


              this._changeDetectorRef.detectChanges();
              
            }
            if(res.task != null)
            {
              this.task = res.task;
            }
            this.taskLoaded = false;
            
          }  
      });
   
      // if(this.tasks.length)
      // {
      //   this.taskLoaded = true;
      //   // this.tasks.forEach((element:any) => {
      //   //   this.formattedTasks.push({
      //   //     id : parseInt(element.id),
      //   //     parentId : parseInt(element.parent_id),
      //   //     title : element.description,
      //   //     start : new Date(element.start_date),
      //   //     end : element.due_date ? new Date(element.due_date): new Date(element.start_date),
      //   //     progress:80
      //   //   });
      //   // });

      //   this.tasks.forEach(element => {
      //     this.items.push({
      //       id:element.id.toString(),
      //       title:element.type,
      //       start : new Date(element.start_date).getTime(),
      //       end : element.due_date != null ? new Date(element.due_date).getTime(): new Date(element.start_date).getTime(),
      //       expandable:true,
      //       children:this.setChildren(element.children).children,
      //       links:this.setChildren(element.children).links
      //     })
      //   });
        
      //   console.log(' this.items', this.items)
      // this.taskLoaded = false;
      // }
    }
    
  }
  
  setChildren(childrens)
  {
    let child:GanttItem[] = [];
    let links = [];

    if(childrens.length)
    {
     
      childrens.forEach(element => {

        let color;
        if(element.status == 3 )
          color = 'blue';
        else if(element.status == 2 )
          color = 'yellow';
        else if(element.status == 1 )
          color = 'purple';
        else if(element.status == 0 )
          color = 'red';  

        links.push(element.id.toString());

        let c: GanttItem = {
          id:element.id.toString(),
          title:element.type,
          start : new Date(element.start_date).getTime(),
          end : element.due_date != null ? new Date(element.due_date).getTime(): new Date(element.start_date).getTime(),
          description:element.description,
          meeting_type:element.meeting_type,
          meeting_start_url:element.meeting_start_url,
          meeting_invite_url:element.meeting_invite_url,
          status:element.status,
          expandable: true,
          color:color,
          children: element.children.length ? this.setChildren(element.children).children: [],
          links: element.children.length ? this.setChildren(element.children).links: [],
        };
        
        child.push(c);

        
      });
    }

    return {children:child,links:links};
  }
  createCall(parent_id,item)
  {
      const dialogRef = this._matDialog.open(AddCallComponent, {
          data: {
            mainId:this.mainId,
            parent_id:parent_id,
            checkListEmployees:this.getListData.checkListEmployees,
            employees:this.getListData.employees,
            maintask:this.getListData.maintask,
            companies:this.getListData.companies,
            contacts:this.getListData.contacts,


          },
          width:'auto',
          height: 'auto'
      });

      dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(result => {
      
          if(result && result != null)
          {

            this.taskAdded.emit(result);
            this.ngOnInit();
            
            
           

          }
        },
      errRes=>{});
  }
  createMeeting(parent_id,item)
  {
    const dialogRef = this._matDialog.open(AddMeetingComponent, {
        data: {
          mainId:this.mainId,
          parent_id:parent_id,
          checkListEmployees:this.getListData.checkListEmployees,
          employees:this.getListData.employees,
          externals:this.getListData.externals,
          maintask:this.getListData.maintask,
          companies:this.getListData.companies,
          contacts:this.getListData.contacts,

        },
        width:'auto',
        height: 'auto'
    });

    dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(result => {
    
        if(result && result != null)
        {
          
          this.taskAdded.emit(result);
          this.ngOnInit();

        }
      },
    errRes=>{});
  }
  createDepartmentTask(parent_id,item)
  {
    const dialogRef = this._matDialog.open(AddDepartmentTaskComponent, {
        data: {
          mainId:this.mainId,
          parent_id:parent_id,
          employees:this.getListData.employees,
          externals:this.getListData.externals,
          companies:this.getListData.companies,
          contacts:this.getListData.contacts,
          officers:this.getListData.officers,
          maintask:this.getListData.maintask,
          department_task_types:this.getListData.department_task_types,
          department_task_modes:this.getListData.department_task_modes,
          department_purposes:this.getListData.department_purposes,
        },
        width:'auto',
        height: 'auto'
    });

    dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(result => {
    
        if(result && result != null)
        {
          
          this.taskAdded.emit(result);
          this.ngOnInit();
        }
      },
    errRes=>{});
  }
  createEmail(parent_id)
  {
    const dialogRef = this._matDialog.open(AddEmailComponent, {
        data: {
          mainId:this.mainId,
          parent_id:parent_id,
          checkListEmployees:this.getListData.checkListEmployees,
          employees:this.getListData.employees,
          maintask:this.getListData.maintask,
          companies:this.getListData.companies,
          contacts:this.getListData.contacts,

        },
        width:'auto',
        height: 'auto'
    });

    dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(result => {
    
        if(result && result != null)
        {
      

        }
      },
    errRes=>{});
  }
  createSMS(parent_id,item)
  {
    const dialogRef = this._matDialog.open(AddSmsComponent, {
        data: {
          mainId:this.mainId,
          parent_id:parent_id,
          checkListEmployees:this.getListData.checkListEmployees,
          employees:this.getListData.employees,
          maintask:this.getListData.maintask,
          companies:this.getListData.companies,
          contacts:this.getListData.contacts,
          email_templates:this.getListData.email_templates,
          sms_templates:this.getListData.sms_templates,

        },
        width:'auto',
        height: 'auto'
    });

    dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(result => {
    
        if(result && result != null)
        {
          
          this.taskAdded.emit(result);
          this.ngOnInit();

        }
      },
    errRes=>{});
  }
  creatToDo(parent_id,item)
  {
      const dialogRef = this._matDialog.open(ToDoComponent, {
          data: {
            mainId:this.mainId,
            parent_id:parent_id,
            checkListEmployees:this.getListData.checkListEmployees,
            employees:this.getListData.employees,
            maintask:this.getListData.maintask,
            companies:this.getListData.companies,
            contacts:this.getListData.contacts,


          },
          width:'auto',
          height: 'auto'
      });

      dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(result => {
      
          if(result && result != null)
          {
            
           
            this.taskAdded.emit(result);
            this.ngOnInit();

          }
        },
      errRes=>{});
  }
  createHelpTask(parent_id,item)
  {
    const dialogRef = this._matDialog.open(AddHelpTaskComponent, {
        data: {
          mainId:this.mainId,
          parent_id:parent_id,
          checkListEmployees:this.getListData.checkListEmployees,
          employees:this.getListData.employees,
          maintask:this.getListData.maintask,
          companies:this.getListData.companies,
          contacts:this.getListData.contacts,
          descriptions:this.getListData.descriptions

        },
        width:'auto',
        height: 'auto'
    });

    dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(result => {
    
        if(result && result != null)
        {
         
          this.taskAdded.emit(result);
          this.ngOnInit();

        }
      },
    errRes=>{});
  }
  requestCRD(parent_id,item)
  {
    const dialogRef = this._matDialog.open(RequestCrdComponent, {
        data: {
          mainId:this.mainId,
          parent_id:parent_id,
          checkListEmployees:this.getListData.checkListEmployees,
          employees:this.getListData.employees,
          maintask:this.getListData.maintask,
          companies:this.getListData.companies,
          contacts:this.getListData.contacts,
          descriptions:this.getListData.descriptions,
          document_types:this.getListData.document_types 

        },
        width:'auto',
        height: 'auto'
    });

    dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(result => {
    
        if(result && result != null)
        {
        
          this.taskAdded.emit(result);
          this.ngOnInit();

        }
      },
    errRes=>{});
  }
  viewTask(item){

    console.log('item',item);
    
    let template;
    if(item.title == 'crd')
      template = ViewCrdComponent;
    else
      template = TaskViewComponent;

    const dialogRef = this._matDialog.open(template, {
        data: {
          item:item,
        },
        width: item.title == 'crd' ? '850px' : 'auto',
        height: 'auto'
    });

    dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(result => {
    
        if(result && result != null)
        {

          
        }
      },
    errRes=>{});
  }

  taskHeld(item)
  {

    let component, task;

    if(item.title == 'call')
      component = HeldCallComponent;
    else if(item.title == 'todo')
      component = HeldToDoComponent;
    else if(item.title == 'meeting')
      component = HeldMeetingComponent;
    else if(item.type == 'department-task')
      component = HeldDepartmentTaskComponent;

    this.tasks.forEach(element => {
      if(element.id == item.id)
      {
        task = element;
      }
    });  
  
    const dialogRef = this._matDialog.open(component, {
        data: {
          item:item,
        },
        width:'auto',
        height: 'auto'
    });

    dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(result => {
    
        if(result && result != null)
        {
            this.ngOnInit();
          
        }
      },
    errRes=>{});
  }
  taskReschedule(item)
  {
    const dialogRef = this._matDialog.open(RescheduleTaskComponent, {
        data: {
          item:item,
        },
        width:'auto',
        height: 'auto'
    });

    dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(result => {
    
        if(result && result != null)
        {
            this.ngOnInit();
          
        }
      },
    errRes=>{});
  }
  taskCancel(item)
  {
    const dialogRef = this._matDialog.open(CancelTaskComponent, {
        data: {
          item:item,
        },
        width:'auto',
        height: 'auto'
    });

    dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(result => {
    
        if(result && result != null)
        {
            this.ngOnInit();
          
        }
      },
    errRes=>{});
  }
  taskAttendance(item)
  {
    const dialogRef = this._matDialog.open(AddAttendanceComponent, {
        data: {
          mainId:this.mainId,
          task_id:item.id,
          task:this.getListData.maintask,
         
          expense_types:this.getListData.expense_types

        },
        width:'auto',
        height: 'auto'
    });

    dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(result => {
    
        if(result && result != null)
        {
        
        

        }
      },
    errRes=>{});
  }
  taskStatusChange(item,status)
  {

    console.log('statusstatusstatus',status)
    const dialogRef = this._matDialog.open(StatusRemarksComponent, {
        data: {
          id:item.id,
          url:'task_change_log',
          column_value:status,
          column_name:'status'

        },
        width:'auto',
        height: 'auto'
    });

    dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(result => {
    
        if(result && result != null)
        {
            this.ngOnInit();
        }
        
      },
    errRes=>{});
  }
  barClick(event)
  {
    console.log('bar clicked',event);
  }
  ngOnDestroy(): void {
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }
}
