import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CallListComponent } from './call-list/call-list.component';
import { AccessGuard } from 'app/guards/access.guard';

const routes: Routes = [
  {
    path     : '',
    children: [ 
      {path     : 'call-list',component: CallListComponent,canActivate:[AccessGuard], data: {'access-type':5}},
      {path     : 'connected-call-list',component: CallListComponent,canActivate:[AccessGuard], data: {'access-type':5}},
      {path     : 'missed-call-list',component: CallListComponent,canActivate:[AccessGuard], data: {'access-type':5}},
      {path     : 'incoming-call-list',component: CallListComponent,canActivate:[AccessGuard], data: {'access-type':5}},
      {path     : 'outgoing-call-list',component: CallListComponent,canActivate:[AccessGuard], data: {'access-type':5}},
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CallListingRoutingModule { }
