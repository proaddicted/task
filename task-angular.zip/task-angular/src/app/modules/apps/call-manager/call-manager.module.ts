import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';



import { CommonListingModule } from '../common-listing/common-listing.module';
import { MatButtonModule } from '@angular/material/button';
import { MatChipsModule } from '@angular/material/chips';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { ReactiveFormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { MatCheckboxModule } from '@angular/material/checkbox';
import {MatRadioModule} from '@angular/material/radio';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatSelectModule } from '@angular/material/select';
import { MatListModule } from '@angular/material/list';
import { NgxEditInlineModule } from 'ngx-edit-inline';
import { AdvanceSearchModule } from '../common-listing/advance-search/advance-search.module';
import { NgxMaskDirective, NgxMaskPipe, provideNgxMask } from 'ngx-mask';
import { ExpandMode, NgxTreeSelectModule } from '../../../../ngx-tree-select/src';
import { EditorModule } from '@tinymce/tinymce-angular';
import { NgxDropzoneModule } from 'ngx-dropzone';
import { EDITABLE_CONFIG, EditableConfig, EditableModule } from '@ngneat/edit-in-place';
import { MatTabsModule } from '@angular/material/tabs';
import { MatNativeDateModule, MatRippleModule } from '@angular/material/core';
import { MatTableExporterModule } from 'mat-table-exporter';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSortModule } from '@angular/material/sort';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatMenuModule } from '@angular/material/menu';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTableModule } from '@angular/material/table';
import { SharedModule } from 'app/shared/shared.module';
import { NgApexchartsModule } from 'ng-apexcharts';
import { DxSchedulerModule } from 'devextreme-angular';
import { NormalCommentModule } from '../normal-comment/normal-comment.module';
import { CallListComponent } from './call-list/call-list.component';
import { CallListingRoutingModule } from './call-manager-routing.module';
import { StarRatingModule } from 'angular-star-rating';
// $ npm install angular-star-rating css-star-rating --save

import { NgxMatDatetimePickerModule, NgxMatNativeDateModule, NgxMatTimepickerModule } from '@angular-material-components/datetime-picker';

@NgModule({
  declarations: [
    CallListComponent
  ],
  imports: [
    CommonModule,
    CommonListingModule,
    CallListingRoutingModule,
    MatChipsModule,
    MatDividerModule,
    ReactiveFormsModule,
    NgSelectModule,
    MatButtonModule,
    MatCheckboxModule,
    MatRadioModule,
    MatFormFieldModule,
    MatTableModule,
    MatProgressSpinnerModule,
    MatIconModule,
    MatInputModule,
    MatMenuModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatRippleModule,
    MatSortModule,
    MatSelectModule,
    MatSlideToggleModule,
    MatTooltipModule,
    SharedModule,
    StarRatingModule,
    AdvanceSearchModule,
    MatTableExporterModule,
    NgSelectModule,
    MatExpansionModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatTabsModule,
    MatListModule,
    NgApexchartsModule,
    AdvanceSearchModule,
    NgxEditInlineModule,
    NgxMaskDirective,
    NgxMaskPipe,
    EditorModule,
    NgxDropzoneModule,
    DxSchedulerModule,
    EditableModule,
    NormalCommentModule,
    NgxMatDatetimePickerModule,
    NgxMatTimepickerModule,
    NgxMatNativeDateModule,
    NgxTreeSelectModule.forRoot({
      idField: 'id',
      textField: 'name',
      expandMode: ExpandMode.Selection
    })
  ],
  providers : [
    provideNgxMask(),
    {
     provide: EDITABLE_CONFIG, 
     useValue: {
       openBindingEvent: 'dblclick',
       closeBindingEvent: 'dblclick',
     } as EditableConfig
   }
]
  /**useExisting: forwardRef(() => MyInputField), */
})
export class CallManagerModule { }
