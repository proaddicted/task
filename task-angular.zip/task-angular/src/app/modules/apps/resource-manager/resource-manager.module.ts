import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ResourceManagerRoutingModule } from './resource-manager-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ResourceManagerRoutingModule,
    
    
    
  ]
})
export class ResourceManagerModule { }
