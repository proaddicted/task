import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path     : '',
    children: [
      {path: 'user', loadChildren: () => import('app/modules/apps/resource-manager/user/user.module').then(m => m.UserModule)},
      {path: 'role', loadChildren: () => import('app/modules/apps/resource-manager/role/role.module').then(m => m.RoleModule)},
      {path: 'salary-head', loadChildren: () => import('app/modules/apps/resource-manager/salary-head/salary-head.module').then(m => m.SalaryHeadModule)},
      {path: 'department', loadChildren: () => import('app/modules/apps/resource-manager/department/department.module').then(m => m.DepartmentModule)},
      {path: 'designation', loadChildren: () => import('app/modules/apps/resource-manager/designation/designation.module').then(m => m.DesignationModule)},
      {path: 'shift', loadChildren: () => import('app/modules/apps/resource-manager/shift/shift.module').then(m => m.ShiftModule)},
      {path: 'employee', loadChildren: () => import('app/modules/apps/resource-manager/employee/employee.module').then(m => m.EmployeeModule)},
      
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ResourceManagerRoutingModule { }
