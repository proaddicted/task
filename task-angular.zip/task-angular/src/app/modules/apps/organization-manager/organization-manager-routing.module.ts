import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path     : '',
    children: [
      {path: 'state', loadChildren: () => import('app/modules/apps/organization-manager/state/state.module').then(m => m.StateModule)},
      {path: 'country', loadChildren: () => import('app/modules/apps/organization-manager/country/country.module').then(m => m.CountryModule)},
      {path: 'page', loadChildren: () => import('app/modules/apps/organization-manager/page/page.module').then(m => m.PageModule)},
      {path: 'module', loadChildren: () => import('app/modules/apps/organization-manager/module/module.module').then(m => m.ModuleModule)},
      {path: 'currency', loadChildren: () => import('app/modules/apps/organization-manager/currency/currency.module').then(m => m.CurrencyModule)},
      {path: 'bank-account', loadChildren: () => import('app/modules/apps/organization-manager/bank-account/bank-account.module').then(m => m.BankAccountModule)},
      {path: 'branch', loadChildren: () => import('app/modules/apps/organization-manager/branch/branch.module').then(m => m.BranchModule)},
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OrganizationManagerRoutingModule { }
