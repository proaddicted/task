import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { OrganizationManagerRoutingModule } from './organization-manager-routing.module';


@NgModule({
  declarations: [

  ],
  imports: [
    CommonModule,
    OrganizationManagerRoutingModule
  ]
})
export class OrganizationManagerModule { }
