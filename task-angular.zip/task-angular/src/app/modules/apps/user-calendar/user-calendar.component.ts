import { HttpClient } from '@angular/common/http';
import { Component, Input, OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';
import { RestApiService } from 'app/services/rest-api.service';
import { Subject, takeUntil } from 'rxjs';
import dayjs, { Dayjs } from 'dayjs/esm';
import { Router } from '@angular/router';
import { FuseMediaWatcherService } from '@fuse/services/media-watcher';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-user-calendar',
  templateUrl: './user-calendar.component.html',
  styleUrls: ['./user-calendar.component.scss']
})
export class UserCalendarComponent implements OnInit,OnDestroy,OnChanges {

  currentDate: Date = new Date();
  private _unsubscribeAll: Subject<any> = new Subject<any>();

  @Input('userid') userid:any;

  appointmentsData:any[]  = [
   
  ];
  prioritiesData: any[] = [
    {
      text: 'Low Priority',
      id: 0,
      color: '#1e90ff',
    }, {
      text: 'Medium Priority',
      id: 1,
      color: '#ff9747',
    }, {
      text: 'High Priority',
      id: 2,
      color: '#873201',
    },
  ];
  constructor(private _restApiService: RestApiService,
    private router: Router,
    private _httpClient:HttpClient,
    private _fuseMediaWatcherService:FuseMediaWatcherService,
    private _formBuilder: FormBuilder

    ){

  }

  task_types: any[] = [];
  groups: any[] = [];
  services: any[] = [];
  companies: any[] = [];
  allcompanies: any[] = [];  // 03/10/2024 Jyoti
  isLoading:boolean = false;
  tasks:any[] = [];
  isScreenSmall:boolean;
  defaultView:any = 'month';
  form: FormGroup;

  public simpleSelected =  {};


  ngOnInit(): void {
    this.isLoading = true;

    this._restApiService._task_getlist$.subscribe((res:any)=>{
        this.task_types = res.task_types;
        this.groups = res.groups;
        this.allcompanies = res.companies;  // 03/10/2024 Jyoti
        this.services = res.services;
        this.services = this.process(res.services);
        this.isLoading = false;
    })

    this.form = this._formBuilder.group({
      type : [null],
      group_id : [null],
      company: [null],
      service:null,
    });

    this._fuseMediaWatcherService.onMediaChange$
        .pipe(takeUntil(this._unsubscribeAll))
        .subscribe(({matchingAliases}) => {

            // Check if the screen is small
            this.isScreenSmall = !matchingAliases.includes('md');

            if(this.isScreenSmall)
              this.defaultView = 'month';
    });
   

    
  }

  // 03/10/2024 Jyoti
  onGroupChange(event){
    if(event && event != null)
    {
        this.companies = this.allcompanies.filter(item => item.group_id === event.id);

        console.info('this.companies',this.allcompanies);
        console.info('event',event);
    }
    else{
      this.companies = this.allcompanies;
    }
  }
  // 03/10/2024 Jyoti

  ngOnChanges(changes: SimpleChanges): void {

    console.log('changes from calender',changes); 

    if(changes){

      if(changes.userid && changes.userid.currentValue != changes.userid.previousValue)
      {

        this.userid = changes.userid.currentValue ;
        this._httpClient.get<any>(`tasks_by_user?userid=${this.userid}`).pipe(
            takeUntil(this._unsubscribeAll)
        ).subscribe( res => { 

            if(res.success)
            {
              if(res.data.length)
              {
                res.data.forEach(element => {

                  this.tasks.push(element);

                  let isAllDay = false , endDate, startDate ;
                  if(element.type == 'help-ticket' || element.type == 'regular-ticket' || element.type == 'crd')
                  {
                    endDate = new Date(dayjs(element.due_date).format("YYYY-MM-DD HH:mm:ss"));

                      if(element.due_date != null)
                        startDate = new Date(dayjs(element.due_date).format("YYYY-MM-DD HH:mm:ss"));
                      else
                        startDate = new Date(dayjs(element.start_date).format("YYYY-MM-DD HH:mm:ss"));

                  }
                  else
                  {
                      startDate = new Date(dayjs(element.start_date).format("YYYY-MM-DD HH:mm:ss"));
                      endDate = new Date(dayjs(element.start_date).add(1, 'hours').format("YYYY-MM-DD HH:mm:ss"));
                  }


                  this.appointmentsData.push({
                    id:element.id,
                    name:element.name,
                    type:element.type,
                    type_name:element.type_name,
                    description:element.description,
                    text:`${element.id} - ${this.fetchType(element.type)}`,
                    startDate:startDate,
                    endDate:endDate,
                    start_date:element.start_date,
                    due_date:element.due_date,
                    priority: element.priority,
                    item:element,
                    allDay: isAllDay,
                    disabled: true 
                  })
                });
              
              }
              this.isLoading = false;
            }
        }); 
      }
    }
  }

  reload(){
    this._httpClient.get<any>(`tasks_by_user?userid=${this.userid}`).pipe(
        takeUntil(this._unsubscribeAll)
    ).subscribe( res => { 

        if(res.success)
        {
          if(res.data.length)
          {
            res.data.forEach(element => {

              this.tasks.push(element);

              let isAllDay = false , endDate, startDate ;
              if(element.type == 'help-ticket' || element.type == 'regular-ticket' || element.type == 'crd')
              {
                endDate = new Date(dayjs(element.due_date).format("YYYY-MM-DD HH:mm:ss"));

                  if(element.due_date != null)
                    startDate = new Date(dayjs(element.due_date).format("YYYY-MM-DD HH:mm:ss"));
                  else
                    startDate = new Date(dayjs(element.start_date).format("YYYY-MM-DD HH:mm:ss"));

              }
              else
              {
                  startDate = new Date(dayjs(element.start_date).format("YYYY-MM-DD HH:mm:ss"));
                  endDate = new Date(dayjs(element.start_date).add(1, 'hours').format("YYYY-MM-DD HH:mm:ss"));
              }


              this.appointmentsData.push({
                id:element.id,
                name:element.name,
                type:element.type,
                type_name:element.type_name,
                description:element.description,
                text:`${element.id} - ${this.fetchType(element.type)}`,
                startDate:startDate,
                endDate:endDate,
                start_date:element.start_date,
                due_date:element.due_date,
                priority: element.priority,
                item:element,
                allDay: isAllDay,
                disabled: true 
              })
            });
          
          }
          this.isLoading = false;
        }
    }); 
  }


  /*****************Mutli Level Service*************/
    private process(data): any {
      let result = [];
      result = data.map((item) => {
        return this.toTreeNode(item);
      });
      return result;
    }
    private toTreeNode(node, parent = null) {
      if (node && node.children) {
        node.children.map(item => {
          return this.toTreeNode(item, node);
        });
      }
      return node;
    }
    onSelectionChange(event){
      let services = [];
      if(event != null && event.length)
      {
        event.forEach(element => {
          services.push(element.id);
        });
        this.form.controls.service.setValue(services);
      }
    }
    clearService(){
      this.simpleSelected = {};
      this.form.controls.service.setValue(null);
    }

  
    onAppointmentFormOpening(e){

      console.log('this hit here');
      e.cancel = true;
      // e.cancel.done(function (response) {  
      //     e.cancel.resolve(response);  
      // });  
    }
   
  /*****************End Mutli Level Service*************/

  isSubmitting:boolean = false;
  onSubmit(data){
    this.isSubmitting = true;
    this.appointmentsData = [];
    let filter = this._restApiService.generateAdvanceSearchData(data);
    this._httpClient.get<any>(`tasks_by_user?${filter}&userid=${this.userid}`).pipe(
      takeUntil(this._unsubscribeAll)
    ).subscribe( res => {
        if(res.success)
        {
          if(res.data.length)
          {
            res.data.forEach(element => {
              this.tasks.push(element);
              let isAllDay = false , endDate, startDate ;
              if(element.type == 'help-ticket' || element.type == 'regular-ticket' || element.type == 'crd')
              {
                endDate = new Date(dayjs(element.due_date).format("YYYY-MM-DD HH:mm:ss"));
                if(element.due_date != null)
                  startDate = new Date(dayjs(element.due_date).format("YYYY-MM-DD HH:mm:ss"));
                else
                  startDate = new Date(dayjs(element.start_date).format("YYYY-MM-DD HH:mm:ss"));
              }
              else
              {
                startDate = new Date(dayjs(element.start_date).format("YYYY-MM-DD HH:mm:ss"));
                endDate = new Date(dayjs(element.start_date).add(1, 'hours').format("YYYY-MM-DD HH:mm:ss"));
              }

              this.appointmentsData.push({
                id:element.id,
                name:element.name,
                type:element.type,
                type_name:element.type_name,
                description:element.description,
                text:`${element.id} - ${this.fetchType(element.type)}`,
                startDate:startDate,
                endDate:endDate,
                start_date:element.start_date,
                due_date:element.due_date,
                priority: element.priority,
                item:element,
                allDay: isAllDay,
                disabled: true 
              })
            });
          }
          this.isSubmitting = false;  
        }
    }); 
  }
  /**10/07/2024 Jyoti**/
  fetchType(type)
  {
    return  type
      .split("-")
      .filter(x => x.length > 0)
      .map((x) => (x.charAt(0).toUpperCase() + x.slice(1)))
      .join(" ");
  }

  customNum:any = [];
  //---------Multi Show Hide-------//
  showItem(val,i){
      this.customNum[i] = val
  }

  hideItem(val,i){
    this.customNum[i] = val;
  } 
  viewTask(id)
  {
    //this.router.navigateByUrl('/apps/task-manager/regular-ticket/regular-ticket-view/'+id);
    this._restApiService.newTabGo('/apps/task-manager/regular-ticket/regular-ticket-view/',id);
  }
  ngOnDestroy(): void {
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }

}
