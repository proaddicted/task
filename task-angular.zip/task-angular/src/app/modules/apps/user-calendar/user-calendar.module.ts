import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserCalendarComponent } from './user-calendar.component';
import { SharedModule } from 'app/shared/shared.module';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatTooltipModule } from '@angular/material/tooltip';
import { DxSchedulerModule } from 'devextreme-angular';
import { MultiEmployeeModule } from '../multi-employee/multi-employee.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { ExpandMode, NgxTreeSelectModule } from 'ngx-tree-select/src';
import { MatTreeModule } from '@angular/material/tree';
import { ServiceTreeModule } from '../service-tree/service-tree.module';
import { MatExpansionModule } from '@angular/material/expansion';

@NgModule({
  declarations: [
    UserCalendarComponent
  ],
  imports: [
    CommonModule,
    MatIconModule,
    SharedModule,
    MatButtonModule,
    MatTooltipModule,
    DxSchedulerModule,
    MultiEmployeeModule,
    NgSelectModule,  // 10/07/2024 
    FormsModule,
    ReactiveFormsModule,
    MatExpansionModule,
    MatTreeModule,
    ServiceTreeModule,
    NgxTreeSelectModule.forRoot({
      idField: 'id',
      textField: 'name',
      expandMode: ExpandMode.Selection
    })  //10/07/2024
  ], 
  exports:[UserCalendarComponent],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
})
export class UserCalendarModule { }
