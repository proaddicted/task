import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatSidenavModule } from '@angular/material/sidenav';
import { SharedModule } from 'app/shared/shared.module';
import { chatRoutes } from 'app/modules/apps/chat/chat.routing';
import { ChatComponent } from 'app/modules/apps/chat/chat.component';
import { ChatsComponent } from 'app/modules/apps/chat/chats/chats.component';
import { ContactInfoComponent } from 'app/modules/apps/chat/contact-info/contact-info.component';
import { EmptyConversationComponent } from 'app/modules/apps/chat/empty-conversation/empty-conversation.component';
import { ConversationComponent } from 'app/modules/apps/chat/conversation/conversation.component';
import { NewChatComponent } from 'app/modules/apps/chat/new-chat/new-chat.component';
import { ProfileComponent } from 'app/modules/apps/chat/profile/profile.component';
import { AvatarModule } from '../avatar/avatar.module';
import { NgxDropzoneModule } from 'ngx-dropzone';
import { MatListModule } from '@angular/material/list';
import { MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatTabsModule } from '@angular/material/tabs';
import { NgSelectModule } from '@ng-select/ng-select';
import { EDITABLE_CONFIG, EditableConfig, EditableModule } from '@ngneat/edit-in-place';

@NgModule({
    declarations: [
        ChatComponent,
        ChatsComponent,
        ContactInfoComponent,
        ConversationComponent,
        EmptyConversationComponent,
        NewChatComponent,
        ProfileComponent
    ],
    imports     : [
        RouterModule.forChild(chatRoutes),
        MatButtonModule,
        MatCheckboxModule,
        MatFormFieldModule,
        MatIconModule,
        MatInputModule,
        MatMenuModule,
        MatSidenavModule,
        SharedModule,
        AvatarModule,
        NgxDropzoneModule,
        MatListModule,
        MatProgressSpinnerModule,
        MatTooltipModule,
        MatTabsModule,
        MatListModule,
        EditableModule,
        NgSelectModule
    ],
    providers : [
      
        
         {
          provide: EDITABLE_CONFIG, 
          useValue: {
            openBindingEvent: 'dblclick',
            closeBindingEvent: 'dblclick',
          } as EditableConfig
        }
  
    ]
})
export class ChatModule
{
}
