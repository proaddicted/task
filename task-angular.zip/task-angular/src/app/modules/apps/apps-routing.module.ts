import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [{
  path     : '',
  children: [
    {path: 'resource-manager', loadChildren: () => import('app/modules/apps/resource-manager/resource-manager.module').then(m => m.ResourceManagerModule)},
    {path: 'organization-manager', loadChildren: () => import('app/modules/apps/organization-manager/organization-manager.module').then(m => m.OrganizationManagerModule)},
    {path: 'master-manager', loadChildren: () => import('app/modules/apps/master-manager/master-manager.module').then(m => m.MasterManagerModule)},
    {path: 'contact-manager', loadChildren: () => import('app/modules/apps/contact-manager/contact-manager.module').then(m => m.ContactManagerModule)},
    {path: 'attendance-manager', loadChildren: () => import('app/modules/apps/attendance-manager/attendance-manager.module').then(m => m.AttendanceManagerModule)},
    {path: 'task-manager', loadChildren: () => import('app/modules/apps/task-manager/task-manager.module').then(m => m.TaskManagerModule)},
    {path: 'leave-manager', loadChildren: () => import('app/modules/apps/leave-manager/leave-manager.module').then(m => m.LeaveManagerModule)},
    {path: 'dashboards', loadChildren: () => import('app/modules/apps/dashboards/dashboards.module').then(m => m.DashboardsModule)},
    {path: 'mailbox', loadChildren: () => import('app/modules/apps/mailbox/mailbox.module').then(m => m.MailboxModule)},
    {path: 'chat', loadChildren: () => import('app/modules/apps/chat/chat.module').then(m => m.ChatModule)},
    {path: 'file-manager', loadChildren: () => import('app/modules/apps/file-listing/file-listing.module').then(m => m.FileListingModule)},
    {path: 'error', loadChildren: () => import('app/modules/apps/error/error.module').then(m => m.ErrorModule)},
    {path: 'call-manager', loadChildren: () => import('app/modules/apps/call-manager/call-manager.module').then(m => m.CallManagerModule)},

  ]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AppsRoutingModule { }
