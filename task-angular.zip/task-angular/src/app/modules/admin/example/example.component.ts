import { Component, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { RestApiService } from 'app/services/rest-api.service';
import { ToastrService } from 'ngx-toastr';

@Component({
    selector     : 'example',
    templateUrl  : './example.component.html',
    encapsulation: ViewEncapsulation.None
})
export class ExampleComponent
{
    /**
     * Constructor
     */
    constructor(private router: Router,private _restApiService: RestApiService,private toastService: ToastrService)
    {
        console.log('this.router.url',this.router.url);
       
    }
    showToast(){
        this._restApiService.store('user',{email: 'a@bc.com'}).subscribe((res:any)=>{
            this.toastService.success('Anulam','Matter Paner');
        });
    }
    showData(){
        this._restApiService.index('user','','','',1,10).subscribe((res: any)=>{
           console.log('list data res >>>>',res);
        });
    }
}
