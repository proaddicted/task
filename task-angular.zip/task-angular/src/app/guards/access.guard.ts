import { Injectable } from '@angular/core';
import { ActivatedRoute, ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { NavigationService } from 'app/core/navigation/navigation.service';
import { UserService } from 'app/core/user/user.service';
import { User } from 'app/core/user/user.types';
import { RestApiService } from 'app/services/rest-api.service';
import { Observable, of, take } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AccessGuard implements CanActivate {

  user: any;
  identifier: any;

  constructor(
    private _userService: UserService,
    private _navigationService: NavigationService,
    private _restApiService: RestApiService,
    private router: Router,
    private activatedRoute: ActivatedRoute
    )
    {}
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
      
      let page_url: any = "";
      let access_type = route.data["access-type"] as Array<string>;


      if(route.data["page-url"] as Array<string> !== null && route.data["page-url"] as Array<string> !== undefined)
      {

        
        if(Object.keys(route.queryParams).length > 0 && route.queryParams.identifier !== null)
        {
        
          this.identifier = route.queryParams.identifier; 
          let url = route.data["page-url"] as Array<string>;
          page_url = `${url}?identifier=${route.queryParams.identifier}`;
        }
        else
        {
          page_url =  route.data["page-url"] as Array<string>;
        }    
      }
      else
      {
        page_url = state.url;
      }
     


      this._userService.user$
        .pipe()
        .subscribe((user: User) => {
            
            this.user = user;
      });

      if(this.user)
      {
        if(this.user.is_superadmin == 1) //make it 1 after testing
          return of(true);
        else{
          this._restApiService.checkPageAccess(page_url,access_type).subscribe((res:any)=>{
            if(res > 0)
            {
              return of(true);
            }
            else
            {
              this.router.navigateByUrl('/apps/error/access-denied');  
              return of(false);
            }
          });
          return of(true);
        }
      }
     
      
      
  }
  
}
