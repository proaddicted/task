import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ExtraOptions, PreloadAllModules, RouterModule } from '@angular/router';
import { FuseModule } from '@fuse';
import { FuseConfigModule } from '@fuse/services/config';
import { FuseMockApiModule } from '@fuse/lib/mock-api';
import { CoreModule } from 'app/core/core.module';
import { appConfig } from 'app/core/config/app.config';
import { mockApiServices } from 'app/mock-api';
import { LayoutModule } from 'app/layout/layout.module';
import { AppComponent } from 'app/app.component';
import { appRoutes } from 'app/app.routing';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { MainInterceptorProvider } from './services/main-interceptor.service';
import { ToastrModule } from 'ngx-toastr';
import { CommonHeaderComponent } from './modal/common-header/common-header.component';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatListModule } from '@angular/material/list';
import { MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { AssignUserComponent } from './modal/assign-user/assign-user.component';
import { ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { NgSelectModule } from '@ng-select/ng-select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { EmployeeCompanyProfileComponent } from './modal/employee-company-profile/employee-company-profile.component';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { EmployeeTimingComponent } from './modal/employee-timing/employee-timing.component';
import { NgxMaskDirective, NgxMaskPipe, provideNgxMask } from 'ngx-mask';
import { ChangePasswordComponent } from './modal/change-password/change-password.component';
import { ContactAddComponent } from './modal/contact-add/contact-add.component';
import { AddressUpdateComponent } from './modal/address-update/address-update.component';
import { GraceModalComponent } from './modal/grace-modal/grace-modal.component';
import { ExpenseApproveComponent } from './modal/expense-approve/expense-approve.component';
import { FileListComponent } from './modal/file-list/file-list.component';
import { DisplayTemplateComponent } from './modal/display-template/display-template.component';
import { FuseCardModule } from '@fuse/components/card';
import { StatusRemarksComponent } from './modal/status-remarks/status-remarks.component';
import { AddCallComponent } from './modal/tasks/call/add-call/add-call.component';
import { AddMeetingComponent } from './modal/tasks/meeting/add-meeting/add-meeting.component';
import { AddEmailComponent } from './modal/tasks/email/add-email/add-email.component';
import { AddSmsComponent } from './modal/tasks/sms/add-sms/add-sms.component';
import { NGX_MAT_DATE_FORMATS, NgxMatDateAdapter, NgxMatDateFormats, NgxMatDatetimePickerModule, NgxMatNativeDateModule, NgxMatTimepickerModule } from '@angular-material-components/datetime-picker';
import { NGX_MAT_MOMENT_DATE_ADAPTER_OPTIONS, NgxMatMomentModule } from '@angular-material-components/moment-adapter';
import { NgxDropzoneModule } from 'ngx-dropzone';
import { MatExpansionModule } from '@angular/material/expansion';
import { AddHelpTaskComponent } from './modal/tasks/help-ask/add-help-task/add-help-task.component';
import { EditorModule } from '@tinymce/tinymce-angular';
import { SharedModule } from './shared/shared.module';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { AddChatGroupComponent } from './modal/add-chat-group/add-chat-group.component';
import { AvatarModule } from './modules/apps/avatar/avatar.module';
import { DocumentViewerComponent } from './modal/document-viewer/document-viewer.component';
import { NgxDocViewerModule } from 'ngx-doc-viewer';
import { ChatForwardComponent } from './modal/chat-forward/chat-forward.component';
import { ChatInformationComponent } from './modal/chat-information/chat-information.component';
import { AddIndividualChatComponent } from './modal/add-individual-chat/add-individual-chat.component';
import { ToDoComponent } from './modal/tasks/to-do/to-do.component';
import { ComposeMailComponent } from './modal/compose-mail/compose-mail.component';
import { QuillModule } from 'ngx-quill';
import { TaskViewComponent } from './modal/task-view/task-view.component';
import { HeldCallComponent } from './modal/tasks/call/held-call/held-call.component';
import { HeldMeetingComponent } from './modal/tasks/meeting/held-meeting/held-meeting.component';
import { HeldToDoComponent } from './modal/tasks/to-do/held-to-do/held-to-do.component';
import { CancelTaskComponent } from './modal/tasks/cancel-task/cancel-task.component';
import { RescheduleTaskComponent } from './modal/tasks/reschedule-task/reschedule-task.component';
import { AddAttendanceComponent } from './modal/add-attendance/add-attendance.component';
import { TaskListComponent } from './modal/task-list/task-list.component';
import { MultiEmployeeModule } from './modules/apps/multi-employee/multi-employee.module';
import { RequestCrdComponent } from './modal/tasks/crd/request-crd/request-crd.component';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { ViewCrdComponent } from './modal/tasks/crd/view-crd/view-crd.component';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSelectModule } from '@angular/material/select';
import {MatRadioModule} from '@angular/material/radio';
import { QuickGroupAddComponent } from './modal/quick-group-add/quick-group-add.component';
import { QuickSubGroupAddComponent } from './modal/quick-sub-group-add/quick-sub-group-add.component';
import { ServiceTreeModule } from './modules/apps/service-tree/service-tree.module';
import { StarRatingModule } from 'angular-star-rating';
import { MyMeetingsComponent } from './modal/my-meetings/my-meetings.component';
import { AddIstComponent } from './modal/tasks/ist/add-ist/add-ist.component';
import { AddDepartmentTaskComponent } from './modal/tasks/department-task/add-department-task/add-department-task.component';
import { HeldDepartmentTaskComponent } from './modal/tasks/department-task/held-department-task/held-department-task.component';
import { ClickToCallComponent } from './modal/click-to-call/click-to-call.component';
import { DepartmentInfoModule } from './modules/apps/task-manager/regular-ticket/regular-ticket-view/department-info/department-info.module';
import { StatusChangeLogComponent } from './modal/status-change-log/status-change-log.component';
import { MatTableModule } from '@angular/material/table';
import { ExpandMode, NgxTreeSelectModule } from '../ngx-tree-select/src';
import { AddRegularTicketComponent } from './modal/tasks/add-regular-ticket/add-regular-ticket.component';
import { RegularTicketChangeLogComponent } from './modal/regular-ticket-change-log/regular-ticket-change-log.component';
import { CheckListComponent } from './modal/check-list/check-list.component';
import { TicketSelectViewComponent } from './modal/ticket-select-view/ticket-select-view.component';
import { DueDateProgressBarModule } from './modules/apps/due-date-progress-bar/due-date-progress-bar.module';
import { FileDetailsComponent } from './modal/file-details/file-details.component';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatTabsModule } from '@angular/material/tabs';
import { UserTaskListComponent } from './modal/user-task-list/user-task-list.component';
import { ChangeLogModalComponent } from './modal/change-log-modal/change-log-modal.component';
import { MailTaskAttachComponent } from './modal/mail-task-attach/mail-task-attach.component';
import { TaskTagComponent } from './modal/task-tag/task-tag.component';
import { EmployeeChangeComponent } from './modal/employee-change/employee-change.component';
import { CallRatingComponent } from './modal/call-rating/call-rating.component';
import { CallMoveComponent } from './modal/call-move/call-move.component';
import { ShowRatingComponent } from './modal/show-rating/show-rating.component';
import { ShowScheduleCallComponent } from './modal/show-schedule-call/show-schedule-call.component';
import { ShowActivityRemarksComponent } from './modal/tasks/show-activity-remarks/show-activity-remarks.component';
import { AttendanceComponent } from './modal/tasks/attendance/attendance.component';
import { IstAttendanceComponent } from './modal/ist-attendance/ist-attendance.component';

const routerConfig: ExtraOptions = {
    preloadingStrategy       : PreloadAllModules,
    scrollPositionRestoration: 'enabled',
    onSameUrlNavigation: 'reload'
};



@NgModule({
    declarations: [
        AppComponent,
        CommonHeaderComponent,
        AssignUserComponent,
        EmployeeCompanyProfileComponent,
        EmployeeTimingComponent,
        ChangePasswordComponent,
        ContactAddComponent,
        AddressUpdateComponent,
        GraceModalComponent,
        ExpenseApproveComponent,
        FileListComponent,
        DisplayTemplateComponent,
        StatusRemarksComponent,
        AddCallComponent,
        AddMeetingComponent,
        AddEmailComponent,
        AddSmsComponent,
        ToDoComponent,
        AddHelpTaskComponent,
        AddChatGroupComponent,
        DocumentViewerComponent,
        ChatForwardComponent,
        ChatInformationComponent,
        AddIndividualChatComponent,
        ComposeMailComponent,
        TaskViewComponent,
        HeldCallComponent,
        HeldMeetingComponent,
        HeldToDoComponent,
        CancelTaskComponent,
        RescheduleTaskComponent,
        AddAttendanceComponent,
        TaskListComponent,
        RequestCrdComponent,
        ViewCrdComponent,
        QuickGroupAddComponent,
        QuickSubGroupAddComponent,
        MyMeetingsComponent,
        AddIstComponent,
        AddDepartmentTaskComponent,
        HeldDepartmentTaskComponent,
        ClickToCallComponent,
        StatusChangeLogComponent,
        AddRegularTicketComponent,
        RegularTicketChangeLogComponent,
        CheckListComponent,
        TicketSelectViewComponent,
        FileDetailsComponent,
        UserTaskListComponent,
        ChangeLogModalComponent,
        MailTaskAttachComponent,
        TaskTagComponent,
        EmployeeChangeComponent,
        CallRatingComponent,
        CallMoveComponent,
        ShowRatingComponent,
        ShowScheduleCallComponent,
        ShowActivityRemarksComponent,
        AttendanceComponent,
        IstAttendanceComponent

    ],
    imports     : [
        BrowserModule,
        BrowserAnimationsModule,
        RouterModule.forRoot(appRoutes, routerConfig),
        HttpClientModule,

        MatButtonModule,
        MatIconModule,
        MatCheckboxModule,
        MatListModule,
        MatDialogModule,
        MatTableModule,
        // Fuse, FuseConfig & FuseMockAPI
        FuseModule,
        FuseConfigModule.forRoot(appConfig),
        FuseMockApiModule.forRoot(mockApiServices),
        FuseCardModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatInputModule,
        NgSelectModule,
        MatSelectModule,
        MatRadioModule,
        MatSlideToggleModule,
        MatDatepickerModule,
        MatNativeDateModule,
        MatProgressSpinnerModule,
        NgxDropzoneModule,
        NgxMaskDirective,
        NgxMaskPipe,
        NgxMatDatetimePickerModule,
        NgxMatTimepickerModule,
        NgxMatNativeDateModule,
        MatExpansionModule,
        EditorModule,
        SharedModule,
        DragDropModule,
        MatTooltipModule,
        AvatarModule,
        NgxDocViewerModule,
        QuillModule,
        // Core module of your application
        CoreModule,
        MultiEmployeeModule,
        ServiceTreeModule,
        DepartmentInfoModule,
        DueDateProgressBarModule,
        // Layout module of your application
        LayoutModule,
        MatTabsModule,
        MatButtonToggleModule,
        StarRatingModule.forRoot(),
        NgxTreeSelectModule.forRoot({
            idField: 'id',
            textField: 'name',
            expandMode: ExpandMode.Selection
        }),
        ToastrModule.forRoot({
            timeOut: 2000,
            positionClass: 'toast-bottom-center',
            preventDuplicates: true,
            progressBar:true
        })
    ],

    providers : [
        {
            provide : HTTP_INTERCEPTORS,
            useClass: MainInterceptorProvider,
            multi   : true
        },
        provideNgxMask()

    ]
    ,
    bootstrap   : [
        AppComponent
    ],
    entryComponents:[
        CommonHeaderComponent,
        AssignUserComponent,
        EmployeeCompanyProfileComponent,
        EmployeeTimingComponent,
        ChangePasswordComponent,
        ContactAddComponent,
        GraceModalComponent,
        ExpenseApproveComponent,
        FileListComponent,
        DisplayTemplateComponent,
        StatusRemarksComponent,
        AddCallComponent,
        HeldCallComponent,
        AddMeetingComponent,
        AddEmailComponent,
        AddSmsComponent,
        AddEmailComponent,
        AddSmsComponent,
        ToDoComponent,
        AddHelpTaskComponent,
        AddChatGroupComponent,
        DocumentViewerComponent,
        ChatForwardComponent,
        ChatInformationComponent,
        AddIndividualChatComponent,
        ComposeMailComponent,
        TaskViewComponent,
        HeldMeetingComponent,
        HeldToDoComponent,
        CancelTaskComponent,
        RescheduleTaskComponent,
        TaskListComponent,
        RequestCrdComponent,
        ViewCrdComponent,
        QuickGroupAddComponent,
        QuickSubGroupAddComponent,
        MyMeetingsComponent,
        AddIstComponent,
        AddDepartmentTaskComponent,
        HeldDepartmentTaskComponent
        
    ]
})
export class AppModule
{
}
