import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ShowHidePipe } from 'app/pipes/show-hide.pipe';
import { PermissionDirective } from 'app/directives/permission.directive';
import { FileSizePipe } from 'app/pipes/file-size.pipe';
import { PeriodFormatDirective } from 'app/directives/period-format.directive';
import { TaskPermissionDirective } from 'app/directives/task-permission.directive';
import { CustomDatePipe } from 'app/pipes/custom-date.pipe';
import { SafePipe } from 'app/pipes/safe.pipe';

@NgModule({
    declarations:[ShowHidePipe,PermissionDirective,FileSizePipe,PeriodFormatDirective,TaskPermissionDirective,CustomDatePipe,SafePipe],
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        
    ],
    exports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        ShowHidePipe,
        PermissionDirective,
        TaskPermissionDirective,
        PeriodFormatDirective,
        FileSizePipe,
        CustomDatePipe,
        SafePipe
        
        
    ],
    schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
})
export class SharedModule
{
}
