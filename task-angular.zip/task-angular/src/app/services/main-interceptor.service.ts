import { Injectable } from '@angular/core';
import { HttpEvent, HttpRequest, HttpHandler, HttpInterceptor, HttpErrorResponse } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import {  catchError } from 'rxjs/operators';
import { environment } from 'environments/environment';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';


const API_URL = environment.apiUrl;
const API_CODE = environment.apiCode;

@Injectable()
export class MainInterceptorProvider implements HttpInterceptor{
    
    constructor(private router:Router,private toastrService: ToastrService){};

    headers : any;

    intercept(req : HttpRequest<any>, next : HttpHandler): Observable<HttpEvent<any>>{

        console.log('window.navigator.onLine',window.navigator.onLine);

        if (req.url.includes("analytics-dashboard-widgets") || req.url.includes("assets") || req.url.includes("project-dashboard-projects") || req.url.includes("project-dashboard-widgets"))
            return next.handle(req);
       
        if(localStorage.getItem("accessToken") != null)
        {   

            if(req.url.includes("fileupload") || req.url.includes("holiday_import"))
            {
                console.log('file up >>>');
                this.headers = {
                    'Cache-Control':  'no-cache, no-store, must-revalidate, post-check=0, pre-check=0',
                    'Access-Control-Allow-Origin':'*',
                    'Pragma': 'no-cache',
                    'Expires': '0',
                    
                    'Accept': 'application/json',
                    'X-MASTER-CODE':API_CODE,
                    'Authorization':`Bearer ${localStorage.getItem("accessToken")}`
                  }
            }
            else
            {
                this.headers = {
                    'Cache-Control':  'no-cache, no-store, must-revalidate, post-check=0, pre-check=0',
                    'Pragma': 'no-cache',
                    'Access-Control-Allow-Origin':'*',
                    'Expires': '0',
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'X-MASTER-CODE':API_CODE,
                    'Authorization':`Bearer ${localStorage.getItem("accessToken")}`
                  }
            }
            
        }
        else
        {
            this.headers = {
                'Cache-Control':  'no-cache, no-store, must-revalidate, post-check=0, pre-check=0',
                'Pragma': 'no-cache',
                'Access-Control-Allow-Origin':'*',
                'Expires': '0',
                'Content-Type': 'application/json',
                'X-MASTER-CODE':API_CODE,
                'Accept': 'application/json'
              }

        }
        const reqWithAuth = req.clone({
            url:`${API_URL}/${req.url}`,
            setHeaders:this.headers
        })
        
    
        return next.handle(reqWithAuth).pipe(
            catchError((error: HttpErrorResponse) => {
                console.log('error Http Request',error);
                if(error.status == 404 || error.status == 405)
                {
                    this.toastrService.error(error.error.message, 'Invalid Access');
                        
                }
                else if(error.status == 403 || error.status == 401)
                {
                    this.toastrService.error(error.error.message, 'Invalid Access');
                    
                    localStorage.removeItem('accessToken');
                    
                    this.router.navigateByUrl('sign-in');
                }
                else if(error.status == 500)
                {
                    this.toastrService.error('Internal Server Error', '500 Server Error');
                        
                }
                /***************ADDED BY DEBARFGA FOR CUSTOMIZE ERROR MESSAGE**************** */
                else if(error.status == 502)
                {
                    this.toastrService.error(error.error.message, 'Validation Violance');
                }
                else if(error.status == 422)
                {
                    if(error.error.message.users.length)
                        this.toastrService.error(error.error.message.users[0], 'Already Exists');
                        
                }
                else if(error.status == 0)
                {
                    if(!window.navigator.onLine)
                        this.toastrService.error('Please Check Your Network', 'Network Error');
                    else
                        this.toastrService.error('Please Contact System Admin', 'Unknown Error'); 
                }
                
                
                return throwError(error.message);
            })
        );        

    }
}
