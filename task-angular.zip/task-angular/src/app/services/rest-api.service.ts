import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { FuseNavigationItem } from '@fuse/components/navigation/navigation.types';
import { FuseConfirmationService } from '@fuse/services/confirmation';
import { FuseMediaWatcherService } from '@fuse/services/media-watcher';
import { NavigationService } from 'app/core/navigation/navigation.service';
import { environment } from 'environments/environment';
import { ToastrService } from 'ngx-toastr';
import { Observable, map, catchError, throwError, share, tap, switchMap, of, BehaviorSubject, Observer, take } from 'rxjs';

export interface ApiData {
  current_page : number,
  data : [],
  first_page_url : string,
  from: number,
  last_page: number,
  last_page_url: string,
  next_page_url: string,
  path: string,
  per_page: number,
  prev_page_url: string,
  to: number,
  total: number
}


@Injectable({
  providedIn: 'root'
})
export class RestApiService {

  advance_submit_data: BehaviorSubject<any>;

  
 
  constructor(private _httpClient: HttpClient,private router: Router,private toastrService: ToastrService,private _fuseConfirmationService: FuseConfirmationService,private _navigationService: NavigationService,private _fuseMediaWatcherService: FuseMediaWatcherService) {
    this.advance_submit_data = new BehaviorSubject({});
   }

  index(url: any,_search:any,filter?: any, sortDirection?: any,pageIndex:number = 1, pageSize:number = 10, type:string=""):  Observable<any> {

    
    
  

      let advanceSearchParams = '';
      let onlySearch;
      // search
      if(_search === undefined || _search === null ||  _search == '' ){
          onlySearch = '';
      }else{
          onlySearch = _search;

      }
      // advance search
      let other_data = filter;
      if(other_data !== undefined && other_data !== null &&  other_data !== ''){
          for(var item in other_data){

              if(other_data[item] != null ){
                  // other_data.other_data[item] = '';

                  const myArray = item.split("-");


                  if(myArray[1] == 'eq' && !(myArray[0] == 'company' || myArray[0] == 'contact' || myArray[0] == 'employee' || myArray[0] == 'service' || myArray[0] == 'group_id' || myArray[0] == 'manager' || myArray[0] == 'supervisor' || myArray[0] == 'officer' || myArray[0] == 'location' || myArray[0] == 'fiscal_year' || myArray[0] == 'preference'))
                    advanceSearchParams = advanceSearchParams + '&'+'filter['+myArray[0]+']'+'='+other_data[item];
                  else if(myArray[1] == 'searchsave')
                    advanceSearchParams = advanceSearchParams + '&'+'search_name'+'='+other_data[item];  
                  else
                    advanceSearchParams = advanceSearchParams + '&'+'advfilter['+item+']'+'='+other_data[item];   
              }

          }
      }
      if(type !== undefined && type !== null &&  type !== '')
      {
          if(advanceSearchParams !== '')
              advanceSearchParams = advanceSearchParams + '&'+type;
          else
              advanceSearchParams = '&'+type;  
      }   
      console.log('advanceSearchParams',advanceSearchParams);
      
    
      return this._httpClient.get(`${url}?per_page=${pageSize}&page=${pageIndex}&search=${onlySearch}&sort=${sortDirection}${advanceSearchParams}&page_url=${this.router.url}`).pipe(
          // map((ApiData : ApiData) => ApiData.data),
          //     catchError(err =>throwError(err))
          switchMap( (apiData: ApiData) =>{
            return of(apiData.data);
          } ),
          catchError(err =>throwError(err))
      );
    //  return of(true);

    }

  store(url:any , data:any): Observable<any>{
    return this._httpClient.post<any>(`${url}?page_url=${this.router.url}`, data)
    .pipe(tap(res => {
        if (res) {
            if(res.success)
                this.toastrService.success(res.message, 'Successfully Submitted');
            else
               {
                  let message = '';
                  message += '<ul>'                  
                  
                  for (let [key, value] of Object.entries(res.message)) {
                    message += `<li>${value}</li>`;
                  }  
                  
                  message += '</ul>';
                  
                  const dialogRef = this._fuseConfirmationService.open({
                    "title": "Update Failed",
                    "message": message,
                    "icon": {
                      "show": true,
                      "name": "heroicons_outline:exclamation",
                      "color": "warn"
                    },
                    "actions": {
                    "confirm": {
                        "show": true,
                        "label": "Okay",
                        "color": "primary"
                        },
                      "cancel": {
                        "show": true,
                        "label": "Cancel"
                      }
                    },
                    "dismissible": false
                  });
               }   

            return res;
        
        }

      })
    );
  }

  show(url:any ,id: number) :  Observable<any> {

    return this._httpClient.get(`${url}/${id}?page_url=${this.router.url}`, {
    }).pipe(
        map(res =>  res)
    );
  }

  update(url:any , data:any) :Observable<any>{
    return this._httpClient.put<any>(`${url}?page_url=${this.router.url}`, data)
    .pipe(map(res => {
        if (res) {
            if(res.success)
                this.toastrService.success(res.message, 'Successfully Updated');
            else
               {
                let message = '';
                  message += '<ul>'                  
                  
                  for (let [key, value] of Object.entries(res.message)) {
                    message += `<li>${value}</li>`;
                  }  
                  
                  message += '</ul>';
                  
                  const dialogRef = this._fuseConfirmationService.open({
                    "title": "Update Failed",
                    "message": message,
                    "icon": {
                      "show": true,
                      "name": "heroicons_outline:exclamation",
                      "color": "warn"
                    },
                    "actions": {
                    "confirm": {
                        "show": true,
                        "label": "Okay",
                        "color": "primary"
                        },
                      "cancel": {
                        "show": true,
                        "label": "Cancel"
                      }
                    },
                    "dismissible": false
                  });
               }   

            return res;
        
        }

      })
    );
  }

  destroy(url:any,id:number) : Observable<any>{
    return this._httpClient.delete<any>(`${url}/${id}?page_url=${this.router.url}`)
    .pipe(map(res => {
        if (res) {
            if(res.success)
                this.toastrService.success(res.message, 'Success');
            else
                this.toastrService.error(res.message,'Deletion Failed');   

            return res;
        
        }

      })
    );
  }
  
  getlist(url:any) :  Observable<any> {

    return this._httpClient.get(`${url}_getlist?page_url=${this.router.url}`, {
    }).pipe(
        map(res =>  res)
    );
  }
  getlistParam(url:any) :  Observable<any> {

    return this._httpClient.get(`${url}&page_url=${this.router.url}`, {}).pipe(
        map(res =>  res)
    );
  }
  getData(url:any) :  Observable<any> {

    return this._httpClient.get(`${url}?page_url=${this.router.url}`, {
    }).pipe(
        map(res =>  res)
    );
  }
  actionAll(url:any , ids: any , action:string , status:any , column:any): Observable<any>{
    return this._httpClient.post<any>(`${url}_actionall?page_url=${this.router.url}`, {'ids':ids,'action':action,'status':status,'column':column})
    .pipe(map(res => {
        if (res) {
            if(res.success)
                this.toastrService.success(res.message, 'Success');
            else
                this.toastrService.error(res.message,'Action Failed');   

            return res;
        
        }

      }),
      share()
    );
  }
  assignAll(url:any , ids: any , emp_id: any): Observable<any>{
    return this._httpClient.post<any>(`${url}_actionall?page_url=${this.router.url}`, {'ids':ids,'action':'assign-employee','emp_id':emp_id})
    .pipe(map(res => {
        if (res) {
            if(res.success)
                this.toastrService.success(res.message, 'Success');
            else
                this.toastrService.error(res.message,'Action Failed');   

            return res;
        
        }

      }),
      share()
    );
  }
  assignAllByColumn(url:any , ids: any , new_value: any,column_name:string,action:string): Observable<any>{
    return this._httpClient.post<any>(`${url}_actionall?page_url=${this.router.url}`, {'ids':ids,'action':action,'new_value':new_value,'column_name':column_name})
    .pipe(map(res => {
        if (res) {
            if(res.success)
                this.toastrService.success(res.message, 'Success');
            else
                this.toastrService.error(res.message,'Action Failed');   

            return res;
        
        }

      }),
      share()
    );
  }
  assignAllResetEmployee(url:any , ids: any , employee: any,manager:any,supervisor:any,column_name:string,action:string): Observable<any>{
    return this._httpClient.post<any>(`${url}_actionall?page_url=${this.router.url}`, {'ids':ids,'action':action,'employee':employee,'manager':manager,'supervisor':supervisor,'column_name':column_name})
    .pipe(map(res => {
        if (res) {
            if(res.success)
                this.toastrService.success(res.message, 'Success');
            else
                this.toastrService.error(res.message,'Action Failed');   

            return res;
        
        }

      }),
      share()
    );
  }

  checkPageAccess(page_url:any, access_type: any): Observable<any>{

      return this._navigationService.permission$
      .pipe(
        take(1),
        map(
          (permissionsArr: any)=>{
            if(permissionsArr.length > 0)
            {
              let access: number = 0;
              const pages: string[] = [];
              permissionsArr.forEach((val, ind) => {
                if(val.page_url == page_url)
                {
                 
                  pages.push(val.page_url);
                  if(val.permission_id == access_type)
                  {
                   
                    access =  val.access;
                  }
                }         
                
              });

              if(pages.indexOf(page_url) === -1)
                access = 0;

              return access;  
            }  
          }
        )
      );
      
  }
  updateMenuPermission(): Observable<any>{
    return this._httpClient.post('user_menu',{}).pipe(
      tap((res: any)=>{
          let nav: FuseNavigationItem[] = [];
          let compactNav: FuseNavigationItem[] = [];

          if(res.data.length > 0){
              let module: FuseNavigationItem[] = [];
              let compactModule: FuseNavigationItem[] = [];
              for(let d of res.data){


                  let chld: FuseNavigationItem[] = [];
                  if(d.pages.length > 0){
                      for(let p of d.pages){
                          let part = (p.url||'').split('?');
                          let queryParams = {};
                          let url = "";
                          if(part.length > 1)
                          {
                              queryParams = JSON.parse('{"' + decodeURI(part[1].replace(/&/g, "\",\"").replace(/=/g,"\":\"")) + '"}');
                              url = part[0];
                          }
                          else
                          {
                              url = p.url;
                          }
                          chld.push({
                                      id   : p.name,
                                      title: p.display_name,
                                      type : 'basic',
                                      exactMatch:false,
                                      queryParams:queryParams,
                                      icon     : p.icon,
                                      link  : url
                                  })

                      }
                  }
                  module.push({ ...module,
                      id: d.name,
                      title    : d.display_name,
                      type     : 'collapsable',
                      icon     : d.icon,
                      children :chld
                  });
                  compactModule.push({ ...compactModule,
                      id: d.name,
                      title    : d.display_name,
                      tooltip : d.display_name,
                      type     : 'aside',
                      icon     : d.icon
                  })

              }
              compactNav = compactModule;
              nav = module;
          }

          this._navigationService._navigation.next({compact: nav,default : nav, futuristic: nav,horizontal: nav});
          this._navigationService._permission.next(res.permissions);
      })
    
    );
  }
  //==========================  table header data start ======================
    items_header_data : any; //variable declar
    tableHeaderData : any;
    tableheaderDropdownChecked : any;
    tableHeaderDataDropdown : any;
    tableDefaultChecked : any;

    private _itemsHeader = new BehaviorSubject(
        []
    );

    get itemsHeaderData(){
        // return [...this._itemsHeader];
        return this._itemsHeader.asObservable();
    }

    headerListData( _getUrl ) : Observable<any>{

        this.items_header_data = []; //blank array items will be push

        // table header column selection
        this.tableHeaderData = [];
        this.tableheaderDropdownChecked = [];
        this.tableDefaultChecked = []

        let _stroageVal = JSON.parse(localStorage.getItem(_getUrl));

        if (_stroageVal != null ) {
            return new BehaviorSubject(_stroageVal).pipe(
                map((resData:any) => {
    
                    if( resData.length > 0){
                        for (const key in resData) {
                            if (resData.hasOwnProperty(key)) {
                            this.items_header_data.push(resData[key]);
                            }
                        }
                    }else{
                    // infinite scroll complite
                    // event.target.complete();
                    }
    
                    // ---- array filter by display and default array item start ---
                    this.items_header_data.forEach((val, ind) => {
                        // dropdown show item
                        if(val.is_display == 1){
                            if (this.tableHeaderData.indexOf(val.column_name) === -1) {
                            this.tableHeaderData.push(val);
                            }
                        }
            
                        // dropdown checked item
                        if(val.is_default == 1){
                            if (this.tableheaderDropdownChecked.indexOf(val.column_name) === -1) {
                            this.tableheaderDropdownChecked.push(val);
                            }
                            
                        }
                    });
    
                    return [
                        this.tableHeaderData, 
                        this.tableheaderDropdownChecked
                    ];
                }),
                tap(itmArry => {
                    // console.log('itmArry >>>>>>>>>>', itmArry);
                    this._itemsHeader.next(itmArry); //update observable data
                }) 
            );
        }
        return this._httpClient.get(`${_getUrl}`).pipe(
            map((resData:any) => {
                // localStorage.setItem(`${_getUrl}_all`, JSON.stringify(resData));

                if( resData.data.length > 0){
                    localStorage.setItem(`${_getUrl}`, JSON.stringify(resData.data));
                    for (const key in resData.data) {
                        if (resData.data.hasOwnProperty(key)) {
                        this.items_header_data.push(resData.data[key]);
                        }
                    }
                }else{
                // infinite scroll complite
                // event.target.complete();
                }

                // ---- array filter by display and default array item start ---
                this.items_header_data.forEach((val, ind) => {
                    // dropdown show item
                    if(val.is_display == 1){
                        if (this.tableHeaderData.indexOf(val.column_name) === -1) {
                        this.tableHeaderData.push(val);
                        }
                    }
        
                    // dropdown checked item
                    if(val.is_default == 1){
                        if (this.tableheaderDropdownChecked.indexOf(val.column_name) === -1) {
                        this.tableheaderDropdownChecked.push(val);
                        }
                        
                    }
                });

                return [
                    this.tableHeaderData, 
                    this.tableheaderDropdownChecked
                ];
            }),
            tap(itmArry => {
                // console.log('itmArry >>>>>>>>>>', itmArry);
                this._itemsHeader.next(itmArry[0]); //update observable data
            }) 
        );
    }


    //================== Advance Search====================//
     
    setAdvanceSubmitData(option) {      
        this.advance_submit_data.next(option)  
    }


    //================Set Tiny Mce Config===============//
    isScreenSmall:boolean;

    tinyInit(){
       this._fuseMediaWatcherService.onMediaChange$
      .pipe()
      .subscribe(({matchingAliases}) => {

          // Check if the screen is small
          this.isScreenSmall = !matchingAliases.includes('md');
      });

      return {
        selector: 'textarea#open-source-plugins',
        plugins: 'preview importcss searchreplace autolink autosave save directionality code visualblocks visualchars fullscreen image link media  codesample table charmap pagebreak nonbreaking anchor insertdatetime advlist lists wordcount help charmap quickbars emoticons',
        editimage_cors_hosts: ['picsum.photos'],
        menubar: 'file edit view insert format tools table help',
        toolbar: 'undo redo | bold italic underline strikethrough | fontfamily fontsize blocks | alignleft aligncenter alignright alignjustify | outdent indent |  numlist bullist | forecolor backcolor removeformat | pagebreak | charmap emoticons | fullscreen  preview save print | insertfile image media link anchor codesample | ltr rtl',
        toolbar_sticky: false,
        toolbar_sticky_offset: this.isScreenSmall ? 102 : 108,
        autosave_ask_before_unload: true,
        autosave_interval: '30s',
        autosave_prefix: '{path}{query}-{id}-',
        autosave_restore_when_empty: false,
        autosave_retention: '2m',
        image_advtab: true,
        link_list: [
          { title: 'My page 1', value: 'https://www.tiny.cloud' },
          { title: 'My page 2', value: 'http://www.moxiecode.com' }
        ],
        image_list: [
          { title: 'My page 1', value: 'https://www.tiny.cloud' },
          { title: 'My page 2', value: 'http://www.moxiecode.com' }
        ],
        image_class_list: [
          { title: 'None', value: '' },
          { title: 'Some class', value: 'class-name' }
        ],
        importcss_append: true,
        file_picker_callback: (callback, value, meta) => {
          /* Provide file and text for the link dialog */
          if (meta.filetype === 'file') {
            callback('https://www.google.com/logos/google.jpg', { text: 'My text' });
          }
      
          /* Provide image and alt text for the image dialog */
          if (meta.filetype === 'image') {
            callback('https://www.google.com/logos/google.jpg', { alt: 'My alt text' });
          }
      
          /* Provide alternative source and posted for the media dialog */
          if (meta.filetype === 'media') {
            callback('movie.mp4', { source2: 'alt.ogg', poster: 'https://www.google.com/logos/google.jpg' });
          }
        },
        height: 600,
        image_caption: true,
        quickbars_selection_toolbar: 'bold italic | quicklink h2 h3 blockquote quickimage quicktable',
        noneditable_class: 'mceNonEditable',
        toolbar_mode: 'sliding',
        contextmenu: 'link image table',
        skin: 'oxide',
        content_css: 'default',
        content_style: 'body { font-family:Helvetica,Arial,sans-serif; font-size:16px }'
      }
    }

    //================File Upload====================//
    tempFileUpload(identifier:string,data:any) :  Observable<any> {

      return this._httpClient.post<any>(`fileupload?page_url=${this.router.url}&identifier=${identifier}`, data)
      .pipe(map(res => {
          if (res) {
              if(res.success)
                  this.toastrService.success(res.message, 'File Uploaded');
              else
                 {
                  for (let [key, value] of Object.entries(res.message)) {
                      
                      this.toastrService.error(
                          `${value}`
                           ,'Upload Failed');
                    }
                 }   
  
              return res;
          
          }
  
        }),
        share()
      );
    }
    mainFileUpload(url:string,identifier:string,data:any) :  Observable<any> {

      return this._httpClient.post<any>(`${url}?page_url=${this.router.url}&identifier=${identifier}`, data, {
        reportProgress: true,
        observe: 'events'
      })
      .pipe(map(res => {
          return res;
          // if (res) {
          //     if(res.success)
          //         this.toastrService.success(res.message, 'File Uploaded');
          //     else
          //        {
          //         for (let [key, value] of Object.entries(res.message)) {
                      
          //             this.toastrService.error(
          //                 `${value}`
          //                  ,'Upload Failed');
          //           }
          //        }   
  
          //     return res;
          
          // }
  
        })
      );
    }
    infoFileUpload(url:string,identifier:string,data:any) :  Observable<any> {

      return this._httpClient.post<any>(`${url}?page_url=${this.router.url}&identifier=${identifier}`, data)
      .pipe(map(res => {
          
                if (res) {
                  if(res.success)
                      this.toastrService.success(res.message, 'File Uploaded');
                  else
                    {
                      for (let [key, value] of Object.entries(res.message)) {
                          
                          this.toastrService.error(
                              `${value}`
                              ,'Upload Failed');
                        }
                    }   

                  return res;
              
              }
        }),
        share()
      );
    }
    importFileUpload(url:string,data:any) :  Observable<any> {

      return this._httpClient.post<any>(`${url}?page_url=${this.router.url}`, data, {
        reportProgress: true,
        observe: 'events'
      })
      .pipe(map(res => {
          return res;
          
  
        })
      );
    }
    //============End File Upload================//

    excel_export(url: any,_search:any,filter?: any, sortDirection?: any,pageIndex:number = 1, pageSize:number = 10, type:string=""){
      let advanceSearchParams = '';
      let onlySearch;
      // search
      if(_search === undefined || _search === null ||  _search == '' ){
          onlySearch = '';
      }else{
          onlySearch = _search;

      }
      // advance search
      let other_data = filter;
      if(other_data !== undefined && other_data !== null &&  other_data !== ''){
          for(var item in other_data){

              if(other_data[item] != null ){
                  const myArray = item.split("-");
                  if(myArray[1] == 'eq' && !(myArray[0] == 'company' || myArray[0] == 'contact' || myArray[0] == 'employee' || myArray[0] == 'manager' || myArray[0] == 'supervisor' || myArray[0] == 'officer' || myArray[0] == 'location' || myArray[0] == 'fiscal_year'))
                    advanceSearchParams = advanceSearchParams + '&'+'filter['+myArray[0]+']'+'='+other_data[item];
                  else if(myArray[1] == 'searchsave')
                    advanceSearchParams = advanceSearchParams + '&'+'search_name'+'='+other_data[item];  
                  else
                    advanceSearchParams = advanceSearchParams + '&'+'advfilter['+item+']'+'='+other_data[item];   
              }

          }
      }
      if(type !== undefined && type !== null &&  type !== '')
      {
          if(advanceSearchParams !== '')
              advanceSearchParams = advanceSearchParams + '&'+type;
          else
              advanceSearchParams = '&'+type;  
      }   
      let link={ 'per_page':pageSize,'page':pageIndex,'search':onlySearch,'sort':sortDirection,'filter':advanceSearchParams};//27/06/24 For excel adv
    
      return link;
    }
    
    newTabGo(path,id)
    {
      window.open(`${environment.appUrl}/${path}/${id}`, '_blank');
    }
    newTabGoURL(path)
    {
      window.open(path, '_blank');
    }

    public _my_meetings: BehaviorSubject<any[]> = new BehaviorSubject(null);
    /**
      * Getter for chats
      */
    get _my_meetings$(): Observable<any[]>
    {
        return this._my_meetings.asObservable();
    }

    public _task_getlist: BehaviorSubject<any[]> = new BehaviorSubject(null);
    
    get _task_getlist$(): Observable<any[]>
    {
        return this._task_getlist.asObservable();
    }

    public _dashboard_counts: BehaviorSubject<any[]> = new BehaviorSubject(null);
    
    get _dashboard_counts$(): Observable<any[]>
    {
        return this._dashboard_counts.asObservable();
    }

    public hideQuickChat: BehaviorSubject<boolean> = new BehaviorSubject(false);
    get hideQuickChat$(): Observable<boolean>
    {
        return this.hideQuickChat.asObservable();
    }
     /**
     * Get chats
     */
     getTaskGetlist(): Observable<any>
     {
         return this._httpClient.get<any>('task_getlist').pipe(
             tap((response: any) => {
              
              if(response.success)
                 this._task_getlist.next(response.data);
             })
         );
     }


     /**
     * Get Time Difference of two tine pass Date() object
     */ 
    getTimeDifference(startTime, endTime) {
      const difference = endTime - startTime;
      const differenceInMinutes = difference / 1000 / 60;
      let hours = Math.floor(differenceInMinutes / 60);
      if (hours < 0) {
        hours = 24 + hours;
      }
      let minutes = Math.floor(differenceInMinutes % 60);
      if (minutes < 0) {
        minutes = 60 + minutes;
      }
      const zeroPad = (num, places) => String(num).padStart(places, '0')
      const hoursAndMinutes = zeroPad(hours,2) + ":" + (minutes < 10 ? '0' : '') + minutes;
      return hoursAndMinutes;
    }

    generateAdvanceSearchData(data)
    {
      let filter = '';
      if(data && data != null)
      {
        for (let [key, value] of Object.entries(data)) {
  
          console.log('value',value);
          if(value != null)
          {
            if(key == 'date' || key == 'start_date' || key == 'due_date' || key == 'ecd' || key == 'received_date' || key == 'created_at')
            {
              filter = filter + `&advfilter[${key}-between]=${value}`
            }
            else
              filter = filter + `&advfilter[${key}-eq]=${value}`
          }
        
        }  
      }
  
      console.log('filter',filter);
      return filter;
    }
}
