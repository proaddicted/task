export interface User
{
    id: string;
    name: string;
    email: string;
    avatar?: string;
    status?: string;
    profile?: string;
    thumbnail?: string;
    type?: string;
    is_superadmin?: number;
    employee_info?: any;
    late_in_reasons?:any[];
}
