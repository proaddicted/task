import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, ReplaySubject, tap } from 'rxjs';
import { Navigation } from 'app/core/navigation/navigation.types';
import { AuthService } from '../auth/auth.service';
import { FuseNavigationItem } from '@fuse/components/navigation';

@Injectable({
    providedIn: 'root'
})
export class NavigationService
{
    public _navigation: ReplaySubject<Navigation> = new ReplaySubject<Navigation>(1);
    public _permission: ReplaySubject<any> = new ReplaySubject<any>(1);

    /**
     * Constructor
     */
    constructor(private _httpClient: HttpClient,private _authService: AuthService)
    {
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Accessors
    // -----------------------------------------------------------------------------------------------------

    /**
     * Getter for navigation
     */
    get navigation$(): Observable<Navigation>
    {
        return this._navigation.asObservable();
    }

    get permission$(): Observable<any>{
        return this._permission.asObservable();
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Get all navigation data
     */
    get(): Observable<Navigation>
    {
        return this._httpClient.post('user_menu',{}).pipe(
            tap((res: any)=>{
                let nav: FuseNavigationItem[] = [];
                let compactNav: FuseNavigationItem[] = [];

                if(res.data.length > 0){
                    let module: FuseNavigationItem[] = [];
                    let compactModule: FuseNavigationItem[] = [];
                    for(let d of res.data){


                        let chld: FuseNavigationItem[] = [];
                        if(d.pages.length > 0){
                            for(let p of d.pages){
                                let part = (p.url||'').split('?');
                                let queryParams = {};
                                let url = "";
                                if(part.length > 1)
                                {
                                    queryParams = JSON.parse('{"' + decodeURI(part[1].replace(/&/g, "\",\"").replace(/=/g,"\":\"")) + '"}');
                                    url = part[0];
                                }
                                else
                                {
                                    url = p.url;
                                }
                                chld.push({
                                            id   : p.name,
                                            title: p.display_name,
                                            type : 'basic',
                                            exactMatch:false,
                                            queryParams:queryParams,
                                            icon     : p.icon,
                                            link  : url,
                                            exactUrl: p.url
                                        })

                            }
                        }
                        module.push({ ...module,
                            id: d.name,
                            title    : d.display_name,
                            type     : 'collapsable',
                            icon     : d.icon,
                            children :chld
                        });
                        compactModule.push({ ...compactModule,
                            id: d.name,
                            title    : d.display_name,
                            tooltip : d.display_name,
                            type     : 'aside',
                            icon     : d.icon
                        })

                    }
                    compactNav = compactModule;
                    nav = module;
                }

                this._navigation.next({compact: nav,default : nav, futuristic: nav,horizontal: nav});
                this._permission.next(res.permissions);
            })
        );
    //    return this._authService.navigation$.pipe(
    //         tap( (res: any) =>{
    //             let nav: FuseNavigationItem[] = [];
    //             if(res.length > 0){
    //                 let module: FuseNavigationItem[] = [];
    //                 for(let d of res){


    //                     let chld: FuseNavigationItem[] = [];
    //                     if(d.pages.length > 0){
    //                         for(let p of d.pages){
    //                             let part = (p.url||'').split('?');
    //                             let queryParams = {};
    //                             let url = "";
    //                             if(part.length > 1)
    //                             {
    //                                 queryParams = JSON.parse('{"' + decodeURI(part[1].replace(/&/g, "\",\"").replace(/=/g,"\":\"")) + '"}');
    //                                 url = part[0];
    //                             }
    //                             else
    //                             {
    //                                 url = p.url;
    //                             }
    //                             chld.push({
    //                                         id   : p.name,
    //                                         title: p.display_name,
    //                                         type : 'basic',
    //                                         exactMatch:true,
    //                                         icon     : p.icon,
    //                                         link  : url
    //                                     })

    //                         }
    //                     }
    //                     module.push({ ...module,
    //                         id: d.name,
    //                         title    : d.display_name,
    //                         subtitle: d.display_name,
    //                         type     : 'group',
    //                         icon     : d.icon,
    //                         children :chld
    //                     });


    //                 }

    //                 nav = module;
    //             }

    //             this._navigation.next({compact: nav,default : nav, futuristic: nav,horizontal: nav});

    //         })
    //     )
        // this._authService.naviGationData.subscribe((res:any)=>{
        //     let nav = [];
        //     if(res.length > 0){
        //         let module = [];
        //         for(let d of res){


        //             let chld = [];
        //             if(d.pages.length > 0){
        //                 for(let p of d.pages){
        //                     let part = (p.url||'').split('?');
        //                     let queryParams = {};
        //                     let url = "";
        //                     if(part.length > 1)
        //                     {
        //                         queryParams = JSON.parse('{"' + decodeURI(part[1].replace(/&/g, "\",\"").replace(/=/g,"\":\"")) + '"}');
        //                         url = part[0];
        //                     }
        //                     else
        //                     {
        //                         url = p.url;
        //                     }
        //                     chld.push({
        //                                 id   : p.name,
        //                                 title: p.display_name,
        //                                 type : 'basic',
        //                                 exactMatch:true,
        //                                 icon     : p.icon,
        //                                 url  : url,
        //                                 params : queryParams
        //                             })

        //                 }
        //             }
        //             module.push({ ...module,
        //                 id: d.name,
        //                 title    : d.display_name,
        //                 translate: d.display_name,
        //                 type     : 'group',
        //                 icon     : d.icon,
        //                 children :chld
        //             });


        //         }

        //         nav = module;
        //     }

        //     navi = [
        //         {
        //             id       : 'applications',
        //             title    : 'Applications',
        //             translate: 'NAV.APPLICATIONS',
        //             type     : 'group',
        //             icon     : 'apps',
        //             children : nav
        //         }
        //     ];
        // });
        // return this._httpClient.get<Navigation>('api/common/navigation').pipe(
        //     tap((navigation) => {

        //        // console.log('navigation',navigation);

        //         this._navigation.next(navigation);
        //     })
        // );
    }
}
