import { NgModule } from '@angular/core';
import { AuthService } from 'app/core/auth/auth.service';

@NgModule({
    imports  : [
        
    ],
    providers: [
        AuthService
    ]
})
export class AuthModule
{
}
