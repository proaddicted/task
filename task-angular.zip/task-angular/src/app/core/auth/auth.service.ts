import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, catchError, Observable, of, switchMap, tap, throwError } from 'rxjs';
import { AuthUtils } from 'app/core/auth/auth.utils';
import { UserService } from 'app/core/user/user.service';
import { ToastrService } from 'ngx-toastr';
import { FuseConfirmationService } from '@fuse/services/confirmation';

@Injectable()
export class AuthService
{
    private _authenticated: boolean = false;
    private naviGationData: BehaviorSubject<any> = new BehaviorSubject<any>([]);
   
    /**
     * Constructor
     */
    constructor(
        private _httpClient: HttpClient,
        private _userService: UserService,
        private toastrService: ToastrService,
        private _fuseConfirmationService: FuseConfirmationService
    )
    {
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Accessors
    // -----------------------------------------------------------------------------------------------------

    /**
     * Setter & getter for access token
     */
    set accessToken(token: string)
    {
        localStorage.setItem('accessToken', token);
    }

    get accessToken(): string
    {
        return localStorage.getItem('accessToken') ?? '';
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Forgot password
     *
     * @param email
     */
    forgotPassword(email: string): Observable<any>
    {
        return this._httpClient.post('forgot_password', {'email':email}).pipe(tap(res => {
            if (res) {
                if(res.success)
                    this.toastrService.success(res.message, 'Mail Sent, Please Check Inbox');
                else
                   {
                      let message = '';
                      message += '<ul>'                  
                      
                      for (let [key, value] of Object.entries(res.message)) {
                        message += `<li>${value}</li>`;
                      }  
                      
                      message += '</ul>';
                      
                      const dialogRef = this._fuseConfirmationService.open({
                        "title": "Update Failed",
                        "message": message,
                        "icon": {
                          "show": true,
                          "name": "heroicons_outline:exclamation",
                          "color": "warn"
                        },
                        "actions": {
                        "confirm": {
                            "show": true,
                            "label": "Okay",
                            "color": "primary"
                            },
                          "cancel": {
                            "show": true,
                            "label": "Cancel"
                          }
                        },
                        "dismissible": false
                      });
                   }   
    
                return res;
            
            }
    
          })
        );
    }

    /**
     * Reset password
     *
     * @param password
     */
    resetPassword(data: any , id: any): Observable<any>
    {
       
        return this._httpClient.post(`reset_password/${id}`, data).pipe(tap(res => {
            if (res) {
                if(res.success)
                    this.toastrService.success(res.message, 'Password Reset Successful');
                else
                   {
                      let message = '';
                      message += '<ul>'                  
                      
                      for (let [key, value] of Object.entries(res.message)) {
                        message += `<li>${value}</li>`;
                      }  
                      
                      message += '</ul>';
                      
                      const dialogRef = this._fuseConfirmationService.open({
                        "title": "Update Failed",
                        "message": message,
                        "icon": {
                          "show": true,
                          "name": "heroicons_outline:exclamation",
                          "color": "warn"
                        },
                        "actions": {
                        "confirm": {
                            "show": true,
                            "label": "Okay",
                            "color": "primary"
                            },
                          "cancel": {
                            "show": true,
                            "label": "Cancel"
                          }
                        },
                        "dismissible": false
                      });
                   }   
    
                return res;
            
            }
    
          })
        );
    }

    /**
     * Sign in
     *
     * @param credentials
     */
    signIn(credentials: { email: string; password: string }): Observable<any>
    {
        // Throw error, if the user is already logged in
        if ( this._authenticated )
        {
            return throwError('User is already logged in.');
        }

        return this._httpClient.post('login', credentials).pipe(
            switchMap((response: any) => {

                if(response.success)
                {
                        // Store the access token in the local storage
                    this.accessToken = response.data.access_token;

                    // Set the authenticated flag to true
                    this._authenticated = true;

                    // Store the user on the user service
                    this._userService.user = response.data.user;

                    this.signInUsingToken().subscribe();
                    // Return a new observable with the response
                    return of(response);
                }
                else
                {
                   

                    this.toastrService.error(response.message,'Invalid Credentials');
                    return of(response);
                }
            })
        );
    }

    /**
     * Sign in using the access token
     */
    signInUsingToken(): Observable<any>
    {
        // Sign in using the token
        return this._httpClient.post('user_info', {
            accessToken: this.accessToken
        }).pipe(
            catchError(() =>

                // Return false
                of(false)
            ),
            switchMap((response: any) => {

                // Replace the access token with the new one if it's available on
                // the response object.
                //
                // This is an added optional step for better security. Once you sign
                // in using the token, you should generate a new one on the server
                // side and attach it to the response object. Then the following
                // piece of code can replace the token with the refreshed one.

                // if ( response.accessToken )
                // {
                //     this.accessToken = response.accessToken;
                // }
                // Set the authenticated flag to true
               
                if(response.success)
                {
                    this._authenticated = true;

                    // Store the user on the user service
                    this._userService.user = response.user;
                }

              
                // Return true
                return of(true);
            })
        );
    }
    
    /**
     * Sign out
     */
    signOut(): Observable<any>
    {
        return this._httpClient.post('logout',{}).pipe(catchError(()=>{
            return of(false);
        }),
          switchMap( (response: any) =>{

            console.log('response',response);
            // Remove the access token from the local storage
            localStorage.removeItem('accessToken');

            // Set the authenticated flag to false
            this._authenticated = false;

            // Return the observable
            return of(true);
            
           
          })  
        )
       
    }

    /**
     * Sign up
     *
     * @param user
     */
    signUp(user: { name: string; email: string; password: string; company: string }): Observable<any>
    {
        return this._httpClient.post('api/auth/sign-up', user);
    }

    /**
     * Unlock session
     *
     * @param credentials
     */
    unlockSession(credentials: { email: string; password: string }): Observable<any>
    {
        return this._httpClient.post('api/auth/unlock-session', credentials);
    }

    /**
     * Check the authentication status
     */
    check(): Observable<boolean>
    {
        // Check if the user is logged in
        if ( this._authenticated )
        {
            return of(true);
        }

        // Check the access token availability
        if ( !this.accessToken )
        {
            return of(false);
        }

        // Check the access token expire date
        if ( AuthUtils.isTokenExpired(this.accessToken) )
        {
            return of(false);
        }

        // If the access token exists and it didn't expire, sign in using it
        return this.signInUsingToken();
    }
}
