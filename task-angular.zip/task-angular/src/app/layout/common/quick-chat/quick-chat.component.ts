import { AfterViewInit, Component, ElementRef, HostBinding, HostListener, Inject, NgZone, OnDestroy, OnInit, Renderer2, ViewChild, ViewEncapsulation } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { ScrollStrategy, ScrollStrategyOptions } from '@angular/cdk/overlay';
import { Subject, map, takeUntil } from 'rxjs';
import { QuickChatService } from 'app/layout/common/quick-chat/quick-chat.service';
import { Chat } from 'app/layout/common/quick-chat/quick-chat.types';
import { ChatService } from 'app/modules/apps/chat/chat.service';
import { UserService } from 'app/core/user/user.service';
import { User } from 'app/core/user/user.types';
import { RestApiService } from 'app/services/rest-api.service';
import { AbstractControl, FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ChatForwardComponent } from 'app/modal/chat-forward/chat-forward.component';
import { MatDialog } from '@angular/material/dialog';
import { FuseConfirmationService } from '@fuse/services/confirmation';
import { AddChatGroupComponent } from 'app/modal/add-chat-group/add-chat-group.component';
import { ChatInformationComponent } from 'app/modal/chat-information/chat-information.component';
import { AddIndividualChatComponent } from 'app/modal/add-individual-chat/add-individual-chat.component';
import { DocumentViewerComponent } from 'app/modal/document-viewer/document-viewer.component';

@Component({
    selector     : 'quick-chat',
    templateUrl  : './quick-chat.component.html',
    styleUrls    : ['./quick-chat.component.scss'],
    encapsulation: ViewEncapsulation.None,
    exportAs     : 'quickChat'
})
export class QuickChatComponent implements OnInit, AfterViewInit, OnDestroy
{
    @ViewChild('messageInput') messageInput: ElementRef;
    chat: any;
    chats: Chat[];
    filteredChatGroups: any[];
    opened: boolean = false;
    searchShow:boolean = false;
    selectedChat: Chat;
    private _mutationObserver: MutationObserver;
    private _scrollStrategy: ScrollStrategy = this._scrollStrategyOptions.block();
    private _overlay: HTMLElement;
    private _unsubscribeAll: Subject<any> = new Subject<any>();
    user: User;
    chatgroups: any[];
    drawerComponent: 'profile' | 'new-chat';
    drawerOpened: boolean = false;
    isFileShow:boolean = false;
    users:any = [];
    /**
     * Constructor
     */
    constructor(
        @Inject(DOCUMENT) private _document: Document,
        private _elementRef: ElementRef,
        private _renderer2: Renderer2,
        private _ngZone: NgZone,
        private _quickChatService: QuickChatService,
        private _scrollStrategyOptions: ScrollStrategyOptions,
        private _chatService: ChatService,
        private _userService: UserService,
        private restApiService: RestApiService,
        private _httpClient : HttpClient,
        private _matDialog: MatDialog,
        private _formBuilder: FormBuilder,
        private _fuseConfirmationService:FuseConfirmationService
    )
    {
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Decorated methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Host binding for component classes
     */
    @HostBinding('class') get classList(): any
    {
        return {
            'quick-chat-opened': this.opened
        };
    }

    /**
     * Resize on 'input' and 'ngModelChange' events
     *
     * @private
     */
    @HostListener('input')
    @HostListener('ngModelChange')
    private _resizeMessageInput(): void
    {
        // This doesn't need to trigger Angular's change detection by itself
        this._ngZone.runOutsideAngular(() => {

            setTimeout(() => {

                // Set the height to 'auto' so we can correctly read the scrollHeight
                this.messageInput.nativeElement.style.height = 'auto';

                // Get the scrollHeight and subtract the vertical padding
                this.messageInput.nativeElement.style.height = `${this.messageInput.nativeElement.scrollHeight}px`;
            });
        });
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void
    {

        this.form = this._formBuilder.group({
            comment:'',
            to_id:[null,Validators.required],
            from_id:[null,Validators.required],
            parent_id:null,
            parent_type:null,
            files: this._formBuilder.array([]),
            
        }); 

        this._userService.user$
            .pipe((takeUntil(this._unsubscribeAll)))
            .subscribe((user: User) => {
                this.user = user;
                            
        });
        // Chat
        this._chatService.chat$
            .pipe(
                takeUntil(this._unsubscribeAll),
                map((chat : any) =>   this.chat = chat)
            ).subscribe((chat: any) => {
                if(this.chat)
                {
                    if(this.chatgroups)
                    {
                        this.isFileShow = false;
                        this.chatgroups.forEach((element: any, key: number) => {
                            if(this.chat.id == element.id)
                            {
                                if(this.chat.chats.length && this.chatgroups[key].chats.length)
                                    this.chatgroups[key].chats[this.chatgroups[key].chats.length - 1].read_ons = this.chat.chats[this.chat.chats.length -1].read_ons;
                            }
                        });
        
        
                        this._chatService._chatgroups.next(this.chatgroups);
                    }
                    
                    this.formArray = new FormArray(this.toGroups());
                    // Mark for check
                    this.form.controls['to_id'].setValue(chat.id);
                    this.form.controls['from_id'].setValue(this.user.id);
                    
                    (<FormArray>this.form.get('files')).reset(); 
                    (this.form.controls['files'] as FormArray).clear();
                    this.file_items.clear();
                    this.isFileShow = false;
                }
                
        
        });

        // Chats
        this._quickChatService.chats$
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe((chats: Chat[]) => {
                this.chats = chats;
        });

        this._chatService.chatgroups$
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe((chatgroups: any[]) => {
                this.chatgroups = this.filteredChatGroups = chatgroups;

        });

        this._chatService.users$
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe((users) => {
                this.users = users;
        });  

        // Selected chat
        this._chatService.chat$
            .pipe(
                takeUntil(this._unsubscribeAll),
                map((chat : any) =>   this.selectedChat = chat)
            ).subscribe((chat: any) => {
                if(this.chat)
                {
                    if(this.chatgroups)
                    {
                        this.isFileShow = false;
                        this.chatgroups.forEach((element: any, key: number) => {
                            if(this.chat.id == element.id)
                            {
                                if(this.chat.chats.length && this.chatgroups[key].chats.length)
                                    this.chatgroups[key].chats[this.chatgroups[key].chats.length - 1].read_ons = this.chat.chats[this.chat.chats.length -1].read_ons;
                            }
                        });
        
        
                        this._chatService._chatgroups.next(this.chatgroups);
                    }
                   

                    this.formArray = new FormArray(this.toGroups());
                    // Mark for check
                    this.form.controls['to_id'].setValue(chat.id);
                    this.form.controls['from_id'].setValue(this.user.id);

                    (<FormArray>this.form.get('files')).reset(); 
                    (this.form.controls['files'] as FormArray).clear();
                    this.file_items.clear();
                    this.isFileShow = false;
                }
        
        });
    }

    addGroup(){

        const dialogRef = this._matDialog.open(AddChatGroupComponent, {
            data: {
              users:this.users,
              action:'add'
            },
            width:'auto',
            height: 'auto'
        });
        dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(result => {
          if(result && result != null)
          {
                this.chatgroups.unshift(result)
                this._chatService._chatgroups.next(this.chatgroups);

          }
        },
        errRes=>{});
    }
    /**
     * After view init
     */
    ngAfterViewInit(): void
    {
        // Fix for Firefox.
        //
        // Because 'position: sticky' doesn't work correctly inside a 'position: fixed' parent,
        // adding the '.cdk-global-scrollblock' to the html element breaks the navigation's position.
        // This fixes the problem by reading the 'top' value from the html element and adding it as a
        // 'marginTop' to the navigation itself.
        this._mutationObserver = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                const mutationTarget = mutation.target as HTMLElement;
                if ( mutation.attributeName === 'class' )
                {
                    if ( mutationTarget.classList.contains('cdk-global-scrollblock') )
                    {
                        const top = parseInt(mutationTarget.style.top, 10);
                        this._renderer2.setStyle(this._elementRef.nativeElement, 'margin-top', `${Math.abs(top)}px`);
                    }
                    else
                    {
                        this._renderer2.setStyle(this._elementRef.nativeElement, 'margin-top', null);
                    }
                }
            });
        });
        this._mutationObserver.observe(this._document.documentElement, {
            attributes     : true,
            attributeFilter: ['class']
        });
    }

    /**
     * On destroy
     */
    ngOnDestroy(): void
    {
        // Disconnect the mutation observer
        this._mutationObserver.disconnect();

        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next(null);
        this._unsubscribeAll.complete();
    }

     /**
     * Filter the chats
     *
     * @param query
     */
     filterChatGroups(query: string): void
     {
         // Reset the filter
         if ( !query )
         {
             this.filteredChatGroups = this.chatgroups;
             return;
         }
 
         this.filteredChatGroups = this.chatgroups.filter(chatgroup => chatgroup.display_name.toLowerCase().includes(query.toLowerCase()));
     }
    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Open the panel
     */
    open(): void
    {
        // Return if the panel has already opened
        if ( this.opened )
        {
            return;
        }

        // Open the panel
        this._toggleOpened(true);
    }

    /**
     * Close the panel
     */
    close(): void
    {
        // Return if the panel has already closed
        if ( !this.opened )
        {
            return;
        }

        // Close the panel
        this._toggleOpened(false);
    }

    /**
     * Toggle the panel
     */
    toggle(): void
    {
        if ( this.opened )
        {
            this.close();
        }
        else
        {
            this.open();
        }
    }

    /**
     * Select the chat
     *
     * @param id
     */
    selectChat(id: string): void
    {
        // Open the panel
        this._toggleOpened(true);

        // Get the chat data
        this._chatService.getChatById(id).subscribe();
    }

    /**
     * Track by function for ngFor loops
     *
     * @param index
     * @param item
     */
    trackByFn(index: number, item: any): any
    {
        return item.id || index;
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Private methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Show the backdrop
     *
     * @private
     */
    private _showOverlay(): void
    {
        // Try hiding the overlay in case there is one already opened
        this._hideOverlay();

        // Create the backdrop element
        this._overlay = this._renderer2.createElement('div');

        // Return if overlay couldn't be create for some reason
        if ( !this._overlay )
        {
            return;
        }

        // Add a class to the backdrop element
        this._overlay.classList.add('quick-chat-overlay');

        // Append the backdrop to the parent of the panel
        this._renderer2.appendChild(this._elementRef.nativeElement.parentElement, this._overlay);

        // Enable block scroll strategy
        this._scrollStrategy.enable();

        // Add an event listener to the overlay
        this._overlay.addEventListener('click', () => {
            this.close();
        });
    }

    /**
     * Hide the backdrop
     *
     * @private
     */
    private _hideOverlay(): void
    {
        if ( !this._overlay )
        {
            return;
        }

        // If the backdrop still exists...
        if ( this._overlay )
        {
            // Remove the backdrop
            this._overlay.parentNode.removeChild(this._overlay);
            this._overlay = null;
        }

        // Disable block scroll strategy
        this._scrollStrategy.disable();
    }

    /**
     * Open/close the panel
     *
     * @param open
     * @private
     */
    private _toggleOpened(open: boolean): void
    {
        // Set the opened
        this.opened = open;

        // If the panel opens, show the overlay
        if ( open )
        {
            this._showOverlay();
        }
        // Otherwise, hide the overlay
        else
        {
            this._hideOverlay();
        }
    }

    form: FormGroup;

    onSubmit(data){
       
        
        this._httpClient.post<any>('send_chat',data).pipe(
            takeUntil(this._unsubscribeAll)
        ).subscribe( res => { 
  
            if(res.success)
            {
                this.form.reset();
                this.resetReply();
                this.chat.chats.push(res.data);
            

                this.chatgroups.forEach((element: any, key: number) => {
                    if(this.chat.id == element.id)
                    {
                        this.chatgroups[key].chats.push(res.data);
                    }
                });


                this._chatService._chatgroups.next(this.chatgroups);
                this._chatService._chat.next(this.chat);

                this.files = [];
                (<FormArray>this.form.get('files')).clear(); 
            
            }  
        });
    }

     /*******File Section Code******/

     files: File[] = [];
     upload_files: File[] = [];
     isUploadLoad:boolean = false;
 
     onFileSelect(event) {
 
         this.isUploadLoad = true;
 
         this.upload_files = [];
 
         this.files.push(...event.addedFiles);
         this.upload_files.push(...event.addedFiles);
 
         const formData = new FormData();
 
         for (var i = 0; i < this.upload_files.length; i++) { 
             formData.append("files[]", this.upload_files[i]);
         }
 
         console.log('files data',this.upload_files
         );
 
         this.restApiService.tempFileUpload(`chat`,formData).pipe(
             takeUntil(this._unsubscribeAll)
         ).subscribe( res => { 
             if(res.success)
             {
                 if(res.data.length > 0)
                 {
                     res.data.forEach(x => {
                         
                         this.file_items.push(
                             this._formBuilder.group({
                                     temp_id:x.id,
                                     file_path:x.file_path,
                                     file_name:x.file_name,
                                     file_size:x.file_size,
                                     file_extension:x.file_extension,
                                     file_description:[''],
                                     full_file_path:x.full_file_path,
                                     identifier:x.identifier,
                                     id:[''],
                             })    
                         );
                         
                         
                     });
 
                     
                 }
                 this.isUploadLoad = false;
 
             }
             this.messageInput.nativeElement.focus();
             
         });
         
 
     }
     onFileRemove(index) {
 
         this.file_items.removeAt(index);
         
 
     }
     get file_items() {
         return this.form.get('files') as FormArray;
     }
     setFiles(files){
         (<FormArray>this.form.get('files')).clear();
         files.forEach(x => {
         
             this.file_items.push(
                 this._formBuilder.group({
                         id:x.id,
                         file_path:x.file_path,
                         file_name:x.file_name,
                         file_size:x.file_size,
                         file_extension:x.file_extension,
                         file_description:x.file_description,
                         identifier:x.identifier,
                         temp_id:[''],
                 })    
             );
         })
     }
     fileDownload(item){
         const salt = (new Date()).getTime();
         return this._httpClient.post(`filedownload?salt=${salt}`,item, {responseType:'blob'}).subscribe(res => {
             var FileSaver = require('file-saver');
             const blob = new Blob([res]);
             FileSaver.saveAs(blob, item.file_name);
             
             
         }, err => {
             console.log(err);
         });
     }
     fileView(item){
        const dialogRef = this._matDialog.open(DocumentViewerComponent, {
            data: {
                file:item
            },
            width:'850px',
            height: '750px'
        });

        dialogRef.afterClosed().subscribe(result => {

            
        },
        errRes=>{});
    }
     /*******File Section Code End******/
 
     /********Reply Section Code********/
     isReplyShow:boolean = false;
     replyItem:any = '';
     setReply(item){
         console.log('item',item);
         this.isReplyShow = true;
         this.replyItem = item;
         this.form.controls['parent_id'].setValue(item.id);
         this.form.controls['parent_type'].setValue(1);
 
     }
     resetReply(){
         this.isReplyShow = false;
         this.replyItem = '';
         this.form.controls['parent_id'].setValue(0);
         this.form.controls['parent_type'].setValue(null);
     }
     /***********Forward Section Code************/
     setForward(item){
         console.log('item',item);
 
         const dialogRef = this._matDialog.open(ChatForwardComponent, {
             data: {
                 item:item,
                 from_id:this.user.id,
                 action:'forward'
             },
             width:'auto',
             height: 'auto'
         });
         dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(result => {
           if(result && result != null)
           {
              
 
           }
         },
         errRes=>{});
     }
     /**
     * Open the new chat sidebar
     */
    openNewChat(): void
    {
        this.drawerComponent = 'new-chat';
        this.drawerOpened = true;

    }
    addIndividual(){
        const dialogRef = this._matDialog.open(AddIndividualChatComponent, {
            data: {
              users:this.users,
              action:'add'
            },
            width:'auto',
            height: 'auto'
        });
        dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(result => {
          if(result && result != null)
          {
                console.log('result',result);
               // this.chatgroups.unshift(result)
                //this._chatService._chatgroups.next(this.chatgroups);

          }
        },
        errRes=>{});
    }
      /**********Message Inline Edit***********/
    formArray: FormArray;
    toGroups(): AbstractControl[] {
        return this.chat.chats.map((data:any) => {
            return new FormGroup({
            
           
                comment: new FormControl(data.comment),
            });
        });
    }
    updateField(item,index: number, field: string): void {
        const control = this.getControl(index, field);

        if (control.valid) {
            
            if(field == 'comment')
            {
                this.commentChange(control,item,index);
            }
        }
    }
    commentChange(control,item,index)
    {
        const dialogRef = this._fuseConfirmationService.open({
            "title": "Update Comment",
            "message": 'Are you sure you want to change comment of selected item?',
            "icon": {
                "show": true,
                "name": "heroicons_outline:exclamation",
                "color": "warn"
            },
            "actions": {
            "confirm": {
                "show": true,
                "label": "Okay",
                "color": "primary"
                },
                "cancel": {
                "show": true,
                "label": "Cancel"
                }
            },
            "dismissible": false
        });

        dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(result => {
            if ( result == 'confirmed' )
            {

                console.log('control',control);
                console.log('item',item);
                
                this.restApiService.update(`edit_chat/${item.id}`,{comment:control.value}).pipe(
                takeUntil(this._unsubscribeAll)
                ).subscribe( res => { 
                    if(res.success)
                    {
                        this.chat.chats[index].comment = control.value;

                        this.chatgroups.forEach((element: any, key: number) => {
                            if(this.chat.id == element.id)
                            {
                                this.chatgroups[key].chats[index].comment = control.value;
                            }
                        });


                        this._chatService._chatgroups.next(this.chatgroups);
                        this._chatService._chat.next(this.chat);
                    }

                });
                
                
            }
           // this.selection.clear();

        });
    }
    getControl(index: number, field: string): FormControl {
        return this.formArray.at(index).get(field) as FormControl;
    }
    cancel(index: number, field: string): void {
        const control = this.getControl(index, field);
        control.setValue(this.chat.chats[index][field]);
    }
    /*Unread Chat*/
    chatsReverse(convs)
    {
        let y = [...convs].reverse();
        return y;
    }
    unreadCount(convs)
    {
        let y = [...convs].reverse();
        let unreadCount = 0;
        y.forEach(element => {
            if(element.read_ons.length)
            {
                element.read_ons.forEach(elem => {
                    if(this.user.id == elem.user_id)
                    {
                        if(elem.is_read == 0)
                        {
                            unreadCount++;
                        }
                    }
                });
            }
        });
        return unreadCount;
    }
    lastChat(convs)
    {
        let y = [...convs].reverse();
        return y[0];
    }

    /***********Chat Info(Read/Deliver Info) Section Code************/
    getChatInfo(item){

        const dialogRef = this._matDialog.open(ChatInformationComponent, {
            data: {
                item:item,
               
            },
            width:'auto',
            height: 'auto'
        });
        dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(result => {
          if(result && result != null)
          {
             

          }
        },
        errRes=>{});
    }
}
