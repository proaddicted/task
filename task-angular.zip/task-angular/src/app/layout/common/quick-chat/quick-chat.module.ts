import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { FuseDrawerModule } from '@fuse/components/drawer';
import { FuseScrollbarModule } from '@fuse/directives/scrollbar';
import { SharedModule } from 'app/shared/shared.module';
import { QuickChatComponent } from 'app/layout/common/quick-chat/quick-chat.component';
import { MatListModule } from '@angular/material/list';
import { MatTabsModule } from '@angular/material/tabs';
import { MatTooltipModule } from '@angular/material/tooltip';
import { NgSelectModule } from '@ng-select/ng-select';
import { EDITABLE_CONFIG, EditableConfig, EditableModule } from '@ngneat/edit-in-place';
import { AvatarModule } from 'app/modules/apps/avatar/avatar.module';
import { NgxDropzoneModule } from 'ngx-dropzone';
import { MatMenuModule } from '@angular/material/menu';
import { MatSidenavModule } from '@angular/material/sidenav';

@NgModule({
    declarations: [
        QuickChatComponent
    ],
    imports     : [
        RouterModule,
        MatButtonModule,
        MatFormFieldModule,
        MatIconModule,
        MatInputModule,
        MatMenuModule,
        FuseDrawerModule,
        MatSidenavModule,
        FuseScrollbarModule,
        SharedModule,
        AvatarModule,
        NgxDropzoneModule,
        MatListModule,
        MatTooltipModule,
        MatTabsModule,
        MatListModule,
        EditableModule,
        NgSelectModule
    ],
    exports     : [
        QuickChatComponent
    ],
    providers : [
      
        
         {
          provide: EDITABLE_CONFIG, 
          useValue: {
            openBindingEvent: 'dblclick',
            closeBindingEvent: 'dblclick',
          } as EditableConfig
        }
  
    ]
})
export class QuickChatModule
{
}
