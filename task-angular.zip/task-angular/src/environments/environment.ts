// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
    production: true,
    apiUrl:"https://easycrm.co.in/application/public/api",
    apiCode:'dost',
    tinyMceKey:'z9aj46f92vbh9o5cnmddkev544zkoyk50dk247jcsx1m9rzm',
    pusherKey:'1cc6b432a41cda45e157',
    pusherCluster:'ap2',
    oneSignalAppId:"0b6c8586-5168-41f0-9cf3-cd70bbec885f",
    appUrl:'https://easycrm.co.in',
    hmr       : false
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
