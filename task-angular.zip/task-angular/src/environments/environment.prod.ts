export const environment = {
    production: true,
    apiUrl:"https://easycrm.co.in/application/public/api",
    apiCode:'dost',
    tinyMceKey:'z9aj46f92vbh9o5cnmddkev544zkoyk50dk247jcsx1m9rzm',
    pusherKey:'1cc6b432a41cda45e157',
    pusherCluster:'ap2',
    oneSignalAppId:"0b6c8586-5168-41f0-9cf3-cd70bbec885f",
    appUrl:'https://easycrm.co.in',
    hmr       : false
};
