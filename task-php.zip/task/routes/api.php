<?php

use App\Http\Controllers\BankAccountController;
use App\Http\Controllers\BranchController;
use App\Http\Controllers\CountryController;
use App\Http\Controllers\CurrencyController;
use App\Http\Controllers\FileUploadController;
use App\Http\Controllers\FiscalYearController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\MasterTypeController;
use App\Http\Controllers\ModuleController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\StateController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\NotificationTemplateController;
use App\Http\Controllers\AddressController;
use App\Http\Controllers\ServiceController;
use Illuminate\Support\Facades\Artisan;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::fallback(function(){
    return response()->json([
        'message' => 'Page Not Found. If error persists, contact info@rnjcs.in'], 404);
});


Route::any('store_all_files',[FileUploadController::class,'store_all_files']);

Route::post('/login',[LoginController::class, 'login']);
Route::post('forgot_password',[LoginController::class,'forgot_password'])->middleware(['masterauth']);
Route::post('reset_password/{id}',[LoginController::class,'reset_password'])->middleware(['masterauth']);

Route::middleware(['auth:api','masterauth'])->group(function () {

    Route::get('generate_link', function (){
        Artisan::call('storage:link');
        echo 'ok';
    });
    
    Route::any('change_password',[LoginController::class,'change_password']);
    Route::any('/logout',[LoginController::class,'logout']);

    Route::any('/testing',[LoginController::class,'testing']);

    Route::resource('user', UserController::class);
    Route::any('user_getlist',[UserController::class,'getlist']);
    Route::any('user_menu',[UserController::class,'createMenu']);
    Route::any('user_page_access',[UserController::class,'checkUserPageAccess']);
    Route::any('user_headers',[UserController::class,'headers']);
    Route::any('user_actionall',[UserController::class,'actionall']);
    Route::any('user_info',[UserController::class,'userInfo']);
    Route::any('user_advance_search_by_url',[UserController::class,'advanceSearchDataPageUrl']);
    Route::any('user_advance_search_delete/{id}',[UserController::class,'deleteAdvanceSearchData']);
    Route::any('user_change_password/{id}',[UserController::class,'change_password']);
    Route::get('server_time',[UserController::class,'server_time']);
    Route::any('add_device',[UserController::class,'add_device']);
    Route::any('add_user',[UserController::class,'add_user']);
    

    Route::resource('page', PageController::class);
    Route::any('page_headers',[PageController::class,'headers']);
    Route::any('page_actionall',[PageController::class,'actionall']);

    Route::resource('module', ModuleController::class);
    Route::any('module_getlist',[ModuleController::class,'getlist']);
    Route::any('module_headers',[ModuleController::class,'headers']);
    Route::any('module_actionall',[ModuleController::class,'actionall']);

    Route::resource('role', RoleController::class);
    Route::any('role_getlist',[RoleController::class,'getlist']);
    Route::any('role_headers',[RoleController::class,'headers']);
    Route::any('role_actionall',[RoleController::class,'actionall']);

    Route::resource('bank_account', BankAccountController::class);
    Route::any('bank_account_headers',[BankAccountController::class,'headers']);
    Route::any('bank_account_actionall',[BankAccountController::class,'actionall']);

    Route::resource('branch', BranchController::class);
    Route::any('branch_getlist',[BranchController::class,'getlist']);
    Route::any('branch_headers',[BranchController::class,'headers']);
    Route::any('branch_actionall',[BranchController::class,'actionall']);

    Route::resource('country',CountryController::class);
    Route::any('country_headers',[CountryController::class,'headers']);
    Route::any('country_actionall',[CountryController::class,'actionall']);

    Route::resource('state',StateController::class);
    Route::any('state_getlist',[StateController::class,'getlist']);
    Route::any('state_headers',[StateController::class,'headers']);
    Route::any('state_actionall',[StateController::class,'actionall']);

    Route::resource('currency',CurrencyController::class);
    Route::any('currency_headers',[CurrencyController::class,'headers']);
    Route::any('currency_actionall',[CurrencyController::class,'actionall']);

    Route::resource('fiscalyear',FiscalYearController::class);
    Route::any('fiscalyear_headers',[FiscalYearController::class,'headers']);
    Route::any('fiscalyear_actionall',[FiscalYearController::class,'actionall']); //23/09/2024

    Route::any('fileupload',[FileUploadController::class,'fileupload']);
    Route::post('filedownload',[FileUploadController::class,'filedownload']);
    Route::any('main_fileupload/{id}/',[FileUploadController::class,'mainfileupload']);
    Route::any('main_filedelete/{id}/',[FileUploadController::class,'mainfiledelete']);
    Route::any('main_fileupdate/{id}/',[FileUploadController::class,'mainfileupdate']);
    Route::any('main_fileupdate_all/{id}/',[FileUploadController::class,'mainfileupdateall']);
    Route::post('tempfileupload_base64',[FileUploadController::class,'tempfileupload_base64']);
    Route::any('mainfileupload_base64/{id}/',[FileUploadController::class,'mainfileupload_base64']);
    Route::any('file_excel_export',[FileUploadController::class,'export']);
    Route::any('file_list_actionall',[FileUploadController::class,'actionall']); //23/09/2024

    Route::resource('file_list', FileUploadController::class);
    Route::get('file_list_headers',[FileUploadController::class,'headers']);
    Route::get('file_list_getlist',[FileUploadController::class,'getlist']);
    Route::any('file_request',[FileUploadController::class,'file_request']);
    Route::any('get_file_array',[FileUploadController::class,'get_file_array']);

    Route::resource('type', MasterTypeController::class);
    Route::any('type_headers',[MasterTypeController::class,'headers']);
    Route::any('type_actionall',[MasterTypeController::class,'actionall']);

    Route::resource('notification_template',NotificationTemplateController::class);
    Route::any('notification_template_headers',[NotificationTemplateController::class,'headers']);
    Route::any('notification_template_actionall',[NotificationTemplateController::class,'actionall']);

    Route::any('address_update/{id}/',[AddressController::class,'update']);


    Route::resource('service', ServiceController::class);
    Route::any('service_getlist',[ServiceController::class,'getlist']);
    Route::any('service_headers',[ServiceController::class,'headers']);
    Route::any('service_actionall',[ServiceController::class,'actionall']);
});
