<?php

namespace App\Exports;

use Maatwebsite\Excel\Excel;
use Illuminate\Contracts\Support\Responsable;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromQuery;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\WithMapping;
use Modules\TaskManager\Entities\Task;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;
use Carbon\Carbon;
class TaskExcelExport implements FromQuery,WithHeadings,WithMapping
{   
    use Exportable;
    
    public $request,$headings,$obj, $service_tree_element,$ticket_services;
    public function __construct($request,$headings) {
        $this->request = $request;
        $this->headings = $headings;
    }
    public function headings(): array
    {
        return $this->headings;
    }
    public function query()
    {
        $query = QueryBuilder::for(Task::class)->allowedFilters(['name','description', AllowedFilter::exact('parent_id')->ignore(null), AllowedFilter::exact('status')->ignore(null), AllowedFilter::exact('priority')->ignore(null), AllowedFilter::exact('type')->ignore(null), AllowedFilter::exact('ist_type')->ignore(null)])->defaultSort('-created_at')->allowedSorts('name','description','start_date','received_date','due_date','ecd','completed_date','start_period','end_period','recursive_end_date','recursive_days','recursive_last_created','status','type','priority','ist_type');
        $query->search(!empty($this->request['search'])?$this->request['search']:"");

        $task_type='';
        if(isset($this->request->filter['type']))
        $task_type=$this->request->filter['type'];
       
        if(count($this->request['filter'])>0)
        {
            foreach($this->request['filter'] as $key=> $val)
            {
                $query->where($key,$val);
            }
        }
        return $query->taskadvanceSearch($this->request['advfilter'],'tasks',$task_type)->with('services','contacts','companies','employees','files','check_lists','members','supervisor','manager');
    }

    public function map($task): array
    {
        $this->ticket_services=[];
        $data=[]; 
        $company=[];
        $services=[];
        $contacts=[];
        $employees=[];
        if(count($task->companies)>0)
        { 
            foreach($task->companies as $comp)
            {
                $company[]=$comp->full_name;
            }
        }
        if(count($task->contacts)>0)
        { 
            foreach($task->contacts as $con)
            {
                $contacts[]=$con->full_name;
            }
        }
        if(count($task->services)>0)
        { 
            foreach($task->services as $serv)
            {
                $this->service_tree_element=[];
                $this->service_tree($serv);
            }
        }
        if(count($task->employees)>0)
        { 
            foreach($task->employees as $emp)
            {
                $employees[]=$emp->name;
            }
        }
        if($this->request['filter']['type']==='regular-ticket')
        {
            foreach ($this->headings as $heading) {
                switch ($heading) {
                    case 'Name':
                        $data[] = $task->name;
                        break;
                    case 'Company':
                        $data[] = count($company)>0?implode(',',$company):'';
                        break;    
                    case 'Contacts':
                        $data[] = count($contacts)>0?implode(',',$contacts):'';
                        break;      
                    case 'Services':
                        $data[] = count($this->ticket_services)>0?implode(',',$this->ticket_services):'';
                        break; 
                    case 'Employees':
                        $data[] = count($employees)>0?implode(',',array_unique($employees)):'';
                        break; 
                    case 'Status':
                        $data[] = $task->status_name;
                        break; 
                    case 'Priority':
                        $data[] = $task->priority_name;
                        break; 
                    case 'Due Date':
                        $data[] =Carbon::parse($task->due_date)->format('d F Y g:i A');
                        break;
                    case 'Added On':
                        $data[] = Carbon::parse($task->created_at)->format('d F Y g:i A');
                        break;       
                    case 'Updated On':
                        $data[] = Carbon::parse($task->updated_at)->format('d F Y g:i A');           
                        break;     
                    default:
                        $data[] = ''; 
                        break;
                }
            }
        }
        return $data;
    }
    function service_tree($service)
    {
        $this->service_tree_element[]=$service->name;
        if($service->parent!=null)
        {
            $this->service_tree($service->parent);
        }
        else{
            $this->ticket_services[]='['.implode('>',array_reverse($this->service_tree_element)).']';
        }

    }
}
