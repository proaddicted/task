<?php

namespace App\Exports;

use App\Models\User;
// use Modules\ContactManaget\Entities\Contact;

use Maatwebsite\Excel\Excel;
use Illuminate\Contracts\Support\Responsable;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromQuery;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\WithMapping;
use Modules\ContactManager\Entities\Contact;//03/06/24
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;
use Carbon\Carbon;


class ContactExport implements FromQuery,WithHeadings,WithMapping
{

    use Exportable;
    
    public $request,$headings,$obj;
    public function __construct($request,$headings) {
        $this->request = $request;
        // dd($this->request->toArray());
        $this->headings = $headings;
    }
    /**
    * @return \Illuminate\Support\Collection
    */
    public function query()
    {
        $query = QueryBuilder::for(Contact::class)->allowedFilters(['fname','lname','mname',
        AllowedFilter::exact('contact_source_id')->ignore(null),
        AllowedFilter::exact('contact_type_id')->ignore(null),
        AllowedFilter::exact('phone')->ignore(null),AllowedFilter::exact('email')->ignore(null),AllowedFilter::exact('type')->ignore(null)])->defaultSort('fname')->allowedSorts('fname','lname','mname','created_at','phone','email','updated_at');

        $query->search(!empty($this->request['search'])?$this->request['search']:"");
        if(count($this->request['filter'])>0)
        {
            foreach($this->request['filter'] as $key=> $val)
            {
                $query->where($key,$val);
            }
        }

        return  $query->with('group','employee','contact','company')->advanceSearch($this->request['advfilter'],'contacts');

       /* $query = QueryBuilder::for(Contact::class)->allowedFilters(['fname','lname','mname',
        AllowedFilter::exact('contact_source_id')->ignore(null),
        AllowedFilter::exact('contact_type_id')->ignore(null),
        AllowedFilter::exact('phone')->ignore(null),AllowedFilter::exact('email')->ignore(null),AllowedFilter::exact('type')->ignore(null)])->defaultSort('fname')->allowedSorts('fname','lname','mname','created_at','phone','email','updated_at');

        $query->where('type',$this->request->type);

        $query->search(!empty($this->request->search)?$this->request->search:"");

        return  $query->with('group','employee','contact','company');*/

    }

    public function headings(): array
    {
        return $this->headings;
    }

    public function map($contact): array
    {
        $data=[];

        $company=[];
        $contacts=[];

        if($contact->type=='individual')
        {
            if(count($contact->company)>0)
            {
                foreach($contact->company as $con)
                {
                    $company[]=$con->full_name;
                }
            }

        }
        else
        {
            if(count($contact->contact)>0)
            {
                foreach($contact->contact as $con)
                {
                    $contacts[]=$con->full_name;
                }
            }
        }
        foreach ($this->headings as $heading) {
            switch ($heading) {
                case 'Name':
                    $data[] = $contact->full_name;
                    break;
                case 'Email':
                    $data[] = $contact->email;
                    break;
                case 'Phone':
                    $data[] = $contact->phone; // Handle null relationships
                    break;
                case 'Company':
                    $data[]=count($company)>0?implode(',',$company):'';
                    break;
                case 'Group':
                    $data[]= isset($contact->group->name)?$contact->group->name:'';
                    break;
                case 'Responsible Person':
                    $data[]= isset($contact->employee->fname)?$contact->employee->full_name:'';
                    break;
                case 'Contacts Name':
                    $data[]=count($contacts)>0?implode(',',$contacts):'';  
                    break;    
                case 'Updated At':
                    $data[] =Carbon::parse($contact->updated_at)->format('d F Y g:i A');
                    break;
                case 'Created At':
                    $data[] = Carbon::parse($contact->created_at)->format('d F Y g:i A');
                    break;
                default:
                    $data[] = ''; // Default to an empty string if the heading is not matched
                    break;
            }
        }
        return $data;
    }
}
