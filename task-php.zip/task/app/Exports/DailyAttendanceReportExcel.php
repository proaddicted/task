<?php

namespace App\Exports;

use Maatwebsite\Excel\Excel;
use Illuminate\Contracts\Support\Responsable;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromQuery;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\WithMapping;
use Modules\AttendanceManager\Entities\DailyAttendanceReport;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;
use Carbon\Carbon;

class DailyAttendanceReportExcel implements FromQuery,WithHeadings,WithMapping
{
    use Exportable;
    
    public $request,$headings,$obj, $service_tree_element,$ticket_services;
    public function __construct($request,$headings) {
        $this->request = $request;
        $this->headings = $headings;
    }
    public function headings(): array
    {
        return $this->headings;
    }
    public function query()
    {
        $query = QueryBuilder::for(DailyAttendanceReport::class)->allowedFilters(['date','reason','description','time',AllowedFilter::exact('company_id')->ignore(null),AllowedFilter::exact('service_id')->ignore(null),AllowedFilter::exact('task_id')->ignore(null),AllowedFilter::exact('emp_id')->ignore(null)])->defaultSort('-date')->allowedSorts('date','reason','updated_at','created_at');

        $query->search(!empty($this->request['search'])?$this->request['search']:"");
        if(count($this->request['filter'])>0)
        {
            foreach($this->request['filter'] as $key=> $val)
            {
                $query->where($key,$val);
            }
        }
       return $query->withSum('expenses as given_expense', 'daily_attendance_expenses.given_cost')->withSum('expenses as approved_expense', 'daily_attendance_expenses.approved_cost')->with('employee','company','service','expenses','files')->advanceSearch($this->request['advfilter'],'daily_attendance_reports');
    }

    public function map($attendance_report): array
    {
        $this->ticket_services=[];
        $data=[]; 
        $company=[];
        $services=[];
        $contacts=[];
        $employees=[];
        foreach ($this->headings as $heading) {
            switch ($heading) {
                case 'Employee':
                    $data[] =isset($attendance_report->employee->id)? $attendance_report->employee->full_name:'';
                    break;
                case 'Company':
                    $data[] =isset($attendance_report->company->id)? $attendance_report->company->fname:'';
                    break;    
                case 'Reason':
                    $data[] = $attendance_report->reason;
                    break;   
                case 'Task':
                        $data[] =!empty($attendance_report->task)? $attendance_report->task->name:'';
                        break;    
                case 'Date':
                    $data[] = ($attendance_report->date!='' & $attendance_report->date!=null)?Carbon::parse($attendance_report->date)->format('d F Y'):'';
                    break; 
                case 'Description':
                    $data[] =$attendance_report->description;
                    break; 
                case 'Status':
                    $data[] = $attendance_report->status_name;
                    break; 
                case 'Time':
                    $data[] = $attendance_report->time;
                    break; 
                case 'Requested Expense':
                    $data[] =isset($attendance_report->given_expense)?$attendance_report->given_expense:'';
                    break;
                case 'Approved Expense':
                    $data[] =isset($attendance_report->approved_expense)?$attendance_report->approved_expense:'';
                    break;       
                case 'Last Updated':
                    $data[] = Carbon::parse($attendance_report->updated_at)->format('d F Y g:i A');           
                    break;     
                default:
                    $data[] = ''; 
                    break;
            }
        }
        return $data;
    }
}
