<?php

namespace App\Exports;

use Maatwebsite\Excel\Excel;
use Illuminate\Contracts\Support\Responsable;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromQuery;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\WithMapping;
use Modules\LeaveManager\Entities\LeaveApplication;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;
use Carbon\Carbon;

class LeaveApplicationExcel implements FromCollection,WithHeadings,WithMapping
{
    use Exportable;

    public $request,$headings;
    public function __construct($request,$headings){
        $this->request = $request;
        $this->headings = $headings;
    }
    public function headings(): array
    {
        return $this->headings;
    }
    public function query()
    {
        $query = QueryBuilder::for(LeaveApplication::class)->allowedFilters(['leave_type_id','description',AllowedFilter::exact('employee_id')->ignore(null),AllowedFilter::exact('user_type_id')->ignore(null)])->defaultSort('leave_type_id')->allowedSorts('name','leave_type','is_halfday','status_name','start_date','end_date','description','updated_by','created_by','updated_at','created_at');

        $query->search(!empty($this->request['search'])?$this->request['search']:"");

        if(count($this->request['filter'])>0)
        {
            foreach($this->request['filter'] as $key=> $val)
            {
                $query->where($key,$val);
            }
        }

        return $query->with('employees','assignEmployees','leave_type')->advanceSearch($this->request['advfilter'],'leave_applications');

    }
    public function map($leave_application): array
    {
        $assignEmployees=[];
        if(count($leave_application->assignEmployees)>0)
        { 
            foreach($leave_application->assignEmployees as $emp)
            {
                $assignEmployees[]=$emp->name;
            }
        }
        
        foreach ($this->headings as $heading) {
            
            switch ($heading) {
                case 'Employee Name':
                    $data[]= isset($leave_application->employees->name)?$leave_application->employees->name:'';
                    break;
                case 'Leave Type':
                    $data[]= isset($leave_application->leave_type->name)?$leave_application->leave_type->name:'';
                    break;
                case 'Start Date':
                    $data[] =Carbon::parse($leave_application->start_date)->format('d F Y g:i A');
                    break;
                case 'End Date':
                    $data[] =Carbon::parse($leave_application->end_date)->format('d F Y g:i A');
                    break;
                case 'No of Days':
                    $data[] = $leave_application->is_halfday == 1 ? ($leave_application->first_second_half == 1 ? '1st Half' : '2nd Half') : $leave_application->no_of_days;  // 25/09/2024 Jyoti
                    break;
                case 'Half Day':
                    $data[]=    $leave_application->is_halfday == 1 ? 'Yes' : 'No';
                    break;
                case 'Assign Emoloyees':
                    $data[]=count($assignEmployees)>0?implode(',',$assignEmployees):'';
                    break;
                case 'Description':
                    $data[] = $leave_application->description;
                    break;
                case 'Status':
                    $data[] = $leave_application->status_name;
                    break; 
                case 'Updated At':
                    $data[] =Carbon::parse($leave_application->updated_at)->format('d F Y g:i A');
                    break;
                case 'Created At':
                    $data[] = Carbon::parse($leave_application->created_at)->format('d F Y g:i A');
                    break;
                case 'Added By':
                    $data[] = isset($leave_application->creator->name)?$leave_application->creator->name:'';;
                    break;       
                case 'Updated By':
                    $data[] = isset($leave_application->editor->name)?$leave_application->editor->name:'';;           
                    break; 
                default:
                    $data[] = ''; // Default to an empty string if the heading is not matched
                    break;
            }
        }
        return $data;
    }







    public function collection()
    {
        return LeaveApplication::all();
    }
}
