<?php

namespace App\Exports;

use Maatwebsite\Excel\Excel;
use Illuminate\Contracts\Support\Responsable;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromQuery;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\WithMapping;
use Modules\TaskManager\Entities\CallLog;
use Modules\ResourceManager\Entities\Employee;
use Modules\ContactManager\Entities\Contact;

use Modules\TaskManager\Entities\Task;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;
use Carbon\Carbon;
class CallLogExcelExport implements FromQuery,WithHeadings,WithMapping
{   
    use Exportable;
    
    public $request,$headings,$obj, $service_tree_element,$ticket_services,$page_name;
    public function __construct($request,$headings,$page_url) {
        $this->request = $this->request;
        $this->headings = $headings;
        $page=explode('/',$page_url);
        $this->page_name=end($page);
    }
    public function headings(): array
    {
        return $this->headings;
    }
    public function query()
    {

        $filter_value='';
        $filter_column='';

        if($this->page_name=='missed-call-list')
        {
            $filter_column='call_status';
            $filter_value='Missed';
        }
        elseif($this->page_name=='connected-call-list')
        {
            $filter_column='call_status';
            $filter_value='Connected';
        } 
        elseif($this->page_name=='incoming-call-list')
        {
            $filter_column='call_type';
            $filter_value='incoming';
        } 
        elseif($this->page_name=='outgoing-call-list')
        {
            $filter_column='call_type';
            $filter_value='outgoing';
        } 

        $query = QueryBuilder::for(CallLog::class)->allowedFilters(['identifier','call_status','call_type'])->defaultSort('-created_at')->allowedSorts('identifier','call_status','call_type');

        $query->search(!empty($this->request['search'])?$this->request['search']:"");
        
        if($filter_value!='' &&  $filter_column!='')
            $query->where($filter_column,$filter_value);

        $table='call_logs';
        
        if(isset($this->request['advfilter']))
        {
            foreach ($this->request['advfilter'] as $key => $value) {
                $parm = explode('-',$key);
                if(count($parm) >= 2)
                {
                    $tableColumn = $table.".".$parm[0];
                    if ($parm[1] == 'like')
                    {    
                            $query->where($tableColumn,"LIKE","%".$value."%");
                    }
                    elseif($parm[1]=='eq')
                    {
                            $query->where($tableColumn,$value);
                    }
                    elseif ($parm[1] == 'nlike')
                    {
                            $query->where($tableColumn,"NOT LIKE","%".$value."%");
                    }
                    elseif ($parm[1] == 'neq') 
                    {
                            $query->where($tableColumn,'<>',$value);
                    }
                    elseif ($parm[1] == 'in') 
                    {
                            $query->whereIn($tableColumn,[$value]);
                    }
                    elseif ($parm[1] == 'nin') 
                    {
                            $query->whereNotIn($tableColumn,[$value]);
                    }
                    elseif ($parm[1] == 'between')
                    {
                        
                        if(is_array($value) && count($value) == 2)
                            $query->whereBetween($tableColumn,[$value[0],$value[1]]);
                        elseif (!empty($value) && count(explode(',',$value))) {
                            if($parm[0] == 'created_at' || $parm[0] == 'updated_at' || $parm[0] == 'date' || $parm[0] == 'start_date' || $parm[0] == 'received_date' || $parm[0] == 'due_date' || $parm[0] == 'ecd' || $parm[0] == 'completed_date')
                            {
                                $values = explode(',',$value);
                                $query->whereRaw('DATE('.$tableColumn.') BETWEEN ? and ?',[$values[0],$values[1]]);
                            }
                        }
                        else    
                            $query->whereRaw('1=1');    
                    }       
                    else
                    {
                        $query->whereRaw('1=1');
                    }
                }
                
            }
        }
        return $query->checkPermission('created_by')->with('taskcall');
    }

    public function map($call): array
    {
            /********Call Type********* */
            if($call->call_type=='outgoing')
            { 
                    $caller_number=str_replace('+91', '', $call->agent_number);
                    $called_number=str_replace('+91', '', $call->called_number);
                    $agent=Employee::where('phone',str_replace('+91', '', $call->agent_number))->first();
                    $called_person=Contact::where('phone',str_replace('+91', '', $call->called_number))->first();
            }
            else
            {
                $caller_number=str_replace('+91', '', $call->caller_number);
                $called_number=str_replace('+91', '', $call->agent_number);
                $agent=Contact::where('phone',str_replace('+91', '', $call->caller_number))->first();
                $called_person=Employee::where('phone',str_replace('+91', '', $call->agent_number))->first();
            }

            /***********Rating Employee***************/
            $rating='';

            if(intval($call->rating_emp_id))
            {
                for ($i=1; $i <=5; $i++) { 
                    if($i<=$call->rating)
                    $rating.='★';
                    else
                    $rating.='☆';
                }
                $ratingemployee=Employee::find($call->rating_emp_id);
            }

            /********Status********* */
            if($call->call_status=='Missed' && $call->call_transfer_status=='Connected' && $call->call_type=='outgoing')
            {
                $status='Contact Not Connected';
            }
            elseif ($call->call_status=='Missed' && $call->call_transfer_status=='Connected' && $call->call_type=='incoming') {
                $status='Employee Not Connected';
            }
            elseif ($call->call_status=='Connected' && $call->call_transfer_status=='Connected') {
                $status='Connected';
            }
            else {
                $status='Call Transfer Failed';
            }

            /*************Task************ */
            $task_name='';
            if($call->taskcall!=null){
                $task_name=$call->taskcall->name;
            }
            foreach ($this->headings as $heading) {
                switch ($heading) {
                    case 'Call Type':
                        $data[] = $call->call_type;
                        break;
                    case 'Call Date':
                        $data[] = Carbon::parse($call->call_date)->format('d F Y g:i A');
                        break;    
                    case 'Task Name':
                        $data[] =$task_name;
                        break;    
                    case 'Caller Name':
                        $data[] = isset($agent->id)?$agent->full_name.'['.$caller_number.']':$caller_number;
                        break; 
                    case 'Called Person':
                        $data[] = isset($called_person->id)?$called_person->full_name.'['.$called_number.']':$called_number;
                        break; 
                    case 'Status':
                        $data[] = $status;
                        break; 
                    case 'Duration':
                        $data[] =$call->duration;
                        break;
                    case 'Call Rating':
                        $data[] = $rating;
                        break;       
                    case 'Rating Employee':
                        $data[] =intval($call->rating_emp_id)>0? $ratingemployee->full_name:'';
                        break;  
                    case 'Rating Remarks':
                        $data[] =$call->remarks;
                        break;    
                    case 'Movement Status':
                        $data[] =$call->call_move_status;
                        break;
                    case 'Recording':
                        $data[] =$call->recording_url;
                        break;
                    default:
                        $data[] = ''; 
                        break;
                }
            }
        return $data;
    }
   
}
