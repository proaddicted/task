<?php

namespace App\Exports;
use Maatwebsite\Excel\Excel;
use Illuminate\Contracts\Support\Responsable;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromQuery;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\WithMapping;
use Modules\ContactManager\Entities\Group;

use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;
use Carbon\Carbon;
class GroupExcelExport implements FromQuery,WithHeadings,WithMapping
{
    use Exportable;
    
    public $request,$headings;
    public function __construct($request,$headings) {
        $this->request =$request;
        $this->headings = $headings;
    }
    public function headings(): array
    {
        return $this->headings;
    }

    public function query()
    {
        $query = QueryBuilder::for(Group::class)->allowedFilters(['name','description',AllowedFilter::exact('emp_id')->ignore(null)])->defaultSort('name')->allowedSorts('name','description','updated_at','created_at');

        $query->search(!empty($this->request['search'])?$this->request['search']:"");

        return $query->with('employee','companies')->advanceSearch($this->request['advfilter'],'groups');
       
    }
    public function map($group): array
    {
    //    dd($group->companies);
       $companies=[];
       if(count($group->companies)>0)
       { 
           foreach($group->companies as $comp)
           {
               $companies[]=$comp->fname;
           }
       }
        foreach ($this->headings as $heading) {
            switch ($heading) {
                case 'Group Name':
                    $data[] =$group->name;
                    break;
                case 'Companies':
                    $data[] =count($companies)>0?implode(',',$companies):'';
                    break; 
                case 'Responsible Person':
                    $data[] =isset($group->employee->id)?$group->employee->full_name:'';
                    break;      
                case 'Last Updated':
                    $data[] = ($group->updated_at!='' & $group->updated_at!=null)?Carbon::parse($group->updated_at)->format('d F Y'):'';
                    break;      
                default:
                    $data[] = ''; 
                    break;
            }
        }
        return $data;
    }
}
