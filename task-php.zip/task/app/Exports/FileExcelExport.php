<?php

namespace App\Exports;

use Maatwebsite\Excel\Excel;
use Illuminate\Contracts\Support\Responsable;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromQuery;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Illuminate\Support\Facades\DB;
use App\Models\File;
use Modules\ContactManager\Entities\Contact;

use Maatwebsite\Excel\Concerns\WithMapping;
use Modules\TaskManager\Entities\Task;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;
use Carbon\Carbon;

class FileExcelExport implements FromQuery,WithHeadings,WithMapping
{

    use Exportable;
    
    public $email;
   

    public $request,$headings,$obj, $service_tree_element,$ticket_services;
    public function __construct($request,$headings) {
        $this->request = $request;
        $this->headings = $headings;
    }
    public function headings(): array
    {
        return $this->headings;
    }
    public function query()
    {
        $query = QueryBuilder::for(File::class)->allowedFilters(['start_date','created_by','file_extension',AllowedFilter::exact('created_by')->ignore(null),
        AllowedFilter::exact('created_by')->ignore(null)])->defaultSort('start_date')->allowedSorts('file_name','file_size','is_client_access','start_date','end_date','document_date');

        $query->search(!empty($this->request['search'])?$this->request['search']:"");
     
        return $query->with('creator','company.group','attendance_reports.company.group','tasks.companies.group')->fileadvanceSearch($this->request['advfilter'],'files')->orderBy('id','desc');//13/09/2024
    }

    public function map($file): array
    {
       
        $tasks_name='';
        $tasks_status='';

        $companies=[];
        $contacts=[];
        $groups=[];
        if(isset($file['tasks']) && $file['tasks']!=null)
        { 
            $getTask=Task::find($file['tasks']->id);
            $tasks_name=$getTask->name;
            $tasks_status=$getTask->status_name;
            
            if(count($file['tasks']->companies))
            {
                foreach($file['tasks']->companies as $comp)
                {
                    $companies[]=$comp->fname;
                    if(isset($comp->group))
                        $groups[]=$comp->group->name;
                }
            }
        }
        elseif ($file['tasks']==null && $file->identifier =='contact') {
            $contact=Contact::find($file->main_id);
            if($contact->type=='company')
            $companies[]=$contact->full_name;
            else
            $contacts[]=$contact->full_name;
        }

        if(intval($file->file_size))
           $file_size=$this->bytesToKb(intval($file->file_size));
        else
            $file_size='0KB';

        foreach ($this->headings as $heading) {
            switch ($heading) {
                case 'Name':
                    $data[] = $file->file_name;
                    break;
                case 'Group':
                    $data[] = count($groups)>0?implode(',',$groups):'';
                    break;
                case 'Company':
                    $data[] = count($companies)>0?implode(',',$companies):'';
                    break;
                case 'Task':
                    $data[] =$tasks_name;
                    break;
                case 'Task Status':
                    $data[] =$tasks_status;
                    break;
                case 'Identifier':
                    $data[] = $file->identifier;
                    break;
                case 'File Size':
                    $data[] = $file_size;
                    break;
                case 'Added On':
                    $data[] = Carbon::parse($file->created_at)->format('d F Y g:i A');
                    break;       
                case 'Added By':
                    $data[] = $file->creator->name;           
                    break;    
                case 'Link':
                    $data[] = 'http://127.0.0.1:8000/storage'.$file->file_path;           
                    break;      
                default:
                    $data[] = ''; 
                    break;
            }

            // echo ;
            //http://127.0.0.1:8000/storage/users/1717761291.jpeg
            //https://easycrm.co.in/application/public/storage/users/1726062738.jpeg
            //  exit;
        }
        return $data;
    }
    function bytesToKb($bytes) {
        $kb=$bytes / 1024;
        if($kb > 1024)
         return  $this->bytesToMb($kb);
        else
         return number_format($kb,2).'KB'; 
    }
    function bytesToMb($kbytes) {
        $mb=$kbytes / 1024;
        return number_format($mb,2).'MB'; 
    }
}
