<?php

namespace App\Exports;
use Maatwebsite\Excel\Excel;
use Illuminate\Contracts\Support\Responsable;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromQuery;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\WithMapping;
use Modules\AttendanceManager\Entities\DailyAttendance;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;
use Carbon\Carbon;

class DailyAttendanceExcel implements FromQuery,WithHeadings,WithMapping
{
    use Exportable;
    
    public $request,$headings;
    public function __construct($request,$headings) {
        $this->request = $request;
        $this->headings = $headings;
    }
    public function headings(): array
    {
        return $this->headings;
    }
    public function query()
    {
        $query = QueryBuilder::for(DailyAttendance::class)->allowedFilters(['date',AllowedFilter::exact('user_id')->ignore(null),
        AllowedFilter::exact('emp_id')->ignore(null)])->defaultSort('date')->allowedSorts('date','start_date_rime','end_date_rime','created_at','updated_at','remarks','start_address','end_address','schedule_in','schedule_out','schedule_break','start_time','end_time');

        $query->search(!empty($this->request['search'])?$this->request['search']:"");
        if(count($this->request['filter'])>0)
        {
            foreach($this->request['filter'] as $key=> $val)
            {
                $query->where($key,$val);
            }
        }
        return $query->with('employee','reason')->advanceSearch($this->request['advfilter'],'daily_attendances');

        
    }

    public function map($daily_attendance): array
    {
        
        $data=[]; 
        $company=[];
        $services=[];
        $contacts=[];
        $employees=[];
        foreach ($this->headings as $heading) {
            switch ($heading) {
                case 'Employee':
                    $data[] =isset($daily_attendance->employee->id)? $daily_attendance->employee->full_name:'';
                    break;
                case 'Date':
                    $data[] = ($daily_attendance->date!='' & $daily_attendance->date!=null)?Carbon::parse($daily_attendance->date)->format('d F Y'):'';
                    break; 
                case 'Schedule In':
                    $data[] = $daily_attendance->schedule_in;
                    break;      
                case 'Schedule Out':
                    $data[] = $daily_attendance->schedule_out;
                    break;      
                case 'Schedule Break':
                    $data[] =$daily_attendance->schedule_break;
                    break; 
                case 'Start Time':
                    $data[] =$daily_attendance->start_time;
                    break; 
                case 'Start Date Time':
                    $data[] =$daily_attendance->start_date_rime;
                    break;    
                case 'End Time':
                    $data[] = $daily_attendance->end_time;
                    break; 
                case 'End Date Time':
                    $data[] =$daily_attendance->end_date_rime;
                    break;
                case 'Start Address':
                    $data[] =$daily_attendance->start_address;
                    break;       
                case 'End Address':
                    $data[] = $daily_attendance->end_address;
                    break;     
                case 'Reason':
                    $data[] = isset($daily_attendance->reason->name)? $daily_attendance->reason->name:'';
                    break;     
                case 'Remarks':
                    $data[] =$daily_attendance->remarks;
                    break;     
                default:
                    $data[] = ''; 
                    break;
            }
        }
        return $data;
    }
}

