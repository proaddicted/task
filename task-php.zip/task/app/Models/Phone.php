<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;

use Illuminate\Database\Eloquent\Relations\Relation;
use Modules\ResourceManager\Entities\Employee;
use Modules\ContactManager\Entities\Contact;
use Modules\TaskManager\Entities\Officer;


class Phone extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait;
    protected $fillable = ['phone_type_id','phone_no','main_id','identifier','is_default','status'];
    
    protected $searchableColumns = ['phone_no'];

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }

    public function main()
    {
        return $this->morphTo(null, 'identifier', 'main_id');
    }

    public function phone_type()
    {
        return $this->belongsTo(MasterType::class,'phone_type_id');
    }

    protected static function boot() 
    {
        parent::boot();
    
        Relation::morphMap([
            'contact' => Contact::class,
            'employee' => Employee::class,
            'officer' => Officer::class,
            'third_party'=>Phone::class
        ]);
        self::creating(function($model){
               
                     
        });

        self::created(function($model){
           
        });

        self::updating(function($model){
           
        });

        self::updated(function($model){
            
        });

        self::deleting(function($model){
           
        });

        self::deleted(function($model){
        });

       
    }
}
