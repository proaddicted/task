<?php

namespace App\Models;

use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;

class NotificationTemplate extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;

    protected $fillable = ['sms_body','name','display_name','email_body','status','subject','notification_body','identifier'];
    
    protected $searchableColumns = ['name','display_name','subject'];

    protected $appends = [];

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }
}
