<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use Modules\ContactManager\Entities\Contact;
use Modules\AttendanceManager\Entities\DailyAttendanceReport;
use Modules\TaskManager\Entities\Task;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
class File extends Model
{

    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait;

    protected $fillable = ['file_path','file_name','file_extension','file_size','identifier','main_id','file_description','file_type_id','is_client_access','start_date','end_date','document_date','file_stage_id','task_information_item_id','information_sub_group_id','information_sub_group_index'];

    protected $searchableColumns = ['file_path','file_name'];

    protected $appends = ['full_file_path'];

    public function getFullFilePathAttribute()
    {
       
        if(!empty($this->attributes['file_path']))
        {
            if(env('FILE_STORE_CLOUD'))
            {
                return  $this->attributes['full_file_path'] =  env('DO_SPACES_CDN'). $this->attributes['file_path'];
            }
            else
                return  $this->attributes['full_file_path'] =  env('APP_URL').'storage'. $this->attributes['file_path'];
        }
        else
            return  $this->attributes['full_file_path'] =  null;
    }

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }

    public function company()
    {
        return $this->belongsTo(Contact::class,'main_id')->where('type','company');

    }
    public function attendance_reports()
    {
        return $this->belongsTo(DailyAttendanceReport::class,'main_id')->whereNotNull('company_id');
    }
    public function tasks()
    {
        return $this->belongsTo(Task::class,'main_id');

    }
    public function file_sources()
    {
        return $this->belongsToMany(MasterType::class,'file_sources','file_id','file_source_id')->wherePivot('deleted_at',NULL)->withTimestamps();
    }

     /**
     * This is a public function which is used for advanced search of index/listing function for task section
     * @param $query query builder reference
     * @param $advance_params array of data
     * @return string or boolean or query
     * @author Debargha Chakraborty <debargha.chakraborty01@gmail.com>
     * @copyright Copyright (c) 2024, Debargha Chakraborty
     */
    public function scopefileadvanceSearch($query,$advance_params,$table)
    {
       if(!empty($advance_params) && count($advance_params) > 0)
       {
            foreach ($advance_params as $key => $value) {
                $parm = explode('-',$key);
                if(count($parm) >= 2)
                {
                    $tableColumn = $table.".".$parm[0];
                    if ($parm[1] == 'like')
                    {    
                        if($parm[0] == 'company' || $parm[0]=='contact')
                        {
                            $query->where('main_id',$value)->where('identifier','contact');
                        }
                        else if($parm[0] == 'group')
                        {
                            $query->whereRaw('main_id in(SELECT distinct id from contacts where group_id='.$value.')')->where('identifier','contact');
                        }
                        else
                            $query->where($tableColumn,"LIKE","%".$value."%");
                       
                    }
                    elseif($parm[1]=='eq')
                    {
                        if($parm[0] == 'company' || $parm[0]=='contact')
                        {
                            $query->where('main_id',$value)->where('identifier','contact');
                        }
                        else if($parm[0] == 'group')
                        {
                            $query->whereRaw('main_id in(SELECT distinct id from contacts where group_id='.$value.')')->where('identifier','contact');
                        }
                        else
                            $query->where($tableColumn,$value);
                    }
                    elseif ($parm[1] == 'nlike')
                    {
                        if($parm[0] == 'company' || $parm[0]=='contact')
                        {
                            $query->where('main_id',"NOT LIKE",$value);
                        }
                        else if($parm[0] == 'group')
                        {
                            $query->whereRaw('main_id in(SELECT distinct id from contacts where group_id NOT LIKE "%'.$value.'%")');
                        }
                        else
                            $query->where($tableColumn,"NOT LIKE","%".$value."%");
                    }
                    elseif ($parm[1] == 'neq') 
                    {
                        if($parm[0] == 'company' || $parm[0]=='contact')
                        {
                            $query->where('main_id',"<>",$value);
                        }
                        else if($parm[0] == 'group')
                        {
                            $query->whereRaw('main_id in(SELECT distinct id from contacts where group_id <>'.$value.')');
                        }
                        else
                            $query->where($tableColumn,"<>",$value);
                    }
                    elseif ($parm[1] == 'in') 
                    {
                        if($parm[0] == 'company' || $parm[0]=='contact')
                        {
                            $query->whereIn('main_id',explode(',',$value))->where('identifier','contact');
                        }
                        else if($parm[0] == 'group')
                        {
                            $query->whereRaw('main_id in(SELECT distinct id from contacts where group_id in ('.$value.'))')->where('identifier','contact');
                        }
                        else
                            $query->whereIn($tableColumn,explode(',',$value));
                    }
                    elseif ($parm[1] == 'nin') 
                    {
                        if($parm[0] == 'company' || $parm[0]=='contact')
                        {
                            $query->whereNotIn('main_id',explode(',',$value));
                        }
                        else if($parm[0] == 'group')
                        {
                            $query->whereRaw('main_id in(SELECT distinct id from contacts where group_id not in ('.$value.'))');
                        }
                        else
                            $query->whereNotIn($tableColumn,explode(',',$value));
                    }
                    elseif ($parm[1] == 'between')
                    {
                        if(is_array($value) && count($value) == 2)
                            $query->whereBetween($tableColumn,[$value[0],$value[1]]);
                        elseif (!empty($value) && count(explode(',',$value))) {

                            if($parm[0] == 'created_at' || $parm[0] == 'updated_at' || $parm[0] == 'document_date' || $parm[0] == 'start_date' || $parm[0] == 'end_date' )
                            {
                                $values = explode(',',$value);
                                $query->whereRaw('DATE('.$tableColumn.') BETWEEN ? and ?',[$values[0],$values[1]]);
                            }
                        }
                        else    
                            $query->whereRaw('1=1');    
                    }       
                    else
                    {
                        $query->whereRaw('1=1');
                    }
                }
                
            }

            return $query;
       }
       else
        return $query;
    }

    protected static function boot() {

        static::deleting(function(File $file) { 
             
            
        });

        parent::boot();
    }
}
