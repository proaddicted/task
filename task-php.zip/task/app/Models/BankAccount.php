<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;

class BankAccount extends Model
{
    use HasFactory,Userstamps,MasterTrait,PermissionTrait,Eloquence,SoftDeletes,CommonTrait;

    protected $fillable = ['name','account_name','account_no','bank_name','branch_name','ifsc_code','micr_code','status'];
    
    protected $searchableColumns = ['name','account_name','account_no','bank_name','branch_name','ifsc_code','micr_code'];

    protected $appends = ['display_name'];

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }

    public function getDisplayNameAttribute()
    {
        $display_name = $this->bank_name;
        $display_name .=empty($this->attributes['account_no'])?'':"(".$this->attributes['account_no'] . ')';
        $this->attributes['display_name'] = $display_name;
        return $this->attributes['display_name'];
    }

    protected static function boot() 
    {
        parent::boot();
    
       
        self::creating(function($model){
                                 
        });

        self::created(function($model){
           
        });

        self::updating(function($model){
            
        });

        self::updated(function($model){
            
        });

        self::deleting(function($model){
           
        });

        self::deleted(function($model){
        });

       
    }
}
