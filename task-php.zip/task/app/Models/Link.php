<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;

class Link extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait;
    protected $fillable = ['link_type_id','link','main_id','identifier','is_default','status'];
    
    protected $searchableColumns = ['link'];

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }
}
