<?php

namespace App\Models;

use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\CommonTrait;

class Country extends Model
{
    use HasFactory,Userstamps,PermissionTrait,MasterTrait,SoftDeletes,Eloquence,CommonTrait;

    protected $fillable = ['name','iso_code','flag','tel_prefix','status'];
    
    protected $searchableColumns = ['name','iso_code','tel_prefix'];

    protected $appends = [];

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }
}
