<?php

namespace App\Models;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;

class NotificationLog extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;
    protected $fillable = ['master_id','batch_id','notification_id','to','identifier','subject','body','mail_type','status','created_at','updated_at','x_message_id','type'];

}
