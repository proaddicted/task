<?php

namespace App\Models;

use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use Illuminate\Support\Facades\Auth;

class Role extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait;

    protected $fillable = ['name','display_name','description','status'];
    
    protected $searchableColumns = ['name','display_name'];

    protected $appends = [];
    
    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }

    public function permission()
    {
        return $this->hasMany(RolePermission::class,'role_id');
    }

    public function roles()
    {
        return $this->belongsToMany(Role::class,'roles_element','main_role_id','role_id')->wherePivot('deleted_at',NULL)->withTimestamps();
    }

    public function scopecheckRoleAccess($query){
        $user = Auth::user();
        
        if($user->is_superadmin == 0)
        {
            $role_ids = array();
            if(count($user->roles))
            {
                foreach ($user->roles as $key => $role) {
                   if(count($role->roles)) 
                   {
                        foreach ($role->roles as $askey => $assocaited_role) {
                            array_push($role_ids,$assocaited_role->id);
                        }
                   }
                   
                }

                if(count($role_ids))
                    return $query->whereIn('id',$role_ids);
                else
                    return $query->whereRaw('1=2');
            }
            else
                return $query->whereRaw('1=2'); 
        }
        else
            return $query->whereRaw('1=1');

    }

    protected static function boot() {

        static::deleting(function(Role $role) { 
             
             $role->permission()->delete();
             $role->roles()->detach();   
        });

        parent::boot();
    }
}
