<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;

class AdvanceSearch extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait;
    protected $fillable = ['user_id','name','page_url','search_value'];
    
    protected $searchableColumns = ['name','page_url'];

    protected $appends = ['search_values'];

    public function getSearchValuesAttribute()
    {
        return $this->attributes['search_values'] = json_decode($this->attributes['search_value'],true);
    }
}
