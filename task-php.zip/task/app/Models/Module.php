<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;

class Module extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;

    protected $fillable = ['url','name','display_name','icon','status','order_no'];
    
    protected $searchableColumns = ['name','display_name','pages.name'];

    protected $appends = [];

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }

    public function pages()
    {
        return $this->belongsToMany(Page::class,'module_pages','module_id','page_id')->withPivot('order_no')->wherePivot('deleted_at',NULL)->orderBy('module_pages.order_no','asc')->withTimestamps();
    }

    public function role_permission()
    {
        return $this->hasMany(RolePermission::class);
    }

    

    protected static function boot() 
    {
        parent::boot();
        static::deleting(function(Module $module) {

            $module->pages()->detach();

        });

    }
}
