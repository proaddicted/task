<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Support\Facades\DB;
use App\Mail\SendGrid;
use App\Mail\MailChimp;
use App\Models\NotificationLog;

class SendNotification extends Notification
{
    
    use Queueable;
    public $data,$task,$recipients,$identifier,$notification_batch_id;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($data,$task,$recipients,$identifier,$notification_batch_id)
    {
        $this->data = $data;
        $this->task = $task;
        $this->recipients = $recipients;
        $this->identifier = $identifier;
        $this->notification_batch_id=$notification_batch_id;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['database'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toDatabase($notifiable)
    {
        $dd = DB::table('notifications')->latest()->first();
        $this->data['variables'] = array();
        $this->data['variables']['[NAME]'] = isset($notifiable->name) ? $notifiable->name : $notifiable->full_name ;
        $this->data['variables']['[LINK]'] = isset($this->data['link'])?$this->data['link']:'';
        $this->data['variables']['[START_DATE]'] =isset($this->data['start_date'])? $this->data['start_date']:'';
        $this->data['variables']['[END_DATE]'] =isset($this->data['end_date'])? $this->data['end_date']:'';
        $this->data['variables']['[HOST]'] = isset($this->data['host'])?$this->data['host']:'';
        $this->data['variables']['[AGENDA]'] = isset($this->data['agenda'])?$this->data['agenda']:'';
        $this->data['variables']['[STATUS_NAME]'] = isset($this->data['status_name'])?$this->data['status_name']:'';
        $this->data['variables']['[REQUESTEE_NAME]'] = isset($this->data['requestee_name'])?$this->data['requestee_name']:'';
        $this->data['variables']['[SUBJECT]'] = isset($this->data['template_subject'])?$this->data['template_subject']:'';
        $this->data['variables']['[CONTENT]'] = isset($this->data['content'])?$this->data['content']:'';
        $this->data['variables']['[TYPE_NAME]'] = isset($this->data['type_name'])?$this->data['type_name']:''; // 19/07/2024 add for leave type, added by Jyoti


        $this->data['variables']['[LEAVE_APPLICATION_URL]'] = isset($this->data['leave_application_url'])?$this->data['leave_application_url']:''; //22/07/2024 Jyoti
        $headerData = ['unique_args' => ['notification_id' => $dd->id]];
        $this->data['header'] = $headerData;
        $this->data['notification_id'] = $dd->id;

        if( $this->data['template'] && !empty( $this->data['template']))
        {
             $template = $this->data['template'];
             
             $this->data['variables']['[SENDER_NAME]'] = isset($this->data['from']) ? $this->data['from'] : env('APP_NAME');
             $this->message = $this->replace_variable($this->data['variables'],$this->data['template']->email_body);
            //  dd($this->data['template']->subject);

             $this->subject = $this->replace_variable($this->data['variables'],$this->data['template']->subject);
             DB::table('notifications')->where('id',$this->data['notification_id'])->update(['notification_body'=> $this->message,'subject'=>$this->subject,'batch_id'=>$this->notification_batch_id]); 
        }
        // dd($this->recipients);
        foreach ($this->recipients  as $item) 
        {
            // dd($item);
            if ($item['email'] === $notifiable->email) {
                $mailType = $item['mail_type'];
                break;
            }
        }
        NotificationLog::create([
            'master_id'=>1,
            'batch_id'=>$this->notification_batch_id,
            'notification_id'=>$this->data['notification_id'],
            'to'=>$notifiable->email,
            'identifier'=>'email',
            'type'=>$notifiable->type,
            'subject'=> $this->subject,
            'body'=> $this->message,
            'mail_type'=> $mailType
        ]);
        return [
            'message'=>$this->message,
            'subject'=>$this->subject
        ];
           
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            'to'=>$notifiable->email,
        ];
    }

    private function asJSON($data)
    {
        $json = json_encode($data);
        $json = preg_replace('/(["\]}])([,:])(["\[{])/', '$1$2 $3', $json);

        return $json;
    }

    private function asString($data)
    {
        $json = $this->asJSON($data);

        return wordwrap($json, 76, "\n   ");
    }

    private function replace_variable($variable_array,$original_body)
    {
        preg_match_all('~{[A-Z_]+}([^{]*){\/[A-Z_]+}~',$original_body,$matches);

                
        if(count($matches)>0)
        {
            $str=array();
            $replaces=array();

            foreach($matches[1] as $key=>$value)
            {
                
                $str[$key] = "";
                preg_match('~\[[A-Z_]+\]~',$value,$matches1);
                
                if(count($matches1) > 0)
                    {
                    if(array_key_exists($matches1[0], $variable_array) && !($variable_array[$matches1[0]]=="" || $variable_array[$matches1[0]]=="false"))
                        $str[$key] =str_replace(array_keys( $variable_array), $variable_array ,$value);
                    
                    $replaces[$key]= '~{'.$matches1[0].'+}([^{]*){\/'.$matches1[0].'+}~';
                    }
                else
                    {
                        //echo htmlentities($matches[0][$key]);
                        preg_match('~\{[A-Z_]+\}~',$matches[0][$key],$matches1);
                        //print_r($matches1); echo "<br>";
                        if(count($matches1) > 0)
                            {
                            $matches1[0] = str_replace("{","[",$matches1[0]);
                            $matches1[0] = str_replace("}","]",$matches1[0]);
                            
                            if(array_key_exists($matches1[0], $variable_array))
                                {
                                    $str[$key] = str_replace(array_keys( $variable_array), $variable_array ,$value);
                                    $replaces[$key]= '~{'.$matches1[0].'+}'. $str[$key] . '{\/'.$matches1[0].'+}~';
                                }
                            else
                                    $replaces[$key]= '~{'.$matches1[0].'+}([^{]*){\/'.$matches1[0].'+}~';
                            }
                            
                    }
                    
            }

            
            $replaced_body=preg_replace($replaces,$str,$original_body,1);
        }
        
        $replaced_body = str_replace(array_keys($variable_array), $variable_array, $replaced_body);

        return $replaced_body;
    } 
}
