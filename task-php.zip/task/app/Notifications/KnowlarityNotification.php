<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Support\Facades\DB;
use App\Mail\SendGrid;
use App\Mail\MailChimp;
use App\Models\NotificationLog;

class KnowlarityNotification extends Notification
{
    use Queueable;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public $data,$task,$recipients,$identifier,$notification_batch_id,$subject,$message,$template;
    public function __construct($data,$notification_batch_id,$template)
    {
        $this->data = $data;
        $this->template = $template;
        $this->notification_batch_id=$notification_batch_id;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['database'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toDatabase($notifiable)
    {
        
        if( $this->template && !empty( $this->template))
        {
             $this->data['[SENDER_NAME]'] = isset($this->data['from']) ? $this->data['from'] : env('APP_NAME');
             $this->message = $this->replace_variable($this->data,$this->template->email_body);
             $this->subject = $this->replace_variable($this->data,$this->template->subject);
        }
      
        NotificationLog::create([
            'master_id'=>1,
            'batch_id'=>$this->notification_batch_id,
            'to'=>$notifiable->email,
            'identifier'=>'email',
            'type'=>$notifiable->type,
            'subject'=> $this->subject,
            'body'=> $this->message,
            'mail_type'=> 'to'
        ]);
        return [
            'message'=>$this->message,
            'subject'=>$this->subject
        ];
           
    }
    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
    private function replace_variable($variable_array,$original_body)
    {
        preg_match_all('~{[A-Z_]+}([^{]*){\/[A-Z_]+}~',$original_body,$matches);

                
        if(count($matches)>0)
        {
            $str=array();
            $replaces=array();

            foreach($matches[1] as $key=>$value)
            {
                
                $str[$key] = "";
                preg_match('~\[[A-Z_]+\]~',$value,$matches1);
                
                if(count($matches1) > 0)
                    {
                    if(array_key_exists($matches1[0], $variable_array) && !($variable_array[$matches1[0]]=="" || $variable_array[$matches1[0]]=="false"))
                        $str[$key] =str_replace(array_keys( $variable_array), $variable_array ,$value);
                    
                    $replaces[$key]= '~{'.$matches1[0].'+}([^{]*){\/'.$matches1[0].'+}~';
                    }
                else
                    {
                        //echo htmlentities($matches[0][$key]);
                        preg_match('~\{[A-Z_]+\}~',$matches[0][$key],$matches1);
                        //print_r($matches1); echo "<br>";
                        if(count($matches1) > 0)
                            {
                            $matches1[0] = str_replace("{","[",$matches1[0]);
                            $matches1[0] = str_replace("}","]",$matches1[0]);
                            
                            if(array_key_exists($matches1[0], $variable_array))
                                {
                                    $str[$key] = str_replace(array_keys( $variable_array), $variable_array ,$value);
                                    $replaces[$key]= '~{'.$matches1[0].'+}'. $str[$key] . '{\/'.$matches1[0].'+}~';
                                }
                            else
                                    $replaces[$key]= '~{'.$matches1[0].'+}([^{]*){\/'.$matches1[0].'+}~';
                            }
                            
                    }
                    
            }

            
            $replaced_body=preg_replace($replaces,$str,$original_body,1);
        }
        
        $replaced_body = str_replace(array_keys($variable_array), $variable_array, $replaced_body);

        return $replaced_body;
    } 
}
