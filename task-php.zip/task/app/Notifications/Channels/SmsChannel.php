<?php

namespace App\Notifications\Channels;
use Illuminate\Support\Facades\DB;
use Illuminate\Notifications\Notification;
use App\Models\NotificationLog;

class SmsChannel
{
    public function send($notifiable, Notification $notification)
    {
        if (!method_exists($notification, 'toSms')) {
            return;
        }
        $message = $notification->toSms($notifiable);
        $phoneNumber = $notification->phoneNumber; // Getting the phone number from the notification instance
        $sms=NotificationLog::create([
            'master_id'=>1,
            'to'=>$phoneNumber,
            'identifier'=>'sms',
            'body'=> $message,
        ]);
        $this->sendSms($phoneNumber, $message,$sms);
    }

    protected function sendSms($phoneNumber, $message,$sms)
    {
        return true; //SMS API is Getting Error 02/09/2024
        $username = urlencode("rnjGSTDOST"); 
        $password = urlencode("gstdost123"); 
        $sender_id = urlencode("DOSTCS"); // compulsory in transactional sms
        $message = rawurlencode(strip_tags(html_entity_decode($message)));
        $mobile = urlencode($phoneNumber);
        // $template_id = $sms->sms_template_id;

        $api = "http://5.189.187.82/sendsms/bulk.php?username=".$username."&password=".$password."&sender=".$sender_id."&mobile=".$mobile."&message=".$message."&type=TEXT&entityId=".env('SMS_ENTITY_ID');
        $sms_response=file_get_contents($api);
        $result = explode('|',$sms_response);
        // dd(isset($result[1])?trim(strip_tags($result[1])):'bc');
         //echo "bbb"; echo $api; exit; 
        if(!empty($result) && count($result) > 1)
        {
            $x_message=isset($result[1])?trim(strip_tags($result[1])):'';
            $sms->x_message_id=$x_message;
            $sms->event_status=$result[0];
            $sms->status=1;
            $sms->save();
            //save $result[1] as sms id in new field or x-message-id
        }
        else
        {
            $sms->event_status='failed';
            $sms->status=2;
            $sms->save();
            //status failed
        }  
        // Handle the response as needed
    }
}
