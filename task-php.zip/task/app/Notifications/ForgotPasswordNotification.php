<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use Illuminate\Support\Facades\DB;
use App\Mail\SendGrid;

class ForgotPasswordNotification extends Notification
{
    use Queueable;
    public $data;
    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($data)
    {
        $this->data = $data;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['database','mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        $dd = DB::table('notifications')->latest()->first();
        $this->data['variables'] = array();

        $this->data['variables']['[FNAME]'] = $this->data['user']['name'];
        $this->data['variables']['[LINK]'] = env('APP_FRONT_URL').'reset-password/'. base64_encode($this->data['user']['id']);
        $headerData = ['unique_args' => ['notification_id' => $dd->id]];
        $this->data['header'] = $headerData;
        $this->data['notification_id'] = $dd->id;

        return (new SendGrid($this->data))->to($notifiable->email);
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            'to'=>$notifiable->email
        ];
    }
}
