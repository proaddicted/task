<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use App\Models\User;
use App\Models\File;

use App\Models\NotificationLog;

use GuzzleHttp\Client;
use Illuminate\Support\Facades\DB;

class MailChimp extends Mailable
{
    use Queueable, SerializesModels;

    public $data,$template_body, $message,$subject,$main_id,$notifiable,$recipients,$notification_batch_id,$identifier,$getuser;

    /**
     * Create a new message instance.,$task,$notifiable,$recipients,$notification_batch_id
     *
     * @return void
     */
    public function __construct($data,$template_body,$main_id,$identifier,$getuser)
    {
        $this->data = $data;
        $this->template_body = $template_body;
        $this->main_id=$main_id;
        $this->identifier=$identifier;
        $this->getuser=$getuser;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {

        $files=File::where('main_id',$this->main_id)->where('identifier',$this->identifier)->get()->toArray();
            $file=[];
            if(count($files)>0){
                $file=array_column($files,'full_file_path');
            }
            $url = 'https://mandrillapp.com/api/1.0/messages/send-template.json';
                $replyto='sahaj@gstdost.com';
                $to=[];
                $merged_vars=[];
                // $mail_body=$this->template_body;
                $log_ids=[];

                if(env('MAIL_PLUS_SUPPORT'))
                {
                    $replyto = str_replace('@', '+' . $this->identifier . '+' . $this->main_id . '@',$replyto); // Add 
                }
                   
                if(count($this->data)>0 )
                {
                    $this->subject=$this->data[0]['subject'];
                    $messages=[];
                    try{
                        if(count($file)>0)
                        {    
                            stream_context_set_default([
                            'ssl' =>[
                                    'verify_peer' => false,
                                    'verify_peer_name' => false,
                            ]
                            ]);
                            $size = sizeOf($file);
                            for($i=0;$i<$size;$i++)
                            { 
                                $filename=basename($file[$i]);
                                $filetype = substr($filename, strpos($filename, ".") + 1); 
                               
                                $attachments[$i]=array(
                                    "type"=>'application/'.$filetype,
                                    "name" => basename($file[$i]),
                                    "content" =>base64_encode(file_get_contents($file[$i])),
                                );   
                            }
                                $data = [
                                    'key' =>env('MAIL_CHIMP_APIKEY'),
                                    'template_name' => 'new_crm_mail_body',
                                    'template_content' => [],
                                    'message' => [
                                        'from_email' => 'sahaj@gstdost.com',
                                        'from_name' => 'GSTDOST',
                                        'subject' =>  $this->subject,
                                        'headers' => array(
                                            'Reply-To' =>$replyto 
                                        ),
                                        'tags' => array(
                                            'notification_log'
                                        ),
                                        "attachments" => $attachments,
                                        'preserve_recipients' => true,
                                        'to' => [],
                                        'merge_vars' => [],
                                        'tracking_domain' => 'mailchimp.gstdost.com',
                                        'tracking_opens' => true,
                                        'tracking_clicks' => true,
                                    ]
                                ];
                        }
                        else{
                            $data = [
                                'key' =>env('MAIL_CHIMP_APIKEY'),
                                'template_name' => 'new_crm_mail_body',
                                'template_content' => [],
                                'message' => [
                                    'from_email' => 'sahaj@gstdost.com',
                                    'from_name' => 'GSTDOST',
                                    'subject' =>  $this->subject,
                                    'headers' => array(
                                        'Reply-To' =>$replyto 
                                    ),
                                    'tags' => array(
                                        'notification_log'
                                    ),
                                    'preserve_recipients' => true,
                                    'to' => [],
                                    'merge_vars' => [],
                                    'tracking_domain' => 'mailchimp.gstdost.com',
                                    'tracking_opens' => true,
                                    'tracking_clicks' => true,
                                ]
                            ];
                        }

                        foreach ($this->data as $logs) {
                            $log_ids[]=$logs['id'];
                            if($this->getuser!='' && isset($this->getuser->email))
                            {
                                DB::table('notification_logs')->where('id',$logs['id'])->update(['from_email'=>$this->getuser->email]);
                            }
                            $user=User::where('email',$logs['to'])->first();

                            $data['message']['to'][] = [
                                'email' => $logs['to'],
                                'name' => $user['name'],
                            'type' => $logs['mail_type'],
                            ];
                        
                            $data['message']['merge_vars'][] = [
                                'rcpt' => $logs['to'],
                                'vars' => [
                                    ['name' => 'NAME', 'content' => $user['name']],
                                    ['name' => 'BODY', 'content' => $logs['body']],
                                ]
                            ];
                        }
                    
                        $ch = curl_init();
                        curl_setopt($ch, CURLOPT_URL, $url);
                        curl_setopt($ch, CURLOPT_POST, 1);
                        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                        $response = curl_exec($ch);
                        curl_close($ch);
                        foreach(json_decode($response) as $resp)
                        {
                            
                            if($resp->status=='sent' || $resp->status=='queued')
                            {
                                // dd($log_ids);
                                // dd( NotificationLog::whereIn('id',$log_ids)->where('to',$resp->email)->get()->toArray());
                                NotificationLog::whereIn('id',$log_ids)->where('to',$resp->email)->update(['x_message_id'=>$resp->_id,'event_status'=>'sent','status'=>1,'main_id'=>$this->main_id,'added_from'=>$this->identifier]);
                            }
                            else
                            {
                                NotificationLog::whereIn('id',$log_ids)->where('to',$resp->email)->update(['x_message_id'=>$resp->_id,'event_status'=>$resp->reject_reason,'status'=>2,'main_id'=>$this->main_id,'added_from'=>$this->identifier]);
                            }
                        }
                    }
                    catch (Exception $ex) {
                        // dd('catch');
                        foreach($this->data as $logs)
                        {
                            NotificationLog::whereIn('id',$logs['id'])->update(['event_status'=>'Please check code','status'=>2,'main_id'=>$this->main_id,'added_from'=>$this->identifier]);
    
                        }
                        return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
                    }
                }

                return $this->html($this->template_body)->subject($this->subject);
        }
}
