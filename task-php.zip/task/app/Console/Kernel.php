<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;
use  Modules\TaskManager\Console\RecursiveTask;
use  Modules\AttendanceManager\Console\OfficeIn;
use  Modules\AttendanceManager\Console\OfficeOut;
use  Modules\TaskManager\Console\PendingTicketEmployee;
use  Modules\TaskManager\Console\DueMailTicket;
use  Modules\AttendanceManager\Console\DailyReport;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        RecursiveTask::class,
        OfficeIn::class,
        OfficeOut::class,
        PendingTicketEmployee::class,
        DueMailTicket::class,
        DailyReport::class,
    ];

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        $schedule->command('recursive:task')->dailyAt('07:00');
      /*  $schedule->command('office:in')
        ->cron('15/15 10-11 * * * *');
        $schedule->command('office:out')
                ->cron('45/15 19-20 * * * *');
        $schedule->command('daily:report')->dailyAt('23:00');
        $schedule->command('pending:task')->dailyAt('23:00');
        $schedule->command('ticket:duemails')->dailyAt('23:30');*/
    }

    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }
}
