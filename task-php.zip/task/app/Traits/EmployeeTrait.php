<?php

namespace App\Traits;

use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Modules\ResourceManager\Entities\Employee;
use Modules\ResourceManager\Entities\EmployeeTiming;
use Modules\AttendanceManager\Entities\DailyAttendance;
use Modules\AttendanceManager\Entities\DailyAttendanceLog;
use Modules\TaskManager\Entities\Task;
use App\Models\Phone;
trait EmployeeTrait
{
    /**
     * Trait for All Common Functions For Employee Related Data
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */
    public function logged_employee()
    {
        $user  = Auth::user();
        if($user && $user->type == 'employee')
        {
            return Employee::where('user_id',$user->id)->first();
        }
        return null;
    }

      /**
     * This is a public function which returns employee object form user
     * @param $user
     * @return string or boolean  
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */

    /**
     * This is a public function which returns employee timing data
     * @param $user
     * @return string or boolean  
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */
    public function employee_info($user)
    {
        if($user->type == 'employee')
        {
            if($employee = Employee::with([
                'employee_timings' => function ($query){
                    $query->where('day','=',date('N'));
                }
            ])->where('user_id',$user->id)->first())
            {   
                
                if(count($employee->employee_timings))
                {
                   
                    $grace = !empty($employee->employee_timings[0]->grace)?$employee->employee_timings[0]->grace:0;
                    $graced_time = date('H:i:s',strtotime("+".$grace." minutes", strtotime($employee->employee_timings[0]->in)));
                    $employee->graced_time = $graced_time;
                    $employee->schedule_in_time = $employee->employee_timings[0]->in;
                    $employee->schedule_out_time = $employee->employee_timings[0]->out;
                    $employee->schedule_lunch_time = $employee->employee_timings[0]->lunch;
                    $employee->schedule_grace = $employee->employee_timings[0]->grace;
                    $employee->schedule_max_in = $employee->employee_timings[0]->max_in != null ? $employee->employee_timings[0]->max_in : env('LATE_IN_MAX');
                   
                }

                $employee->grace_modal_show = env('GRACE_MODAL_SHOW');
                $employee->knowlarity_available = env('KNOWLARITY_AVAILABLE');
                $employee->late_in_ist = env('LATE_IN_IST');
                $employee->wfh_ist = env('WFH_IST');
                $employee->ot_ist = env('OT_IST');

                $employee->officein_time=null;
                $employee->officeout_time=null;
                $phone=Phone::where('main_id',$employee->id)->first();
		        if(isset($phone->phone_no))
	                $employee->phone=$phone->phone_no;		
                
                $office=DailyAttendanceLog::where('emp_id', $employee->id)->where('date',date('Y-m-d'))->orderBy('created_at','desc')->get()->toArray();
                if(count($office)>0)
                {
                    if(!empty($office[0]['start_time']) && empty($office[0]['end_time']))
                    {
                        $employee->officein_time=$office[0]['start_time'];
                        $employee->officeout_time=$office[0]['end_time'];
                    }
                    $employee->grace_modal_show = false;
                }
                $employee->attendance_data = $office;
                

                $employee->department_users = $this->department_employee($employee->department_id,true);
                $employee->branch_users =  $this->branch_employee($employee->branch_id,true);
                ;
                $hierarchy_users = array();
                $hierarchy_users = $this->hierarchy_employee($employee->id, $hierarchy_users,true);
                $employee->hierarchy_users =  $hierarchy_users;


                $employee->department_employees = $this->department_employee($employee->department_id,false);
                $employee->branch_employees =  $this->branch_employee($employee->branch_id,false);
                ;
                $hierarchy_employees = array();
                $hierarchy_employees = $this->hierarchy_employee($employee->id, $hierarchy_employees,false);
                $employee->hierarchy_employees =  $hierarchy_employees;
                if($employee->manager_id > 0)
                {   
                    $manager = Employee::find($employee->manager_id);
                    $employee->manager_user_id =  $manager->user_id;
                }
                if($employee->hr_manager_id > 0)
                {   
                    $hr_manager = Employee::find($employee->hr_manager_id);
                    $employee->hr_manager_user_id =  $hr_manager->user_id;
                }
               
                if(env('LATE_IN_IST'))
                {
                    $employee->attendance_request = Task::whereHas('members', function ($q) use ($user){
                            $q->where('task_users.user_id',$user->id);
                    })->where('type','ist')->where('ist_type','attendance-request')->whereRaw('DATE(start_date) = ?',[date('Y-m-d')])->whereIn('status',[0,1])->count();
                }
                else
                    $employee->attendance_request = 0;
                
                if(env('WFH_IST'))
                {
        		    $employee->wfh_request = Task::whereHas('members', function ($q) use ($user){
                            $q->where('task_users.user_id',$user->id);
                    })->where('type','ist')->where('ist_type','wfh-request')->whereRaw('DATE(start_date) = ?',[date('Y-m-d')])->whereIn('status',[0,1])->count();
                }
                else
                	$employee->wfh_request = 0;    
              

               // $this->hierarchy_employee($employee->manager_id,true);

                return $employee;
            }
        }
        else
        {
           return false;
        }
    }
    /**
     * This is a public function which returns employees by department
     * @param $department_id,$is_user
     * @return string or boolean  
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */
    public function department_employee($department_id,$is_user=false)
    {
        $data=array();

        if($department_id > 0)
        {
            $employees=Employee::select('id','user_id')->where('status',1)->where('department_id',$department_id)->get()->toArray();

            foreach ($employees as $key => $value) 
            {
                if($is_user)
                {
                    if($value['user_id']>0)
                        $data[$key]=$value['user_id'];
                }   
                else
                {
                    $data[$key]=$value['id']; 
                }
            }
        }
        

        return $data;
    }
    /**
     * This is a public function which returns employees by location
     * @param $location_id,$is_user
     * @return string or boolean  
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */
    public function branch_employee($branch_id,$is_user=false)
    {
        $data=array();

        if($branch_id > 0)
        {
            $employees=Employee::select('id','user_id')->where('status',1)->where('branch_id',$branch_id)->get()->toArray();

            foreach ($employees as $key => $value)
            {
                
                if($is_user)
                {
                    if($value['user_id']>0)
                        $data[$key]=$value['user_id'];
                }   
                else
                {
                    $data[$key]=$value['id']; 
                }  
            }
        }

        return $data;
    }
    /**
     * This is a public recursive function which returns employees by hierarchy
     * @param $manager_id,$hierarchy_users,$is_user
     * @return string or boolean  
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */
    public function hierarchy_employee($manager_id,$hierarchy_users = array(),$is_user = false)
    {
        $data=array();
        
       if($manager_id > 0)
       {
            $manager=Employee::find($manager_id);
            $employees=Employee::where('status',1)->where('manager_id',$manager_id)->get()->toArray();

            if($is_user)
                $hierarchy_users[]=$manager->user_id;
            else
                $hierarchy_users[] = $manager_id;
            
            if(count($employees))
            {
                foreach ($employees as $key => $value)
                {
                
                    $hierarchy_users=$this->hierarchy_employee($value['id'], $hierarchy_users,$is_user);
                }
            }
            else
                return $hierarchy_users;
       }

       return $hierarchy_users;



    }

}
