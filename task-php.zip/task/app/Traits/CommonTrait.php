<?php

namespace App\Traits;

use Exception;
use Illuminate\Support\Facades\Storage;
use Illuminate\Http\Request;
use App\Models\AdvanceSearch;
use App\Traits\EmployeeTrait;

use Modules\AttendanceManager\Entities\DailyAttendanceReport;
use Modules\TaskManager\Entities\Task;
use App\Models\Service;
use Carbon\Carbon;


trait CommonTrait
{
    use EmployeeTrait;

    /**
     * Trait for All Common Functions & Variables Which Can Be Used In Multiple Modules
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */

    public $attendance_report_status  = array(
        array( 'id' => 0 , 'name' => 'Pending' ),
        array( 'id' => 1 , 'name' => 'Rejected'),
        array( 'id' => 2 , 'name' => 'Full Approved'),
        array( 'id' => 3 , 'name' => 'Part Approved')
    );

    public $attendance_types  = array(
        array( 'id' => 0 , 'name' => 'Productive' ),
        array( 'id' => 1 , 'name' => 'Client Service'),
        array( 'id' => 2 , 'name' => 'Internal')
    );
    
    public $ticket_statuses  = array(
        array( 'id' => 0 , 'name' => 'Pending' ),
        array( 'id' => 1 , 'name' => 'Review'),
        array( 'id' => 2 , 'name' => 'Completed')
    );

    public $is_ists = array(
        array('id' => 0 , 'name' => 'No' ),
        array('id' => 1 , 'name' => 'Yes' )
    );
    
    public $task_statuses  = array(
        array( 'id' => 0 , 'name' => 'Pending' ),
        array( 'id' => 1 , 'name' => 'Canceled'),
        array( 'id' => 2 , 'name' => 'Held'),
        array( 'id' => 3 , 'name' => 'Reschedule')
    );

    public $task_types  = array(
        array( 'id' => 'meeting' , 'name' => 'Meeting' ),
        array( 'id' => 'call' , 'name' => 'Call'),
        array( 'id' => 'todo' , 'name' => 'To Do'),
        array( 'id' => 'crd' , 'name' => 'Information Request'),
        array( 'id' => 'help-ticket', 'name' => 'Help Ticket'),
        array( 'id' => 'regular-ticket' , 'name' => 'Regular Ticket'),
        array( 'id' => 'department-task' , 'name' => 'Department Task'),
        array( 'id' => 'memorized-ticket' , 'name' => 'Memorized Ticket'),
        array( 'id' => 'ist' , 'name' => 'IST')
    );

    public $ist_statuses  = array(
        array( 'id' => 0 , 'name' => 'Pending' ),
        array( 'id' => 1 , 'name' => 'Rejected'),
        array( 'id' => 2 , 'name' => 'Approved')
    );
    public $ist_types = array(
        array( 'id' => 'attendance-request' , 'name' => 'Office In Request' ),
        array( 'id' => 'wfh-request' , 'name' => 'Work From Home Request'),
        array( 'id' => 'over-time-request' , 'name' => 'Over Time Request'),
        array( 'id' => 'change-attendance-request' , 'name' => 'Office Time Change Request'),
        array( 'id' => 'early-out-request' , 'name' => 'Early Out Request' ),
        array( 'id' => 'late-in-request' , 'name' => 'Late In Request' ),
        array( 'id' => 'other-request' , 'name' => 'Other Request' )
    );

    public $ticket_priorities  = array(
        array( 'id' => 0 , 'name' => 'Low' ),
        array( 'id' => 1 , 'name' => 'Medium'),
        array( 'id' => 2 , 'name' => 'High'),
        array( 'id' => 3 , 'name' => 'Urgent')
    );

    public $recursive_types = array(
        array('id'=>1,'name'=>'Yearly'),
        array('id'=>2,'name'=>'Monthly'),
        array('id'=>3,'name'=>'Weekly'),
        array('id'=>4,'name'=>'Daily'),
        array('id'=>5,'name'=>'Quater'),
        array('id'=>6,'name'=>'Half Yearly'),
        array('id'=>7,'name'=>'Custom Date'),
        array('id'=>8,'name'=>'One Time')

    );

    public $recursive_weeks = array(
        array('id'=>1,'name'=>'Monday'),
        array('id'=>2,'name'=>'Tuesday'),
        array('id'=>3,'name'=>'Wednessday'),
        array('id'=>4,'name'=>'Thurdsday'),
        array('id'=>5,'name'=>'Friday'),
        array('id'=>6,'name'=>'Saturday'),
        array('id'=>0,'name'=>'Sunday')

    );
    public $department_task_types = array(
                array('id'=>1,'name'=>'Client'),
                array('id'=>2,'name'=>'Department'),
                array('id'=>3,'name'=>'In House'),
                array('id'=>4,'name'=>'Third Party'),
                array('id'=>5,'name'=>'Others')        
  
   );
    
    public $department_task_modes=  array(
              array('id'=>1,'name'=>'Call'),
              array('id'=>2,'name'=>'Mail'),
              array('id'=>3,'name'=>'Whatsapp'),
              array('id'=>4,'name'=>'Portal'),
              array('id'=>5,'name'=>'Cloud Server'),
              array('id'=>6,'name'=>'Self'),
              array('id'=>7,'name'=>'Instruction')
    );

    public $information_field_types = array(
        array('id'=>0,'name'=>"Text Box"),
        array('id'=>1,'name'=>"Radio Button"),
        array('id'=>3,'name'=>"CheckBox"),
        array('id'=>7,'name'=>"Drop Down"),
        array('id'=>4,'name'=>"File Upload"),
        array('id'=>6,'name'=>"Date"),
        array('id'=>5,'name'=>"Date Time"),
        array('id'=>2,'name'=>"Rich Text Editor")
    );

    public $leave_application_status  = array(
        array( 'id' => 0 , 'name' => 'Processing' ),
        array( 'id' => 1 , 'name' => 'Declined'),
        array( 'id' => 2 , 'name' => 'Approved'),
    );

    public $frequency = array(
        array('id'=>1,'name'=>"Monthly"),
        array('id'=>2,'name'=>"Yearly")
    );

    public $lapse_or_paid = array(
        array('id'=>1,'name'=>"Lapse"),
        array('id'=>2,'name'=>"Paid")
    );

    public $carry_forward = array(
        array('id'=>1,'name'=>"Yes"),
        array('id'=>2,'name'=>"No")
    );

    public $is_paid_nonpaid = array(
        array('id'=>1,'name'=>"Paid"),
        array('id'=>2,'name'=>"Non-Paid")
    );
    
    /**
     * This is a public function which converts base64 data to file data and save to storage folder
     * @param $base64_data Base 64 Data
     * @param $target_folder Folder where image will be uploaded
     * @return string or boolean  
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */
    public function base64_upload($base64_data,$target_folder)
    {
        try{
            $extension = explode('/', explode(':', substr($base64_data, 0, strpos($base64_data, ';')))[1])[1];   // .jpg .png .pdf
      
            $replace = substr($base64_data, 0, strpos($base64_data, ',')+1); 
        
            // find substring fro replace here eg: data:image/png;base64,
            
            $image = str_replace($replace, '', $base64_data); 
            
            $image = str_replace(' ', '+', $image); 
            
            $imageName = time().'.'.$extension;

            $file_path = $target_folder.'/'.$imageName;

            if(env('FILE_STORE_CLOUD'))
            {
                 Storage::disk('spaces')->put($file_path, base64_decode($image),'public');
               
            }
            else
            {
                Storage::disk('public')->put($file_path, base64_decode($image));
            }   
            
            

            return $file_path;
        }
        catch(Exception $ex){
            return false;
        }
        
    }

     /**
     * This is a public function which converts base64 data and returns information
     * @param $base64_data Base 64 Data
     * @param $target_folder Folder where image will be uploaded
     * @return array 
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */
    public function base64_info($base64_data)
    {
        $extension = explode('/', explode(':', substr($base64_data, 0, strpos($base64_data, ';')))[1])[1];   // .jpg .png .pdf
        $imageName = time().'.'.$extension;
        $size_in_bytes = (int) (strlen(rtrim($base64_data, '=')) * 3 / 4);
        return ['extension'=>$extension,'file_name'=>$imageName,'size'=> $size_in_bytes];
    }
    
     /**
     * This is a public function which is used for advanced search of index/listing function
     * @param $query query builder reference
     * @param $advance_params array of data
     * @return string or boolean or query
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */
    public function scopeadvanceSearch($query,$advance_params,$table)
    {
       if(!empty($advance_params) && count($advance_params) > 0)
       {
          
            
            foreach ($advance_params as $key => $value) {
                
                $parm = explode('-',$key);
                if(count($parm) >= 2)
                {
                    $tableColumn = $table.".".$parm[0];

                    if ($parm[1] == 'like')
                    {
                        $query->where($tableColumn,"LIKE","%".$value."%");
                    }
                    elseif ($parm[1] == 'eq')
                    {
                        $query->where($tableColumn,$value);
                    }
                    elseif ($parm[1] == 'nlike')
                    {
                        $query->where($tableColumn,"NOT LIKE","%".$value."%");
                    }
                    elseif ($parm[1] == 'neq') 
                    {
                        $query->where($tableColumn,"<>",$value);
                    }
                    elseif ($parm[1] == 'in') 
                    {
                        $query->whereIn($tableColumn,explode(',',$value));
                    }
                    elseif ($parm[1] == 'nin') 
                    {
                        $query->whereNotIn($tableColumn,explode(',',$value));
                    }
                    elseif ($parm[1] == 'between')
                    {
                        
                        if(is_array($value) && count($value) == 2)
                            $query->whereBetween($tableColumn,[$value[0],$value[1]]);
                        elseif (!empty($value) && count(explode(',',$value))) {
                            if($parm[0] == 'created_at' || $parm[0] == 'updated_at' || $parm[0] == 'date' || $parm[0] == 'start_date' || $parm[0] == 'received_date' || $parm[0] == 'due_date' || $parm[0] == 'ecd' || $parm[0] == 'completed_date')
                            {
                                $values = explode(',',$value);
                                $query->whereRaw('DATE('.$tableColumn.') BETWEEN ? and ?',[$values[0],$values[1]]);
                            }
                        }
                        else    
                            $query->whereRaw('1=1');    
                    }       
                    else
                    {
                        $query->whereRaw('1=1');
                    }
                }
                
            }

            return $query;
       }
       else
        return $query;
    }

    
     /**
     * This is a public save advance search data respected to page and user
     * @param Request $request form request
     * @return string or boolean 
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */
    public function saveAdvanceSearchData(Request $request)
    {
        //return false; //converted to API because of select box and another issue

        if(!empty($request->search_name))
        {
            $filter_arr = [];
            if(!empty($request->filter))
            {
                foreach ($request->filter as $key => $value) {
                    $filter_arr[$key.'-eq'] = $value;
                }
            }
            if(!empty($request->advfilter))
            {
                foreach ($request->advfilter as $key => $value) {
                    $filter_arr[$key] = $value;
                }
            }
           
            AdvanceSearch::create([
                'name'=>$request->search_name,
                'user_id'=>$request->user_id,
                'page_url'=>$request->page_url,
                'search_value'=>json_encode($filter_arr)
            ]);

            return true;
        }
       
        return false;

    }

    /**
     * It Creates Directory Recursively
     *
     * @param  $path
     * @return boolean
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */
    function createPath($path) {
        if (is_dir($path)) return true;
        $prev_path = substr($path, 0, strrpos($path, '/', -2) + 1 );
        $return = $this->createPath($prev_path);
        return ($return && is_writable($prev_path)) ? mkdir($path) : false;
    }

     /**
     * Zoom API For Meeting Link Create
     *
     * @param  $task
     * @return api data
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2024, Prosanta Mitra
     */
    public function create_zoom_meeting($task)
    {
        $meeting_info = [];
        $client_id = env('ZOOM_CLIENT_ID');
        $client_secret = env('ZOOM_CLIENT_SECRET');
    
        /*****************************Initialiazation Of Code**********************************/
        $token_url = 'https://zoom.us/oauth/token?grant_type=account_credentials&account_id='.env('ZOOM_ACCOUNT_ID');
        $authorization = base64_encode($client_id . ':' . $client_secret);

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $token_url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => array(
            
                'Content-Type: application/x-www-form-urlencoded',
                'Authorization: Basic ' . $authorization,
            )
        ));
    
        $response = curl_exec($curl);
        curl_close($curl);
        $data =  json_decode($response,true);

       
        if(!empty($data))
        {
            $token = $data['access_token'];
        
            
            $userId = env('ZOOM_USER_ID');
            
            $meeting_curl = curl_init();
            curl_setopt_array($meeting_curl, array(
                CURLOPT_URL => "https://api.zoom.us/v2/users/".$userId."/meetings",
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => json_encode(array(
                    "topic" => "GST DOST's Zoom Meeting",
                    "type" => 2,
                    "start_time" => implode('T',explode(' ',$task->start_date)),
                    "duration" => 60,
                    "timezone" => env('APP_TIMEZONE'),
                    "agenda" => $task->description,
                    "settings" => array(
                        "host_video" => true,
                        "participant_video" => true,
                        "join_before_host" => false
                    )
                )),
                CURLOPT_HTTPHEADER => array(
                    "Authorization: Bearer $token",
                    "Content-Type: application/json"
                ),
            ));

            $response = curl_exec($meeting_curl);
            $err = curl_error($meeting_curl);

            $meeting_info = json_decode($response,true);
        }
        sleep(2);

        return $meeting_info;
    }

    public function time_diff($start,$end)
    {

        $start = Carbon::createFromTimeString($start);
        $end = Carbon::createFromTimeString($end);
        $difference = $start->diff($end);
        $formattedDifference = sprintf('%02d:%02d', $difference->h, $difference->i);
        return $formattedDifference; 
    }

    /**
     * Function for Auto Attendance Create
     *
     * @param  $request , $id
     * @return api data
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2024, Prosanta Mitra
     */
    public function create_auto_attendance(Request $request,$id,$type)
    {
        $task = Task::with('history','employees')->find($id);

        $employee_info = $this->employee_info($user);

        if($type == 'direct')
        {
            foreach ($task->employees as $key => $value) 
            {
                $daily_attendance_report = DailyAttendanceReport::create([
                    'task_id'=>$id,
                    'description'=> $task->remarks,
                    'date'=>date('Y-m-d'),
                    'time'=>$this->time_diff($request->in_time,$request->out_time),
                    'user_id'=>$value->user_id,
                    'emp_id'=>$value->id,
                    'auto_entry'=>1,
                    'reason'=>$task->type == 'department-task' ? 'Department Visit': 'Meeting'
                ]);
            }
        }
        elseif ($type == 'held') {

            
            
        }
       
    }

     /**
     * Function for Validate Phone Number
     *
     * @param  $value Phone No
     * @return string
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2024, Prosanta Mitra
     */
    public function validate_mobile($value)
    {
		$value = preg_replace("/[^0-9]/", "", $value);
		if(strlen($value)==10 && intval(substr($value,0,1)) > 0)
			return $value;
		else if(strlen($value)==12 && substr($value,0,2) == "91" && intval(substr($value,2,1)) > 6)
			return substr($value,2,strlen($value)-2);
		else if(strlen($value)==13 && substr($value,0,3) == "+91" && intval(substr($value,3,1)) > 6)
			return substr($value,3,strlen($value)-3);
		else
			return "";
	}	


     /**
     * Function for Add Multiple Times
     *
     * @param  $value Phone No
     * @return string
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2024, Prosanta Mitra
     */
    public function AddMultipleTime($times) 
    {
        $minutes = 0; //declare minutes either it gives Notice: Undefined variable
        
        // loop throught all the times
        foreach ($times as $time) {
            if(!empty($time))
            {
                list($hour, $minute) = explode(':', $time);
                $minutes += $hour * 60;
                $minutes += $minute;  
            }
           
        }

        $hours = floor($minutes / 60);
        $minutes -= $hours * 60;

        // returns the time already formatted
        return sprintf('%02d:%02d', $hours, $minutes);
    }

     /**
     * Function for negetive time check
     *
     * @param  $value Phone No
     * @return boolean
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2024, Prosanta Mitra
     */
    public function nagitive_check($value){
        if (isset($value)){
            if (substr(strval($value), 0, 1) == "-"){
            return 0;
        } else {
            return 1;
        }
            }
    }


     /**
     * This is a public recursive function which returns services child
     * @param $parent_id,$services
     * @return string or boolean  
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2024, Prosanta Mitra
     */
    public function child_services($parent_id,$services = array())
    {
        $data=array();
        
       if($parent_id > 0)
       {
            $childrens=Service::where('status',1)->where('parent_id',$parent_id)->get()->toArray();

            
            $services[] =  intval($parent_id);
            
            if(count($childrens))
            {
                foreach ($childrens as $key => $value)
                {
                
                    $services=$this->child_services($value['id'], $services);
                }
            }
            else
                return $services;
       }

       return $services;



    }

  
}
