<?php

namespace App\Traits;

use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Traits\EmployeeTrait;

trait PermissionTrait
{

    use EmployeeTrait;
    /**
     * This Trait Will Be Used for Custom Permission Checking
     * access->1
     * insert->2
     * update->3
     * view->4
     * list->5
     * delete->6
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */

    public $access_types = array(
        array('name'=>'None','id'=>0),
        array('name'=>'Self','id'=>1),
        array('name'=>'Hierchy','id'=>2),
        array('name'=>'My Location','id'=>3),
        array('name'=>'My Department','id'=>4),
        array('name'=>'All','id'=>5)
    );

    public function checkGlobalAccess()
    {
       
        $res = DB::table('users')->select(DB::raw('MAX(role_permission.access) as access,role_permission.permission_id,role_permission.page_id,users.id as user_id,pages.url as page_url'))->leftJoin('role_user','role_user.user_id','=','users.id')->leftJoin('role_permission','role_permission.role_id','=','role_user.role_id')->leftJoin('pages','pages.id','=','role_permission.page_id')->where('users.id',Auth::user()->id)->where('role_user.master_id',request()->master_id)->where('role_permission.master_id',request()->master_id)->where('pages.master_id',request()->master_id)->whereNull('role_permission.deleted_at')->whereNull('role_user.deleted_at')->whereNull('pages.deleted_at')->groupBy('role_permission.permission_id')->groupBy('role_permission.page_id')->get();
        
        return $res;
    }
    public function checkAccessType($permission_id)
    {
       // $res = $this->permissionResult;
        
        //dd($res);
      
        $res = DB::table('users')->select(DB::raw('MAX(role_permission.access) as access,role_permission.permission_id,role_permission.page_id,users.id as user_id,pages.url as page_url'))->leftJoin('role_user','role_user.user_id','=','users.id')->leftJoin('role_permission','role_permission.role_id','=','role_user.role_id')->leftJoin('pages','pages.id','=','role_permission.page_id')->where('pages.url',request()->page_url)->where('role_permission.permission_id',$permission_id)->where('users.id',Auth::user()->id)->where('role_user.master_id',request()->master_id)->where('role_permission.master_id',request()->master_id)->where('pages.master_id',request()->master_id)->whereNull('role_permission.deleted_at')->whereNull('role_user.deleted_at')->whereNull('pages.deleted_at')->groupBy('role_permission.permission_id')->groupBy('role_permission.page_id')->get();

        return $res;
    }
    /**
     * This function check query with added_by or emp_id column where ever this scope is appended
     * Only If Used In Query like $query->checkPermission()
     * @param $query, $column (should be passed from controller index function)
     * @return $query
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */ 
    public function scopecheckPermission($query,$column)
    {
        
       // echo $column; exit;
        //print_r($this->checkAccessType(5));exit;

        $user = Auth::user();
        
       // dd($employee_info);

        if($user->is_superadmin == 0)
        {
            $employee_info = $this->employee_info($user);
            $res = $this->checkAccessType(5);
    
           // $this->result  = $res;
            if(count($res) > 0)
            {
                
                if($res[0]->access == 0)     /* No Access */
                    $query->whereRaw('1=2');
                elseif($res[0]->access == 1) /* Self Access */
                    $query->where($column,$user->id);
                elseif($res[0]->access == 2) /* Hierarchy Access */
                    $query->whereIn($column,$employee_info->hierarchy_users);
                elseif($res[0]->access == 3) /* Branch Access */
                    $query->whereIn($column,$employee_info->branch_users);   
                elseif($res[0]->access == 4) /* Department Access */
                    $query->whereIn($column,$employee_info->department_users);    
                elseif($res[0]->access == 5) /* All Access */
                    $query->whereRaw('1=1');
                else
                    $query->whereRaw('1=2');    
            }
            else
                $query->whereRaw('1=2');

       }

        return $query;
    }

    /**
     * This function check query with user_id column where ever this scope is appended
     * 
     * @param $query, $column (should be passed from controller getlist function Employee Call)
     * @return $query
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */ 
    public function scopecheckEmployeePermission($query,$column)
    {

        $user = Auth::user();

        if($user->is_superadmin == 0)
        {
            $employee_info = $this->employee_info($user);
            $query->whereIn($column,$employee_info->hierarchy_users);
        }

        return $query;

    }
     /**
     * This is a mutator function it returns is_delete column true or false based on conditions
     * (It will only append column if $appends used in Respective Model)
     * @return $attribute
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */ 
    public function getIsDeleteAttribute()
    {
         $is_delete = false;
         $user= Auth::user();

         if($user->is_superadmin == 0)
         {
            $res = $this->checkAccessType(6);

            if(count($res) > 0)
            {
                if($res[0]->access == 0) /*No Access*/
                    $is_delete = false;
                elseif($res[0]->access == 1) /*Self Access*/
                    $is_delete = $this->attributes['created_by'] == $user->id ? true:false;
                elseif($res[0]->access == 5) /*All Access*/ 
                    $is_delete = true;
                else
                    $is_delete = false;    

            }   
            else
                $is_delete = false;
         }
         else
            $is_delete = true;
         

         return $this->attributes['is_delete'] = $is_delete;
    }

    /**
     * This is a mutator function it returns is_edit column true or false based on conditions
     * (It will only append column if $appends used in Respective Model)
     * @return $attribute
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */ 
    

    public function getIsEditAttribute()
    {
         $is_edit = false;
         
         $user = Auth::user();

         if($user->is_superadmin == 0)
         {
         
            $res = $this->checkAccessType(3);

            if(count($res) > 0)
            {
                if($res[0]->access == 0) /*No Access*/
                    $is_edit = false;
                elseif($res[0]->access == 1)/*Self Access*/
                    $is_edit = $this->attributes['created_by'] == $user->id ? true:false;
                elseif($res[0]->access == 5) /*All Access*/   
                    $is_edit = true;
                else
                    $is_edit = false;    
            }   
            else
                $is_edit = false;    
         }
         else
            $is_edit = true;
         

         return $this->attributes['is_edit'] = $is_edit;
    }

    /**
     * This function it returns check if user can create or not based on condition. If added in controller
     * @return boolean
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */ 
    public function checkStoreAccess()
    {   
        //Need To Check The Code from Frontend Page URL
        // $user = Auth::user();
        // if($user->is_superadmin  == 0)
        // {
        //     $res = $this->checkAccessType(2);

        //     if(count($res) > 0)
        //     {
        //         if($res[0]->access == 1)
        //             return true;
        //         else
        //             return false;    
        //     }
        //     else
        //         return false;
        // }
        // else
            return true;
    }
     /**
     * This function it returns check if user can create or not based on condition. If added in controller
     * @return boolean
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */ 
    public function checkViewAccess($object)
    {   
        $user = Auth::user();
        if($user->is_superadmin  == 0)
        {
            $res = $this->checkAccessType(4);

            if(count($res) > 0)
            {
                if($res[0]->access == 1)
                    return true;
                else
                    return false;    
            }
            else
                return false;
        }
        else
            return true;
    }
    /**
     * This function it returns check if user can make update or not based on condition. If added in controller
     * @return boolean
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */ 
    public function checkUpdateAccess($object)
    {
        //Need To Check The Code from Frontend Page URL
        // $user = Auth::user();
        // if($user->is_superadmin  == 0)
        // {
        //     $employee_info = $this->employee_info($user);

        //     $res = $this->checkAccessType(3);

        //     if(count($res) > 0)
        //     {
        //         if($res[0]->access == 0) /*No Access*/
        //             return false;
        //         elseif($res[0]->access == 1) /*Self Access*/
        //         {
        //             if($object->created_by == $user->id)
        //                 return true;
        //             else 
        //                 return false;   
        //         }
        //         elseif($res[0]->access == 2)/* Hierarchy Access */
        //         {
        //             if(in_array($object->created_by,$employee_info->hierarchy_users))
        //                return true;
        //             else 
        //                return false;   
        //         }
        //         elseif($res[0]->access == 3)/* Branch Access */
        //         {
        //             if(in_array($object->created_by,$employee_info->branch_users))
        //                return true;
        //             else 
        //                return false;   
        //         }
        //         elseif($res[0]->access == 4)/* Department Access */
        //         {
        //             if(in_array($object->created_by,$employee_info->department_users))
        //                return true;
        //             else 
        //                return false;   
        //         }
        //         elseif($res[0]->access == 5) /*All Access*/   
        //             return true;
        //         else
        //             return false;    
        //     }
        //     else
        //         return false;
        // }
        // else
            return true;
    }
   
    /**
     * This function it returns check if user can delete or not based on condition. If added in controller
     * @return boolean
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */ 
    public function checkDeleteAccess($object)
    {
        $user = Auth::user();
        if($user->is_superadmin  == 0)
        {
            $employee_info = $this->employee_info($user);
            $res = $this->checkAccessType(6);

            if(count($res) > 0)
            {
                if($res[0]->access == 0) /*No Access*/
                    return false;
                elseif($res[0]->access == 1) /*Self Access*/
                {
                    if($object->created_by == $user->id)
                        return true;
                    else 
                        return false;   
                }
                elseif($res[0]->access == 2)/* Hierarchy Access */
                {
                    if(in_array($object->created_by,$employee_info->hierarchy_users))
                       return true;
                    else 
                       return false;   
                }
                elseif($res[0]->access == 3)/* Branch Access */
                {
                    if(in_array($object->created_by,$employee_info->branch_users))
                       return true;
                    else 
                       return false;   
                }
                elseif($res[0]->access == 4)/* Department Access */
                {
                    if(in_array($object->created_by,$employee_info->department_users))
                       return true;
                    else 
                       return false;   
                }
                elseif($res[0]->access == 5) /*All Access*/   
                    return true;
                else
                    return false;    
            }
            else
                return false;
        }
        else
            return true;
    }

    public function checkBulkAcess($permission_id)
    {
        $user = Auth::user();
        if($user->is_superadmin == 0)
         {
            $res = $this->checkAccessType($permission_id);
            if(count($res) > 0)
            {
                if($res[0]->access == 5)
                    return true;
                else
                    return false;     
            }
            else
                return false;
         }
         else
            return true;
    }

    /**
     * This is a mutator function it returns status in boolean value (0/1)
     * @return boolean
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */
    public function getStatusAttribute()
    {
        return intval($this->attributes['status']);
    }

    
    
    /**
     * This function it returns check if user can make update or not based on condition. If added in controller
     * @return boolean
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */ 
    public function checkTaskUpdateAccess($object)
    {
        $user = Auth::user();
        if($user->is_superadmin  == 0)
        {
            $employee_info = $this->employee_info($user);

            $res = $this->checkAccessType(3);

            if(count($res) > 0)
            {
                $employess = [];
                if(count($object->employees))
                    $employess = array_column($object->employees->toArray(),'id');
                    
                if($res[0]->access == 0) /*No Access*/
                    return false;
                elseif($res[0]->access == 1) /*Self Access*/
                {
                    if(in_array($employee_info->id,$employess) || $object->created_by == $user->id)
                        return true;
                    else 
                        return false;   
                }
                elseif($res[0]->access == 2)/* Hierarchy Access */
                {
                    if(count(array_intersect($employess,$employee_info->hierarchy_employees)) || in_array($object->created_by,$employee_info->hierarchy_users))
                       return true;
                    else 
                       return false;   
                }
                elseif($res[0]->access == 3)/* Branch Access */
                {
                    if(count(array_intersect($employess,$employee_info->branch_employees)) || in_array($object->created_by,$employee_info->branch_users))
                       return true;
                    else 
                       return false;   
                }
                elseif($res[0]->access == 4)/* Department Access */
                {
                    if(count(array_intersect($employess,$employee_info->department_employees))|| in_array($object->created_by,$employee_info->department_users))
                       return true;
                    else 
                       return false;   
                }
                elseif($res[0]->access == 5) /*All Access*/   
                    return true;
                else
                    return false;    
            }
            else
                return false;
        }
        else
            return true;
    }

     /**
     * This function it returns check if user can delete or not based on condition. If added in controller
     * @return boolean
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */ 
    public function checkTaskDeleteAccess($object)
    {
        $user = Auth::user();
        if($user->is_superadmin  == 0)
        {
            $employee_info = $this->employee_info($user);
            $res = $this->checkAccessType(6);
            
            if(count($res) > 0)
            {
                $employess = [];
                if(count($object->employees))
                    $employess = array_column($object->employees->toArray(),'id');
                    
                if($res[0]->access == 0) /*No Access*/
                    return false;
                elseif($res[0]->access == 1) /*Self Access*/
                {
                    if(in_array($employee_info->id,$employess) || $object->created_by == $user->id)
                        return true;
                    else 
                        return false;   
                }
                elseif($res[0]->access == 2)/* Hierarchy Access */
                {
                    if(count(array_intersect($employess,$employee_info->hierarchy_employees)) || in_array($object->created_by,$employee_info->hierarchy_users))
                       return true;
                    else 
                       return false;   
                }
                elseif($res[0]->access == 3)/* Branch Access */
                {
                    if(count(array_intersect($employess,$employee_info->branch_employees)) || in_array($object->created_by,$employee_info->branch_users))
                       return true;
                    else 
                       return false;   
                }
                elseif($res[0]->access == 4)/* Department Access */
                {
                    if(count(array_intersect($employess,$employee_info->department_employees)) || in_array($object->created_by,$employee_info->department_users))
                       return true;
                    else 
                       return false;   
                }
                elseif($res[0]->access == 5) /*All Access*/   
                    return true;
                else
                    return false;    
            }
            else
                return false;
        }
        else
            return true;
    }


   
}

?>
