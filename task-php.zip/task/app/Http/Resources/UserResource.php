<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class UserResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $main = parent::toArray($request);
        $profile = '';
        if(env('FILE_STORE_CLOUD'))
        {
            $profile = env('DO_SPACES_CDN').$this->profile;
        }
        else
            $profile = asset('storage/'.$this->profile);
        return array_merge($main,['roles'=>$this->roles,'profile'=> $profile ]);
    }
}
