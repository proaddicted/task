<?php

namespace App\Http\Controllers;

use App\Http\Resources\StateResource;
use App\Models\Country;
use App\Models\State;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Illuminate\Http\Request;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;

class StateController extends Controller
{
    use PermissionTrait,CommonTrait;

    public function headers()
    {
        $headers = array(
            array('column_name'=>'country','display_name'=>'Country','is_display'=>1,'is_default'=>1,'is_sortable'=>0 , 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'),
            array('column_name'=>'name','display_name'=>'Name','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'iso_code','display_name'=>'ISO Code','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'gst_code','display_name'=>'GST Code','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),  
            array('column_name'=>'creator','display_name'=>'Created By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
            array('column_name'=>'editor','display_name'=>'Updated By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
            array('column_name'=>'updated_at','display_name'=>'Updated On','is_display'=>1,'is_default'=>1,'is_sortable'=>1), 
            array('column_name'=>'created_at','display_name'=>'Added On','is_display'=>1,'is_default'=>0,'is_sortable'=>1)     
        );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    public function getlist()
    {
        $data['countries'] = Country::where('status',1)->checkPermission('created_by')->get();

        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $query = QueryBuilder::for(State::class)->allowedFilters(['name','gst_code','iso_code','country_id',AllowedFilter::exact('country_id')->ignore(null)])->defaultSort('name')->allowedSorts('name','gst_code','iso_code');

        $query->search(!empty($request->search)?$request->search:"");

        $states = $query->with('country','creator','editor')->advanceSearch($request->advfilter,'states')->checkPermission('created_by')->paginate($request->per_page);

        $this->saveAdvanceSearchData($request);

        return response(['data' => $states,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if(!$this->checkStoreAccess())
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403); 

        $validator = Validator::make($request->all(), [
            'name' => 'required'

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            $state = State::create($request->all());


            DB::commit();
            return response(['data' => new StateResource($state),'success'=>true,'message' => 'State Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return response(['data' =>new StateResource(State::findOrFail($id)),'success'=>true,'message' => 'State Retrived Successfully'], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $state=State::find($id);
        
        if(!$this->checkUpdateAccess($state))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        $validator = Validator::make($request->all(), [
            'name' => 'required'

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            
            $state->update($request->all());
            
             

            DB::commit();
            
            return response(['data' => new StateResource($state),'success'=>true,'message' => 'State Updated Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $state=State::find($id);
        
        if(!$this->checkDeleteAccess($state))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);
        
        DB::beginTransaction();
        try {
            
            $state->delete();
            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'State Deleted Successfully'], 200);
    }

    /**
     * Bulk Action function of footer (pass 6  for delete and 3 for update)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function actionall()
    {
        
        $access = request()->action == 'delete' ? 6 : 3;

        if(!$this->checkBulkAcess( $access))
            return response(['data' => array(),'success'=>false,'message' =>"You Don't Have Access For Bulk Action"], 200);

        DB::beginTransaction();
        try {
           
            if($access == 6)
                {
                    State::whereIn('id',request()->ids)->get()->each(function($state) 
                    {
                        $state->delete();
                    });
                }
            elseif($access == 3)  
                State::whereIn('id',request()->ids)->update([request()->column => request()->status]);

            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Updated successfully'], 200);
    }
}
