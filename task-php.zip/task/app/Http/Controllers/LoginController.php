<?php

namespace App\Http\Controllers;

use App\Http\Resources\UserResource;
use App\Models\Test;
use App\Models\User;
use App\Models\NotificationTemplate;
use Illuminate\Validation\ValidationException;
use App\Notifications\ForgotPasswordNotification;

use Exception;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class LoginController extends Controller
{
    /**
     * This Controller used for Authentication Services
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */


    /**
     * Used for login authentication. (Auth Provider is Passport)
     *
     * @return \Illuminate\Http\Response
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */ 
    public function login(Request $request)
    {
        $request->validate([
            'email' => ['required','email'],
            'password' =>['required']
        ]);

        
         if(Auth::attempt(['email' => $request->email, 'password' => $request->password, 'status' => 1])){
            $user = Auth::user();
            $success['access_token'] =  $user->createToken('Auth Token')->accessToken;
            $success['return_data'] = ['id'=>$user->id,'email'=>$user->email,'name'=>$user->name,'avatar'=>$user->thumbnail,'status'=>'online','is_superadmin'=>$user->is_superadmin,'type'=>$user->type];

            return $this->sendResponse($success, 'User login successfully.');
        }
        else{
            $messages = "Invalid Access Contact System Administrator";
            return $this->sendError('Invalid Credentials Please Check Or Contact System Administrator', $messages,200);
        }


    }

    /**
     * Used for logout
     *
     * @return \Illuminate\Http\Response
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */ 
    public function logout() {

        DB::table('oauth_access_tokens')
        ->where('user_id', Auth::user()->id)
        ->update([
            'revoked' => true
        ]);

        return $this->sendResponse(null, 'You have been successfully logged out!');
    }

    public function testing(Request $request)
    {

        // $test = new Test();
        // $test->title = "Aaa";
        // $test->save();
        return $this->sendResponse(Test::all()->toArray(), 'Record Instered successfully.');
    }

    /**
     * Used for change password after login
     *
     * @return \Illuminate\Http\Response
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */ 
    public function change_password(Request $request)
    {
       
        //echo Auth::user()->id; exit;
           
        $validator = Validator::make($request->all(), [
            'old_password' => 'required',
            'new_password' => 'required|min:6',
            'confirm_password' => 'required|same:new_password',

        ]);
        
        if ($validator->fails()) {
            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        } else {

            DB::beginTransaction();
            
            try {
                
                if ((Hash::check($request->old_password, Auth::user()->password)) == false) 
                {
                    DB::commit();
                    return response(['data' => array(),'success'=>false,'message' => ["Check your old password, Not matched"]], 200);
                } 
                else if ((Hash::check($request->new_password, Auth::user()->password)) == true) {
                    DB::commit();
                    return response(['data' => array(),'success'=>false,'message' => ["Please enter a password which is not similar then current password"]], 200);

                } 
                else 
                {
                    
                    User::where('id', Auth::user()->id)->update(['password' => Hash::make($request->new_password)]);
                    
                    DB::commit();
                    return response(['data' => array(),'success'=>true,'message' => "Password updated successfully"], 200);
                
                }
            } catch (Exception $ex) {
                DB::rollBack();
                return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
            }
        }
       
    }


    /**
     * Used for forgot password for user
     *
     * @return \Illuminate\Http\Response
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */ 
    public function forgot_password(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',

        ]);
        if ($validator->fails()) {
            //
            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {

            if($user = User::where('email',$request->email)->where('status',1)->first())
            {
                if($template = NotificationTemplate::where('name','forgot-password-user')->where('status',1)->first())
                {
                        try{
                    
                            $data['user'] = $user;
                            $data['template'] = $template;
                            $user->notify(new ForgotPasswordNotification($data));
                            DB::commit();
                            return response(['data' => array(),'success'=>true,'message' => 'Notification Send'], 200);
                        }
                        catch (Exception $ex) {
                            DB::rollBack();
                            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
                        } 
                }
                else
                {
                    DB::commit();
                    return response(['data' => array(),'success'=>true,'message' => 'Notification Is Disabled'], 500);  
                }
            }
            else
            {
                DB::commit();
                return response(['data' => array(),'success'=>true,'message' => 'User is Disabled,Contact System Admin'], 500);
            }
            
            
            
        }catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' => $ex->getMessage()], 500);

        }    
        
    }

    /**
     * Used for reset password for user
     * @param $id - base 64 encoded user id
     * @return \Illuminate\Http\Response
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */ 
    public function reset_password(Request $request,$id)
    {
        $validator = Validator::make($request->all(), [
          
            'password' => 'required|min:5',
            'confirm_password' => 'required|same:password',

        ]);
        
        if ($validator->fails()) {
            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        } else {

            DB::beginTransaction();
            
            try {
                
                
                    if($user = User::find(base64_decode($id)))
                    {
                        $user->password = Hash::make($request->password);
                        $user->save();
                        DB::commit();
                        return response(['data' => array(),'success'=>true,'message' => "Please Go To Signin Page To Login"], 200);
                    }
                    else
                    {
                        DB::rollBack();
                        return response(['data' => array(),'success'=>true,'message' =>  "Invalid Id"], 500);
                    }
                    // User::where('id', base64_decode($id))->update(['password' => Hash::make($request->password)]);
                    
                  
                
               
            } catch (Exception $ex) {
                DB::rollBack();
                return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
            }
        }
    }
}
