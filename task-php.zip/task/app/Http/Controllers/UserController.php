<?php

namespace App\Http\Controllers;

use App\Http\Resources\UserResource;
use App\Models\Module;
use App\Models\Role;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\AdvanceSearch;
use App\Traits\CommonTrait;
use App\Traits\PermissionTrait;
use App\Traits\EmployeeTrait;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;
use App\Models\MasterType;
use App\Models\PushNotificationUser;

class UserController extends Controller
{
    use PermissionTrait,CommonTrait,EmployeeTrait;
    
    public function headers()
    {
        $headers = array(
            array('column_name'=>'name','display_name'=>'Name','is_display'=>1,'is_default'=>1,'is_sortable'=>1,'is_multiple'=>0),
            array('column_name'=>'email','display_name'=>'Email','is_display'=>1,'is_default'=>1,'is_sortable'=>1,'is_multiple'=>0),
            array('column_name'=>'roles','display_name'=>'Roles','is_display'=>1,'is_default'=>1,'is_sortable'=>0,'is_multiple'=>1,'child_column'=>'display_name'),
            array('column_name'=>'creator','display_name'=>'Created By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
            array('column_name'=>'editor','display_name'=>'Updated By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
            array('column_name'=>'updated_at','display_name'=>'Updated On','is_display'=>1,'is_default'=>1,'is_sortable'=>1), 
            array('column_name'=>'created_at','display_name'=>'Added On','is_display'=>1,'is_default'=>0,'is_sortable'=>1)            
        );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    /**
     * This Controller used for User Resources Methods
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */
    public function getlist()
    {
    
        //DB::enableQueryLog();
        $data['roles']=Role::where('status',1)->checkRoleAccess()->get();
        //dd(DB::getQueryLog());
        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

        $query = QueryBuilder::for(User::class)->allowedFilters(['name',AllowedFilter::exact('email')->ignore(null),AllowedFilter::exact('id')->ignore(null)])->defaultSort('-created_at')->allowedSorts('name','email');

        $query->search(!empty($request->search)?$request->search:"");

        $users = $query->with('roles','creator','editor')->advanceSearch($request->advfilter,'users')->checkPermission('id')->paginate($request->per_page);

        $this->saveAdvanceSearchData($request);

        return response(['data' => $users,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       
        
        if(!$this->checkStoreAccess())
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'password' => 'required',
            'email' => 'required|email|unique:users,email',

        ]);

        if ($validator->fails()) {
            //
            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {

            $user = new User();
            $user->name = $request->name;
            $user->email = $request->email;
            $user->password = Hash::make($request->password);
            $user->is_superadmin = $request->is_superadmin==true?1:0;

            if($profile = $this->base64_upload($request->input('image'),'users'))
                $user->profile = $profile;
            
            $user->status = $request->status;
            $user->save();

            $user->roles()->attach($request->role_id,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id]); 


            DB::commit();

            return response(['data' => new UserResource($user),'success'=>true,'message' => 'User Created successfully'], 200);

        } catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(User $user)
    {
        return response(['data' =>new UserResource($user),'success'=>true,'message' => 'User Retrived Successfully'], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, User $user)
    {
        //echo $request->password; echo "---"; echo $user->password; exit;
        //dd($request->image);
        //dd($request->input('image')); 
        // echo $profile = $this->base64_upload($request->input('image'),'users');exit;
        if(!$this->checkUpdateAccess($user))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'email' => 'required|email|unique:users,email,'.$user->id,

        ]);

        if ($validator->fails()) {
            //
            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {


            $user->name = $request->name;
            $user->email = $request->email;

            if($request->password != $user->password)
                $user->password = Hash::make($request->password);
            
            $user->is_superadmin = $request->is_superadmin==true?1:0;

            if($profile = $this->base64_upload($request->input('image'),'users'))
                $user->profile = $profile;


            $user->status = $request->status;    
            $user->save();

            if(isset($request->role_id) && count($request->role_id) > 0)
            {
                $user->roles()->detach();
                $user->roles()->attach($request->role_id,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id]);
            }
            

            DB::commit();

            return response(['data' => new UserResource($user),'success'=>true,'message' => 'User Updated successfully'], 200);

        } catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' => $ex->getMessage()], 500);

        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(User $user)
    {
        if(!$this->checkDeleteAccess($user))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        DB::beginTransaction();
        try {
            $user->delete();
            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'User Deleted successfully'], 200);
    }

    /**
     * Bulk Action function of footer (pass 6  for delete and 3 for update)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function actionall()
    {
        
        $access = request()->action == 'delete' ? 6 : 3;

        if(!$this->checkBulkAcess( $access))
            return response(['data' => array(),'success'=>false,'message' =>"You Don't Have Access For Bulk Action"], 200);

        DB::beginTransaction();
        try {
           
            if($access == 6)
                {
                    User::whereIn('id',request()->ids)->get()->each(function($user) 
                    {
                        $user->delete();
                    });
                }
            elseif($access == 3)  
                User::whereIn('id',request()->ids)->update([request()->column => request()->status]);

            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Updated successfully'], 200);
    }
     /**
     * Generates Menu For Left Side Navigation
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function createMenu()
    {
        $user = Auth::user();
        $user_roles = array_column($user->roles->toArray(),'id');
        
        if( Auth::user()->is_superadmin == 0)
        {
            
            $modules = Module::with(['pages'=> function($q) use ($user_roles){ $q->whereHas('role_permission', function($q2) use ($user_roles){$q2->whereIn('role_id',$user_roles)->where('permission_id',1)->where('access','>',0);
                });
            }])->whereHas('role_permission', function($q) use ($user_roles){
                $q->whereIn('role_id',$user_roles)->where('access','>',0);
            })->where('status',1)->orderBy('order_no','asc')->get();
        }
        else
        {
            $modules = Module::with('pages')->where('status',1)->orderBy('order_no','asc')->get();
            // $modules = Module::with(['pages'=> function($q) use ($user_roles){ $q->whereHas('role_permission', function($q2) use ($user_roles){$q2->whereIn('role_id',$user_roles)->where('permission_id',1)->where('access','>',0);
            //     });
            // }])->whereHas('role_permission', function($q) use ($user_roles){
            //     $q->whereIn('role_id',$user_roles)->where('access','>',0);
            // })->where('status',1)->orderBy('order_no','asc')->get();
        }        
       
        return response(['data' => $modules,'permissions'=>$this->checkGlobalAccess(),'user'=>['id'=>$user->id,'email'=>$user->email,'name'=>$user->name,'avatar'=>env('APP_URL').'storage/'.$user->profile,'status'=>'online'], 'success'=>true,'message' => 'Data Retrived successfully'], 200);
    }
    /**
     * Check Access Of A Page
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function checkUserPageAccess()
    {
        
        $res = $this->checkAccessType(request()->access_type);
        
        return response(['data' => $res,'success'=>true,'message' => 'User Access Fetched'], 200);

    }
    /**
     * Generates User Information
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function userInfo(){
        $user = Auth::user();
        return response(['user'=>['id'=>$user->id,'email'=>$user->email,'name'=>$user->name,'avatar'=>$user->thumbnail,'status'=>'online','is_superadmin'=>$user->is_superadmin,'type'=>$user->type,'employee_info'=>$this->employee_info($user),'late_in_reasons'=>MasterType::where('status',1)->whereIn('identifier',['late-in'])->select('id','name','identifier')->get()], 'success'=>true,'message' => 'Data Retrived successfully'], 200);
    }
    /**
     * Return Advance Search Saved Filters By Page URL and Auth User
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function advanceSearchDataPageUrl(){
        $advance_search_data = AdvanceSearch::where('user_id',Auth::user()->id)->where('page_url',request()->page_url)->orderBy('created_by','desc')->take(10)->get();
        
        return response(['data' => $advance_search_data , 'success'=>true,'message' => 'Data Retrived successfully'], 200);
    }
    /**
     * Delete Advance Search Saved Filters
     * @param $id (Id of Advance Search Filter)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function deleteAdvanceSearchData($id){
        DB::beginTransaction();
        try {
            $advance_search_data=AdvanceSearch::find($id);
            $advance_search_data->delete();
            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Filter Deleted successfully'], 200);
    }

    /**
     * Change Password Of A User By Id
     * @param \Illuminate\Http\Request  $request
     * @param $id (User Tables ID)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function change_password(Request $request,$id)
    {
        $validator = Validator::make($request->all(), [
            'password' => 'min:5|required_with:conf_password|same:conf_password',
            'conf_password' => 'min:5'

        ]);

        if ($validator->fails()) {
            //
            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {

            $user = User::find($id);
           
            if($request->password != $user->password)
                $user->password = Hash::make($request->password);
            
            $user->save();    

            DB::commit();

            return response(['data' => new UserResource($user),'success'=>true,'message' => 'User Updated successfully'], 200);

        } catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' => $ex->getMessage()], 500);

        }
    }

    public function server_time(){
        return response(['data' => ['server_date_time'=>date('Y-m-d H:i:s'),'server_time'=>date('H:i:s')],'success'=>true,'message' => 'Date Time Fetched'], 200);

    }
    public function add_device(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'device_id' => 'required'
        ]);

        if ($validator->fails()) {
            //
            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {

            $pushusers = PushNotificationUser::where('device_id',$request->device_id)->where('user_id',Auth::user()->id);

            if($pushusers->count() == 0){
                PushNotificationUser::where('user_id',Auth::user()->id)->update(['status'=>0]);
                PushNotificationUser::create([
                    'user_id' => Auth::user()->id,
                    'device_id' => $request->device_id,
                    'status' => 1
                ]);
            }

            DB::commit();

            return response(['data' => [],'success'=>true,'message' => 'Device Added Successfully'], 200);

        } catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' => $ex->getMessage()], 500);

        }
    }

    public function add_user(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|unique:users,email',

        ]);

        if ($validator->fails()) {
            //
            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
        
            $name = explode('@',$request->email);

            $user = new User();
            $user->name = count($name) > 0 ? $name[0] : "";
            $user->email = $request->email;

            
            $user->password = Hash::make('1234');
            
            $user->is_superadmin = 0;

            $user->status = 0;    
            $user->save();
            
            DB::commit();

            return response(['data' => new UserResource($user),'success'=>true,'message' => 'User Updated successfully'], 200);

        } catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' => $ex->getMessage()], 500);

        }
    }
}
