<?php

namespace App\Http\Controllers;

use App\Http\Resources\RoleResource;
use App\Models\Module;
use App\Models\Role;
use App\Models\RolePermission;
use App\Traits\PermissionTrait;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;

class RoleController extends Controller
{
    use PermissionTrait;

    public $access_element = array(
        array('name'=>'Access','id'=>1),
        array('name'=>'Insert','id'=>2),
        array('name'=>'Update','id'=>3),
        array('name'=>'View','id'=>4),
        array('name'=>'List','id'=>5),
        array('name'=>'Delete','id'=>6)

    ); 

    public function headers()
    {
        $headers = array(
            array('column_name'=>'display_name','display_name'=>'Display Name','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'creator','display_name'=>'Created By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
            array('column_name'=>'editor','display_name'=>'Updated By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
            array('column_name'=>'updated_at','display_name'=>'Updated On','is_display'=>1,'is_default'=>1,'is_sortable'=>1), 
            array('column_name'=>'created_at','display_name'=>'Added On','is_display'=>1,'is_default'=>0,'is_sortable'=>1)              
        );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    public function getlist()
    {
        $data['modules'] = Module::with('pages')->where('status',1)->get();
        $data['access_types'] = $this->access_types;
        $data['access_types_insert'] = array(
            array('id'=>1,'name'=>"Yes"),
            array('id'=>0,'name'=>'No')
        );
        $data['access_element'] = $this->access_element;
        $data['roles'] = Role::where('status',1)->get();
        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);

    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $query = QueryBuilder::for(Role::class)->allowedFilters(['name','display_name'])->defaultSort('-created_at')->allowedSorts('name','display_name','display_name','updated_at');

        $query->search(!empty($request->search)?$request->search:"");

        $roles = $query->with('creator','editor')->checkPermission('created_by')->paginate($request->per_page);

        return response(['data' => $roles,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        if(!$this->checkStoreAccess())
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        $validator = Validator::make($request->all(), [
            'name' => 'required|unique:roles,name,NULL,id,deleted_at,NULL',
            'display_name' => 'required'

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            $role = Role::create($request->except(['module']));
            
            /*foreach($request->role as $data)
            {
                $object=new RolePermission($data);
                $role->permission()->save($object); 
            }*/
            foreach ($request->module as $key => $module) 
            {
                
                foreach ($module['page'] as $key => $page) 
                {
                    if(isset($page['permission']) && count($page['permission'])>0)
                    {
                        foreach ($page['permission'] as $key => $permission) 
                        {
                            
                            if(isset($permission['access']))
                            {
                                
                                $submit['module_id']=$module['id'];
                                $submit['page_id']=$page['id'];
                                $submit['permission_id']=$permission['id'];
                                $submit['access']=$permission['access'];
                                
                                $object=new RolePermission($submit);
                                $role->permission()->save($object); 
                            }
                            

                        }
                    }
                        
                }
            }

            $role->roles()->attach($request->role_id,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id]); 
            
            DB::commit();

            $role->modules = Module::with(['pages.role_permission'=> function($q2) use($role) {
                $q2->where('role_id',$role->id);
            }])->whereHas('role_permission', function($q) use ($role){
                $q->where('role_id',$role->id);
            })->where('status',1)->orderBy('order_no','asc')->get();

            return response(['data' => new RoleResource($role),'success'=>true,'message' => 'Role Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $role = Role::findOrFail($id);
        /*'pages'=> function($q) use ($id){ $q->whereHas('role_permission', function($q2) use ($id){$q2->where('role_id',$id);
            });
        },*/
        $role->modules = Module::with(['pages.role_permission'=> function($q2) use($id) {
            $q2->where('role_id',$id);
        }])->whereHas('role_permission', function($q) use ($id){
            $q->where('role_id',$id);
        })->where('status',1)->orderBy('order_no','asc')->get();

        return response(['data' => new RoleResource($role),'success'=>true,'message' => 'Role Retrived Successfully'], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $role=Role::find($id);
        
        if(!$this->checkUpdateAccess($role))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);
            
        $validator = Validator::make($request->all(), [
            'name' => 'required|unique:roles,name,'.$role->id.',id,deleted_at,NULL',
            'display_name' => 'required'

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            
            $role->update($request->except(['module','role_id']));
            
            // foreach($request->role as $data)
            // {
            //     $object=new RolePermission($data);
            //     $role->permission()->save($object); 
            // }
            if($request->module && count($request->module) > 0)
            {
                foreach ($request->module as $key => $module) 
                {
                  
                    foreach ($module['page'] as $key => $page) 
                    {
                       if(isset($page['permission']) && count($page['permission'])>0)
                       {
                            foreach ($page['permission'] as $key => $permission) 
                            {
                                
                                  $submit['module_id']=$module['id'];
                                  $submit['page_id']=$page['id'];
                                  $submit['permission_id']=$permission['id'];
                                  $submit['access']=$permission['access'];
                                  
                                  if(isset($permission['role_permission_id']) && $permission['role_permission_id'] > 0)
                                  {
                                        $object=RolePermission::find($permission['role_permission_id']);
                                        $object->fill($submit);
                                  }
                                  else
                                    $object=new RolePermission($submit);
                                
                                  $role->permission()->save($object); 
                               
                             

                            }
                       }
                            
                    }
                }
            }
            


            $role->roles()->detach();
            
            if(isset($request->role_id) && count($request->role_id) > 0)
            {
              
            
                $role->roles()->attach($request->role_id,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id]); 
            }

            DB::commit();
            
            $role->modules = Module::with(['pages.role_permission'=> function($q2) use($id) {
                $q2->where('role_id',$id);
            }])->whereHas('role_permission', function($q) use ($id){
                $q->where('role_id',$id);
            })->where('status',1)->orderBy('order_no','asc')->get();

            return response(['data' => new RoleResource($role),'success'=>true,'message' => 'Role Updated Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
           
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $role=Role::find($id);
        
        if(!$this->checkDeleteAccess($role))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        DB::beginTransaction();
        
        try {
            
            $role->delete();
            
            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Role Deleted Successfully'], 200);
    }

    /**
     * Bulk Action function of footer (pass 6  for delete and 3 for update)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function actionall()
    {
        
        $access = request()->action == 'delete' ? 6 : 3;

        if(!$this->checkBulkAcess( $access))
            return response(['data' => array(),'success'=>false,'message' =>"You Don't Have Access For Bulk Action"], 200);

        DB::beginTransaction();
        try {
           
            if($access == 6)
                {
                    Role::whereIn('id',request()->ids)->get()->each(function($role) 
                    {
                        $role->delete();
                    });
                }
            elseif($access == 3)  
                Role::whereIn('id',request()->ids)->update([request()->column => request()->status]);

            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Updated successfully'], 200);
    }
    
}
