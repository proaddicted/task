<?php

namespace App\Http\Controllers;
use App\Http\Resources\FileUploadResource;//23/09/2024
use App\Models\TempFile;
use App\Models\File;
use Illuminate\Http\Request;
use App\Traits\PermissionTrait; //23/09/2024
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use App\Traits\CommonTrait;
use Illuminate\Support\Facades\Auth;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;
use App\Models\User;
use Maatwebsite\Excel\Facades\Excel;//18/09/2024
use App\Exports\FileExcelExport;//18/09/2024
use Modules\ContactManager\Entities\Contact;
use Modules\ContactManager\Entities\Group;
use Modules\TaskManager\Entities\TaskChangeLog;
use Carbon\Carbon;

class FileUploadController extends Controller
{
    use PermissionTrait, CommonTrait; //23/09/2024

    /**
     * List Page of File Table
     * @param $id id of file table
     * @author Debargha Chakraborty <debargha.chakraborty01@gmail.com>
     * @copyright Copyright (c) 2024, Debargha Chakraborty
     * @return \Illuminate\Http\Response
     */
    public function getlist()
    {
        $data['employees'] = User::select('id','name','profile')->get();
        $data['contacts'] = Contact::select('id','fname','mname','lname')->where('type','individual')->get();
        $data['companies'] = Contact::select('id','fname','mname','lname')->where('type','company')->get();
        $data['groups'] = Group::select('id','name')->where('status',1)->get();

        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * List Page headers of File Table
     * @param $id id of file table
     * @author Debargha Chakraborty <debargha.chakraborty01@gmail.com>
     * @copyright Copyright (c) 2024, Debargha Chakraborty
     * @return \Illuminate\Http\Response
     */
    public function headers()
    {
        // dd('stop');
        $headers = array(
            array('column_name'=>'file_name','display_name'=>'Name','is_display'=>1,'is_default'=>1,'is_sortable'=>0, 'is_multiple'=>1,'is_belongs'=>0,'child_column'=>'name'),

            array('column_name'=>'group','display_name'=>'Group','is_display'=>1,'is_default'=>1,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>0,'child_column'=>'group'),

            array('column_name'=>'company','display_name'=>'Company','is_display'=>1,'is_default'=>1,'is_sortable'=>0, 'is_multiple'=>1,'is_belongs'=>0,'child_column'=>'name'),

            array('column_name'=>'tasks','display_name'=>'Task','is_display'=>1,'is_default'=>1,'is_sortable'=>0, 'is_multiple'=>1,'is_belongs'=>0,'child_column'=>'name'),

            array('column_name'=>'tasks','display_name'=>'Task Status','is_display'=>1,'is_default'=>1,'is_sortable'=>0, 'is_multiple'=>1,'is_belongs'=>0,'child_column'=>'status_name'),


            array('column_name'=>'identifier','display_name'=>'Identifier','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0,'child_column'=>'identifier'),
            array('column_name'=>'profile','display_name'=>'Added By','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'),

            array('column_name'=>'file_size','display_name'=>'File Size','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
            // array('column_name'=>'end_date','display_name'=>'End Date','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
           
            array('column_name'=>'updated_at','display_name'=>'Last Updated Date','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0)   
        );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Excel Export for Tasks
     * @author Debargha Chakraborty <debargha.chakraborty01@gmail.com> 
     * @copyright Copyright (c) 2024, Debargha Chakraborty 
     * @return \Illuminate\Http\Response
     */
    public function export(Request $request)
    {
        parse_str($request->filter, $output);
        $result = ['per_page' => $request->per_page, 'page' => $request->page, 'search' => $request->search, 'sort' => $request->sort, 'filter' => isset($output['filter']) ? $output['filter'] : [], 'advfilter' => isset($output['advfilter']) ? $output['advfilter'] : [], 'page_url' => $request->page_url];
            $excel_name = 'FileList';
            $headings = [
                'Name',
                'Group',
                'Company',
                'Task',
                'Task Status',
                'Identifier',
                'File Size',
                'Added On',
                'Added By',
                'Link',
            ];
        $saved_excel_name = $excel_name . '_' . date('d-m-Y') . '.xlsx';
        $save_file = Excel::store(new FileExcelExport($result, $headings), $saved_excel_name);

        if ($save_file && file_exists(storage_path('/app/' . $saved_excel_name))) {
            $file = storage_path('/app/' . $saved_excel_name);
            return  response()->file($file);
        } else
            return response(['data' => array(), 'success' => false, 'message' => "Invalid File Path"], 500);
    }
    /**
     * List Page of File Table
     * @param $id id of file table
     * @author Debargha Chakraborty <debargha.chakraborty01@gmail.com>
     * @copyright Copyright (c) 2024, Debargha Chakraborty
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $data=[];
        $query = QueryBuilder::for(File::class)->allowedFilters(['start_date','created_by','file_extension',AllowedFilter::exact('created_by')->ignore(null),
        AllowedFilter::exact('created_by')->ignore(null)])->defaultSort('start_date')->allowedSorts('file_name','file_size','is_client_access','start_date','end_date','document_date');

        $query->search(!empty($request->search)?$request->search:"");
     
        $files=  $query->with('creator','company.group','attendance_reports.company.group','tasks.companies.group')->fileadvanceSearch($request->advfilter,'files')->orderBy('id','desc')->paginate($request->per_page);//13/09/2024
      
        foreach($files as $key=>$value)
        {
            $company=[];
            $group=[];
            if($value['identifier'] == 'contact' && $value['company']!=null)
            {
                $company[]=$value['company'];
            }
            elseif($value['identifier'] == 'attendance-report' &&  $value['attendance_reports']!=null && $value['attendance_reports']['company']!=null){
                $company[]=$value['attendance_reports']['company'];
            }
            elseif( $value['identifier'] == 'task' &&  $value['tasks']!=null && count($value['tasks']['companies'])>0)
            {
                foreach($value['tasks']['companies'] as $value2)   
                {
                    $company[]=$value2;
                }
            }
            if(count($company)> 0)
            {
                foreach($company as $value3)
                {
                    $group[]=$value3['group'];
                }
            }
            $files[$key]['companies']=$company;
            $files[$key]['groups']=$group;
        }

        $this->saveAdvanceSearchData($request);


        return response(['data' => $files,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }



    /**
     * List Page of File Table File Count
     * @param $id id of file table
     * @author Debargha Chakraborty <debargha.chakraborty01@gmail.com>
     * @copyright Copyright (c) 2024, Debargha Chakraborty
     * @return \Illuminate\Http\Response
     */
    public function file_request(Request $request)
    {
            $data=[];
            $file_size=0;
            $query = QueryBuilder::for(File::class)->allowedFilters(['start_date','created_by','file_extension',AllowedFilter::exact('created_by')->ignore(null),
            AllowedFilter::exact('created_by')->ignore(null)])->defaultSort('start_date')->allowedSorts('file_name','file_size','is_client_access','start_date','end_date','document_date');

            $query->search(!empty($request->search)?$request->search:"");
            $query->fileadvanceSearch($request->advfilter,'files');

            $file_arr=[];
            $files=$query->select(DB::raw("SUM(file_size) as total_file_size"),DB::raw("COUNT(id) as total_files"),DB::raw('GROUP_CONCAT(id) as ids'))->get()->toArray();

            $total_file_size=$files[0]['total_file_size'];
            $kb=1024;
            $mb=$kb*1024;
            $gb=$mb*1024;
            
            if($total_file_size>=$kb)
                $file_size=number_format($total_file_size/1024,2).' KB';
            if($total_file_size>=$mb){
                $file_size=number_format($total_file_size/$mb,2).' MB';
            }
            if($total_file_size>=$gb)
                $file_size=number_format($total_file_size/$gb,2).' GB';

            return response(['data' => $files,'file_arr'=>$file_arr,'total_file_size'=>$file_size,'total_file_count'=>$files[0]['total_files'],'success'=>true,'message' => 'Data Retrived Successfully'], 200);

     
    }

    /**
     * List Page of File Table File Count
     * @param $id id of file table
     * @author Debargha Chakraborty <debargha.chakraborty01@gmail.com>
     * @copyright Copyright (c) 2024, Debargha Chakraborty
     * @return \Illuminate\Http\Response
     */
    public function get_file_array(Request $request)
    {
         $files= File::with('creator')->whereIn('id',explode(',',$request->file_ids))->get()->toArray();
            $total_file_size=0;
            $old_large_files=[];
            $old_medium_files=[];
            $old_small_files=[];
            $new_large_files=[];
            $new_medium_files=[];
            $new_small_files=[];

            foreach($files as $val)
            {
                //for time tab
                $date1 = Carbon::parse($val['created_at']);
                $date2 = Carbon::parse(date('Y-m-d'));
                $difference = $date1->diffInDays($date2); 

                if($difference >=env('RECENT_FILE_DIFFERENCE'))
                {
                    if($val['file_size']>=env('LARGE_FILE_SIZE'))
                     $old_large_files[]=$val;
                     elseif($val['file_size']< env('LARGE_FILE_SIZE') &&  $val['file_size'] >= env('MEDIUM_FILE_SIZE'))
                     {
                        $old_medium_files[]=$val;
                     }
                     else
                     $old_small_files[]=$val;
                }
                else
                {
                    if($val['file_size']>=env('LARGE_FILE_SIZE'))
                    {
                        $new_large_files[]=$val;
                    }
                    elseif($val['file_size']< env('LARGE_FILE_SIZE') &&  $val['file_size'] >= env('MEDIUM_FILE_SIZE'))
                    {
                        $new_medium_files[]=$val;
                    }
                    else
                    $new_small_files[]=$val;
                }
                
            }
            $file_arr=[
                'old_files'=>[
                    'large_files'=>$old_large_files,
                    'medium_files'=>$old_medium_files,
                    'small_files'=>$old_small_files,
                ],
                'recent_files'=>[
                    'large_files'=>$new_large_files,
                    'medium_files'=>$new_medium_files,
                    'small_files'=>$new_small_files,
                ],
                
               
            ];

            $kb=1024;
            $mb=$kb*1024;
            $gb=$mb*1024;
            
            if($total_file_size>=$kb)
                $file_size=number_format($total_file_size/1024,2).' KB';
            if($total_file_size>=$mb){
                $file_size=number_format($total_file_size/$mb,2).' MB';
            }
            if($total_file_size>=$gb)
                $file_size=number_format($total_file_size/$gb,2).' GB';

        return response(['data' => $file_arr,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
        
    }


     /**
     * Dropzone File Upload & Store to Temp File Table
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra 14/09/2024
     * @return \Illuminate\Http\Response
     */
    public function fileupload(Request $request)
    {

        if(!$request->hasFile('files')) {
            return response(['data' => array(),'success'=>false,'message' => "No files found"], 500);
        }
        $file_arr = array();
        $files = $request->file('files');
         if(count($files) > 0)
         {
            $total_size=0;
            foreach ($files as $key => $file) 
            {
                $size=$file->getSize() ;
                $total_size+=intval($size);
            }
        
            $totalBytes = $total_size;
            $file_in_kb = ($totalBytes / 1024);

            if($file_in_kb < env('MAX_UPLOAD_FILESIZE'))
            {
                foreach ($files as $key => $file) 
                {
                    // sleep(1);
                    $file_name_org_arr = explode('.'.$file->getClientOriginalExtension(), $file->getClientOriginalName());
                    
                    if(count($file_name_org_arr) > 0)
                        $file_name_formated = str_replace(' ', '_',strtolower($file_name_org_arr[0]));
                    else
                        $file_name_formated = md5(microtime());
    
                    $extenstion=$file->getClientOriginalExtension();
                    $size=$file->getSize() ;
    
                    $fileName = $file_name_formated."_".time().'.'.$extenstion; 
                    
                    // $folder_path = storage_path().'/uploads/temp/'.request()->identifier."/";
                    // if (!file_exists($folder_path)) {
                    //     $this->createPath($folder_path);
                    // }

                    if(env('FILE_STORE_CLOUD'))
                    {
                        $f_u = Storage::disk('spaces')->put(
                            'uploads/'.request()->identifier,$file, 'public'
                        );
                    }
                    else
                    {
                        Storage::disk('public')->putFileAs(
                            'uploads/temp/'.request()->identifier,$file,$fileName
                        );

                        $f_u = '/uploads/temp/'.request()->identifier.'/'.$fileName;
                    }
                   
    
                    //Storage::disk('public')->put('/uploads/temp/'.request()->identifier.'/',$file);
                    //$path = $file->move(storage_path()., $fileName); 
                    $original_file_name = $file->getClientOriginalName(); 
    
                    $temp_file = TempFile::create(['file_path' => $f_u,'file_size'=>$size,'file_extension'=> $extenstion,'file_name'=> $original_file_name,'identifier'=>request()->identifier]);
    
                    $file_arr[$key] = $temp_file ;
                }
                return response(['data' =>$file_arr,'success'=>true,'message' => 'Files Uploaded Successfully'], 200);
            }
            else
            {
                $megabytes = env('MAX_UPLOAD_FILESIZE') / 1_024; 
                $formattedSize = number_format($megabytes, 2);
                return response()->json(['data' => array(), 'success' => false, 'message' => 'File must not bigger than '.$formattedSize.'MB'], 502);
            }

           
         }
         else
         return response()->json(['data' => array(), 'success' => false, 'message' => 'No files found'], 500);
        
    }
    /**
     * Download File And Return File As File Response
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function filedownload(Request $request)
    {
     
        if(env('FILE_STORE_CLOUD'))
        {

            $file = Storage::disk('spaces')->get($request->file_path);
            // dd($file );
            // return  response()->file($file);
            // if(file_exists(env('DO_SPACES_CDN').$request->file_path))
            // {
            //     $file = env('DO_SPACES_CDN').$request->file_path;
            //     return  response()->file($file);
            // }
            // else
            //     return response(['data' => array(),'success'=>false,'message' => "Invalid File C Path"], 500);
        }
        else
        {
            if(file_exists(public_path('storage').$request->file_path))
            {
                $file = public_path('storage').$request->file_path;
                return  response()->file($file);
            }
            else
                return response(['data' => array(),'success'=>false,'message' => "Invalid File Path"], 500);
        }
       
    }
    /**
     * Dropzone File Upload & Store to Main File Table
     * @param $id as main_id 
     * @author Prosanta Mitra <pro.addicted@gmail.com> 14/09/2024
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function mainfileupload(Request $request,$id)
    {
        if(!$request->hasFile('files')) {
            return response(['data' => array(),'success'=>false,'message' => "No files found"], 500);
        }
        $file_arr = array();
        $files = $request->file('files');
        if(count($files) > 0)
        {
                $total_size=0;
                foreach ($files as $key => $file) 
                {
                    $size=$file->getSize() ;
                    $total_size+=intval($size);
                }
            
                $totalBytes = $total_size;
                $file_in_kb = ($totalBytes / 1024);

                if($file_in_kb < env('MAX_UPLOAD_FILESIZE'))
                {
                        foreach ($files as $key => $file) 
                        {
                            // sleep(1);
                            $file_name_org_arr = explode('.'.$file->getClientOriginalExtension(), $file->getClientOriginalName());
                            
                            if(count($file_name_org_arr) > 0)
                                $file_name_formated = str_replace(' ', '_',strtolower($file_name_org_arr[0]));
                            else
                                $file_name_formated = md5(microtime());
            
                            $extenstion=$file->getClientOriginalExtension();
                            $size=$file->getSize() ;
            
                            $fileName = $file_name_formated."_".time().'.'.$extenstion; 
                            

                            if(env('FILE_STORE_CLOUD'))
                            {
                                $f_u = Storage::disk('spaces')->put(
                                    'uploads/'.request()->identifier,$file, 'public'
                                );
                            }
                            else
                            {
                                Storage::disk('public')->putFileAs(
                                    'uploads/'.request()->identifier,$file,$fileName
                                );

                                $f_u = '/uploads/'.request()->identifier.'/'.$fileName;
                            }
                            //$file->store('/', 'spaces');
                            //Storage::setVisibility($photo->image, 'public');
                            // echo 
                            // dd(Storage::disk('public'));
                            // dd($file);
                           
                            //Storage::setVisibility('/'.$f_u, 'public');
                            // Storage::disk('spaces')->putFileAs(
                            //     'uploads/'.request()->identifier,$file,$fileName
                            // );
            
                            // $folder_path = storage_path().'/uploads/'.request()->identifier."/";
                            // if (!file_exists($folder_path)) {
                            //     $this->createPath($folder_path);
                            // }
                            
                            // $path = $file->move(storage_path().'/uploads/'.request()->identifier.'/', $fileName); 
                            $original_file_name = $file->getClientOriginalName(); 
            
                            $temp_file = File::create(['file_path' => $f_u ,'file_size'=>$size,'file_extension'=> $extenstion,'file_name'=> $original_file_name,'identifier'=>request()->identifier,'main_id'=>$id,'task_information_item_id'=>request()->task_information_item_id,'information_sub_group_id'=>request()->information_sub_group_id,'information_sub_group_index'=>request()->information_sub_group_index,'isLoading'=>false]);
            
            
                            if($request->identifier=='task')
                            {
                                TaskChangeLog::create(['action'=>'add','task_id'=>$id,'column_name'=>'file','new_value'=>$temp_file->id]);//11/07/2024
                            }
            
                            $file_arr[$key] = $temp_file ;
                        }
            
                    return response(['data' =>$file_arr,'success'=>true,'message' => 'Files Uploaded Successfully'], 200);
                }
                else
                {
                    $megabytes = env('MAX_UPLOAD_FILESIZE') / 1_024; 
                    $formattedSize = number_format($megabytes, 2);
                    return response()->json(['data' => array(), 'success' => false, 'message' => 'File must not bigger than '.$formattedSize.'MB'], 502);
                }
        }
        else
        return response()->json(['data' => array(), 'success' => false, 'message' => 'No files found'], 500);
        
    }
    /**
     * Unlink File and Delete from Main File Table
     * @param $id id of file table 
     * Updated By Debargha
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function mainfiledelete(Request $request,$id)
    {
        DB::beginTransaction();
        try {
            $main_file=File::find($id);
            
            if(!empty($main_file->file_path))
            {
                if(env('FILE_STORE_CLOUD'))
                {
                    Storage::disk('spaces')->delete($main_file->file_path);
                }
                else
                {
                    if(file_exists(public_path('storage').$main_file->file_path))
                    {
                        $files_count=File::where('file_path',$main_file->file_path)->count();
                        if($files_count==1)
                        {
                            if (copy(public_path('storage').$main_file->file_path, public_path('storage\backup').'\backup_'.basename($main_file->file_path)) )
                            {
                                unlink(public_path('storage').$main_file->file_path);
                            } 
                        
                        }
                    }
                }
                
            }
            $main_file->delete();
            
            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'File Deleted Successfully'], 200);
    }

     /**
     * Unlink File and Delete from Main File Table
     * @param $id id of file table
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function mainfileupdate(Request $request,$id)
    {
        DB::beginTransaction();
        try {
            
            $main_file=File::find($id);
            $main_file->update([$request->column_name => $request->column_value]);

            if($request->identifier=='task')
            {
                TaskChangeLog::create(['action'=>'update','task_id'=>$id,'column_name'=>'file','new_value'=>$request->column_value]);//11/07/2024
            }


            DB::commit();
            return response(['data' => $main_file,'success'=>true,'message' => 'File Updated Successfully'], 200);
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

      
    }

    /**
     * Unlink File and Delete from Main File Table
     * @param $id id of file table
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function mainfileupdateall(Request $request,$id)
    {
        DB::beginTransaction();
        try {
            
            $main_file=File::find($id);
            $main_file->update($request->all());

            if(isset($request->file_source_id) && count($request->file_source_id))
            {
                $main_file->file_sources()->detach();

                $main_file->file_sources()->attach($request->file_source_id,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id]);
            }
           

            DB::commit();
            return response(['data' => $main_file,'success'=>true,'message' => 'File Updated Successfully'], 200);
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

      
    }

      /**
     * Base 64 File Upload In Temp Table
     * @param $id id of file table
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function tempfileupload_base64(Request $request)
    {
        if($profile = $this->base64_upload($request->input('file'),'/uploads/temp/'.request()->identifier))
       {
        $info = $this->base64_info($request->input('file'));
        $temp_file = TempFile::create(['file_path' => $profile,'file_size'=>$info['size'],'file_extension'=>  $info['extension'],'file_name'=>  $info['file_name'],'identifier'=>request()->identifier]);

        return response(['data' =>$temp_file,'success'=>true,'message' => 'Files Uploaded Successfully'], 200);

       }
       else
        return response(['data' => array(),'success'=>false,'message' => "No files found"], 500);
    }

    /**
     * Base 64 File Upload In Main Table
     * @param $id id of file table
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function mainfileupload_base64(Request $request,$id)
    {
       if($profile = $this->base64_upload($request->input('file'),'/uploads/'.request()->identifier))
       {
            $info = $this->base64_info($request->input('file'));
            $temp_file = File::create(['file_path' => $profile,'file_size'=>$info['size'],'file_extension'=>  $info['extension'],'file_name'=>  $info['file_name'],'identifier'=>request()->identifier,'main_id'=>$id,'task_information_item_id'=>request()->task_information_item_id,'information_sub_group_id'=>request()->information_sub_group_id,'information_sub_group_index'=>request()->information_sub_group_index,'isLoading'=>false]);

            return response(['data' =>$temp_file,'success'=>true,'message' => 'Files Uploaded Successfully'], 200);

       }
       else
        return response(['data' => array(),'success'=>false,'message' => "No files found"], 500);

    }
    
    //23/09/2024
     /**
     * Bulk Action function of footer (pass 6  for delete and 3 for update)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function actionall()
    {
        
        $access = request()->action == 'delete' ? 6 : 3;

        if(!$this->checkBulkAcess( $access))
            return response(['data' => array(),'success'=>false,'message' =>"You Don't Have Access For Bulk Action"], 200);

        DB::beginTransaction();
        try {
           
            if($access == 6)
                {
                    File::whereIn('id',request()->ids)->get()->each(function($files) 
                    {
                        $files->delete();
                    });
                }
            elseif($access == 3)  
            File::whereIn('id',request()->ids)->update([request()->column => request()->status]);

            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Updated successfully'], 200);
    }

    public function store_all_files(Request $request)
    {
        $file = new File;
        $file->id = $request->id;
        $file->file_name = $request->file_name;
        $file->master_id = $request->master_id;
        $file->main_id = $request->main_id;

        if($request->identifier=='ticket')
            $identifier='task';
        elseif($request->identifier=='comment')
            $identifier='communication';
        else
            $identifier=$request->identifier;

        $file->identifier = $identifier;
        $file->file_path = $request->file_path;
        $file->file_extension = $request->file_extension;
        $file->file_size = $request->file_size;
        $file->file_description = $request->file_description;
        $file->file_type_id = $request->file_type_id;
        $file->is_client_access = $request->is_client_access;
        $file->start_date = $request->start_date;
        $file->end_date = $request->end_date;
        $file->document_date = $request->document_date;
        $file->file_stage_id = $request->stage;
        $file->information_sub_group_id = $request->file_subgroup_id;
        $file->information_sub_group_index = $request->file_subgroup_index;
        $file->created_at = $request->created_at;
        $file->updated_at = $request->updated_at;
        $file->created_by = $request->created_by;
        $file->updated_by = $request->updated_by;
        if($request->is_mirror>0)
        {
            $file->file_action = 'mirror';
            $file->parent_task_id=$request->mirror_ticket_id;
        }
        elseif ($request->moved_main_id>0) {
            $file->file_action = 'move';
            $file->parent_task_id=$request->moved_main_id;
        }
        $file->save();
    }
    
}
