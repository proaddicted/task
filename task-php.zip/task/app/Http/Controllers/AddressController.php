<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Address;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class AddressController extends Controller
{
    public function update(Request $request,$id)
    {
        $address=Address::find($id);
     
        $validator = Validator::make($request->all(), [
            'address_line1' => 'required'

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
             
            
            $address->update($request->except('is_default','status'));
            
            DB::commit();

            return response(['data' => $address,'success'=>true,'message' => 'Address Updated successfully'], 200);

        } catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' => $ex->getMessage()], 500);

        }
    }
}
