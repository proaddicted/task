<?php

namespace App\Http\Controllers;

use App\Http\Resources\ServiceResource;
use App\Models\Service;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Illuminate\Http\Request;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;

class ServiceController extends Controller
{
    use PermissionTrait,CommonTrait;
   
    /**
     * Returns Header Information Needed To Display Columns in Listing Page
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function headers()
    {
        $headers = array(
            array('column_name'=>'name','display_name'=>'Name','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'code','display_name'=>'Code','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'creator','display_name'=>'Created By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
            array('column_name'=>'editor','display_name'=>'Updated By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
            array('column_name'=>'updated_at','display_name'=>'Updated On','is_display'=>1,'is_default'=>1,'is_sortable'=>1), 
            array('column_name'=>'created_at','display_name'=>'Added On','is_display'=>1,'is_default'=>0,'is_sortable'=>1)        
        );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    /**
     * Returns Items Need For Select Boxes in Add/Edit Page
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function getlist(Request $request)
    {
        // $services=Service::where('status',1)->orderBy('name','asc')->get();
        // $services_arr=array();
        // foreach ($services as $key => $value) 
        // {
        //    $services_arr[$key]['id']=$value->id;
        //    $services_arr[$key]['name']=$this->parent_tree($value->id);
        // }
        // $data['services']=$services_arr;
        $data['services'] = Service::with('children')->where('status',1)->orderBy('name','asc')->where('parent_id',0)->get();
        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    public function parent_tree($id)
    {
        $service=Service::find($id);
        $name = "";
        $name = $service->name;
        if($service->parent_id > 0)
        {
          if($parent_service=Service::find($service->parent_id))
          	$name .=" > ".$this->parent_tree($parent_service->id);
        }
        return $name;
        
    }

    /**
     * Display a listing of the resource.
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $query = QueryBuilder::for(Service::class)->allowedFilters(['name','code',AllowedFilter::exact('parent_id')->ignore(null)->default(0)])->defaultSort('name')->allowedSorts('name','code','created_at','order_no');

        $query->search(!empty($request->search)?$request->search:"");

        $services = $query->advanceSearch($request->advfilter,'services')->with('creator','editor')->checkPermission('created_by')->paginate($request->per_page);
        
        $this->saveAdvanceSearchData($request);

        return response(['data' => $services,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Store a newly created resource in storage.
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if(!$this->checkStoreAccess())
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403); 

        $validator = Validator::make($request->all(), [
            'name' => 'required|unique:services,name,NULL,id,deleted_at,NULL', //|unique:pages,name,NULL,id,deleted_at,NULL
            'code' => 'required'

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            
            $service = Service::create($request->all());
            DB::commit();
            return response(['data' => new ServiceResource($service),'success'=>true,'message' => 'Service Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Display the specified resource.
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

        return response(['data' =>new ServiceResource(Service::findOrFail($id)),'success'=>true,'message' => 'Service Retrived Successfully'], 200);

    }

    /**
     * Update the specified resource in storage.
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $service=Service::find($id);
        
        if(!$this->checkUpdateAccess($service))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);
        
        $validator = Validator::make($request->all(), [
            'name' =>'required|unique:services,name,'.$service->id.',id,deleted_at,NULL', //|unique:pages,name,'.$page->id.',id,deleted_at,NULL
            'code' => 'required'

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
             
            
            $service->update($request->all());
            
            DB::commit();

            return response(['data' => new ServiceResource($service),'success'=>true,'message' => 'Service Updated successfully'], 200);

        } catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' => $ex->getMessage()], 500);

        }

    }

    /**
     * Remove the specified resource from storage.
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $service=Service::find($id);
        
        if(!$this->checkDeleteAccess($service))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        DB::beginTransaction();
        try {
            
            $service->delete();
            DB::commit();
            return response(['data' => array(),'success'=>true,'message' => 'Service Deleted Successfully'], 200);
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

       
    }

    /**
     * Bulk Action function of footer (pass 6  for delete and 3 for update)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function actionall()
    {
        
        $access = request()->action == 'delete' ? 6 : 3;

        if(!$this->checkBulkAcess( $access))
            return response(['data' => array(),'success'=>false,'message' =>"You Don't Have Access For Bulk Action"], 200);

        DB::beginTransaction();
        try {
           
            if($access == 6)
                {
                    Service::whereIn('id',request()->ids)->get()->each(function($service) 
                    {
                        $service->delete();
                    });
                }
            elseif($access == 3)  
                Service::whereIn('id',request()->ids)->update([request()->column => request()->status]);

            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Updated successfully'], 200);
    }
}
