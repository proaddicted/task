<?php

namespace Modules\ChatManager\Transformers;

use Illuminate\Http\Resources\Json\JsonResource;

class ChatReadOnResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request
     * @return array
     */
    public function toArray($request)
    {
        $main = parent::toArray($request);
        return array_merge($main,['user'=>$this->user]);
    }
}
