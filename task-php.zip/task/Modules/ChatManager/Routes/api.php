<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:api')->get('/chatmanager', function (Request $request) {
//     return $request->user();
// });

Route::any('store_all_chat_groups',[Modules\ChatManager\Http\Controllers\ChatRoomController::class,'store_all_chat_groups']);
Route::any('store_chat_groups_employees',[Modules\ChatManager\Http\Controllers\ChatRoomController::class,'store_chat_groups_employees']);
Route::any('store_all_chats',[Modules\ChatManager\Http\Controllers\ChatRoomController::class,'store_all_chats']);


Route::middleware(['auth:api','masterauth'])->group(function () {

    Route::resource('chat_group',ChatRoomController::class);
    Route::get('chat_getlist',[Modules\ChatManager\Http\Controllers\ChatRoomController::class,'getlist']);
    Route::get('get_chat_by_group/{id}/',[Modules\ChatManager\Http\Controllers\ChatRoomController::class,'get_chat_by_group']);
    Route::post('send_chat',[Modules\ChatManager\Http\Controllers\ChatRoomController::class,'send_chat']);
    Route::post('forward_chat',[Modules\ChatManager\Http\Controllers\ChatRoomController::class,'forward_chat']);
    Route::any('delete_user_from_group/{id}/',[Modules\ChatManager\Http\Controllers\ChatRoomController::class,'delete_user_from_group']);
    Route::any('attach_user_to_group/{id}/',[Modules\ChatManager\Http\Controllers\ChatRoomController::class,'attach_user_to_group']);
    Route::any('update_profile_picture/{id}/',[Modules\ChatManager\Http\Controllers\ChatRoomController::class,'update_profile_picture']);
    Route::any('edit_chat/{id}/',[Modules\ChatManager\Http\Controllers\ChatRoomController::class,'edit_chat']);
    Route::any('read_chat/{id}/',[Modules\ChatManager\Http\Controllers\ChatRoomController::class,'read_chat']);
    
}); 