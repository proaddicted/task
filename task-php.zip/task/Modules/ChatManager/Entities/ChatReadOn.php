<?php

namespace Modules\ChatManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use App\Models\User;

class ChatReadOn extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;

    protected $fillable = ['chat_group_id','chat_id','user_id','read_on','is_read'];
    protected $searchableColumns = [];

    protected $appends = [];
    
    public function user()
    {
        return $this->belongsTo(User::class,'user_id');
    }
    public function setIsReadAttribute($value)
    {
        $this->attributes['is_read'] = (int) $value;
    }

    protected static function boot() 
    {
        parent::boot();
        static::deleting(function(Chat $chat) {


        });

    }
    
   
}
