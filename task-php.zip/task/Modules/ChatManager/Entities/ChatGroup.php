<?php

namespace Modules\ChatManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Modules\ChatManager\Entities\Chat;


class ChatGroup extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;

    protected $fillable = ['name','type','profile','last_chat_on'];

    protected $searchableColumns = ['name','type'];

    protected $appends = ['thumbnail','display_name'];

    public function getThumbnailAttribute(){

        if($this->attributes['type'] == 'group')
        {
            if(!empty($this->attributes['profile']))
                return  $this->attributes['thumbnail'] =  env('APP_URL').'storage/'. $this->attributes['profile'];
            else
                return  $this->attributes['thumbnail'] =  null;
        }
        elseif($this->attributes['type'] == 'individual')
        {
            $users = $this->users()->where('chat_group_users.user_id','<>',Auth::user()->id);
            if($users->count())
                return $users->first()->thumbnail;
        }

    }
    public function getDisplayNameAttribute()
    {
        if($this->attributes['type'] == 'group')
        {
            return  $this->attributes['display_name'] = $this->attributes['name'];
        }
        elseif($this->attributes['type'] == 'individual')
        {
            $users = $this->users()->where('chat_group_users.user_id','<>',Auth::user()->id);
             if($users->count())
                return $users->first()->name;
             else
                return Auth::user()->name;
        }
    }
    public function chats(){
        return  $this->hasMany(Chat::class,"to_id","id")->whereNull('deleted_at')->orderBy('date','asc');
    }
    public function users()
    {
	
        return $this->belongsToMany(User::class,"chat_group_users","chat_group_id","user_id")->wherePivot('deleted_at',NULL)->withTimestamps()->withPivot('type','user_type');
    }
    /**
    * This is a public function which is used for permission checking of chat group
    * @param $query query builder reference
    * @return string or boolean or query
    * @author Prosanta Mitra <pro.addicted@gmail.com>
    * @copyright Copyright (c) 2023, Prosanta Mitra
    */
   public function scopeCheckPermission($query)
   {
        $query->whereHas('users', function ($q){
            $q->where('users.id',Auth::user()->id);
        });
        return $query;
   }

    protected static function boot() 
    {
        parent::boot();
        static::deleting(function(ChatGroup $chat_group) {

            $chat_group->users()->detach();

        });

    }
    
    
}
