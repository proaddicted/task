<?php

namespace Modules\ChatManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use App\Models\User;
use App\Models\File;
use Modules\ChatManager\Entities\ChatReadOn;


class Chat extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;

    protected $fillable = ['date','from_id','to_id','comment','parent_id','parent_type'];
    protected $searchableColumns = ['comment','date'];

    protected $appends = [];
    
    public function from()
    {
        return $this->belongsTo(User::class,'from_id');

    }
    public function parent()
    {
        return $this->belongsTo(Chat::class,'parent_id');

    }
    public function files()
    {
        return $this->hasMany(File::class,"main_id","id")->where('identifier','chat')->whereNull('deleted_at');
    }
    public function read_ons()
    {
        return $this->hasMany(ChatReadOn::class,"chat_id","id")->whereNull('deleted_at')->with('user');
    }
    protected static function boot() 
    {
        parent::boot();
        static::deleting(function(Chat $chat) {
           
            $chat->files()->delete();
            $chat->read_ons()->delete();
        });

    }
}
