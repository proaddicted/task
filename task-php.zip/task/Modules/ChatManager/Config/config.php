<?php

return [
    'name' => 'ChatManager'
];
