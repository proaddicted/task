<?php

namespace Modules\ChatManager\Events;

use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcastNow;

class ChatRead implements ShouldBroadcastNow
{
    use Dispatchable,InteractsWithSockets,SerializesModels;

    public $chat_read_on ,  $channels;
    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct($chat_read_on,$channels)
    {
        $this->chat_read_on = $chat_read_on;
        $this->channels = $channels;
    }

    public function broadcastOn()
    {
       // return ['my-channel'];
       return $this->channels;
    }
  
    public function broadcastAs()
    {
        return 'chat-read';
    }

    public function broadcastWith()
    {
        return ['chat_read_on'=>$this->chat_read_on];
    }
}
