<?php

namespace Modules\ChatManager\Events;

use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcastNow;

class Message implements ShouldBroadcastNow
{
    use Dispatchable,InteractsWithSockets,SerializesModels;

    /**
     * Create a new event instance.
     *
     * @return void
     */
    public $chat;
    public $channels;

    public function __construct($chat,$channels)
    {
        $this->chat = $chat;
        $this->channels = $channels;
    }
  
    public function broadcastOn()
    {
       // return ['my-channel'];
       return $this->channels;
    }
  
    public function broadcastAs()
    {
        return 'chat-message';
    }

    public function broadcastWith()
    {
        return ['chat_id' => $this->chat->id,'chat_group_id'=>$this->chat->to_id,'comment'=>$this->chat->comment,'chat'=>$this->chat];
    }
}
