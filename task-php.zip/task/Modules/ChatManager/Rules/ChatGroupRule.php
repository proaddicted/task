<?php

namespace Modules\ChatManager\Rules;

use Illuminate\Contracts\Validation\Rule;
use Modules\ChatManager\Entities\ChatGroup;
use Illuminate\Support\Facades\DB;

class ChatGroupRule implements Rule
{
    public $message;
    /**
     * Create a new rule instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value)
    {
      
        if(count($value))
        {
            if(request()->type == 'individual')
            {
                if(count($value) == 2)
                {
                    // $chat_groups = ChatGroup::where('type','individual')->whereHas('users', function ($q) use ($value){
                    //     $q->whereIn('users.id',$value);
                    // })->count();
                    //00000000000000000000000000000000
                    //98745325645146567855466846846856
                    //SELECT * FROM `chat_group_users` where user_id in (2, 1) and chat_group_id in (select id from chat_groups where type='individual' and deleted_at is null) group by chat_group_id, user_id having count(*) > 1

                    $chat_groups = DB::table('chat_group_users')->select(DB::raw('distinct chat_group_id,count(*) as c,id'))->whereIn('user_id',$value)->whereRaw("chat_group_id in (select id from chat_groups where type='individual' and deleted_at is null)")->whereNull('deleted_at')->groupBy('chat_group_id')->havingRaw("count(*) > 1")->get();

                   // dd( $chat_groups[0]->c);    
                    if(count($chat_groups) && $chat_groups[0]->c == 2)
                    {
                        $this->message = "Private Chat Already Exists With The User";
                        return false;
                    }
                    else
                        return true;
                }
                else
                {
                    $this->message = "Private Chat Must Be Between 2 Users";
                    return false;
                }
            }
            return true;
        }
        else
        {
            $this->message = "Please Select User";
            return false;
        }   
    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return $this->message;
    }
}
