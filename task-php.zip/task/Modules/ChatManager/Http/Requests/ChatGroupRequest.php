<?php

namespace Modules\ChatManager\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Modules\ChatManager\Rules\ChatGroupRule;

class ChatGroupRequest extends FormRequest
{
    public $message;
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'type'  => 'required',
            'users' => ['required',new ChatGroupRule]

        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
       return true;   
    }
    protected function prepareForValidation()
    {
        $user = Auth::user();

        $users = $this->users;

        if(is_array($users) && count($users))
        {
            array_push($users,  $user->id);
        }
        else
        {
            $users = [$this->users,  $user->id];
        }
    
        $this->merge([
            'master_id'=>request()->master_id,
            'users'=>$users,
        ]);
        
    }

    protected function failedValidation(\Illuminate\Contracts\Validation\Validator $validator)
    {
        
        $response = new JsonResponse(['data' => array(),'success'=>false,'message' => $validator->errors()], 422);

        throw new \Illuminate\Validation\ValidationException($validator, $response);
    
    }
}
