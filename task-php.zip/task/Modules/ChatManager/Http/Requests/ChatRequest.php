<?php

namespace Modules\ChatManager\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class ChatRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //'comment'  => 'required',
            'to_id' => 'required'
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    protected function prepareForValidation()
    {

        if($this->comment != "undefined")
            $text = $this->comment;
        else
            $text = "" ;
            
        $reg_exUrl = "/(http|https|ftp|ftps)\:\/\/[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,3}(\/\S*)?/";

        

        if(preg_match_all($reg_exUrl, $text, $url)) {

                //print_r($url); exit();
                $replace=array();
                if(count($url) > 0)
                {
                    if(count($url[0]) > 0)
                    {
                        foreach ($url[0] as $link) {
                            //echo  $link;
                            $replace[$link]="<a href='".$link."' style='color: blue;' target='_blank'>".$link."</a> ";
                            //str_replace($link, "<a href=".$link.">".$link."</a> ", $text);
                        }
                    }
                }
            
                $text = str_replace(array_keys($replace), $replace, $text);

        } else {

                if(preg_match_all("#\*" . "((?:(?!\*\/).)*)" . "\*#", $text, $bold_matches))
                {
                    //print_r($bold_matches); exit();
                    $replace_bold=array();
                    if(count($bold_matches) > 0)
                    {
                        if(count($bold_matches[0]) > 0)
                        {
                            foreach ($bold_matches[0] as $key => $link) {
                                //echo  $link;
                                $replace_bold[$link]="<b>".$bold_matches[1][$key]."</b>";
                                //str_replace($link, "<a href=".$link.">".$link."</a> ", $text);
                            }
                        }
                    }
                    $text = str_replace(array_keys($replace_bold), $replace_bold, $text);
                } 

                if(preg_match_all("#\_" . "((?:(?!\*\/).)*)" . "\_#", $text, $italic_matches))
                {
                    
                    //print_r($bold_matches); exit();
                    $replace_italic=array();
                    if(count($italic_matches) > 0)
                    {
                        if(count($italic_matches[0]) > 0)
                        {
                            foreach ($italic_matches[0] as $key => $link) {
                                //echo  $link;
                                $replace_italic[$link]="<var>".$italic_matches[1][$key]."</var>";
                                //str_replace($link, "<a href=".$link.">".$link."</a> ", $text);
                            }
                        }
                    }
                    $text = str_replace(array_keys($replace_italic), $replace_italic, $text);
                }
                
            

        }
        $this->merge([
            'comment'=>$text,
            'parent_id'=>$this->parent_id > 0 ? $this->parent_id : 0 ,
            'master_id'=>request()->master_id,
            'date'=>date('Y-m-d H:i:s')
            
        ]);
    }

    protected function failedValidation(\Illuminate\Contracts\Validation\Validator $validator)
    {
        
        $response = new JsonResponse(['data' => array(),'success'=>false,'message' => $validator->errors()], 422);

        throw new \Illuminate\Validation\ValidationException($validator, $response);
    
    }
}
