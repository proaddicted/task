<?php

namespace Modules\ChatManager\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;
use Modules\ChatManager\Events\Message;
use Modules\ChatManager\Events\ChatRead;
use Modules\ChatManager\Events\ChatEdit;
use Modules\ChatManager\Entities\ChatGroup;
use Modules\ChatManager\Transformers\ChatGroupResource;
use Modules\ChatManager\Http\Requests\ChatGroupRequest;
use Modules\ChatManager\Entities\Chat;
use Modules\ChatManager\Entities\ChatReadOn;
use Modules\ChatManager\Transformers\ChatResource;
use Modules\ChatManager\Http\Requests\ChatRequest;
use Modules\ChatManager\Rules\ChatGroupRule;
use App\Models\User;
use Modules\ResourceManager\Entities\Employee;//07/10/2024
use App\Models\TempFile;
use App\Models\File;
use OneSignal;

class ChatRoomController extends Controller
{
    use PermissionTrait,CommonTrait;


    public function getlist(Request $request)
    {
       

        //$data['chat_groups'] = ChatGroup::with('users','chats')->CheckPermission()->get();
        $data['users'] = User::where('status',1)->select('id','name','profile','email')->orderBy('name','asc')->get();
      
        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index(Request $request)
    {
        $query = QueryBuilder::for(ChatGroup::class)->allowedFilters(['name'])->defaultSort('-last_chat_on')->allowedSorts('name');

        $query->search(!empty($request->search)?$request->search:"");

        $chat_groups = $query->with('users','chats.parent','chats.parent.from','chats.read_ons','chats.read_ons.user')->CheckPermission()->get();


        return response(['data' => $chat_groups,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Store a newly created resource in storage.
     * @param ChatGroupRequest $request
     * @return Response
     */
    public function store(ChatGroupRequest $request)
    {
      
        $validator = Validator::make($request->all(), [
           

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            $chat_group = ChatGroup::create($request->except('users'));
           
            $chat_group->users()->detach();

            $chat_group->users()->attach($request->users,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 

            if($profile = $this->base64_upload($request->input('profile'),'chat_group'))
                $chat_group->profile = $profile;

            $chat_group->save();

            DB::commit();
            
            return response(['data' => ChatGroup::with('users','chats.from','chats.files','chats.parent','chats.parent.from','chats.read_ons','chats.read_ons.user')->CheckPermission()->find($chat_group->id),'success'=>true,'message' => 'Chat Group Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
       // event(new Message($request->input('message')));
       // return response(['data' => [],'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Response
     */
    public function show($id)
    {
        return response(['data' =>new ChatGroupResource(ChatGroup::findOrFail($id)),'success'=>true,'message' => 'Chat Group Retrived Successfully'], 200);
    }

    /**
     * Update the specified resource in storage.
     * @param ChatGroupRequest $request
     * @param int $id
     * @return Response
     */
    public function update(ChatGroupRequest $request, $id)
    {
        $validator = Validator::make($request->all(), [

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            $chat_group = ChatGroup::find($id);
            $chat_group->update($request->except('users'));
           
            $chat_group->users()->detach();

            $chat_group->users()->attach($request->users,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 

            if($profile = $this->base64_upload($request->input('profile'),'chat_group'))
                $chat_group->profile = $profile;

            $chat_group->save();
            
            DB::commit();
            return response(['data' => new ChatGroupResource($chat_group),'success'=>true,'message' => 'Chat Group Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Response
     */
    public function destroy($id)
    {
        $chat_group=ChatGroup::find($id);
    
        
        DB::beginTransaction();
        try {
            
            $chat_group->delete();
            DB::commit();
            return response(['data' => array(),'success'=>true,'message' => 'Chat Group Deleted Successfully'], 200);
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }
    }

    public function get_chat_by_group(Request $request,$id)
    {
        if(ChatGroup::CheckPermission()->find($id))
        {
            DB::beginTransaction();
            try {
                $readed = ChatReadOn::where('chat_group_id',$id)->where('user_id',Auth::user()->id)->where('is_read',0)->update([
                    'is_read'=>1,
                    'read_on'=>date('Y-m-d H:i:s')
                ]);
                
                $chat_group = ChatGroup::with('users','chats.from','chats.files','chats.parent','chats.parent.from','chats.read_ons','chats.read_ons.user')->find($id);
                
                
        
                if(count($chat_group->chats) && $readed)
                {
                  
                    $channels = [];
                    $i=0;
                    if(count($chat_group->users))
                    {
                        foreach ($chat_group->users as $key => $value) {
                            
                            if($value->id != Auth::user()->id)
                            {
                                // dd($value->device->device_id);
                                $channels[$i]="channel-".$value->id;
                                $i++;
                            }
                        }
        
                        
                    }
                    $chats = $chat_group->chats->toArray();
                    $last_chat = last($chats);
                
                    if(isset($last_chat['read_ons']) && count($last_chat['read_ons']))
                    {
                        foreach ($last_chat['read_ons'] as $key => $value) {
                            if($value['user_id'] == Auth::user()->id)
                            {
                                event(new ChatRead($value,$channels));
                            }
                        }
                    }
                }
                DB::commit();
                return response(['data' => $chat_group,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
            }
            catch (Exception $ex) {
    
                DB::rollBack();
                return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
            }    
        }
        else
        {
            return response(['data' => array(),'success'=>false,'message' => "Access Denied"], 200);
        }

        

    }

    public function delete_user_from_group(Request $request,$id)
    {
        $validator = Validator::make($request->all(), [
            'user_id' => 'required'

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
           

            DB::table('chat_group_users')->where('chat_group_id',$id)->where('user_id',$request->input('user_id'))->update(['deleted_at' => date('Y-m-d H:i:s'),'deleted_by'=>Auth::user()->id]);

            DB::commit();
            return response(['data' => ChatGroup::with('users','chats.from','chats.files','chats.parent','chats.parent.from','chats.read_ons','chats.read_ons.user')->find($id),'success'=>true,'message' => 'Members Updated Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    public function attach_user_to_group(Request $request,$id)
    {
         $validator = Validator::make($request->all(), [
            'users' => 'required'
        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            
            $chat_group = ChatGroup::find($id);

            $chat_group->users()->attach($request->users,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 

            
            DB::commit();
            return response(['data' =>  ChatGroup::with('users','chats.from','chats.files','chats.parent','chats.parent.from','chats.read_ons','chats.read_ons.user')->find($id),'success'=>true,'message' => 'Chat Group Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    public function update_profile_picture(Request $request,$id)
    {
        $validator = Validator::make($request->all(), [

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            $chat_group = ChatGroup::find($id);

            if($profile = $this->base64_upload($request->input('profile'),'chat_group'))
                $chat_group->profile = $profile;

            $chat_group->save();
            
            DB::commit();
            return response(['data' =>  ChatGroup::with('users','chats.from','chats.files','chats.parent','chats.parent.from','chats.read_ons','chats.read_ons.user')->find($id),'success'=>true,'message' => 'Profile Updated Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    public function send_chat(ChatRequest $request)
    {
        // $validator = Validator::make($request->all(), [
        // ]);

        // if ($validator->fails()) {

        //     return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        // }

        DB::beginTransaction();
        try {
            $chat = Chat::create($request->all());
           
            if($request->input('files') && count($request->input('files')) > 0)
            {
                foreach ($request->input('files') as $data) 
                {
                    
                    $data['identifier']=isset($data['identifier'])?$data['identifier']:"chat";
                    if(intval($data['id']) > 0 || intval($data['temp_id']) > 0)
                    {
                        if($object = File::withTrashed()->find($data['id']))
                        {
                            $object->restore();
                            $object->fill($data);
                        }
                        else
                        {
                            if($tempobject = TempFile::find($data['temp_id']))
                            {
                                
                                $object = new File($data);
                            }
                        }
                            
                        $chat->files()->save($object);
                    }
                }
            }

            $chat_group = ChatGroup::with('users')->find($request->to_id);
            $users = [];
            $channels = [];
            $devices = [];
            $i=0;
            if(count($chat_group->users))
            {
                foreach ($chat_group->users as $key => $value) {
                    if($value->id != Auth::user()->id)
                    {
                        $users[$key] = [
                            'master_id'=>$request->master_id,
                            'user_id'=>$value->id,
                            'chat_group_id'=>$chat_group->id,
                            'chat_id'=>$chat->id,
                            'is_read'=>$value->id == Auth::user()->id ? 1 : 0,
                            'read_on'=>$value->id == Auth::user()->id ? date('Y-m-d H:i:s') : null,
                            'created_at'=>date('Y-m-d H:i:s'),
                            'created_by'=> Auth::user()->id,
                            'updated_at'=>date('Y-m-d H:i:s'),
                            'updated_by'=> Auth::user()->id
                        ];
                        $channels[$i]="channel-".$value->id;
                        $devices[$i]=!empty($value->device) ? $value->device->device_id : null;
                        $i++;
                    }
                }

                if(count($users)>0)
                {
                    ChatReadOn::insert($users);
                    event(new Message(new ChatResource($chat),$channels));
                }
            }
            $fields['include_player_ids'] = array_values(array_filter($devices));
            $fields['contents'] = array(
                          "en" => $chat->comment
                      );
            $fields['headings'] = array(
                        "en" =>  $chat->from->name
                    );  
            $fields['web_url']=env('APP_FRONT_URL')."apps/chat/".$chat_group->id;     

         
            $notification = OneSignal::sendPush($fields);
            /*Push Notification Code*/        
            $chat_group->last_chat_on = date('Y-m-d H:i:s');
            $chat_group->save();

            DB::commit();
            return response(['data' => new ChatResource($chat),'success'=>true,'message' => 'Message Updated Successfully','not'=> $notification], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }
    public function forward_chat(Request $request)
    {
        $validator = Validator::make($request->all(), [
           
            'group_id.*' => 'required|min:1'
        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {

            foreach ($request->group_id as $key => $group_id) 
            {
                $chat = Chat::create(
                    [
                        'parent_id' => $request->parent_id,
                        'parent_type'=>$request->parent_type,
                        'comment'=>$request->comment,
                        'to_id'=>$group_id,
                        'from_id'=>Auth::user()->id,
                        'date'=>date('Y-m-d H:i:s')
                    ]
                );
            
                if($request->input('files') && count($request->input('files')) > 0)
                {
                    foreach ($request->input('files') as $data) 
                    {
                        
                        $data['identifier']=isset($data['identifier'])?$data['identifier']:"chat";
                        if(intval($data['id']) > 0 || intval($data['temp_id']) > 0)
                        {
                            if($object = File::withTrashed()->find($data['id']))
                            {
                                $object->restore();
                                $object->fill($data);
                            }
                            else
                            {
                                if($tempobject = TempFile::find($data['temp_id']))
                                {
                                    
                                    $object = new File($data);
                                }
                            }
                                
                            $chat->files()->save($object);
                        }
                    }
                }

                $chat_group = ChatGroup::with('users')->find($group_id);
                $users = [];
                $channels = [];
                $devices = [];
                $i=0;
                if(count($chat_group->users))
                {
                    foreach ($chat_group->users as $key => $value) {
                        if($value->id != Auth::user()->id)
                        {
                            $users[$key] = [
                                'master_id'=>$request->master_id,
                                'user_id'=>$value->id,
                                'chat_group_id'=>$chat_group->id,
                                'chat_id'=>$chat->id,
                                'is_read'=>$value->id == Auth::user()->id ? 1 : 0,
                                'read_on'=>$value->id == Auth::user()->id ? date('Y-m-d H:i:s') : null,
                                'created_at'=>date('Y-m-d H:i:s'),
                                'created_by'=> Auth::user()->id,
                                'updated_at'=>date('Y-m-d H:i:s'),
                                'updated_by'=> Auth::user()->id
                            ];

                        
                            // dd($value->device->device_id);
                                $channels[$i]="channel-".$value->id;
                                $devices[$i]=!empty($value->device) ? $value->device->device_id : null;
                                $i++;
                            }
                    }

                    if(count($users)>0)
                    {
                        ChatReadOn::insert($users);
                        event(new Message(new ChatResource($chat),$channels));
                    }
                }

                

                /*Push Notification Code*/
                $fields['include_player_ids'] = array_values(array_filter($devices));
                $fields['contents'] = array(
                            "en" => $chat->comment
                        );
                $fields['headings'] = array(
                            "en" =>  $chat->from->name
                        );  
                $fields['web_url']=env('APP_FRONT_URL')."apps/chat/".$chat_group->id;     

                $notification = OneSignal::sendPush($fields);
                /*Push Notification Code*/        
                $chat_group->last_chat_on = date('Y-m-d H:i:s');
                $chat_group->save();
            }
                

            DB::commit();
            return response(['data' => [],'success'=>true,'message' => 'Chat Forwarded Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    public function edit_chat(Request $request,$id)
    {
        // $validator = Validator::make($request->all(), [
           
        //     'comment' => 'required'
        // ]);

        // if ($validator->fails()) {

        //     return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        // }

        DB::beginTransaction();
        try {

            $chat = Chat::find($id);
            $chat->update($request->all());
                
            $chat_group = ChatGroup::with('users')->find($chat->to_id);
            $channels = [];
            $users=[];
            $i=0;
            if(count($chat_group->users))
            {
                foreach ($chat_group->users as $key => $value) {
                    
                    if($value->id != Auth::user()->id)
                    {
                        $users[]=$value;
                        // dd($value->device->device_id);
                        $channels[$i]="channel-".$value->id;
                        $i++;
                    }
                }
                if(count($users)>0)
                event(new ChatEdit($chat,$channels));
            }

            DB::commit();
            return response(['data' => [],'success'=>true,'message' => 'Chat Updated Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    public function read_chat(Request $request,$id)
    {
        DB::beginTransaction();
        try 
        {

            ChatReadOn::where('chat_id',$id)->where('user_id',$request->userid)->where('is_read',0)->update([
                'is_read'=>1,
                'read_on'=>date('Y-m-d H:i:s')
            ]);


            $chat_read_on = ChatReadOn::where('chat_id',$id)->where('user_id',$request->userid)->latest()->first();

            
            $chat_group = ChatGroup::with('users')->find($chat_read_on->chat_group_id);
            $channels = [];
            $users=[];
            $i=0;
            if(count($chat_group->users))
            {
                foreach ($chat_group->users as $key => $value) {
                    
                    if($value->id != Auth::user()->id)
                    {
                        $users[]=$value;
                        // dd($value->device->device_id);
                        $channels[$i]="channel-".$value->id;
                        $i++;
                    }
                }
                if(count($users)>0)
                event(new ChatRead($chat_read_on,$channels));
            }

            
            DB::commit();
            return response(['data' => $chat_read_on,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }    
    }

     /**********************For chat Groups ********************** */
     public function store_all_chat_groups(Request $request)
     {
         $chat_groups=new ChatGroup;
         $chat_groups->id=$request->id;
         $chat_groups->master_id=$request->master_id;
         $chat_groups->name=$request->name;
         $chat_groups->type=$request->type;
         $chat_groups->created_at=$request->created_at;
         $chat_groups->updated_at=$request->updated_at;
         $chat_groups->created_by=$request->created_by;
         $chat_groups->updated_by=$request->updated_by;
         $chat_groups->save();
     }

      /**********************For chat Groups Employees********************** */
      public function store_chat_groups_employees(Request $request)
      {
        $employee=Employee::where('id',$request->user_id)->first();
        DB::table('chat_group_users')->insert(
            [
                'id'=>$request->id,
                'master_id'=>$request->master_id,
                'chat_group_id'=>$request->chat_group_id,
                'user_id'=>isset($employee->user_id)?$employee->user_id:0,
                'created_at'=>$request->created_at,
                'updated_at'=>$request->updated_at,
                'created_by'=>$request->created_by,
                'updated_by'=>$request->updated_by,
            ]
        );
      }
 
      /**********************For Chats and Chat Reads********************** */
      public function store_all_chats(Request $request)
      {
          $chats=new Chat;
          $chats->master_id=$request->master_id;
          $chats->from_id=$request->from_id;
          $chats->to_id=$request->to_id;
          $chats->comment=$request->comment;
          $chats->to_id=$request->to_id;
          $chats->parent_id=$request->parent_id;
          $chats->parent_type=1;
          $chats->created_at=$request->created_at;
          $chats->updated_at=$request->updated_at;
          $chats->created_by=$request->created_by;
          $chats->updated_by=$request->updated_by;

          if($chats->save()==TRUE)
          {
            $chat_group = ChatGroup::with('users')->find($request->to_id);
            $users = [];
            if(count($chat_group->users))
            {
                foreach ($chat_group->users as $key => $value) {
                        $users[$key] = [
                            'master_id'=>$request->master_id,
                            'user_id'=>$value->id,
                            'chat_group_id'=>$chat_group->id,
                            'chat_id'=>$chats->id,
                            'is_read'=> 1,
                            'read_on'=>$value->id ==$request->created_at,
                            'created_at'=>$request->created_at,
                            'created_by'=> $request->created_by,
                            'updated_at'=>$request->updated_at,
                            'updated_by'=>$request->updated_by
                        ];
                }

                if(count($users)>0)
                {
                    ChatReadOn::insert($users);
                }
            }
          }
      }
}
