<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware(['auth:api','masterauth'])->group(function () {

   
    Route::any('office_in',[Modules\AttendanceManager\Http\Controllers\DailyAttendanceController::class,'officein']);
    Route::any('office_out',[Modules\AttendanceManager\Http\Controllers\DailyAttendanceController::class,'officeout']); 
    
    Route::any('daily_attendance_headers',[Modules\AttendanceManager\Http\Controllers\DailyAttendanceController::class,'headers']);
    Route::any('daily_attendance_getlist',[Modules\AttendanceManager\Http\Controllers\DailyAttendanceController::class,'getlist']);
    Route::resource('daily_attendance',DailyAttendanceController::class);
    Route::get('office_time_list',[Modules\AttendanceManager\Http\Controllers\DailyAttendanceController::class,'office_time_list']);
    Route::get('office_time_list_headers',[Modules\AttendanceManager\Http\Controllers\DailyAttendanceController::class,'office_time_headers']);
    Route::any('office_time_update',[Modules\AttendanceManager\Http\Controllers\DailyAttendanceController::class,'office_time_update']);
    Route::get('daily_wise_report',[Modules\AttendanceManager\Http\Controllers\DailyAttendanceController::class,'daily_wise_report']);
    Route::get('daily_wise_report_headers',[Modules\AttendanceManager\Http\Controllers\DailyAttendanceController::class,'daily_wise_report_headers']);
    

    Route::any('daily_attendance_report_excel_export',[Modules\AttendanceManager\Http\Controllers\DailyAttendanceReportController::class,'export']); 
    Route::any('daily_attndance_export_excel',[Modules\AttendanceManager\Http\Controllers\DailyAttendanceController::class,'export']);
    

    Route::resource('holiday',HolidayController::class);
    Route::get('holiday_getlist',[Modules\AttendanceManager\Http\Controllers\HolidayController::class,'getlist']);
    Route::get('holiday_headers',[Modules\AttendanceManager\Http\Controllers\HolidayController::class,'headers']);
    Route::any('holiday_actionall',[Modules\AttendanceManager\Http\Controllers\HolidayController::class,'actionall']);
    Route::post('bulk_holiday_store',[Modules\AttendanceManager\Http\Controllers\HolidayController::class,'bulk_holiday_store']);
    Route::any('holiday_import',[Modules\AttendanceManager\Http\Controllers\HolidayController::class,'holiday_import']);


    Route::resource('daily_attendance_report',DailyAttendanceReportController::class);
    Route::get('daily_attendance_report_getlist',[Modules\AttendanceManager\Http\Controllers\DailyAttendanceReportController::class,'getlist']);
    Route::get('daily_attendance_report_headers',[Modules\AttendanceManager\Http\Controllers\DailyAttendanceReportController::class,'headers']);
    Route::any('daily_attendance_report_actionall',[Modules\AttendanceManager\Http\Controllers\DailyAttendanceReportController::class,'actionall']);
    Route::any('daily_attendance_report_change_log/{id}/',[Modules\AttendanceManager\Http\Controllers\DailyAttendanceReportController::class,'change_log']);

    
});  

Route::any('newcrm_save_multi_officeout',[Modules\AttendanceManager\Http\Controllers\DailyAttendanceController::class,'newcrm_save_multi_officeout']); 

Route::any('newcrm_save_multi_officein',[Modules\AttendanceManager\Http\Controllers\DailyAttendanceController::class,'newcrm_save_multi_officein']); 

Route::any('newcrm_dailyattendance',[Modules\AttendanceManager\Http\Controllers\DailyAttendanceController::class,'newcrm_dailyattendance']); 

Route::any('store_daily_attendances',[Modules\AttendanceManager\Http\Controllers\DailyAttendanceController::class,'store_daily_attendances']);
Route::any('store_daily_attendance_logs',[Modules\AttendanceManager\Http\Controllers\DailyAttendanceController::class,'store_daily_attendance_logs']);
Route::any('store_daily_attendance_logs',[Modules\AttendanceManager\Http\Controllers\DailyAttendanceReportController::class,'store_daily_attendance_logs']);