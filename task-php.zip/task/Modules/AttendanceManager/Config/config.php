<?php

return [
    'name' => 'AttendanceManager'
];
