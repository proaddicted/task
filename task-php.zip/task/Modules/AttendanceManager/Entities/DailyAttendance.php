<?php

namespace Modules\AttendanceManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Modules\ResourceManager\Entities\Employee;
use App\Models\MasterType;
use App\Models\File;
use Modules\TaskManager\Entities\Task;
class DailyAttendance extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;

    protected $fillable = ['user_id','emp_id','date','schedule_in','schedule_out','schedule_break','schedule_grace','start_time','start_date_time','start_ip','start_latitude','start_longitude','start_address','end_time','end_date_time','end_ip','end_latitude','end_longitude','end_address','status','reason_id','remarks','is_paid','is_half_day','is_early_in','is_late_in','is_early_out','is_late_out','is_force_out','is_work_day','salary_processed','is_ist','task_id'];
    
    protected $searchableColumns = ['date','remarks'];
    protected $appends = ['status_name','is_ist_name'];  
    public $statuses=array(
        array('id'=>0,'name'=>'Absent'),
        array('id'=>1,'name'=>'Present'),
        array('id'=>2,'name'=>'Holiday'),
        array('id'=>3,'name'=>'Leave')
    );

    public function tasks()
    {
        return $this->belongsTo(Task::class,'task_id')->with('editor');
    }
    public function employee()
    {
        return $this->belongsTo(Employee::class,'emp_id');
    }
    public function reason()
    {
        return $this->belongsTo(MasterType::class,'reason_id');
    }
    public function files()
    {
        return $this->hasMany(File::class,"main_id","id")->where('identifier','daily-attendance')->whereNull('deleted_at');
    }
    public function getStatusNameAttribute()
    {
        if(isset($this->attributes['status']))
        {
            $statuses=array_column($this->statuses,'name', 'id'); 
            $status_name=$statuses[$this->attributes['status']];
            $this->attributes['status_name']=$status_name ;
            return $this->attributes['status_name'];
        }
        
    }

    public function getIsIstNameAttribute()
    {
        if(isset($this->attributes['is_ist']))
        {
            $is_ist=array_column($this->is_ists,'name', 'id'); 
        
            return $this->attributes['is_ist_name'] = $is_ist[$this->attributes['is_ist']];
        }
               
    }

    protected static function boot() 
    {
        parent::boot();
        
        self::creating(function($model){
          		            
		
        });

        self::created(function($model){
            
        });

        self::updating(function($model){
            
        });

        self::updated(function($model){
            
        });

        self::deleting(function($model){
           
        });

        self::deleted(function($model){
        
        });

       
    }
    
}
