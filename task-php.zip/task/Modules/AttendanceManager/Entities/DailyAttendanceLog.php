<?php

namespace Modules\AttendanceManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;

class DailyAttendanceLog extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;

    protected $fillable = ['user_id','emp_id','daily_attendance_id','date','start_time','start_date_time','start_ip','start_latitude','start_longitude','start_address','end_time','end_date_time','end_ip','end_latitude','end_longitude','end_address'];
    
    protected $searchableColumns = ['date'];



    protected static function boot() 
    {
        parent::boot();
        
        self::creating(function($model){
          		            
		
        });

        self::created(function($model){
            
        });

        self::updating(function($model){
            
        });

        self::updated(function($model){
            
        });

        self::deleting(function($model){
           
        });

        self::deleted(function($model){
        
        });

       
    }
}
