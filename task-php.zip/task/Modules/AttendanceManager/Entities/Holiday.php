<?php

namespace Modules\AttendanceManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use App\Models\Branch;
use App\Models\FiscalYear;

class Holiday extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;

    protected $fillable = ['date','reason','status','branch_id','fiscal_year_id'];

    protected $searchableColumns = ['date','reason'];

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }
    public function branch()
    {
        return $this->belongsTo(Branch::class,'branch_id');
    }
    public function fiscal_year()
    {
        return $this->belongsTo(FiscalYear::class,'fiscal_year_id');
    }
}
