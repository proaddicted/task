<?php

namespace Modules\AttendanceManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;

class DailyAttendanceReportChangeLog extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait;
    protected $fillable = ['column_name','new_value','old_value','daily_attendance_report_id','remarks'];
    
    protected $searchableColumns = ['column_name','new_value','old_value'];
}
