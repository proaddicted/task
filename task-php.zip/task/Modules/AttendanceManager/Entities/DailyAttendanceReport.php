<?php

namespace Modules\AttendanceManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Modules\ResourceManager\Entities\Employee;
use Modules\ContactManager\Entities\Contact;
use App\Models\MasterType;
use App\Models\Service;
use App\Models\File;
use Modules\TaskManager\Entities\Task;
use Carbon\Carbon; 
use Illuminate\Support\Facades\Auth;

class DailyAttendanceReport extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;

    protected $searchableColumns = ['date','reason','description','employees.fname','services.name'];

    protected $fillable = ['company_id','service_id','task_id','date','reason','time','is_outside','auto_entry','type','description','emp_id','user_id','link','status','longitude','latitude','address'];

    protected $appends = ['status_name','is_editable','attendance_type'];

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }
    public function employee()
    {
        return $this->belongsTo(Employee::class,'emp_id');
    }
    public function company()
    {
        return $this->belongsTo(Contact::class,'company_id');
    }
    public function service()
    {
        return $this->belongsTo(Service::class,'service_id');
    }
    public function tasks()
    {
        return $this->belongsTo(Task::class,'task_id');
    }
    public function files()
    {
        return $this->hasMany(File::class,"main_id","id")->where('identifier','attendance-report')->whereNull('deleted_at');
    }
    public function expenses()
    {
        return $this->belongsToMany(MasterType::class,'daily_attendance_expenses','attendance_id','expense_type_id')->withPivot('given_cost','approved_cost')->wherePivot('deleted_at',NULL)->withTimestamps();
    }
    public function task()
    {
        return $this->belongsTo(Task::class,'task_id');
    }

    public function getStatusNameAttribute()
    {
        if(isset($this->attributes['status']))
        {
            $statuses=array_column($this->attendance_report_status,'name', 'id'); 
        
            return $this->attributes['status_name'] = $statuses[$this->attributes['status']];
        }
               
    }

    public function getIsEditableAttribute()
    {
        if(isset($this->attributes['date']))
        {
            if(Auth::user()->is_superadmin == 0)
            {
                $date = Carbon::parse($this->attributes['date']);
                $now = Carbon::now();

                $diff = $date->diffInDays($now);
                
                if($diff > env('ATTENDANCE_DAYS_LIMIT'))
                    return $this->attributes['is_edit'] = false;
                else
                    return $this->attributes['is_edit'] = true;
            }
            else
             return $this->attributes['is_edit'] = true;
            
        
        }

    }

     public function getAttendanceTypeAttribute($value)
     {
         if(isset($this->attributes['type']))
         {
             $types=array_column($this->attendance_types,'name', 'id');
                     
             return $this->attributes['attendance_type'] = $types[$this->attributes['type']];
         }
     }

    protected static function boot() 
    {
        parent::boot();
        
        static::created(function (DailyAttendanceReport $daily_attendance_report) {
            if($daily_attendance_report->company_id != null && $daily_attendance_report->task_id != null){
                $daily_attendance_report->type = $daily_attendance_report->attendance_types[0]['id'];
            }
            elseif($daily_attendance_report->company_id != null && $daily_attendance_report->task_id == null){
                $daily_attendance_report->type = $daily_attendance_report->attendance_types[1]['id'];
            }
            else{
                $daily_attendance_report->type = $daily_attendance_report->attendance_types[2]['id'];
            }
            
            $daily_attendance_report->save();
        });
        
        static::deleting(function(DailyAttendanceReport $daily_attendance_report) {

            $daily_attendance_report->expenses()->detach();

        });

       
    }
    
    
}
