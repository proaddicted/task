<?php

namespace App\Imports;

use Modules\AttendanceManager\Entities\Holiday;
use Maatwebsite\Excel\Concerns\ToModel;
use App\Models\Branch;
use App\Models\FiscalYear;
use Exception;

class HolidayImport implements ToModel
{
    /**
     * @param array $row
     *
     * @return Holiday|null
     */
    public function model(array $row)
    {
        
        try {
           
            $fiscal_year = FiscalYear::where('name', $row['fiscal_year'])->first();
            $branch = Branch::where('name', $row['branch'])->first();
            
            return new Holiday([
                'fiscal_year_id' => !empty($fiscal_year) ? $fiscal_year->id : '',
                'branch_id'    => !empty($branch) ? $branch->id : '',
                'date'    => $row['date'],
                'reason' => $row['reason'],
                'status' => true
            ]);

        } catch (Exception $ex) {

           return $ex;
        }
    }
}
