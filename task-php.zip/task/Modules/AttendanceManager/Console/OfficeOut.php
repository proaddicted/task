<?php

namespace Modules\AttendanceManager\Console;

use Illuminate\Console\Command;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputArgument;
use App\Models\User;
use App\Models\NotificationTemplate;
use App\Notifications\SendSmsNotification;
use App\Notifications\SendNotification;
use Illuminate\Support\Facades\Notification;
use App\Models\NotificationLog;
use Illuminate\Support\Facades\Mail;
use App\Mail\MailChimp;
use Illuminate\Support\Facades\Auth;
use Modules\LeaveManager\Entities\LeaveApplication;
use Modules\AttendanceManager\Entities\DailyAttendance;
use Modules\AttendanceManager\Entities\Holiday;
use Modules\ResourceManager\Entities\EmployeeTiming;
use Modules\ResourceManager\Entities\Employee;
use Illuminate\Support\Facades\DB;

class OfficeOut extends Command
{
    public $notification_batch_id=0,$template_body='';
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'office:out';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
       
        if($template = DB::table('notification_templates')->where('name','employee-office-out-alert')->where('status',1)->first())
        {
            $not=DB::table('notifications')->max('batch_id');
            $this->notification_batch_id=$not+1;
            $users=DB::table('employees')->where('status',1)->where('user_id','>',0)->get();
            foreach ($users as $key => $value) 
            {   
                $holiday = Holiday::where('date',date('Y-m-d'))->where('master_id',$value->master_id)->where('status',1)->count();
                            
                $leave = LeaveApplication::where('employee_id',$value->id)->where('status',1)->whereRaw('? between start_date and end_date',[date('Y-m-d')])->count();

                $employee_timing=EmployeeTiming::where('emp_id',$value->id)->where('day','=',date('N'))->where('is_holiday',1)->count();

                $weekmonth = (date('W',strtotime(date('Y-m-d')))-date('W',strtotime(date('Y-m-01'))))+1;

                $alternative=EmployeeTiming::where('emp_id',$value->id)->where('type',2)->where('day','=',date('N'))->get();
                if(count($alternative)>0)
                {
                    $alter=DailyAttendance::where('date',date('Y-m-d', strtotime('-7 days') ))->where('status',2)->where('user_id',$value->id)->get();
                }


                $custom=EmployeeTiming::where('emp_id',$value->id)->where('type',3)->where('day',date('N'))->whereRaw('week REGEXP  "&quot;'.$weekmonth.'&quot;"')->get();

                if($holiday==0 && $leave==0 && $employee_timing==0 && count($custom)==0 &&(count($alternative)==0 || (count($alternative)>0 && count($alter)==1)))
                { 
                    $cnt=DB::table('daily_attendances')->whereNull('deleted_at')->where('user_id',$value->id)->where('date','=',date('Y-m-d'))->where('start_time','<>',null)->whereNull('end_time')->count();              
    
    
                        if($cnt==1)
                        {
                           
                            $notification_data['template'] = $template;
                            $notification_data['template_subject'] =$template->subject;
                            $notification_data['link'] =env('HTML_URL');
                            $user=User::find($value->user_id);
                            $recipients[]=array('email'=>$user->email,'name'=>$user->name,'mail_type'=>'to');
                            // dd($template);
                            if($template->sms_body!='')
                            {
                                $phoneNumber = $value->phone; // The phone number to send the SMS to
                                $user->notify(new SendSmsNotification($phoneNumber, $template->sms_body));
                                // dd('ppam');
                            }
                            Notification::send($user, new SendNotification($notification_data,'',$recipients,'daily-attendance',$this->notification_batch_id));//old
                            
                            $this->sendMailFunc($this->notification_batch_id,$template->email_body); //24/05/24
                            $this->notification_batch_id=$this->notification_batch_id+1;
                            // echo 'pop';
                        }     
                }
            }
            // dd('stop');
        }
    }


    public function sendMailFunc($batch_id,$template_body)
    {
        $notifications=NotificationLog::where('batch_id',$this->notification_batch_id)->where('status',0)->get()->toArray();
        if(count($notifications)>0)
         Mail::send(new MailChimp($notifications,$template_body,0,'daily-attendance',''));
    }

    /**
     * Get the console command arguments.
     *
     * @return array
     */
    protected function getArguments()
    {
        return [
            ['example', InputArgument::REQUIRED, 'An example argument.'],
        ];
    }

    /**
     * Get the console command options.
     *
     * @return array
     */
    protected function getOptions()
    {
        return [
            ['example', null, InputOption::VALUE_OPTIONAL, 'An example option.', null],
        ];
    }
}
