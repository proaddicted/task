<?php

namespace Modules\AttendanceManager\Console;

use Illuminate\Console\Command;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputArgument;
use App\Models\User;
use App\Models\NotificationTemplate;
use App\Notifications\SendSmsNotification;
// use App\Notifications\SendCronNotification;
use App\Notifications\SendNotification;

use Illuminate\Support\Facades\Notification;
use App\Models\NotificationLog;
use Illuminate\Support\Facades\Mail;
use App\Mail\MailChimp;
use Illuminate\Support\Facades\Auth;
use Modules\LeaveManager\Entities\LeaveApplication;
use Modules\AttendanceManager\Entities\DailyAttendance;
use Modules\AttendanceManager\Entities\Holiday;
use Modules\ResourceManager\Entities\EmployeeTiming;
use Modules\ResourceManager\Entities\Employee;
use Illuminate\Support\Facades\DB;

class DailyReport extends Command
{
    public $notification_batch_id=0,$template_body='';
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'daily:report';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        if($template = DB::table('notification_templates')->where('name','daily-report-missing-alert')->where('status',1)->first())
        {
            $not=DB::table('notifications')->max('batch_id');
            $this->notification_batch_id=$not+1;
            $employees=DB::table('employees')->where('user_id','>',0)->whereNull('deleted_at')->where('status',1)->get();
            foreach($employees as $value)
            {
                

                $holiday = Holiday::where('date',date('Y-m-d'))->where('master_id',$value->master_id)->where('status',1)->count();

                $leave = LeaveApplication::where('employee_id',$value->id)->where('status',1)->whereRaw('? between start_date and end_date',[date('Y-m-d')])->count();

                $employee_timing=EmployeeTiming::where('emp_id',$value->id)->where('day','=',date('N'))->where('is_holiday',1)->count();
            
                $weekmonth = (date('W',strtotime(date('Y-m-d')))-date('W',strtotime(date('Y-m-01'))))+1;

                $alternative=EmployeeTiming::where('emp_id',$value->id)->where('type',2)->where('day','=',date('N'))->get();
                if(count($alternative)>0)
                {
                    $alter=DB::table('daily_attendances')->where('date',date('Y-m-d', strtotime('-7 days') ))->where('status',2)->where('user_id',$value->id)->get();
                }

                $custom=EmployeeTiming::where('emp_id',$value->id)->where('type',3)->where('day',date('N'))->whereRaw('week REGEXP  "&quot;'.$weekmonth.'&quot;"')->get();

                $time=DB::table('daily_attendances')->whereNull('deleted_at')->where('user_id',$value->id)->where('date',date('Y-m-d'))->get();

                // dd(DB::table('daily_attendances')->where('user_id',$value->id)->where('date',date('Y-m-d'))->where('status',1)->whereNull('end_time')->first());
                
                if(count($time)==0)
                {
                    // dd($value);/
                        
                    $schedule=EmployeeTiming::where('emp_id',$value->id)->where('day','=',date('N'))->whereNull('deleted_at')->first();

                    $schedule_in="";
                    $schedule_out="";
                    $schedule_break="";
                    if($schedule)
                    {
                        $schedule_in=$schedule->in;
                        $schedule_out=$schedule->out;
                        $schedule_break=$schedule->lunch;
                    }

                    $attendance=DailyAttendance::create([
                        'start_ip'=>'',
                        'user_id'=>$value->user_id,
                        'emp_id'=>$value->id,
                        'start_time'=>'00:00:00',
                        'end_time'=>'00:00:00',
                        'end_ip'=>'',
                        'master_id'=>$value->master_id,
                        'schedule_in'=>$schedule_in,
                        'schedule_break'=>$schedule_break,
                        'date'=>date('Y-m-d'),
                    ]);
                    
                    
                    if($holiday>0)
                        $attendance->status = 2;
                    elseif((count($alternative)>0) && count($alter)==0)
                        $attendance->status = 2;
                    elseif(count($custom)>0)
                        $attendance->status = 2;
                        elseif($employee_timing>0)
                        $attendance->status = 2;
                    elseif($leave>0)
                        $attendance->status =3;
                    else
                        $attendance->status = 0;
                    if($attendance->save()==TRUE)
                    {
                        if ($attendance->status == 0)
                            $attendance->is_paid = 0;
                        elseif($leave > 0 && $attendance->status == 3) 
                        {
                            $leavestatus = LeaveApplication::where('employee_id',$value->id)->where('status',1)->whereRaw('? between start_date and end_date',[date('Y-m-d')])->first();
                            if ($leavestatus->is_paid == 0) 
                                $attendance->is_paid = 0;
                            elseif ($leavestatus->is_paid == 1)
                                $attendance->is_paid = 1;
                                if ($leavestatus->half_day > 0)
                            {
                                $attendance->is_half_day = $leavestatus->half_day;
                                $attendance->status = 1;
                            }
                        }
                        if (isset($alter))
                            $alter_count = count($alter);
                        else
                            $alter_count = 0;

                            if ($holiday >0 || $alter_count > 0 || count($custom) > 0 || $employee_timing > 0) 
                            $attendance->is_work_day = 0;

                            $attendance->save();
                    }    
                }
                else
                {
                    if($daily_att=DB::table('daily_attendances')->where('user_id',$value->id)->where('date',date('Y-m-d'))->where('status',1)->whereNull('end_time')->first())
                    {
                        if (isset($alter))
                            $alter_count = count($alter);
                        else
                            $alter_count = 0;
                        // $daily_att->end_time = "16:00:00";
                        // $daily_att->end_ip="Force Out";
                        if ($holiday >0 || $alter_count > 0 || count($custom) > 0)
                                $is_force_out = 0;
                        else
                            $is_force_out = 1;
                        // $daily_att->save();
                        DB::table('daily_attendances')->where('id',$daily_att->id)->update(['end_time'=>"16:00:00",'end_ip'=>"Force Out",'is_force_out'=>$is_force_out]);

                    }
                    // if($daily_att=DB::table('daily_attendances')->where('user_id',$value->id)->where('date',date('Y-m-d'))->where('status',1)->whereNull('end_time')->first())
                    // {
                    //     if (isset($alter))
                    //         $alter_count = count($alter);
                    //     else
                    //         $alter_count = 0;
                        
                    //     $daily_att->end_time = "16:00:00";
                    //     $daily_att->end_ip="Force Out";
                    //     if ($holiday >0 || $alter_count > 0 || count($custom) > 0)
                    //             $daily_att->is_force_out = 0;
                    //     else
                    //         $daily_att->is_force_out = 1;
                    //     $daily_att->save();
                    // }
                
                }  
                $late_in=DB::table('daily_attendances')->where('master_id',$value->master_id)->where('user_id',$value->id)->whereRaw("UNIX_TIMESTAMP(concat(concat(date,' '), start_time)) > (UNIX_TIMESTAMP(concat(concat(date,' '),schedule_in)) + (schedule_grace*60))")->where('status',1)->where('date',date('Y-m-d'))->count();

                $late_out=DB::table('daily_attendances')->where('master_id',$value->master_id)->where('user_id',$value->id)->whereRaw("UNIX_TIMESTAMP(concat(concat(date,' '), end_time)) > UNIX_TIMESTAMP(concat(concat(date,' '),schedule_out))")->where('status',1)->where('date',date('Y-m-d'))->count();
                //early in
                $early_in=DB::table('daily_attendances')->where('master_id',$value->master_id)->where('user_id',$value->id)->whereRaw("UNIX_TIMESTAMP(concat(concat(date,' '), start_time)) <= UNIX_TIMESTAMP(concat(concat(date,' '),schedule_in))")->where('status',1)->where('date',date('Y-m-d'))->count();
                // dd($early_in);
                //early out
                $early_out=DB::table('daily_attendances')->where('master_id',$value->master_id)->where('user_id',$value->id)->whereRaw("UNIX_TIMESTAMP(concat(concat(date,' '), end_time)) < UNIX_TIMESTAMP(concat(concat(date,' '),schedule_out))")->where('status',1)->where('date',date('Y-m-d'))->count();
                //force out
                $force_out=DB::table('daily_attendances')->where('master_id',$value->master_id)->where('user_id',$value->id)->where('status',1)->where('end_ip','Force Out')->where('date',date('Y-m-d'))->count();


                $attendance_report = DB::table('daily_attendances')->select(DB::raw('daily_attendances.*,SEC_TO_TIME(TIME_TO_SEC(start_time) -  TIME_TO_SEC(schedule_in)) as late_in,SEC_TO_TIME(TIME_TO_SEC(end_time) -  TIME_TO_SEC(schedule_out)) as late_out,SEC_TO_TIME(TIME_TO_SEC(schedule_out) -  TIME_TO_SEC(schedule_in) - TIME_TO_SEC(schedule_break)) as expected_time, SEC_TO_TIME(TIME_TO_SEC(end_time) - TIME_TO_SEC(start_time)) as system_time'))->where('user_id',$value->id)->where('date',date('Y-m-d'))->where('status',1)->first();


                if (isset($alter) && !empty($alter))
                 $alter_count = count($alter);
                else
                 $alter_count = 0;
                
                //  $leavestatus = LeaveApplication::where('employee_id',$value->id)->where('status',1)->whereRaw('? between start_date and end_date',[date('Y-m-d')])->first();
                $leavestatus = DB::table('leave_applications')->where('employee_id',$value->id)->where('status',1)->whereRaw('? between start_date and end_date',[date('Y-m-d')])->first();


                 if (!empty($attendance_report))
                 {
                     if ($holiday >0 || $alter_count > 0 || count($custom) > 0 || $employee_timing > 0) 
                     {
                        //  $attendance_report->is_work_day = 0;
                        //  $attendance_report->is_force_out = 0;
                        //  $attendance_report->is_late_in = 0;
                        //  $attendance_report->is_late_out = 0;
                        //  $attendance_report->is_early_in = 0;
                        //  $attendance_report->is_early_out = 0;
     
                        //  $attendance_report->save();
                        DB::table('daily_attendances')->where('id',$attendance_report->id)->update(['is_work_day'=>0,'is_force_out'=>0,'is_late_in'=>0,'is_late_out'=>0,'is_early_in'=>0,'is_early_out'=>0]);
                     }
                     elseif (!empty($leavestatus) && $leavestatus->half_day > 0) 
                     {
                        //  $attendance_report->is_half_day = $leavestatus->half_day;
                        //  $attendance_report->is_late_in = 0;
                        //  $attendance_report->is_late_out = 0;
                        //  $attendance_report->is_early_in = 0;
                        //  $attendance_report->is_early_out = 0;
                        //  $attendance_report->save();

                         DB::table('daily_attendances')->where('id',$attendance_report->id)->update(['is_half_day'=>$leavestatus->half_day,'is_late_in'=>0,'is_late_out'=>0,'is_early_in'=>0,'is_early_out'=>0]);
                     }
                     else
                     {
                        if ($late_in > 0)
                         {
                            $attendance_report->is_late_in = 1;
                            DB::table('daily_attendances')->where('id',$attendance_report->id)->update(['is_late_in'=>1]);
                         }
                         if ($late_out > 0)
                         {
                            $attendance_report->is_late_out = 1;
                            DB::table('daily_attendances')->where('id',$attendance_report->id)->update(['is_late_out'=>1]);
                         }
                         if ($early_in > 0)
                         {
                            $attendance_report->is_early_in = 1;
                            DB::table('daily_attendances')->where('id',$attendance_report->id)->update(['is_early_in'=>1]);
                         }
                         if ($early_out > 0 && $attendance_report->is_force_out == 0)
                        {
                            $attendance_report->is_early_out = 1;
                            DB::table('daily_attendances')->where('id',$attendance_report->id)->update(['is_early_out'=>1]);
                        }
     
                     }
     
                 }

                 if($holiday==0 && $leave==0 && $employee_timing==0 && count($custom)==0 &&(count($alternative)==0 || (count($alternative)>0 && count($alter)==1)))
                 {
              
                   
                     $cnt=DB::table('daily_attendances')->whereNull('deleted_at')->where('user_id',$value->id)->where('date','=',date('Y-m-d'))->where('status',1)->count(); //error
       
       
                       if($cnt==1)
                       {  
                           $missing=DB::table('daily_attendance_reports')->whereNull('deleted_at')->where('emp_id',$value->id)->where('date','=',date('Y-m-d'))->count();
                           if ($missing==0) 
                           {

                            $notification_data['template'] = $template;
                            $notification_data['template_subject'] =$template->subject;
                            $notification_data['start_date'] = date('d F Y');
                           
                            
                            $user=User::find($value->user_id);
                            $recipients=[];
                            if($user){
                                $recipients[]=array('email'=>$user->email,'name'=>$user->name,'mail_type'=>'to');

                                // dd($template);
                                if($template->sms_body!='')
                                {
                                    $phoneNumber = $value->phone; // The phone number to send the SMS to
                                    $user->notify(new SendSmsNotification($phoneNumber, $template->sms_body));
                                }
                                $data=array();
                                // dd($data);
                                Notification::send($user, new SendNotification($notification_data,'',$recipients,'daily-attendance',$this->notification_batch_id));//old
                                
                                $this->sendMailFunc($this->notification_batch_id,$template->email_body);
                                $this->notification_batch_id=$this->notification_batch_id+1;
                            }
                               // echo "daily report miss";
                           }
                       }  
                 }
            }
        // dd('stop');
     }
    }
    public function sendMailFunc($batch_id,$template_body)
    {
       /* $notifications=NotificationLog::where('batch_id',$this->notification_batch_id)->where('status',0)->get()->toArray();
        if(count($notifications)>0)
         Mail::send(new MailChimp($notifications,$template_body,0,'daily-report',''));*/
    }
}
