<?php

namespace Modules\AttendanceManager\Rules;

use Illuminate\Contracts\Validation\Rule;
use Modules\AttendanceManager\Entities\DailyAttendance;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;


class AttendanceReportLimitDaysRule implements Rule
{
    /**
     * Create a new rule instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value)
    {
        if(Auth::user()->is_superadmin == 0)
        {
          // 04/10/2024 Jyoti
          $today = Carbon::today();
          $threeDaysAgo = $today->subDays(env('ATTENDANCE_DAYS_LIMIT'))->startOfDay();
          $attendanceDate = Carbon::parse($value);

          return $attendanceDate->greaterThanOrEqualTo($threeDaysAgo);
      
          // $attendanceDate = Carbon::parse($value);
          // $threeDaysAgo = Carbon::now()->subDays(env('ATTENDANCE_DAYS_LIMIT'))->startOfDay();  
          // return $attendanceDate->greaterThanOrEqualTo($threeDaysAgo);

          // 04/10/2024 Jyoti
        
        }else{
            return true;
        }
    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return "You cannot edit attendance records older than 3 days.";
    }
}
