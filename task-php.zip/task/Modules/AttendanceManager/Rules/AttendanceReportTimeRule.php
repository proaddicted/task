<?php

namespace Modules\AttendanceManager\Rules;

use Illuminate\Contracts\Validation\Rule;
use Modules\AttendanceManager\Entities\DailyAttendance;
use Illuminate\Support\Facades\DB;

class AttendanceReportTimeRule implements Rule
{
    /**
     * Create a new rule instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value)
    {
        $expected_minutes = DB::table('daily_attendances')->select(DB::raw("(TIME_TO_SEC(schedule_out) - TIME_TO_SEC(start_time))/60 AS `expected_minutes`"))->where('master_id',request()->master_id)->where('emp_id',request()->emp_id)->where('date',request()->date)->whereNull('deleted_at')->first();

        $attendace_minutes =  DB::table('daily_attendance_reports')->select(DB::raw('sum(TIME_TO_SEC( time ))/60 as `attendace_minutes`'))->where('master_id',request()->master_id)->where('emp_id',request()->emp_id)->where('date',request()->date)->whereNull('deleted_at')->first();


        if($value)
        {
            if($expected_minutes && $expected_minutes != null)
            {
                $time_arr = explode(':',$value);
                $time_in_minute = $time_arr[0] * 60 + $time_arr[1];
                $att_min =  floatval($attendace_minutes->attendace_minutes) + $time_in_minute ;
    
                if($att_min > floatval($expected_minutes->expected_minutes))
                    return false;
                else
                   return true;
            }
            else
                return true;
        }

    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return  "Time shouldn't exceed expected office time";
    }
}
