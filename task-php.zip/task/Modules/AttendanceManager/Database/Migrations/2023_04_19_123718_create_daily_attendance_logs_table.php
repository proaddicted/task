<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDailyAttendanceLogsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('daily_attendance_logs', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('master_id')->nullable();
            $table->unsignedBigInteger('user_id')->nullable()->comment('users table id');
            $table->unsignedBigInteger('emp_id')->nullable()->comment('employees table id');
            $table->unsignedBigInteger('daily_attendance_id')->nullable()->comment('daily attendances table id');
            $table->date('date')->nullable();
            
            $table->string('start_time')->nullable();
            $table->dateTime('start_date_time')->nullable();
            $table->string('start_ip')->nullable();
            $table->string('start_latitude')->nullable();
            $table->string('start_longitude')->nullable();
            $table->text('start_address')->nullable();

            $table->string('end_time')->nullable();
            $table->dateTime('end_date_time')->nullable();
            $table->string('end_ip')->nullable();
            $table->string('end_latitude')->nullable();
            $table->string('end_longitude')->nullable();
            $table->text('end_address')->nullable();
            
            
            $table->softDeletes();
            $table->timestamps();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->unsignedBigInteger('deleted_by')->nullable();
          
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('daily_attendance_logs');
    }
}
