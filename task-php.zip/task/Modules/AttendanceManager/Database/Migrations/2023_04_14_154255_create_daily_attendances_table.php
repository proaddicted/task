<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDailyAttendancesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('daily_attendances', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('master_id')->nullable();
            $table->unsignedBigInteger('user_id')->nullable()->comment('user table id');
            $table->unsignedBigInteger('emp_id')->nullable()->comment('employee table id');
            $table->date('date')->nullable();
            $table->string('schedule_in')->nullable();
            $table->string('schedule_out')->nullable();
            $table->string('schedule_break')->nullable();
            $table->string('schedule_grace')->default('0')->nullable();
            
            $table->string('start_time')->nullable();
            $table->dateTime('start_date_time')->nullable();
            $table->string('start_ip')->nullable();
            $table->string('start_latitude')->nullable();
            $table->string('start_longitude')->nullable();
            $table->text('start_address')->nullable();

            $table->string('end_time')->nullable();
            $table->dateTime('end_date_time')->nullable();
            $table->string('end_ip')->nullable();
            $table->string('end_latitude')->nullable();
            $table->string('end_longitude')->nullable();
            $table->text('end_address')->nullable();
            
            $table->tinyInteger('is_paid')->default(1);
            $table->tinyInteger('is_half_day')->default(0);
            $table->tinyInteger('is_early_in')->default(0);
            $table->tinyInteger('is_late_in')->default(0);
            $table->tinyInteger('is_early_out')->default(0);
            $table->tinyInteger('is_late_out')->default(0);
            $table->tinyInteger('is_force_out')->default(0);
            $table->tinyInteger('is_work_day')->default(1);
            $table->tinyInteger('salary_processed')->default(1);

            $table->unsignedBigInteger('reason_id')->nullable();
            $table->longText('remarks')->nullable();
            $table->softDeletes();
            $table->timestamps();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->unsignedBigInteger('deleted_by')->nullable();
            $table->tinyInteger('status')->default(0)->comment('0 Absent/1 Present/2 Holiday/3 Approved Leave/4 Unaproved Leave');;
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('daily_attendances');
    }
}
