<?php

namespace Modules\AttendanceManager\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\JsonResponse;
use Geocoder;
use Exception;
use Illuminate\Support\Facades\Auth;
use App\Traits\EmployeeTrait;
use Illuminate\Http\Request;
class OfficeInRequest extends FormRequest
{
    use EmployeeTrait;
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'emp_id' => 'required',
            'user_id' => 'required',
            'date' => 'required',
            'start_time' =>'required'
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    protected function prepareForValidation()
    {
        $user = Auth::user();

        if($employee = $this->employee_info($user))
        {
            if(count($employee->employee_timings))
            {
                $this->merge([
                    'schedule_in'=>$employee->employee_timings[0]->in,
                    'schedule_out'=>$employee->employee_timings[0]->out,
                    'schedule_lunch'=>$employee->employee_timings[0]->lunch,
                    'schedule_grace'=>$employee->employee_timings[0]->grace,
                    'emp_id'=>$employee->id
                ]);
            }
            else
            {
                $this->merge([
                   
                    'emp_id'=>$employee->id
                ]);
            }
        }
        $start_address = '';
        if($this->longitude != "" &&  $this->latitude != "")
        {
            if(env('GEOCODE_ENABLE'))
            {
                try {
                    $geocode = Geocoder::getAddressForCoordinates($this->latitude,$this->longitude);
                
                    if(!empty($geocode) && is_array($geocode))
                        $start_address = $geocode['formatted_address'];
                } catch (Exception $ex) {
                    $start_address = $ex->getMessage();
                }
            }    
           
        }    
        $this->merge([
            'user_id'=>$user->id,
            'date'=>!empty($this->date) ? $this->date : date('Y-m-d'),
            'start_time'=>!empty($this->start_time) ? $this->start_time : date('H:i:s'),
            'start_date_time'=>!empty($this->start_date_time) ? $this->start_date_time : date('Y-m-d H:i:s'),
            'start_ip '=> Request::ip(),
            'start_longitude'=>!empty($this->longitude) ? $this->longitude : '',
            'start_latitude'=>!empty($this->latitude) ? $this->latitude : '',
            'start_address'=>$start_address,
            'status'=>1
        ]);    
    }

    protected function failedValidation(\Illuminate\Contracts\Validation\Validator $validator)
    {
        
        $response = new JsonResponse(['data' => array(),'success'=>false,'message' => $validator->errors()], 422);

        throw new \Illuminate\Validation\ValidationException($validator, $response);
    
    }
}
