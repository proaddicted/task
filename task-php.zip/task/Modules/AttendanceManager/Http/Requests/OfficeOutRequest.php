<?php

namespace Modules\AttendanceManager\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Geocoder;
use Exception;
use Illuminate\Support\Facades\Auth;
use App\Traits\EmployeeTrait;
use Illuminate\Http\Request;

class OfficeOutRequest extends FormRequest
{
    use EmployeeTrait;
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            
            'end_time' =>'required'
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    protected function prepareForValidation()
    {
        $user = Auth::user();
        
        if($employee = $this->employee_info($user))
        {
            if(count($employee->employee_timings))
            {
                $this->merge([

                    'emp_id'=>$employee->id
                ]);
            }
        }
        
        $end_address = '';
        if($this->longitude != "" &&  $this->latitude != "")
        {
            if(env('GEOCODE_ENABLE'))
            {
                try {
                    $geocode = Geocoder::getAddressForCoordinates($this->latitude,$this->longitude);
                
                    if(!empty($geocode) && is_array($geocode))
                        $end_address = $geocode['formatted_address'];
                } catch (Exception $ex) {
                    $end_address = $ex->getMessage();
                }
            }
            
           
        }    
        $this->merge([
            'date'=>!empty($this->date) ? $this->date : date('Y-m-d'),
            'end_time'=>!empty($this->end_time) ? $this->end_time : date('H:i:s'),
            'end_date_time'=>!empty($this->end_date_time) ? $this->end_date_time : date('Y-m-d H:i:s'),
            'end_ip '=> Request::ip(),
            'end_longitude'=>!empty($this->longitude) ? $this->longitude : '',
            'end_latitude'=>!empty($this->latitude) ? $this->latitude : '',
            'end_address'=>$end_address
        ]);
    }
    
    protected function failedValidation(\Illuminate\Contracts\Validation\Validator $validator)
    {
        
        $response = new JsonResponse(['data' => array(),'success'=>false,'message' => $validator->errors()], 422);

        throw new \Illuminate\Validation\ValidationException($validator, $response);
    
    }
}
