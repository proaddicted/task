<?php

namespace Modules\AttendanceManager\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Models\User;
use App\Models\AdvanceSearch;
use App\Traits\CommonTrait;
use App\Traits\PermissionTrait;
use App\Traits\EmployeeTrait;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;
use Modules\AttendanceManager\Http\Requests\OfficeInRequest;
use Modules\TaskManager\Entities\Task;
use Modules\AttendanceManager\Http\Requests\OfficeOutRequest;
use Modules\AttendanceManager\Http\Requests\OfficeTimeManageRequest;
use Modules\AttendanceManager\Entities\DailyAttendance;
use Modules\AttendanceManager\Entities\DailyAttendanceLog;
use App\Models\MasterType;
use Modules\ResourceManager\Entities\Employee;
use Modules\AttendanceManager\Entities\DailyAttendanceReport;
use App\Exports\DailyAttendanceExcel;
use Maatwebsite\Excel\Facades\Excel;
use App\Models\TempFile;
use App\Models\File;
use Modules\ContactManager\Entities\Contact;
use Modules\TaskManager\Entities\TaskChangeLog;

class DailyAttendanceController extends Controller
{
    use PermissionTrait,CommonTrait,EmployeeTrait;
    
    public $status=array(
        array('id'=>0,'name'=>'Absent'),
        array('id'=>1,'name'=>'Present'),
        array('id'=>2,'name'=>'Holiday'),
        array('id'=>3,'name'=>'Leave')
    );

    public function headers()
    {
        $headers = array(
             
           // 09/09/2024 Jyoti
           array('column_name'=>'employee','display_name'=>'Employee','is_display'=>1,'is_default'=>1,'is_sortable'=>0 ,'is_belongs'=>0, 'is_multiple'=>0,'is_profile'=>1,'child_column'=>'thumbnail','tooltip_column'=>'full_name'),
           array('column_name'=>'date','display_name'=>'Date','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
           array('column_name'=>'schedule_in','display_name'=>'Schedule In','is_display'=>1,'is_default'=>0,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
           array('column_name'=>'schedule_out','display_name'=>'Schedule Out','is_display'=>1,'is_default'=>0,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
           array('column_name'=>'schedule_break','display_name'=>'Schedule Break','is_display'=>1,'is_default'=>0,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
           array('column_name'=>'start_time','display_name'=>'Start Time','is_display'=>1,'is_default'=>1,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>0),
           array('column_name'=>'start_date_time','display_name'=>'Start Date Time','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
           array('column_name'=>'start_address','display_name'=>'Start Address','is_display'=>1,'is_default'=>0,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
           array('column_name'=>'start_ip','display_name'=>'Start IP','is_display'=>1,'is_default'=>0,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
           array('column_name'=>'end_time','display_name'=>'End Time','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
           array('column_name'=>'end_date_time','display_name'=>'End Date Time','is_display'=>1,'is_default'=>0,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
           array('column_name'=>'end_ip','display_name'=>'End IP','is_display'=>1,'is_default'=>0,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
           array('column_name'=>'end_address','display_name'=>'End Address','is_display'=>1,'is_default'=>0,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
           array('column_name'=>'is_ist_name','display_name'=>'IST','is_display'=>1,'is_default'=>1,'is_sortable'=>1),  // 25/09/2024 Jyoti
           array('column_name'=>'status_name','display_name'=>'Status','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
           array('column_name'=>'reason','display_name'=>'Reason','is_display'=>1,'is_default'=>0,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0,'is_belongs'=>1,'child_column'=>'name'),
           array('column_name'=>'remarks','display_name'=>'Remarks','is_display'=>1,'is_default'=>0,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
           array('column_name'=>'creator','display_name'=>'Created By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
           array('column_name'=>'editor','display_name'=>'Updated By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
           array('column_name'=>'updated_at','display_name'=>'Updated On','is_display'=>1,'is_default'=>1,'is_sortable'=>1), 
           array('column_name'=>'created_at','display_name'=>'Added On','is_display'=>1,'is_default'=>0,'is_sortable'=>1)  
           // 09/09/2024 
                  
        );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    public function getlist(Request $request)
    {
        $data['master_types'] = MasterType::where('status',1)->whereIn('identifier',['late-in'])->select('id','name','identifier')->get();
        $data['employees'] = Employee::where('status',1)->select('id','fname','mname','lname','profile')->checkPermission('user_id')->get();
        $data['companies']=Contact::where('status',1)->where('type','company')->select('fname','mname','lname','id','profile','phone','email')->get();
        $data['is_ists']= $this->is_ists; // 25/09/2024 Jyoti

        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

     /**
     * Excel Export for Tasks
     * @author Debargha Chakraborty <debargha.chakraborty01@gmail.com>
     * @copyright Copyright (c) 2023, Debargha Chakraborty 
     * @return \Illuminate\Http\Response
     */
    public function export(Request $request)
    {
        parse_str($request->filter, $output); 
        $result = ['per_page' => $request->per_page, 'page' => $request->page, 'search' => $request->search, 'sort' => $request->sort, 'filter' =>  isset($output['filter'])?$output['filter']:[], 'advfilter' => isset($output['advfilter'])?$output['advfilter']:[], 'page_url' =>$request->page_url]; 
        
        $excel_name='DailyAttendance';
        $headings=[
            'Employee',
            'Date', 
            'Schedule In', 
            'Schedule Out', 
            'Schedule Break',
            'Start Time',
            'Start Date Time',
            'End Time',  
            'End Date Time',    
            'Start Address',
            'End Address',    
            'Reason',   
            'Remarks',    
        ];
        $saved_excel_name=$excel_name.'_'.date('d-m-Y H:i:s').'.xlsx';
        $save_file=Excel::store(new DailyAttendanceExcel($result,$headings),$saved_excel_name);

        if($save_file && file_exists(storage_path('/app/'.$saved_excel_name)))
        {
            $file = storage_path('/app/'.$saved_excel_name);
            return  response()->file($file);
        }
        else
            return response(['data' => array(),'success'=>false,'message' => "Invalid File Path"], 500);
        
    }
    public function index(Request $request)
    {
        $query = QueryBuilder::for(DailyAttendance::class)->allowedFilters(['date',AllowedFilter::exact('user_id')->ignore(null),
        AllowedFilter::exact('emp_id')->ignore(null)])->defaultSort('date')->allowedSorts('date','start_date_rime','end_date_rime','created_at','updated_at','remarks','start_address','end_address','schedule_in','schedule_out','schedule_break','start_time','end_time');

        $query->search(!empty($request->search)?$request->search:"");

        $daily_attendances = $query->with('employee','reason','tasks','creator','editor')->advanceSearch($request->advfilter,'daily_attendances')->checkPermission('user_id')->paginate($request->per_page);  // 25/09/2024 Jyoti

        $this->saveAdvanceSearchData($request);

        return response(['data' => $daily_attendances,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    //07/10/2024
    public function store_daily_attendances(Request $request)
    {
        $daily_attendance = new DailyAttendance;
        $daily_attendance->id = $request->id;
        $daily_attendance->master_id = $request->master_id;
        $emp=Employee::where('id',$request->user_id)->first();
        if(isset($emp->user_id))
        {
            $daily_attendance->user_id = $emp->user_id;
        }
        $daily_attendance->emp_id = $request->user_id;
        $daily_attendance->date = $request->date;
        if($request->ist_id>0)
        {
            $daily_attendance->is_ist = 1;
        } 
        $daily_attendance->schedule_in = $request->schedule_in;
        $daily_attendance->schedule_out = $request->schedule_out;
        $daily_attendance->schedule_break = $request->schedule_break;
        $daily_attendance->schedule_grace = $request->schedule_grace;
        $daily_attendance->status = $request->status;
        $daily_attendance->is_paid = $request->is_paid;
        $daily_attendance->is_half_day = $request->is_half_day;
        $daily_attendance->is_early_in = $request->is_early_in;
        $daily_attendance->is_late_in = $request->is_late_in;
        $daily_attendance->is_early_out = $request->is_early_out;
        $daily_attendance->is_late_out = $request->is_late_out;
        $daily_attendance->is_force_out = $request->is_force_out;
        $daily_attendance->is_work_day = $request->is_work_day;
        $daily_attendance->salary_processed = $request->salary_processed;
        $daily_attendance->reason_id = $request->reason_id;
        $daily_attendance->remarks = $request->remarks;
        $daily_attendance->start_latitude = $request->start_latitude;
        $daily_attendance->start_longitude = $request->start_longitude;
        $daily_attendance->end_latitude = $request->end_latitude;
        $daily_attendance->end_longitude = $request->end_longitude;
        $daily_attendance->start_address = $request->start_address;
        $daily_attendance->end_address = $request->end_address;
        $daily_attendance->start_time = $request->start_time;
        $daily_attendance->end_time = $request->end_time;
        $daily_attendance->start_ip = $request->start_ip;
        $daily_attendance->end_ip = $request->end_ip;
        $daily_attendance->created_at = $request->created_at;
        $daily_attendance->updated_at = $request->updated_at;
        $daily_attendance->created_by = $request->created_by;
        $daily_attendance->updated_by = $request->updated_by;
        $daily_attendance->deleted_at = $request->deleted_at;
        $daily_attendance->task_id = $request->ist_id;
        $daily_attendance->start_date_time = $request->date.' '.$request->start_time ;
        $daily_attendance->end_date_time = $request->date.' '.$request->end_time;
        $daily_attendance->save();
    }
                

    //07/10/2024
    public function store_daily_attendance_logs(Request $request)
    {     
        $daily_attendance_log = new DailyAttendanceLog;
        $daily_attendance_log->id = $request->id;
        $daily_attendance_log->master_id = $request->master_id;
        $employee=Employee::where('id',$request->user_id)->first();
        if(isset($employee->user_id))
        {
            $daily_attendance_log->user_id = $employee->user_id;
        }
        $daily_attendance_log->emp_id = $request->user_id;
        $daily_attendance_log->date = $request->date;
        $daily_attendance_log->start_time = $request->start_time;
        $daily_attendance_log->end_time = $request->end_time;
        $daily_attendance_log->start_date_time = $request->date.' '.$request->start_time;
        $daily_attendance_log->end_date_time = $request->date.' '.$request->end_time;
        $daily_attendance_log->start_ip = $request->start_ip;
        $daily_attendance_log->end_ip = $request->end_ip;
        $daily_attendance_log->start_address = $request->start_address;
        $daily_attendance_log->end_address = $request->end_address;
        $daily_attendance_log->start_latitude = $request->start_latitude;
        $daily_attendance_log->start_longitude = $request->start_longitude;
        $daily_attendance_log->end_latitude = $request->end_latitude;
        $daily_attendance_log->end_longitude = $request->end_longitude;
        $daily_attendance_log->created_at = $request->created_at;
        $daily_attendance_log->updated_at = $request->updated_at;
        $daily_attendance_log->created_by = $request->created_by;
        $daily_attendance_log->updated_by = $request->updated_by;
        $daily_attendance_log->deleted_at = $request->deleted_at;

        $daily_attendance=DailyAttendance::where('emp_id',$request->user_id)->whereRaw('DATE(date) = ? ',[$request->date])->first();
        if(isset($daily_attendance->id))
        $daily_attendance_log->daily_attendance_id = $daily_attendance->id;

        $daily_attendance_log->save();
    }




    /**
     * save attendance into New CRM from Sahaj
     * @author Debargha 10/08/2024
     * @copyright belongs to Debargha, August 2024
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function newcrm_dailyattendance(Request $request)
    {
        
        $system_user=Employee::find($request->user_id);
               $attendance = DailyAttendance::create($request->except('user_id','emp_id'));
               $attendance->update(['user_id'=>$system_user->user_id,'emp_id'=>$system_user->id]);
	    $log= DailyAttendanceLog::create($request->except('user_id','emp_id'));
        $log->update(['user_id'=>$system_user->user_id,'emp_id'=>$system_user->id]);
	 
                if(isset($request->ist) && $request->ist!=null )
                {
                    $oldtask=Task::find($request->ist['new_crm_istid']);
                   $task= Task::where('id',$request->ist['new_crm_istid'])->where('type','ist')->update(['status'=>$request->ist['status']]);
                   if(isset($request->change_log_remarks))
                    TaskChangeLog::create(['action' => 'update', 'task_id' => $oldtask->id,'remarks'=>$request->change_log_remarks, 'column_name' => 'status', 'new_value' => $request->ist['status'],'old_value'=>$oldtask->status,'created_by'=>$request->change_log_updator,'updated_by'=>$request->change_log_updator,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);                }
                return response(['success'=>true,'message' => 'Data Retrived successfully'], 200);
         
    }

    /**
     * save multi time office in into New CRM from Sahaj
     * @author Debargha 12/08/2024
     * @copyright belongs to Debargha, August 2024
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function newcrm_save_multi_officein(Request $request)
    {
        $system_user=Employee::find($request->user_id);
        DB::beginTransaction();
        try {
            
                if(DailyAttendance::where('date',$request->date)->where('emp_id',$system_user->id)->count())
                {
                    $daily_attendance_logs=DailyAttendanceLog::create($request->except('user_id','emp_id','created_by','updated_by'));
                    $daily_attendance_logs->update(['user_id'=>$system_user->user_id,'emp_id'=>$system_user->id,'created_by'=>$system_user->user_id,'updated_by'=>$system_user->user_id]);
                }
                else
                {
                    $attendance = DailyAttendance::create($request->except('user_id','emp_id','created_by','updated_by'));
                    $attendance->update(['user_id'=>$system_user->user_id,'emp_id'=>$system_user->id,'created_by'=>$system_user->user_id,'updated_by'=>$system_user->user_id,'status'=>1]);
                    $daily_attendance_logs=DailyAttendanceLog::create($request->except('user_id','emp_id','created_by','updated_by'));
                    $daily_attendance_logs->update(['user_id'=>$system_user->user_id,'emp_id'=>$system_user->id,'created_by'=>$system_user->user_id,'updated_by'=>$system_user->user_id]);
                }
                DB::commit();
                return response(['success'=>true,'message' => 'Data Retrived successfully'], 200);
            }
            catch (Exception $ex) 
            {
                 DB::rollBack();
                return response(['data' => array(),'success'=>false,'message' =>  $ex->getMessage()], 500);
            }
    }

    /**
     * save multi time office out  into New CRM from Sahaj
     * @author Debargha 12/08/2024
     * @copyright belongs to Debargha, August 2024
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function newcrm_save_multi_officeout(Request $request)
    { 
        DB::beginTransaction();
        try {

                $update_data=array('end_time'=>$request->end_time,'end_ip'=>$request->end_ip,'end_address'=>$request->end_address,'end_latitude'=>$request->end_latitude,'end_longitude'=>$request->end_longitude);

                $attendance = DailyAttendance::where('date',$request->date)->where('emp_id',$request->user_id)->orderBy('created_at','desc')->first();
                $attendance->update($update_data);

                $daily_attendance_logs=DailyAttendanceLog::where('date',$request->date)->where('emp_id',$request->user_id)->orderBy('created_at','desc')->first();
                $daily_attendance_logs->update($update_data);
            
                DB::commit();
                return response(['success'=>true,'message' => 'Data Retrived successfully'], 200);
            }
            catch (Exception $ex) 
            {
                 DB::rollBack();
                return response(['data' => array(),'success'=>false,'message' =>  $ex->getMessage()], 500);
            }
    }

    /**
     * send attendance into SAHAJ from New CRM
     * @author Debargha 10/08/2024
     * @copyright belongs to Debargha, August 2024
     * @param  \Illuminate\Http\Request  $request 
     * @return \Illuminate\Http\Response
     */
    public function send_officein_sahaj($attendance)
    {
        $ch = curl_init(env('OLD_SAHAJ_LINK').'store_daily_atttendance?master=dost'); 
         $jsonData = json_encode($attendance);
       
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Content-Length: ' . strlen($jsonData)
        ]);
         curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);

         // Execute the request
        $response = curl_exec($ch);
            //print_r($response);
        //	dd('pop');
            if ($response === false) {
            $error = curl_error($ch);
            curl_close($ch);
            throw new Exception("cURL error: $error");
        }
         curl_close($ch);
    }

     /**
     * send office out into SAHAJ from New CRM
     * @author Debargha 10/08/2024
     * @copyright belongs to Debargha, August 2024
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function send_officeout_sahaj($attendance)
    {
        $ch = curl_init(env('OLD_SAHAJ_LINK').'officeout_sahaj?master=dost'); 
        $jsonData = json_encode($attendance);
    
       curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
       curl_setopt($ch, CURLOPT_POST, true);
       curl_setopt($ch, CURLOPT_HTTPHEADER, [
           'Content-Type: application/json',
           'Content-Length: ' . strlen($jsonData)
       ]);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);


        // Execute the request
        $response = curl_exec($ch);
        if ($response === false) {
            $error = curl_error($ch);
            curl_close($ch);
            throw new Exception("cURL error: $error");
        }
       
        curl_close($ch);
    }

    /**
     * This Function is Used to Give Office In (Attendance) For Users
     * @param Custom Request 
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */
    public function officein(OfficeInRequest $request)
    {
        $office=DailyAttendance::where('emp_id', $request->emp_id)->where('date',$request->date)->first();

        if(!empty($office))
        {
            DB::beginTransaction();
            try {
                $office_multi=DailyAttendanceLog::where('emp_id', $request->emp_id)->where('date',$request->date)->orderBy('created_at','desc')->get()->toArray();

                if(count($office_multi) > 0)
                {
                    
                    if($office_multi[0]['start_time']!="" && $office_multi[0]['end_time']=="")
                    {
                         DB::commit();
                        
                         return response(['data' => [],'success'=>false,'message' => ["You Are Logged In At ".$office_multi[0]['start_time']." Please Office Out To Give Office In Again"]], 200);
                    }
                    else
                    {
                       // DailyAttendanceLog::create($request->all());
			$multi_attendance=  DailyAttendanceLog::create($request->all());
			$this->send_officein_sahaj($multi_attendance);
                        $user = User::find($request->user_id);

                    
                        DB::commit();
                            
                        return response(['user'=>['id'=>$user->id,'email'=>$user->email,'name'=>$user->name,'avatar'=>env('APP_URL').'storage/'.$user->profile,'status'=>'online','is_superadmin'=>$user->is_superadmin,'type'=>$user->type,'employee_info'=>$this->employee_info($user)], 'success'=>true,'message' => 'Data Retrived successfully'], 200);
                    }
                }
                else
                {
                   // DailyAttendanceLog::create($request->all());
                    $multi_attendance=  DailyAttendanceLog::create($request->all());
		    $this->send_officein_sahaj($multi_attendance);
                    $user = User::find($request->user_id);
                
                    DB::commit();
                        
                    return response(['user'=>['id'=>$user->id,'email'=>$user->email,'name'=>$user->name,'avatar'=>env('APP_URL').'storage/'.$user->profile,'status'=>'online','is_superadmin'=>$user->is_superadmin,'type'=>$user->type,'employee_info'=>$this->employee_info($user)], 'success'=>true,'message' => 'Data Retrived successfully'], 200);
                }
    
              
               
            }
            catch (Exception $ex) {
    
                DB::rollBack();
                return response(['data' => array(),'success'=>false,'message' =>  $ex->getMessage()], 500);
            }
        }
        else
        {
            DB::beginTransaction();
            try {
                
                $attendance = DailyAttendance::create($request->all());
                $this->send_officein_sahaj($attendance);
                if($request->input('files') && count($request->input('files')) > 0)
                {
                    foreach ($request->input('files') as $data) 
                    {
                        
                        $data['identifier']=isset($data['identifier'])?$data['identifier']:"daily-attendance";
                        if(intval($data['id']) > 0 || intval($data['temp_id']) > 0)
                        {
                            if($object = File::withTrashed()->find($data['id']))
                            {
                                $object->restore();
                                $object->fill($data);
                            }
                            else
                            {
                                if($tempobject = TempFile::find($data['temp_id']))
                                {
                                    
                                    $object = new File($data);
                                }
                            }
                                
                            $attendance->files()->save($object);
                        }
                    }
                }

                $request->merge([
                    'daily_attendance_id' => $attendance->id,
                ]);
                $attendance_log = DailyAttendanceLog::create($request->all());

                $user = User::find($attendance->user_id);
                
                DB::commit();
                
                return response(['user'=>['id'=>$user->id,'email'=>$user->email,'name'=>$user->name,'avatar'=>env('APP_URL').'storage/'.$user->profile,'status'=>'online','is_superadmin'=>$user->is_superadmin,'type'=>$user->type,'employee_info'=>$this->employee_info($user)], 'success'=>true,'message' => 'Data Retrived successfully'], 200);
            }
            catch (Exception $ex) {
    
                DB::rollBack();
                return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
            }
        }
   
    }

    /**
     * This Function is Used to Give Office Out (Attendance) For Users
     * @param Custom Request 
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */
    public function officeout(OfficeOutRequest $request)
    {
        $office=DailyAttendance::where('emp_id', $request->emp_id)->orderBy('created_at','desc')->get()->toArray();
        if(count($office))
        {   
            DB::beginTransaction();    
            try{
                $attendance=DailyAttendance::find($office[0]['id']);

                $attendance->update($request->all());
                $this->send_officeout_sahaj($attendance);
                $office_multi=DailyAttendanceLog::where('emp_id', $request->emp_id)->orderBy('created_at','desc')->get()->toArray();
                $request->merge([
                    'daily_attendance_id' => $attendance->id,
                ]);
                $attendance_multiple=DailyAttendanceLog::find($office_multi[0]['id']);
                $attendance_multiple->update($request->all());

                $user = User::find($attendance->user_id);
                
                DB::commit();
                
                return response(['user'=>['id'=>$user->id,'email'=>$user->email,'name'=>$user->name,'avatar'=>env('APP_URL').'storage/'.$user->profile,'status'=>'online','is_superadmin'=>$user->is_superadmin,'type'=>$user->type,'employee_info'=>$this->employee_info($user)], 'success'=>true,'message' => 'Data Retrived successfully'], 200);
            }
            catch (Exception $ex) {
    
                DB::rollBack();
                return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
            }      

        }
        else
        {
            return response(['data' => array(),'success'=>false,'message' =>  ["Please Give Your Office Time First"]], 200);
        }
   
    }
    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Response
     */
    public function destroy($id)
    {
        
    }

    /**
     * This Function is Used to Header Of Office Time List For Users
     * @param Custom Request 
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */
    public function office_time_headers(){
        $headers = array(
             
            array('column_name'=>'full_name','display_name'=>'Employee','is_display'=>1,'is_default'=>1,'is_sortable'=>0 ,'is_belongs'=>0, 'is_multiple'=>0,'is_profile'=>1,'child_column'=>'thumbnail','tooltip_column'=>'full_name'),
            array('column_name'=>'date','display_name'=>'Date','is_display'=>1,'is_default'=>1,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'schedule_in','display_name'=>'Schedule In','is_display'=>1,'is_default'=>1,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'schedule_out','display_name'=>'Schedule Out','is_display'=>1,'is_default'=>1,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>0),
            
            array('column_name'=>'start_time','display_name'=>'Start Time','is_display'=>1,'is_default'=>1,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'start_date_time','display_name'=>'Start Date Time','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>0),
          
            array('column_name'=>'end_time','display_name'=>'End Time','is_display'=>1,'is_default'=>1,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'end_date_time','display_name'=>'End Date Time','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'status_name','display_name'=>'Status','is_display'=>1,'is_default'=>1,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>0),
                  
        );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    /**
     * This Function is Used to Manage Office Time List For Users
     * @param Custom Request 
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */
    public function office_time_list(Request $request)
    {
        $query = QueryBuilder::for(Employee::class)->allowedFilters(['fname','lname','mname',AllowedFilter::exact('branch_id')->ignore(null),AllowedFilter::exact('manager_id')->ignore(null),AllowedFilter::exact('hr_manager_id')->ignore(null),AllowedFilter::exact('department_id')->ignore(null),
        AllowedFilter::exact('employee_type_id')->ignore(null),
        AllowedFilter::exact('phone')->ignore(null),AllowedFilter::exact('email')->ignore(null)])->defaultSort('fname')->allowedSorts('fname','lname','mname','created_at','phone','email','updated_at');

        $query->search(!empty($request->search)?$request->search:"");
        $request->date = !empty($request->date) ? $request->date : date('Y-m-d');

        $employees = $query->with([
            'employee_timings' => function ($query) use ($request) {
                $query->where('day','=',date('N',strtotime($request->date)));
            },
            'daily_attendances'=> function ($query) use ($request) {
                $query->where('date','=',$request->date);
            }
        ])->advanceSearch($request->advfilter,'employees')->where('user_id','>',0)->where('status',1)->checkPermission('created_by')->paginate($request->per_page);

        $this->saveAdvanceSearchData($request);

        if(count($employees))
        {
            foreach ($employees as $key => $value) {
                if(count($value['employee_timings']))
                {
                    $employees[$key]['schedule_in'] = $value['employee_timings'][0]['in'];
                    $employees[$key]['schedule_out'] = $value['employee_timings'][0]['out'];
                }
                $employees[$key]['date'] = $request->date; 
                if(count($value['daily_attendances']))
                {
                    $employees[$key]['start_time'] = $value['daily_attendances'][0]['start_time'];
                    $employees[$key]['end_time'] = $value['daily_attendances'][0]['end_time'];
                    $employees[$key]['start_date_time'] = $value['daily_attendances'][0]['start_date_time'];
                    $employees[$key]['end_date_time'] = $value['daily_attendances'][0]['end_date_time'];
                    $status=array_column($this->status,'name', 'id'); 
                    $employees[$key]['status_name']=$status[$value['daily_attendances'][0]['status']];
                }
                else
                {
                    $employees[$key]['start_time'] = "";
                    $employees[$key]['end_time'] = "";
                    $employees[$key]['start_date_time'] = "";
                    $employees[$key]['end_date_time'] = "";
                    $status=array_column($this->status,'name', 'id'); 
                    $employees[$key]['status_name']=$status[0];
                }
            }
        }

        return response(['data' => $employees,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    /**
     * This Function is Used to Update Office Time
     * @param Custom Request 
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */
    public function office_time_update(OfficeTimeManageRequest $request)
    {
       
        if($request->update)
        {
            DB::beginTransaction();
            try 
            {
                $attendance=DailyAttendance::find($request->attendance_id);

                $attendance->update($request->all());

                $office_first=DailyAttendanceLog::where('emp_id', $request->emp_id)->orderBy('created_at','asc')->get()->toArray();

                $office_last=DailyAttendanceLog::where('emp_id', $request->emp_id)->orderBy('created_at','desc')->get()->toArray();
                
                $request->merge([
                    'daily_attendance_id' => $attendance->id,
                ]);

                if(!empty($request->start_time))
                {
                    $attendance_start=DailyAttendanceLog::find($office_first[0]['id']);
                    $attendance_start->update($request->except('end_time','end_date_time'));
                }
                if(!empty($request->end_time))
                {
                    $attendance_end=DailyAttendanceLog::find($office_last[0]['id']);
                    $attendance_end->update($request->except('start_time','start_date_time'));
                }

                DB::commit();
                
                return response(['data'=>$attendance, 'success'=>true,'message' => 'Data Retrived successfully'], 200);
            }
            catch (Exception $ex) {
    
                DB::rollBack();
                return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
            }  
        }
        else
        {
            DB::beginTransaction();
            try {
                
                $attendance = DailyAttendance::create($request->all());
                $request->merge([
                    'daily_attendance_id' => $attendance->id,
                ]);
                $attendance_log = DailyAttendanceLog::create($request->all());
                
                DB::commit();
                
                return response(['data'=>$attendance, 'success'=>true,'message' => 'Data Retrived successfully'], 200);
            }
            catch (Exception $ex) {
    
                DB::rollBack();
                return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
            }  
        }
    }

    public function daily_wise_report(Request $request)
    {
        $results= QueryBuilder::for(DailyAttendance::class)->allowedFilters(['date',AllowedFilter::exact('user_id')->ignore(null),
        AllowedFilter::exact('emp_id')->ignore(null)])->defaultSort('-date')->allowedSorts('date','start_date_rime','end_date_rime','created_at','updated_at','remarks','start_address','end_address','schedule_in','schedule_out','schedule_break','start_time','end_time')->select(DB::raw('daily_attendances.*,SEC_TO_TIME(TIME_TO_SEC(start_time) -  TIME_TO_SEC(schedule_in)) as late_in,SEC_TO_TIME(TIME_TO_SEC(end_time) -  TIME_TO_SEC(schedule_out)) as late_out,SEC_TO_TIME(TIME_TO_SEC(schedule_out) -  TIME_TO_SEC(schedule_in) - TIME_TO_SEC(schedule_break)) as expected_time'))->with('reason','employee')->advanceSearch($request->advfilter,'daily_attendances')->paginate($request->per_page);

        $str = "";

        foreach ($results as $key => $value) 
        {
            if($value['employee'] !=null){
                $results[$key]['name']=$value['employee']['full_name'];
            }
            else
                $results[$key]['name']='';
            
            
            $early_in_duration = "";
            $late_in_duration = "";

            $early_out_duration = "";
            $late_out_duration = "";
             
            // 0 for Negetive 1 for Positive
            if($this->nagitive_check($value['late_in']) == 1)
            {
                $late_in_duration = $value['late_in'] ; 
            }
            else
            {
               $early_in_duration = preg_replace('/\-/', '', $value['late_in']);
            }

            if($this->nagitive_check($value['late_out']) == 1)
            {
                $late_out_duration = $value['late_out'];
            }
            else
            {
               
                $early_out_duration = preg_replace('/\-/', '', $value['late_out']);
            }
           //exit();
           $results[$key]['late_in_duration']=$late_in_duration;
           $results[$key]['early_in_duration']=$early_in_duration;
           
           $results[$key]['late_out_duration']=$late_out_duration;
           $results[$key]['early_out_duration']=$early_out_duration;

           $system_time=DB::table('daily_attendance_logs')->select(DB::raw("sum(UNIX_TIMESTAMP(concat(concat(date,' '),end_time)) - UNIX_TIMESTAMP(concat(concat(date,' '),start_time))) as system_hour"))->where('master_id',$request->master_id)->where('user_id',$value['user_id'])->where('date',$value['date'])->whereNull('deleted_at')->get();
             
           $system_hour=sprintf('%02d',floor($system_time[0]->system_hour/3600) );
           $system_time=sprintf('%02d',intval(($system_time[0]->system_hour%3600)/60));
           if($system_hour > 0)	
               $results[$key]['system_time']=$system_hour.":".$system_time;


            $daily_attendance_reports=DailyAttendanceReport::with('expenses')->withSum('expenses as given_expense', 'daily_attendance_expenses.given_cost')->withSum('expenses as approved_expense', 'daily_attendance_expenses.approved_cost')->where('master_id',$request->master_id)->where('emp_id',$value['emp_id'])->where('date',$value['date'])->get();
            $given_expense=0;
            $approved_expense=0;
            $times=array();
            $productive_time = array();
            $non_productive_time = array(); 
            foreach ($daily_attendance_reports as $key1 => $value1) 
            {
                
                
                
                
                $given_expense=$given_expense+$value1->given_expense;
                $approved_expense=$approved_expense+$value1->approved_expense;


                $times[]=$value1['time'];

                if($value1['task_id'] > 0)
                    $productive_time[]=$value1['time'];
                else
                    $non_productive_time[]=$value1['time'];      
                
            }

            $results[$key]['given_expense']=$given_expense;
            $results[$key]['approved_expense']=$approved_expense;
            $results[$key]['total_attendance_time']=$this->AddMultipleTime($times);
            $results[$key]['productive_time']=$this->AddMultipleTime($productive_time);
            $results[$key]['non_productive_time']=$this->AddMultipleTime($non_productive_time);    

        }

        return response(['data' => $results,'success'=>true,'message' => 'Data Retrived Successfully'], 200);


    }

    public function daily_wise_report_headers()
    {
        $headers=array(
            array('column_name'=>'employee','display_name'=>'Employee','is_display'=>1,'is_default'=>1,'is_sortable'=>0 ,'is_belongs'=>0, 'is_multiple'=>0,'is_profile'=>1,'child_column'=>'thumbnail','tooltip_column'=>'full_name'),
            array('column_name'=>'date','display_name'=>'Date','is_default'=>1,'is_display'=>1,'is_sortable'=>0,'excel_column'=>'date'),
            array('column_name'=>'status_name','display_name'=>'Status','is_default'=>1,'is_display'=>1,'is_sortable'=>0,'excel_column'=>'status_name'),

            array('column_name'=>'schedule_in','display_name'=>'Schedule In','is_default'=>1,'is_display'=>1,'is_sortable'=>0,'excel_column'=>'schedule_in'),
            array('column_name'=>'start_time','display_name'=>'Office In Time','is_default'=>1,'is_display'=>1,'is_sortable'=>0,'excel_column'=>'start_time'),
            array('column_name'=>'late_in_duration','display_name'=>'Late In Duration','is_default'=>1,'is_display'=>1,'is_sortable'=>0,'excel_column'=>'late_in_duration'),
            array('column_name'=>'early_in_duration','display_name'=>'Early In Duration','is_default'=>1,'is_display'=>1,'is_sortable'=>0,'excel_column'=>'early_in_duration'),
             array('column_name'=>'start_address','display_name'=>'Office In Address','is_default'=>1,'is_display'=>1,'is_sortable'=>0,'excel_column'=>'start_address'),
            
            array('column_name'=>'schedule_out','display_name'=>'Schedule Out','is_default'=>1,'is_display'=>1,'is_sortable'=>0,'excel_column'=>'schedule_out'),
            array('column_name'=>'end_time','display_name'=>'Office Out Time','is_default'=>1,'is_display'=>1,'is_sortable'=>0,'excel_column'=>'end_time'),
            array('column_name'=>'late_out_duration','display_name'=>'Late Out Duration','is_default'=>1,'is_display'=>1,'is_sortable'=>0,'excel_column'=>'late_out_duration'),
            array('column_name'=>'early_out_duration','display_name'=>'Early Out Duration','is_default'=>1,'is_display'=>1,'is_sortable'=>0,'excel_column'=>'early_out_duration'),
            array('column_name'=>'end_address','display_name'=>'Office Out Address','is_default'=>1,'is_display'=>1,'is_sortable'=>0,'excel_column'=>'end_address'),

            
           
            array('column_name'=>'reason','display_name'=>'Reason','is_display'=>1,'is_default'=>1,'is_sortable'=>0 , 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'),
            array('column_name'=>'remarks','display_name'=>'Remarks','is_default'=>1,'is_display'=>1,'is_sortable'=>0,'excel_column'=>'remarks'),
            array('column_name'=>'expected_time','display_name'=>'Expected Hrs','is_default'=>1,'is_display'=>1,'is_sortable'=>0,'excel_column'=>'expected_time'),
            array('column_name'=>'system_time','display_name'=>'System Hrs','is_default'=>1,'is_display'=>1,'is_sortable'=>0,'excel_column'=>'system_time'),
            array('column_name'=>'total_attendance_time','display_name'=>'Total Attendance hrs','is_default'=>1,'is_display'=>1,'is_sortable'=>0,'excel_column'=>'total_attendance_time'),
            array('column_name'=>'productive_time','display_name'=>'Task Attendance hrs','is_default'=>1,'is_display'=>1,'is_sortable'=>0,'excel_column'=>'productive_time'),
            array('column_name'=>'non_productive_time','display_name'=>'Others Attendance hrs','is_default'=>1,'is_display'=>1,'is_sortable'=>0,'excel_column'=>'non_productive_time'),
            array('column_name'=>'given_expense','display_name'=>'Given Expense','is_default'=>1,'is_display'=>1,'is_sortable'=>0,'excel_column'=>'given_expense'),
            array('column_name'=>'approved_expense','display_name'=>'Approved Expense','is_default'=>1,'is_display'=>1,'is_sortable'=>0,'excel_column'=>'approved_expense'),


        );
        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);

    }


}
