<?php

namespace Modules\AttendanceManager\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;
use Modules\AttendanceManager\Entities\Holiday;
use Modules\AttendanceManager\Transformers\HolidayResource;
use App\Models\Branch;
use App\Models\FiscalYear;
use App\Imports\HolidayImport;
use Excel;

class HolidayController extends Controller
{
    use PermissionTrait,CommonTrait;

    public function getlist(Request $request)
    {
        $data['fiscal_years'] = FiscalYear::orderBy('created_at','desc')->get();
        $data['branches'] = Branch::where('status',1)->get();

        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    /**
     * Display a headers of the listing page.
     * @return \Illuminate\Http\Response
     */
    public function headers()
    {
        $headers = array(
            array('column_name'=>'branch','display_name'=>'Branch','is_display'=>1,'is_default'=>1,'is_sortable'=>0 , 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'),
            array('column_name'=>'fiscal_year','display_name'=>'Fiscal Year','is_display'=>1,'is_default'=>1,'is_sortable'=>0 , 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'),
            array('column_name'=>'date','display_name'=>'Date','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'reason','display_name'=>'Reason','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'creator','display_name'=>'Created By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
            array('column_name'=>'editor','display_name'=>'Updated By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
            array('column_name'=>'updated_at','display_name'=>'Updated On','is_display'=>1,'is_default'=>1,'is_sortable'=>1), 
            array('column_name'=>'created_at','display_name'=>'Added On','is_display'=>1,'is_default'=>0,'is_sortable'=>1)          );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Display a listing of the resource.
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $current_fiscal_year = FiscalYear::where('status',1)->first();
        $query = QueryBuilder::for(Holiday::class)->allowedFilters(['date','reason',AllowedFilter::exact('fiscal_year_id')->ignore(null)->default($current_fiscal_year->id),AllowedFilter::exact('branch_id')->ignore(null)])->defaultSort('date')->allowedSorts('date','reason','updated_at','created_at');

        $query->search(!empty($request->search)?$request->search:"");

        $holidays = $query->with('branch','fiscal_year','creator','editor')->advanceSearch($request->advfilter,'holidays')->checkPermission('created_by')->paginate($request->per_page);

        $this->saveAdvanceSearchData($request);

        return response(['data' => $holidays,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if(!$this->checkStoreAccess())
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403); 

        $validator = Validator::make($request->all(), [
            'date' => 'required',
            'reason' => 'required',

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            $holiday = Holiday::create($request->all());


            DB::commit();
            return response(['data' => new HolidayResource($holiday),'success'=>true,'message' => 'Holiday Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return response(['data' =>new HolidayResource(Holiday::findOrFail($id)),'success'=>true,'message' => 'Holiday Retrived Successfully'], 200);
    }

   
    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $holiday=Holiday::find($id);
        
        if(!$this->checkUpdateAccess($holiday))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        $validator = Validator::make($request->all(), [
            'date' => 'required',
            'reason' => 'required'

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            
            $holiday->update($request->all());
            
            DB::commit();
            
            return response(['data' => new HolidayResource($holiday),'success'=>true,'message' => 'Holiday Updated Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $holiday=Holiday::find($id);
        
        if(!$this->checkDeleteAccess($holiday))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);
        
        DB::beginTransaction();
        try {
            
            $holiday->delete();

            DB::commit();

            return response(['data' => array(),'success'=>true,'message' => 'Holiday Deleted Successfully'], 200);
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        
    }


    /**
     * Bulk Action function of footer (pass 6  for delete and 3 for update)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function actionall()
    {
        
        $access = request()->action == 'delete' ? 6 : 3;

        if(!$this->checkBulkAcess( $access))
            return response(['data' => array(),'success'=>false,'message' =>"You Don't Have Access For Bulk Action"], 200);

        DB::beginTransaction();
        
        try {
           
            if($access == 6)
                {
                    Holiday::whereIn('id',request()->ids)->get()->each(function($holiday) 
                    {
                        $holiday->delete();
                    });
                }
            elseif($access == 3)  
                Holiday::whereIn('id',request()->ids)->update([request()->column => request()->status]);

            DB::commit();

            return response(['data' => array(),'success'=>true,'message' => 'Updated successfully'], 200);
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

      
    }

    /**
     * Bulk Action function of footer (pass 6  for delete and 3 for update)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function bulk_holiday_store(Request $request)
    {
        if(!$this->checkStoreAccess())
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403); 

        $validator = Validator::make($request->all(), [
           

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            
            if(count($request->branches))
            {
                foreach ($request->branches as $key => $branch) 
                {
                   foreach ($request->input('holiday') as $key => $holiday) {
                        
                        Holiday::create(['branch_id'=>$branch , 'date' => $holiday['date'] , 'reason'=>$holiday['reason'], 'status'=>true , 'fiscal_year_id'=>$request->fiscal_year_id]);
                   }
                }
            }


            DB::commit();
            return response(['data' =>[],'success'=>true,'message' => 'Holiday Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    public function holiday_import(Request $request)
    {
        if(!$this->checkStoreAccess())
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403); 

        $validator = Validator::make($request->all(), [
           

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            $files = $request->file('files');
           
            if(count($files) > 0)
            {
                
               foreach ($files as $key => $file) 
               {
                    Excel::import(new HolidayImport, $file);

               }
            }  
            DB::commit();
            return response(['data' =>[],'success'=>true,'message' => 'Import Successfully'], 200);
        }
        catch (Exception $ex) {
            
            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }
}
