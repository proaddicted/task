<?php

namespace Modules\AttendanceManager\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;
use Modules\AttendanceManager\Entities\DailyAttendanceReport;
use Modules\AttendanceManager\Entities\DailyAttendance;
use Modules\AttendanceManager\Entities\DailyAttendanceReportChangeLog;
use Modules\AttendanceManager\Transformers\DailyAttendanceReportResource;
use App\Models\Service;
use Modules\ContactManager\Entities\Contact;
use Modules\ResourceManager\Entities\Employee;
use App\Models\MasterType;
use App\Exports\DailyAttendanceReportExcel;
use Maatwebsite\Excel\Facades\Excel;
use App\Models\TempFile;
use App\Models\File;
use Modules\TaskManager\Entities\TaskChangeLog;
use Modules\AttendanceManager\Rules\AttendanceReportOfficeInRule;
use Modules\AttendanceManager\Rules\AttendanceReportTimeRule;
use Modules\AttendanceManager\Rules\AttendanceReportLimitDaysRule;
use Geocoder;


class DailyAttendanceReportController extends Controller
{
    use PermissionTrait,CommonTrait;

    public function getlist(Request $request)
    {
        $data['services'] = Service::with('children')->where('status',1)->orderBy('name','asc')->where('parent_id',0)->get();
        $data['companies']=Contact::where('status',1)->where('type','company')->select('fname','mname','lname','id','profile','phone','email')->get();
        $data['employees'] = Employee::where('status',1)->select('id','fname','mname','lname','profile')->checkEmployeePermission('user_id')->get();
        $data['master_types'] = MasterType::where('status',1)->whereIn('identifier',['expense'])->select('id','name','identifier')->get();
        $data['statuses'] = $this->attendance_report_status;
        $data['attendance_types'] = $this->attendance_types;
        
        $data['daily_attendance_reports'] = DailyAttendanceReport::withSum('expenses as given_expense', 'daily_attendance_expenses.given_cost')->withSum('expenses as approved_expense', 'daily_attendance_expenses.approved_cost')->with('employee','company','service','expenses')->where('date',$request->date)->where('emp_id',$request->emp_id)->get();

        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    /**
     * Display a headers of the listing page.
     * @return \Illuminate\Http\Response
     */
    public function headers()
    {
        $headers = array(
            array('column_name'=>'employee','display_name'=>'Employee','is_display'=>1,'is_default'=>1,'is_sortable'=>0 ,'is_belongs'=>0, 'is_multiple'=>0,'is_profile'=>1,'child_column'=>'thumbnail','tooltip_column'=>'full_name'),
            array('column_name'=>'attendance_type','display_name'=>'Type','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),  // 16-09-2024 Jyoti
            array('column_name'=>'task','display_name'=>'Task','is_display'=>1,'is_default'=>1,'is_sortable'=>0 , 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), //add this line
            array('column_name'=>'company','display_name'=>'Company','is_display'=>1,'is_default'=>1,'is_sortable'=>0 , 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'full_name'),
            array('column_name'=>'reason','display_name'=>'Reason','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'date','display_name'=>'Date','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'description','display_name'=>'Description','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'status_name','display_name'=>'Status','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'time','display_name'=>'Time','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'address','display_name'=>'Address','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'longitude','display_name'=>'Longitude','is_display'=>1,'is_default'=>0,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0), //add this line
            array('column_name'=>'latitude','display_name'=>'Latitude','is_display'=>1,'is_default'=>0,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0), //add this line
            array('column_name'=>'given_expense','display_name'=>'Requested Expense','is_display'=>1,'is_default'=>1,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'approved_expense','display_name'=>'Approved Expense','is_display'=>1,'is_default'=>1,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'creator','display_name'=>'Created By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
            array('column_name'=>'editor','display_name'=>'Updated By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
            array('column_name'=>'updated_at','display_name'=>'Updated On','is_display'=>1,'is_default'=>1,'is_sortable'=>1), 
            array('column_name'=>'created_at','display_name'=>'Added On','is_display'=>1,'is_default'=>0,'is_sortable'=>1)          );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }


     /**
     * Excel Export for Tasks
     * @author Debargha Chakraborty <debargha.chakraborty01@gmail.com>
     * @copyright Copyright (c) 2023, Debargha Chakraborty 
     * @return \Illuminate\Http\Response
     */
    public function export(Request $request)
    {
        parse_str($request->filter, $output); 
        $result = ['per_page' => $request->per_page, 'page' => $request->page, 'search' => $request->search, 'sort' => $request->sort, 'filter' =>  isset($output['filter'])?$output['filter']:[], 'advfilter' => isset($output['advfilter'])?$output['advfilter']:[], 'page_url' =>$request->page_url]; 
       
            $excel_name='AttendanceReport';
            $headings=[
                'Employee',
                'Task',
                'Company', 
                'Reason', 
                'Date', 
                'Description',
                'Status',
                'Time',
                'Requested Expense',
                'Approved Expense',  
                'Last Updated',    

            ];
        $saved_excel_name=$excel_name.'_'.date('d-m-Y H:i:s').'.xlsx';
        $save_file=Excel::store(new DailyAttendanceReportExcel($result,$headings),$saved_excel_name);

        if($save_file && file_exists(storage_path('/app/'.$saved_excel_name)))
        {
            $file = storage_path('/app/'.$saved_excel_name);
            return  response()->file($file);
        }
        else
            return response(['data' => array(),'success'=>false,'message' => "Invalid File Path"], 500);
        
    }

    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index(Request $request)
    {
        $query = QueryBuilder::for(DailyAttendanceReport::class)->allowedFilters(['date','reason','description','time',AllowedFilter::exact('company_id')->ignore(null),AllowedFilter::exact('service_id')->ignore(null),AllowedFilter::exact('task_id')->ignore(null),AllowedFilter::exact('emp_id')->ignore(null),AllowedFilter::exact('status')->ignore(null)])->defaultSort('-date')->allowedSorts('date','reason','updated_at','created_at');

        $query->search(!empty($request->search)?$request->search:"");
        
        /*
            @author Prosanta Mitra

            -----This is Used To Get Sum Of Expenses-----
            ->withCount([
                'expenses AS given_expense_total' => function ($q) {
                    $q->select(DB::raw("SUM(given_cost) as given_cost_total"));
                }
            ])

            -----Alternative Approach-----
            ->withSum('expenses as given_expense', 'daily_attendance_expenses.given_cost')    
        
        */

        $daily_attendance_reports = $query->withSum('expenses as given_expense', 'daily_attendance_expenses.given_cost')->withSum('expenses as approved_expense', 'daily_attendance_expenses.approved_cost')->with('employee','company','service','expenses','files','task','creator','editor')->advanceSearch($request->advfilter,'daily_attendance_reports')->checkPermission('created_by')->paginate($request->per_page);

        $this->saveAdvanceSearchData($request);

        return response(['data' => $daily_attendance_reports,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create()
    {
    }

     /**
     * Send attendance reports to new crm
     * @author Debargha Chakraborty <debargha.chakraborty01@gmail.com>
     * @copyright Copyright (c) 2023, Debargha Chakraborty 
     * @return \Illuminate\Http\Response
     */
    public function send_attendance_report_sahaj($daily_attendance_report_id)
    {
        $attendance_report=DailyAttendanceReport::with('tasks')->where('id',$daily_attendance_report_id)->first();
        $ch = curl_init(env('OLD_SAHAJ_LINK').'add_newcrm_attendance?master=dost'); 
        $jsonData = json_encode($attendance_report);
      
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Content-Length: ' . strlen($jsonData)
        ]);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);

        $response = curl_exec($ch);
        if ($response === false) {
            $error = curl_error($ch);
            curl_close($ch);
            throw new Exception("cURL error: $error");
        }
        curl_close($ch);
    }
    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Response
     */
    public function store(Request $request)
    {

      

        if(!$this->checkStoreAccess())
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403); 

        // 04/10/2024 Jyoti
        $today = today();
        $threeDaysAgo = today()->subDays(env('ATTENDANCE_DAYS_LIMIT'));
        $attendanceDate = Carbon::parse($request->date);

        if ($attendanceDate->greaterThanOrEqualTo($threeDaysAgo) == true) {
            $validator = Validator::make($request->all(), [
                'date' => ['required'],
                'time' => ['required'],  //new AttendanceReportTimeRule
                'description' => 'required',
            ]);
        }else{
            $validator = Validator::make($request->all(), [
                'date' => ['required',new AttendanceReportOfficeInRule],
                'time' => ['required'],  //new AttendanceReportTimeRule
                'description' => 'required',
            ]);
        }
        // 04/10/2024 Jyoti

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {

            $address = "";
            if($request->longitude != "" &&  $request->latitude != "")
            {
                if(env('GEOCODE_ENABLE'))
                {
                    try {
                        $geocode = Geocoder::getAddressForCoordinates($this->latitude,$this->longitude);
                    
                        if(!empty($geocode) && is_array($geocode))
                            $address = $geocode['formatted_address'];
                    } catch (Exception $ex) {
                        $address = $ex->getMessage();
                    }
                }    
            
            }    
            $request->merge([
                'address' => $address
            ]);

            // 25/09/2024 Jyoti
            if($request->reason != null || $request->task_id != null){
                $request->merge([
                    'service_id' => null
                ]);
            }
            // 25/09/2024 Jyoti

            $daily_attendance_report = DailyAttendanceReport::create($request->all());
            $this->send_attendance_report_sahaj($daily_attendance_report->id);
            

            $daily_attendance_report->expenses()->attach($request->expense,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 

            if(intval($request->task_id)>0)
            TaskChangeLog::create(['action'=>'add','task_id'=>$request->task_id,'column_name'=>'attendance-report','new_value'=>$daily_attendance_report->id]);

            if($request->input('files') && count($request->input('files')) > 0)
            {
                foreach ($request->input('files') as $data) 
                {
                    
                    $data['identifier']=isset($data['identifier'])?$data['identifier']:"attendance-report";
                    if(intval($data['id']) > 0 || intval($data['temp_id']) > 0)
                    {
                        if($object = File::withTrashed()->find($data['id']))
                        {
                            $object->restore();
                            $object->fill($data);
                        }
                        else
                        {
                            if($tempobject = TempFile::find($data['temp_id']))
                            {
                                
                                $object = new File($data);
                            }
                        }
                            
                        $daily_attendance_report->files()->save($object);
                    }
                }
            }

            DB::commit();
            
            return response(['data' => DailyAttendanceReport::withSum('expenses as given_expense', 'daily_attendance_expenses.given_cost')->withSum('expenses as approved_expense', 'daily_attendance_expenses.approved_cost')->with('employee','company','service','expenses','files')->find($daily_attendance_report->id),'success'=>true,'message' => 'Attendance Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Response
     */
    public function show($id)
    {
        return response(['data' =>new DailyAttendanceReportResource(DailyAttendanceReport::findOrFail($id)),'success'=>true,'message' => 'Attendance Retrived Successfully'], 200);

    }

    public function store_daily_attendance_reports(Request $request)
    {
        $daily_attendance_report = new DailyAttendanceReport;
        $daily_attendance_report->id = $request->id;
        $daily_attendance_report->master_id = $request->master_id;
        $daily_attendance_report->emp_id = $request->emp_id;
        $daily_attendance_report->date = $request->date;
        $daily_attendance_report->time = $request->time;
        if($request->status==1){
            $daily_attendance_report->status=2;
        }
        $daily_attendance_report->description = $request->comment;
        $daily_attendance_report->longitude = $request->attendance_longitude;
        $daily_attendance_report->latitude = $request->attendance_latitude;
        $daily_attendance_report->address = $request->attendance_address;
        $daily_attendance_report->company_id = $request->company_id;
        $daily_attendance_report->service_id = $request->service_id;
        $daily_attendance_report->task_id = $request->ticket_id;
        $daily_attendance_report->is_outside = $request->is_outside;
        $daily_attendance_report->auto_entry = $request->auto_entry;
        $daily_attendance_report->type = $request->type;
        $daily_attendance_report->link = $request->link;
        $daily_attendance_report->reason = $request->reason;                  
        $daily_attendance_report->created_at = $request->created_at;
        $daily_attendance_report->updated_at = $request->updated_at;
        $daily_attendance_report->created_by = $request->created_by;
        $daily_attendance_report->updated_by = $request->updated_by;
        $daily_attendance_report->deleted_at = $request->deleted_at;

        $daily_attendance_report->save();

        if (isset($request->expense->id)) 
        {
            $daily_attendance_report->expenses()->detach();
            $daily_attendance_report->expenses()->attach([$request->expense->id], ['master_id' => $daily_attendance_report->master_id, 'created_by' => 1, 'updated_by' =>1, 'created_at' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s')]);
        }           
    }


    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Response
     */
    public function edit($id)
    {
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
        $daily_attendance_report=DailyAttendanceReport::find($id);
        
        if(!$this->checkUpdateAccess($daily_attendance_report))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        $validator = Validator::make($request->all(), [
            'date' => ['required',new AttendanceReportLimitDaysRule], 
            'time' => ['required'], //,new AttendanceReportTimeRule
            'description' => 'required'

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {

            $address = "";
            if($request->longitude != "" &&  $request->latitude != "")
            {
                if(env('GEOCODE_ENABLE'))
                {
                    try {
                        $geocode = Geocoder::getAddressForCoordinates($request->latitude,$request->longitude);
                    
                        if(!empty($geocode) && is_array($geocode))
                            $address = $geocode['formatted_address'];
                    } catch (Exception $ex) {
                        $address = $ex->getMessage();
                    }
                }    
            
            }    
            $request->merge([
                'address' => $address
            ]);
            
            $daily_attendance_report->update($request->all());

            if(isset($request->expense) && count($request->expense) > 0)
            {
                $daily_attendance_report->expenses()->detach();
            
                $daily_attendance_report->expenses()->attach($request->expense,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
            }

            if($request->input('files') && count($request->input('files')) > 0)
            {
                foreach ($request->input('files') as $data) 
                {
                    
                    $data['identifier']=isset($data['identifier'])?$data['identifier']:"attendance-report";
                    if(intval($data['id']) > 0 || intval($data['temp_id']) > 0)
                    {
                        if($object = File::withTrashed()->find($data['id']))
                        {
                            $object->restore();
                            $object->fill($data);
                        }
                        else
                        {
                            if($tempobject = TempFile::find($data['temp_id']))
                            {
                                
                                $object = new File($data);
                            }
                        }
                            
                        $daily_attendance_report->files()->save($object);
                    }
                }
            }
            
            DB::commit();
            
            return response(['data' => new DailyAttendanceReportResource($daily_attendance_report),'success'=>true,'message' => 'Attendance Updated Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Response
     */
    public function destroy($id)
    {
        $daily_attendance_report = DailyAttendanceReport::find($id);
        
        if(!$this->checkDeleteAccess($daily_attendance_report))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        DB::beginTransaction();
        try {
            $daily_attendance_report->delete();
            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Attendance Report Deleted successfully'], 200);
    }

    /**
     * Function used for Inline Edit Note In Attendance List
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @param $id = Daily Attendance Id (daily_attendance_reports table id)
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function change_log(Request $request,$id)
    {
        DB::beginTransaction();
        try {
            
            $daily_attendance_report=DailyAttendanceReport::find($id);
            
            DailyAttendanceReportChangeLog::create(['daily_attendance_report_id'=>$id,request()->remarks,'column_name'=>request()->column_name,'new_value'=>request()->column_value,'old_value'=>$daily_attendance_report->{request()->column_name}]); // 19/09/2024 Jyoti
            $daily_attendance_report->update([$request->column_name => $request->column_value]);
            
            if(isset($request->expense) && count($request->expense) > 0)
            {
                $daily_attendance_report->expenses()->detach();
            
                $daily_attendance_report->expenses()->attach($request->expense,['master_id'=>$request->master_id,'created_by'=>$daily_attendance_report->user_id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
            }

            DB::commit();

            return response(['data' =>  DailyAttendanceReport::withSum('expenses as given_expense', 'daily_attendance_expenses.given_cost')->withSum('expenses as approved_expense', 'daily_attendance_expenses.approved_cost')->with('employee','company','service','expenses')->find($id),'success'=>true,'message' => 'File Updated Successfully'], 200);

        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }
    }

    // 25/09/2024 Jyoti
    public function actionall()
    {
        
        $access = request()->action == 'delete' ? 6 : 3;

        if(!$this->checkBulkAcess( $access))
            return response(['data' => array(),'success'=>false,'message' =>"You Don't Have Access For Bulk Action"], 200);

        DB::beginTransaction();
        
        try {
           
            if($access == 6)
                {
                    DailyAttendanceReport::whereIn('id',request()->ids)->get()->each(function($daily_attendance_report) 
                    {
                        $daily_attendance_report->delete();
                    });
                }
            elseif($access == 3)  
            DailyAttendanceReport::whereIn('id',request()->ids)->update([request()->column => request()->status]);

            DB::commit();

            return response(['data' => array(),'success'=>true,'message' => 'Updated successfully'], 200);
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        } 
    }
    // 25/09/2024 Jyoti
}
