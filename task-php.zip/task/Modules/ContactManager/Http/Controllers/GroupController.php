<?php

namespace Modules\ContactManager\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;
use Modules\ContactManager\Entities\Group;
use Modules\ContactManager\Entities\GroupChangeLog;
use Modules\ResourceManager\Entities\Employee;
use Modules\ContactManager\Transformers\GroupResource;
use App\Exports\GroupExcelExport;
use Maatwebsite\Excel\Facades\Excel;
use Modules\ContactManager\Entities\Contact;

class GroupController extends Controller
{
    use PermissionTrait,CommonTrait;

    public function getlist()
    {
        $data['employees'] = Employee::where('status',1)->get();
        $data['companies']=Contact::where('status',1)->where('type','company')->select('fname','mname','lname','id','profile','phone','email')->get();   // 16-09-2024 Jyoti


        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    public function headers()
    {
        $headers = array(
            array('column_name'=>'name','display_name'=>'Name','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'employee','display_name'=>'Responsible Person','is_display'=>1,'is_default'=>1,'is_sortable'=>0 ,'is_belongs'=>0, 'is_multiple'=>0,'is_profile'=>1,'child_column'=>'thumbnail'),
            array('column_name'=>'company','display_name'=>'Company','is_display'=>1,'is_default'=>0,'is_sortable'=>0 , 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'full_name'),  // 04/10/2024 Jyoti
            array('column_name'=>'creator','display_name'=>'Created By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
            array('column_name'=>'editor','display_name'=>'Updated By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
            array('column_name'=>'updated_at','display_name'=>'Updated On','is_display'=>1,'is_default'=>1,'is_sortable'=>1), 
            array('column_name'=>'created_at','display_name'=>'Added On','is_display'=>1,'is_default'=>0,'is_sortable'=>1)          );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Excel Export for Tasks
     * @author Debargha Chakraborty <debargha.chakraborty01@gmail.com>
     * @copyright Copyright (c) 2023, Debargha Chakraborty 
     * @return \Illuminate\Http\Response
     */
    public function export(Request $request)
    {
        parse_str($request->filter, $output); 
        $result = ['per_page' => $request->per_page, 'page' => $request->page, 'search' => $request->search, 'sort' => $request->sort, 'filter' =>  isset($output['filter'])?$output['filter']:[], 'advfilter' => isset($output['advfilter'])?$output['advfilter']:[], 'page_url' =>$request->page_url]; 
        
        $excel_name='DailyAttendance';
        $headings=[
            'Group Name',
            'Companies',
            'Responsible Person',
            'Last Updated',  
        ];
        $saved_excel_name=$excel_name.'_'.date('d-m-Y H:i:s').'.xlsx';
        $save_file=Excel::store(new GroupExcelExport($result,$headings),$saved_excel_name);

        if($save_file && file_exists(storage_path('/app/'.$saved_excel_name)))
        {
            $file = storage_path('/app/'.$saved_excel_name);
            return  response()->file($file);
        }
        else
            return response(['data' => array(),'success'=>false,'message' => "Invalid File Path"], 500);
        
    }
    
    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index(Request $request)
    {
        $query = QueryBuilder::for(Group::class)->allowedFilters(['name','description',AllowedFilter::exact('emp_id')->ignore(null),AllowedFilter::exact('company_id')->ignore(null)])->defaultSort('name')->allowedSorts('name','description','updated_at','created_at');  

        $query->search(!empty($request->search)?$request->search:"");

        $groups = $query->with('employee','company','creator','editor')->advanceSearch($request->advfilter,'groups')->checkPermission('created_by')->paginate($request->per_page);

        $this->saveAdvanceSearchData($request);

        return response(['data' => $groups,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
        if(!$this->checkStoreAccess())
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403); 

        $validator = Validator::make($request->all(), [
            'name' => 'required'

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            $group = Group::create($request->all());


            DB::commit();
            return response(['data' => new GroupResource($group),'success'=>true,'message' => 'Group Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        return response(['data' =>new GroupResource(Group::findOrFail($id)),'success'=>true,'message' => 'Group Retrived Successfully'], 200);
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        $group=Group::find($id);
        
        if(!$this->checkUpdateAccess($group))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        $validator = Validator::make($request->all(), [
            'name' => 'required'

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            
            $group->update($request->all());
            
            DB::commit();
            
            return response(['data' => new GroupResource($group),'success'=>true,'message' => 'Group Updated Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        $group=Group::find($id);
        
        if(!$this->checkDeleteAccess($group))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);
        
        DB::beginTransaction();
        try {
            
            $group->delete();
            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Industry Deleted Successfully'], 200);
    }

    /**
     * Bulk Action function of footer (pass 6  for delete and 3 for update)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function actionall()
    {
        
        $access = request()->action == 'delete' ? 6 : 3;

        if(!$this->checkBulkAcess( $access))
            return response(['data' => array(),'success'=>false,'message' =>"You Don't Have Access For Bulk Action"], 200);

        DB::beginTransaction();
        
        try {
           
            if($access == 6 && request()->action == 'delete')
            {
                Group::whereIn('id',request()->ids)->get()->each(function($group) 
                {
                    $group->delete();
                });
            }
            elseif($access == 3 && request()->action == 'update')  
                Group::whereIn('id',request()->ids)->update([request()->column => request()->status]);
            elseif($access == 3 && request()->action == 'assign-employee')
            {
                Group::whereIn('id',request()->ids)->get()->each(function($group)
                {
                    GroupChangeLog::create(['column_name'=>'emp_id','new_value'=>request()->emp_id,'old_value'=>$group->emp_id]);

                    $group->emp_id = request()->emp_id;
                    $group->save();
                });
            }      

            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Updated successfully'], 200);
    }
}
