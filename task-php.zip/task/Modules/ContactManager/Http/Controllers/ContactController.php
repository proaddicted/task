<?php

namespace Modules\ContactManager\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;
use Modules\ContactManager\Entities\Group;
use Modules\ContactManager\Entities\SubGroup;
use Modules\ResourceManager\Entities\Employee;
use Modules\ContactManager\Entities\Industry;
use Modules\ContactManager\Entities\Contact;
use Modules\ContactManager\Entities\ContactChangeLog;
use Modules\ContactManager\Entities\ContactContactRel;
use Modules\ContactManager\Transformers\ContactResource;
use App\Models\Link;
use App\Models\Phone;
use App\Models\Email;
use App\Models\Address;
use App\Models\MasterType;
use App\Models\Country;
use App\Models\State;
use App\Models\User;
use App\Models\Role;
use App\Models\File;
use App\Exports\ContactExport;
use Maatwebsite\Excel\Facades\Excel;
class ContactController extends Controller
{
    use PermissionTrait,CommonTrait;

    public function headers()
    {
        if(request()->type == 'individual')
        {
            $headers = array(
                array('column_name'=>'thumbnail','display_name'=>'Profile','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
                array('column_name'=>'full_name','display_name'=>'Name','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
                array('column_name'=>'phone','display_name'=>'Phone','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
                array('column_name'=>'email','display_name'=>'Email','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
                array('column_name'=>'company','display_name'=>'Company','is_display'=>1,'is_default'=>1,'is_sortable'=>0,'is_multiple'=>1,'child_column'=>'fname'), 
                array('column_name'=>'creator','display_name'=>'Created By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
                array('column_name'=>'editor','display_name'=>'Updated By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
                array('column_name'=>'updated_at','display_name'=>'Updated On','is_display'=>1,'is_default'=>1,'is_sortable'=>1), 
                array('column_name'=>'created_at','display_name'=>'Added On','is_display'=>1,'is_default'=>0,'is_sortable'=>1)              );
        }
        else
        {
            $headers = array(
             
                array('column_name'=>'group','display_name'=>'Group','is_display'=>1,'is_default'=>1,'is_sortable'=>0 , 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'),
                array('column_name'=>'fname','display_name'=>'Company','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
                array('column_name'=>'contact','display_name'=>'Contact','is_display'=>1,'is_default'=>1,'is_sortable'=>0,'is_multiple'=>1,'child_column'=>'full_name'), 
                array('column_name'=>'employee','display_name'=>'Responsible Person','is_display'=>1,'is_default'=>1,'is_sortable'=>0 ,'is_belongs'=>0, 'is_multiple'=>0,'is_profile'=>1,'child_column'=>'thumbnail','tooltip_column'=>'full_name'),
                array('column_name'=>'creator','display_name'=>'Created By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
                array('column_name'=>'editor','display_name'=>'Updated By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
                array('column_name'=>'updated_at','display_name'=>'Updated On','is_display'=>1,'is_default'=>1,'is_sortable'=>1), 
                array('column_name'=>'created_at','display_name'=>'Added On','is_display'=>1,'is_default'=>0,'is_sortable'=>1)              );
        }
        

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    /**
     * Fetch Data For Add/Edit Page
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function getlist()
    {
        $data['master_types'] = MasterType::where('status',1)->whereIn('identifier',['title','phone','email','address','contact','contact-source','turnover','contact-designation'])->select('id','name','identifier')->get();
        $data['countries'] = Country::where('status',1)->select('id','name')->get();
        $data['states'] = State::where('status',1)->select('id','name')->get();
   
        $data['employees'] = Employee::where('status',1)->select('id','fname','mname','lname','profile')->get();
        $data['assignable_users'] = User::with('roles')->where('status',1)->whereRaw('( id not in ( select user_id from employees where status = 1 and user_id > 0 and deleted_at is null ) or id not in (select user_id from contacts where status = 1 and user_id > 0 and deleted_at is null) )')->select('id','name','password','email','is_superadmin','status')->get();
        $data['roles']=Role::where('status',1)->select('name','id','display_name')->CheckRoleAccess()->get();
        $data['groups']=Group::where('status',1)->select('name','id')->get();
        $data['companies']=Contact::where('status',1)->where('type','company')->select('fname','mname','lname','id','profile','phone','email')->get();
        $data['contacts']=Contact::where('status',1)->where('type','individual')->select('fname','mname','lname','id','profile','phone','email')->get();
        $data['industries']=Industry::where('status',1)->select('name','id')->get();
        $data['sub_groups']=SubGroup::where('status',1)->select('name','id')->get();
        
        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

      /**
     * Excel Export for Contacts & Companies
     * @author Debargha Chakraborty <debargha.chakraborty01@gmail.com>
     * @copyright Copyright (c) 2023, Debargha Chakraborty 
     * @return \Illuminate\Http\Response
     */
    public function export(Request $request)
    {
        parse_str($request->filter, $output); 
        $result = ['per_page' => $request->per_page, 'page' => $request->page, 'search' => $request->search, 'sort' => $request->sort, 'filter' => $output['filter'], 'advfilter' => isset($output['advfilter'])?$output['advfilter']:[], 'page_url' =>$request->page_url]; 
        if($request->type=='individual')
        {
            $excel_name='Contact';
            $headings=[
                'Name',
                'Email',
                'Phone',
                'Company',
                'Created At',
                'Updated At',
            ];
        }
        else{
            $excel_name='Company';
            $headings=[
                'Name',
                'Email',
                'Group',
                'Responsible Person',
                'Contacts Name',
                'Created At',
                'Updated At',
            ];
        }

        $saved_excel_name=$excel_name.'_'.date('d-m-Y H:i:s').'.xlsx';
        $save_file=Excel::store(new ContactExport($result,$headings),$saved_excel_name);

        if($save_file && file_exists(storage_path('/app/'.$saved_excel_name)))
        {
            $file = storage_path('/app/'.$saved_excel_name);
            return  response()->file($file);
        }
        else
            return response(['data' => array(),'success'=>false,'message' => "Invalid File Path"], 500);
        
    }

     /**
     * Display a listing of the resource.
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $query = QueryBuilder::for(Contact::class)->allowedFilters(['fname','lname','mname',
        AllowedFilter::exact('contact_source_id')->ignore(null),
        AllowedFilter::exact('contact_type_id')->ignore(null),
        AllowedFilter::exact('phone')->ignore(null),AllowedFilter::exact('email')->ignore(null),AllowedFilter::exact('type')->ignore(null)])->defaultSort('fname')->allowedSorts('fname','lname','mname','created_at','phone','email','updated_at');

        $query->search(!empty($request->search)?$request->search:"");

        $contacts = $query->with('group','employee','contact','company','creator','editor')->advanceSearch($request->advfilter,'contacts')->checkPermission('created_by')->paginate($request->per_page);

        $this->saveAdvanceSearchData($request);

        return response(['data' => $contacts,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        if(!$this->checkStoreAccess())
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403); 

        $validator = Validator::make($request->all(), [
            'fname' => 'required',

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            $contact = Contact::create($request->except('phone','email','link','address'));

            if($profile = $this->base64_upload($request->input('profile'),'contact'))
                $contact->profile = $profile;

            if($request->input('phone') != null && count($request->input('phone'))>0)
            {
                $contact->phones()->delete();

                foreach ($request->input('phone') as $data) 
                {
                    if(!empty($data['phone_no']))
                    {
                        $data['identifier']="contact";
                        if(intval($data['id']) > 0)
                        {
                            if($object = Phone::withTrashed()->find($data['id']))
                            {
                                $object->restore();
                                $object->fill($data);
                            }
                            else
                                $object = new Phone($data);
                        }
                        else
                            $object = new Phone($data);
                        
                        
                        $contact->phones()->save($object);
                        
                        if($data['is_default']==1)
                            $contact->phone = $data['phone_no'];
                    }        
                }
            }

            if($request->input('email') != null && count($request->input('email'))>0)
            {
                $contact->emails()->delete();

                foreach ($request->input('email') as $data) 
                {
                    if(!empty($data['email']))
                    {
                        $data['identifier']="contact";
                        if(intval($data['id']) > 0)
                        {
                            if($object = Email::withTrashed()->find($data['id']))
                            {
                                $object->restore();
                                $object->fill($data);
                            }
                            else
                                $object = new Email($data);
                        }
                        else
                            $object = new Email($data);
                        
                        
                        $contact->emails()->save($object);
                        
                        if($data['is_default']==1)
                            $contact->email = $data['email'];
                    }
                        
                        
                }
            }

            if($request->input('link') != null && count($request->input('link'))>0)
            {
                $contact->links()->delete();

                foreach ($request->input('link') as $data) 
                {
                        
                        $data['identifier']="contact";
                        if(intval($data['id']) > 0)
                        {
                            if($object = Link::withTrashed()->find($data['id']))
                            {
                                $object->restore();
                                $object->fill($data);
                            }
                            else
                                $object = new Link($data);
                        }
                        else
                            $object = new Link($data);
                        
                        
                        $contact->links()->save($object);
                        
                        
                }
            }

            if($request->input('address') != null && count($request->input('address'))>0)
            {
                $contact->address()->delete();

                foreach ($request->input('address') as $data) 
                {
                        if(!empty($data['address_line1']))
                        {
                            $data['identifier']="contact";
                            if(intval($data['id']) > 0)
                            {
                                if($object = Address::withTrashed()->find($data['id']))
                                {
                                    $object->restore();
                                    $object->fill($data);
                                }
                                else
                                    $object = new Address($data);
                            }
                            else
                                $object = new Address($data);
                            
                            
                            $contact->address()->save($object);
                        }
                        
                        
                        
                }
            }

            if($contact->type == 'individual')
            {
                if($request->input('contactrel') != null && count($request->input('contactrel'))>0)
                {
                    $contact->contactrel()->delete();
                    foreach ($request->input('contactrel') as $data) 
                    {
                        if(!empty($data['parent_contact_id']))
                        {
                            if(intval($data['id']) > 0)
                            {
                                if($object = ContactContactRel::withTrashed()->find($data['id']))
                                {
                                    $object->restore();
                                    $object->fill($data);
                                }
                                else
                                    $object = new ContactContactRel($data);
                            }
                            else
                                $object = new ContactContactRel($data);
                            
                            
                            $contact->contactrel()->save($object);
                        }    
                        
                    }
                }
            }

            $contact->save();
            
            DB::commit();
            
            return response(['data' => new ContactResource($contact),'success'=>true,'message' => 'Contact Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Response
     */
    public function show($id)
    {
        return response(['data' =>new ContactResource(Contact::findOrFail($id)),'success'=>true,'message' => 'Contact Retrived Successfully'], 200);

    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Response
     */
    public function edit($id)
    {
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
        $contact=Contact::find($id);
        
        if(!$this->checkUpdateAccess($contact))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        $validator = Validator::make($request->all(), [
            'fname' => 'required'

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            
            $contact->update($request->except('phone','email','link','address'));
            
            if($profile = $this->base64_upload($request->input('profile'),'contact'))
                $contact->profile = $profile;

            if($request->input('phone') != null && count($request->input('phone'))>0)
            {
                $contact->phones()->delete();

                foreach ($request->input('phone') as $data) 
                {
                    if(!empty($data['phone_no']))
                    {
                        $data['identifier']="contact";
                        if(intval($data['id']) > 0)
                        {
                            if($object = Phone::withTrashed()->find($data['id']))
                            {
                                $object->restore();
                                $object->fill($data);
                            }
                            else
                                $object = new Phone($data);
                        }
                        else
                            $object = new Phone($data);
                        
                        
                        $contact->phones()->save($object);
                        
                        if($data['is_default']==1)
                            $contact->phone = $data['phone_no'];
                    }        
                }
            }

            if($request->input('email') != null && count($request->input('email'))>0)
            {
                $contact->emails()->delete();

                foreach ($request->input('email') as $data) 
                {
                    if(!empty($data['email']))
                    {
                        $data['identifier']="contact";
                        if(intval($data['id']) > 0)
                        {
                            if($object = Email::withTrashed()->find($data['id']))
                            {
                                $object->restore();
                                $object->fill($data);
                            }
                            else
                                $object = new Email($data);
                        }
                        else
                            $object = new Email($data);
                        
                        
                        $contact->emails()->save($object);
                        
                        if($data['is_default']==1)
                            $contact->email = $data['email'];
                    }
                        
                        
                }
            }

            if($request->input('link') != null && count($request->input('link'))>0)
            {
                $contact->links()->delete();

                foreach ($request->input('link') as $data) 
                {
                        
                        $data['identifier']="contact";
                        if(intval($data['id']) > 0)
                        {
                            if($object = Link::withTrashed()->find($data['id']))
                            {
                                $object->restore();
                                $object->fill($data);
                            }
                            else
                                $object = new Link($data);
                        }
                        else
                            $object = new Link($data);
                        
                        
                        $contact->links()->save($object);
                        
                      
                }
            }

            if($request->input('address') != null && count($request->input('address'))>0)
            {
                $contact->address()->delete();

                foreach ($request->input('address') as $data) 
                {
                        if(!empty($data['address_line1']))
                        {
                            $data['identifier']="contact";
                            if(intval($data['id']) > 0)
                            {
                                if($object = Address::withTrashed()->find($data['id']))
                                {
                                    $object->restore();
                                    $object->fill($data);
                                }
                                else
                                    $object = new Address($data);
                            }
                            else
                                $object = new Address($data);
                            
                            
                            $contact->address()->save($object);
                        }
                        
                        
                      
                }
            }

            if($contact->type == 'individual')
            {
                if($request->input('contactrel') != null && count($request->input('contactrel'))>0)
                {
                    $contact->contactrel()->delete();
                    foreach ($request->input('contactrel') as $data) 
                    {
                        if(!empty($data['parent_contact_id']))
                        {
                            if(intval($data['id']) > 0)
                            {
                                if($object = ContactContactRel::withTrashed()->find($data['id']))
                                {
                                    $object->restore();
                                    $object->fill($data);
                                }
                                else
                                    $object = new ContactContactRel($data);
                            }
                            else
                                $object = new ContactContactRel($data);
                            
                            
                            $contact->contactrel()->save($object);
                        }    
                      
                    }
                }
            }

            $contact->save();

            DB::commit();
            
            return response(['data' => new ContactResource($contact),'success'=>true,'message' => 'Contact Updated Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Response
     */
    public function destroy($id)
    {
        $contact=Contact::find($id);
        
        if(!$this->checkDeleteAccess($contact))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);
        
        DB::beginTransaction();
        try {
            
            $contact->delete();
            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Contact Deleted Successfully'], 200);
    }

    /**
     * Bulk Action function of footer (pass 6  for delete and 3 for update)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function actionall()
    {
        
        $access = request()->action == 'delete' ? 6 : 3;

        if(!$this->checkBulkAcess( $access))
            return response(['data' => array(),'success'=>false,'message' =>"You Don't Have Access For Bulk Action"], 200);

        DB::beginTransaction();
        
        try {
           
            if($access == 6 && request()->action == 'delete')
            {
                Contact::whereIn('id',request()->ids)->get()->each(function($contact) 
                {
                    $contact->delete();
                });
            }
            elseif($access == 3 && request()->action == 'update')  
                Contact::whereIn('id',request()->ids)->update([request()->column => request()->status]);
            elseif($access == 3 && request()->action == 'assign-employee')
            {
                Contact::whereIn('id',request()->ids)->get()->each(function($contact)
                {
                    ContactChangeLog::create(['column_name'=>'emp_id','new_value'=>request()->emp_id,'old_value'=>$contact->emp_id]);

                    $contact->emp_id = request()->emp_id;
                    $contact->save();
                });
            }
            elseif($access == 3 && request()->action == 'assign-group')
            {
                Contact::whereIn('id',request()->ids)->get()->each(function($contact)
                {
                    ContactChangeLog::create(['column_name'=>request()->column_name,'new_value'=>request()->new_value,'old_value'=>$contact->group_id]);

                    $contact->group_id = request()->new_value;
                    $contact->save();
                });
            } 
            elseif($access == 3 && request()->action == 'assign-contact')
            {
                Contact::whereIn('id',request()->ids)->get()->each(function($contact)
                {
                   if($contact->type == 'company')
                   {
                    if(is_array(request()->new_value) && count(request()->new_value) > 0)
                    {
                        $data = [];
                        foreach (request()->new_value as $id) 
                        {
                                
                            $data['contact_id'] = $id;
                            $object = new ContactContactRel($data);
                            
                            
                            $contact->companyrel()->save($object);
                                
                              
                        }
                    }
                   
                   }
                });
            }  

            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Updated successfully'], 200);
    }

    /**
     * View Page Function For Contact
     * @param $request , $id
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function view(Request $request,$id)
    {
        $contact = Contact::with('emails.email_type','phones.phone_type','links','address.address_type','address.country','address.state','files','contact','company','employee','group','industry','turnover')->find($id);
        
        $data['contacts']=Contact::where('status',1)->where('type','individual')->select('fname','mname','lname','id','profile','phone','email')->get();
        $data['master_types'] = MasterType::where('status',1)->whereIn('identifier',['title','phone','email','address','contact','contact-source','turnover','contact-designation'])->select('id','name','identifier')->get();
        $data['countries'] = Country::where('status',1)->select('id','name')->get();
        $data['states'] = State::where('status',1)->select('id','name')->get();
        
        return response(['data' => $contact,'getlist_data'=>$data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

     /**
     * View Page Quick Add Contact
     * @param $request , $id
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function quick_add_contact(Request $request,$id)
    {
        if($request->is_new)
        {
            $validator = Validator::make($request->all(), [
                'fname' => 'required',
                'lname' => 'required',
                'email' =>'nullable|email',
                'phone'=>'required'
            ]);
        }
        else
        {
            $validator = Validator::make($request->all(), [
                'contact_id' => 'required',
            ]);
        }
        

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            if($request->is_new)
            {
                $contact = Contact::create($request->except('phone','email','link','address'));

                $phones = array(
                    array('phone_no'=>$request->phone,'id'=>null,'is_default'=>1)
                );
                if($phones != null && count($phones)>0)
                {
                    $contact->phones()->delete();

                    foreach ($phones as $data) 
                    {
                        if(!empty($data['phone_no']))
                        {
                            $data['identifier']="contact";
                            if(intval($data['id']) > 0)
                            {
                                if($object = Phone::withTrashed()->find($data['id']))
                                {
                                    $object->restore();
                                    $object->fill($data);
                                }
                                else
                                    $object = new Phone($data);
                            }
                            else
                                $object = new Phone($data);
                            
                            
                            $contact->phones()->save($object);
                            
                            if($data['is_default']==1)
                                $contact->phone = $data['phone_no'];
                        }        
                    }
                }

                $emails = array(
                    array('email'=>$request->email,'id'=>null,'is_default'=>1)
                );
                if($emails != null && count($emails)>0)
                {
                    $contact->emails()->delete();

                    foreach ($emails as $data) 
                    {
                        if(!empty($data['email']))
                        {
                            $data['identifier']="contact";
                            if(intval($data['id']) > 0)
                            {
                                if($object = Email::withTrashed()->find($data['id']))
                                {
                                    $object->restore();
                                    $object->fill($data);
                                }
                                else
                                    $object = new Email($data);
                            }
                            else
                                $object = new Email($data);
                            
                            
                            $contact->emails()->save($object);
                            
                            if($data['is_default']==1)
                                $contact->email = $data['email'];
                        }
                            
                            
                    }
                }

                $contactrels = array(
                    array('parent_contact_id'=>$id,'id'=>null)
                );
                if($contactrels != null && count($contactrels)>0)
                {
                    $contact->contactrel()->delete();
                    foreach ($contactrels as $data) 
                    {
                        if(!empty($data['parent_contact_id']))
                        {
                            if(intval($data['id']) > 0)
                            {
                                if($object = ContactContactRel::withTrashed()->find($data['id']))
                                {
                                    $object->restore();
                                    $object->fill($data);
                                }
                                else
                                    $object = new ContactContactRel($data);
                            }
                            else
                                $object = new ContactContactRel($data);
                            
                            
                            $contact->contactrel()->save($object);
                        }    
                        
                    }
                }

                $contact->save();
            }
            elseif($request->contact_id > 0)
            {
                $contact = Contact::find($id);
                
                if($contact->type == 'individual')
                {
                    $contactrels = array(
                        array('parent_contact_id'=>$id)
                    );
                    if($contactrels != null && count($contactrels)>0)
                    {
                        
                        foreach ($contactrels as $data) 
                        {
                            if(!empty($data['parent_contact_id']))
                            {
                                if(intval($data['id']) > 0)
                                {
                                    if($object = ContactContactRel::withTrashed()->find($data['id']))
                                    {
                                        $object->restore();
                                        $object->fill($data);
                                    }
                                    else
                                        $object = new ContactContactRel($data);
                                }
                                else
                                    $object = new ContactContactRel($data);
                                
                                
                                $contact->contactrel()->save($object);
                            }    
                            
                        }
                    }
                }
               
            }
           
            DB::commit();
            return response(['data' => new ContactResource($contact),'success'=>true,'message' => 'Updated successfully'], 200);
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }
    }

     /**
     * View Page Contact Relation Delete
     * @param $request , $id
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function contact_rel_delete(Request $request,$id)
    {
        // $validator = Validator::make($request->all(), [
        //     'contact_id' => 'required',
        // ]);

        // if ($validator->fails()) {

        //     return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        // }

        DB::beginTransaction();
        try {
            $contactrel = ContactContactRel::find($id);
            $contactrel->delete();
           // ContactContactRel::where('contact_id',$request->contact_id)->where('parent_contact_id',$id)->delete();
            DB::commit();
            return response(['data' => [],'success'=>true,'message' => 'Deleted successfully'], 200);

        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }
    }

     /**
     * Change Column Value From Inline Edit
     * @param Request $request, $id id of cotact table
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function change_log(Request $request,$id)
    {
        DB::beginTransaction();
        try {
            
            $contact=Contact::with('emails.email_type','phones.phone_type','links','address.address_type','address.country','address.state','files','contact','company','employee','group','industry','turnover')->find($id);
            
            ContactChangeLog::create(['column_name'=>request()->column_name,'new_value'=>request()->new_value,'old_value'=>$contact->{request()->column_name}]);

            $contact->update([$request->column_name => $request->column_value]);
            DB::commit();
            return response(['data' => $contact,'success'=>true,'message' => 'File Updated Successfully'], 200);
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

      
    }

    /**
     * Fetch Contacts Respected To Company Ids
     * @param Request $request
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function get_contacts_by_company(Request $request)
    {
        $contacts = [];
        $contactrels = ContactContactRel::whereIn('parent_contact_id',$request->company_id)->get();

        if(count($contactrels))
        {
            $contacts = Contact::select('fname','mname','lname','id','profile','phone','email')->where('type','individual')->whereIn('id',$contactrels->pluck('contact_id')->toArray())->where('status',1)->get();
        }

        return response(['data' => $contacts,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Assign User to Contact 
     * @param $id, Request $request 
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function assign_user(Request $request,$id)
    {
        $contact = Contact::find($id);
        
        if($contact->user_id > 0)
            return response(['data' => array(),'success'=>false,'message' =>"User Already Assigned"], 403);
        if(!$this->checkUpdateAccess($contact))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        DB::beginTransaction();
        try {
           
            if($request->userid > 0)
            {
                
                if($user = User::find($request->userid))
                {
                   
                    $validator = Validator::make($request->all(), [
                        'name' => 'required',
                        'email' => 'required|email|unique:users,email,'.$user->id,
            
                    ]);
            
                    if ($validator->fails()) {
                        //
                        return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
                    }

                    $user->name = $request->name;
                    
                    $user->email = $request->email;
        
                    if($request->password != $user->password)
                        $user->password = Hash::make($request->password);
                    
                    $user->is_superadmin = $request->is_superadmin==true?1:0;
        
                    if($employee->profile != null)
                        $user->profile = $employee->profile;
                    elseif($user->profile != null)
                        $contact->profile = $user->profile;
                    
                    $user->status = $request->status; 
                    $user->type = 'contact';   
                    $user->save();

                    if(isset($request->role_id) && count($request->role_id) > 0)
                    {
                        $user->roles()->detach();
                        $user->roles()->attach($request->role_id,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id]);
                    }
                
                    $contact->user_id = $user->id;
                    $contact->save();
                }
               
            }
            else
            {
                $validator = Validator::make($request->all(), [
                    'name' => 'required',
                    'password' => 'required',
                    'email' => 'required|email|unique:users,email',
        
                ]);
        
                if ($validator->fails()) {
                    //
                    return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
                }
                //echo "new"; exit;
                $user = new User();
                $user->name = $request->name;
                $user->email = $request->email;
                $user->password = Hash::make($request->password);
                $user->is_superadmin = $request->is_superadmin==true?1:0;

                if($contact->profile != null)
                    $user->profile = $contact->profile;
                
                $user->status = $request->status;
                $user->type = 'contact';
                $user->save();

                $user->roles()->attach($request->role_id,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id]); 

                $contact->user_id = $user->id;
                $contact->save();
            }

            DB::commit();

            return response(['data' => $contact,'success'=>true,'message' => 'Data Retrived Successfully'], 200);

        }catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }    

    }

    /**
     * Revoke User Information from Employee  
     * @param $id, Request $request 
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function revoke_user(Request $request,$id)
    {
        $contact = Contact::find($id);
        if(!$this->checkUpdateAccess($contact))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        DB::beginTransaction();
        try {

            if($user = User::find($contact->user_id))
            {
                $user->status = 0;
                $user->save();
            }   

            DB::commit();

            return response(['data' => $contact,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
            
        }catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }    
    }
}
