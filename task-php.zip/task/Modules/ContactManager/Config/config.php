<?php

return [
    'name' => 'ContactManager'
];
