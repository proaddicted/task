<?php

namespace Modules\ContactManager\Transformers;

use Illuminate\Http\Resources\Json\JsonResource;

class ContactResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request
     * @return array
     */
    public function toArray($request)
    {
        $main = parent::toArray($request);
        return array_merge($main,['emails'=>$this->emails,'phones'=>$this->phones,'address'=>$this->address,'links'=>$this->links ,'company'=>$this->company,'contact'=>$this->contact,'contactrel'=>$this->contactrel]);
    }
}
