<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware(['auth:api','masterauth'])->group(function () {

    Route::resource('industry',IndustryController::class);
    Route::get('industry_headers',[Modules\ContactManager\Http\Controllers\IndustryController::class,'headers']);
    Route::any('industry_actionall',[Modules\ContactManager\Http\Controllers\IndustryController::class,'actionall']);

    Route::resource('group',GroupController::class);
    Route::get('group_getlist',[Modules\ContactManager\Http\Controllers\GroupController::class,'getlist']);
    Route::get('group_headers',[Modules\ContactManager\Http\Controllers\GroupController::class,'headers']);
    Route::any('group_actionall',[Modules\ContactManager\Http\Controllers\GroupController::class,'actionall']);

    Route::resource('sub_group',SubGroupController::class);
    Route::get('sub_group_getlist',[Modules\ContactManager\Http\Controllers\SubGroupController::class,'getlist']);
    Route::get('sub_group_headers',[Modules\ContactManager\Http\Controllers\SubGroupController::class,'headers']);
    Route::any('sub_group_actionall',[Modules\ContactManager\Http\Controllers\SubGroupController::class,'actionall']);


    Route::resource('contact',ContactController::class);
    Route::get('contact_getlist',[Modules\ContactManager\Http\Controllers\ContactController::class,'getlist']);
    Route::get('contact_headers',[Modules\ContactManager\Http\Controllers\ContactController::class,'headers']);
    Route::any('contact_actionall',[Modules\ContactManager\Http\Controllers\ContactController::class,'actionall']);
    Route::get('contact_view/{id}/',[Modules\ContactManager\Http\Controllers\ContactController::class,'view']);
    Route::post('quick_add_contact/{id}/',[Modules\ContactManager\Http\Controllers\ContactController::class,'quick_add_contact']);
    Route::any('contact_rel_delete/{id}/',[Modules\ContactManager\Http\Controllers\ContactController::class,'contact_rel_delete']);
    Route::any('contact_change_log/{id}/',[Modules\ContactManager\Http\Controllers\ContactController::class,'change_log']);
    Route::any('get_contacts_by_company',[Modules\ContactManager\Http\Controllers\ContactController::class,'get_contacts_by_company']);
    Route::any('contact_assign_user/{id}/',[Modules\ContactManager\Http\Controllers\ContactController::class,'assign_user']);
    Route::any('contact_revoke_user/{id}/',[Modules\ContactManager\Http\Controllers\ContactController::class,'revoke_user']);


    Route::any('group_export_excel',[Modules\ContactManager\Http\Controllers\GroupController::class,'export']);
    Route::any('contact_excel_export',[Modules\ContactManager\Http\Controllers\ContactController::class,'export']);
});    