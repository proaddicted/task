<?php

namespace Modules\ContactManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Modules\ResourceManager\Entities\Employee;
use Modules\ContactManager\Entities\GroupChangeLog;
use Modules\ContactManager\Entities\Contact;;

class Group extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;

    protected $fillable = ['name','description','status','emp_id'];

    protected $searchableColumns = ['name','description','employees.fname'];

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }

    public function employee()
    {
        return $this->belongsTo(Employee::class,'emp_id');
    }
    public function change_logs()
    {
		    return $this->hasMany(GroupChangeLog::class,"group_id","id")->whereNull('deleted_at');
    }
    public function companies()
    {
		    return $this->hasMany(Contact::class,"group_id","id")->whereNull('deleted_at');
    }
    public function company()
    {
        return $this->belongsTo(Contact::class,'company_id');
    }
  

    protected static function boot() 
    {
        parent::boot();
        
        self::creating(function($model){
          		            
        });

        self::created(function($model){
            
        });

        self::updating(function($model){
            
        });

        self::updated(function($model){
            
        });

        self::deleting(function($model){
           
        });

        self::deleted(function($model){
         
        });

       
    }
}
