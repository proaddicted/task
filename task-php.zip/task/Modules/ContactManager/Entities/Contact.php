<?php

namespace Modules\ContactManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use App\Models\Phone;
use App\Models\Email;
use App\Models\Link;
use App\Models\Address;
use App\Models\File;
use App\Models\MasterType;
use Modules\ResourceManager\Entities\Employee;
use Modules\ContactManager\Entities\Group;
use Modules\ContactManager\Entities\Industry;
use Modules\ContactManager\Entities\ContactContactRel;
use Modules\ContactManager\Entities\SubGroup;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\Auth;


class Contact extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait,Notifiable;

    protected $fillable = ['fname','mname','lname','registered_name','phone','email','profile','pan_no','contact_type_id','contact_source_id','dob','user_id','emp_id','description','group_id','turnover_id','type','industry_id','status','is_notification','sub_group_id','hide_email','hide_phone'];

    protected $searchableColumns = ['fname','lname','mname','phone','email'];
    
    protected $appends = ['full_name','thumbnail'];
    
    
    public function emails()
    {
        return $this->hasMany(Email::class,"main_id","id")->where('identifier','contact')->whereNull('deleted_at');
    }
    public function phones()
    {
        return $this->hasMany(Phone::class,"main_id","id")->where('identifier','contact')->whereNull('deleted_at');
    }
    public function links()
    {
        return $this->hasMany(Link::class,"main_id","id")->where('identifier','contact')->whereNull('deleted_at');
    }
    public function files()
    {
        return $this->hasMany(File::class,"main_id","id")->where('identifier','contact')->whereNull('deleted_at');
    }
    public function address()
    {
        return $this->hasMany(Address::class,"main_id","id")->where('identifier','contact')->whereNull('deleted_at');
    }

    public function contact_type()
    {
        return $this->belongsTo(MasterType::class,'contact_type_id');
    }
    public function contact_source()
    {
        return $this->belongsTo(MasterType::class,'contact_source_id');
    }
    public function turnover()
    {
        return $this->belongsTo(MasterType::class,'turnover_id');
    }
    public function employee()
    {
        return $this->belongsTo(Employee::class,'emp_id');
    }
    public function group()
    {
        return $this->belongsTo(Group::class,'group_id');
    }
    public function sub_group()
    {
        return $this->belongsTo(SubGroup::class,'group_id');
    }
    public function industry()
    {
        return $this->belongsTo(Industry::class,'industry_id');
    }
    public function getThumbnailAttribute()
    {
      if(!empty($this->attributes['profile']))
        return  $this->attributes['thumbnail'] =  env('APP_URL').'storage/'. $this->attributes['profile'];
      else
        return  $this->attributes['thumbnail'] =  null;
    }
    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }
    public function setIsNotificationAttribute($value)
    {
        $this->attributes['is_notification'] = (int) $value;
    }
    public function setHideEmailAttribute($value)
    {
        $this->attributes['hide_email'] = (int) $value;
    }
    public function setHidePhoneAttribute($value)
    {
        $this->attributes['hide_phone'] = (int) $value;
    }
    public function contact()
    {
       return $this->belongsToMany(Contact::class,'contact_contact_rels','parent_contact_id','contact_id')->withPivot('designation_id','is_notification','is_access','id')->wherePivot('deleted_at',NULL)->withTimestamps();
    }
    public function company()
    {
       return $this->belongsToMany(Contact::class,'contact_contact_rels','contact_id','parent_contact_id')->withPivot('designation_id','is_notification','is_access','id')->wherePivot('deleted_at',NULL)->withTimestamps();

       /*https://github.com/ajcastro/eager-load-pivot-relations use this package for nested pivot eager loading*/
    }
    public function contactrel()
    {
        return $this->hasMany(ContactContactRel::class,'contact_id')->whereNull('deleted_at')->orderBy('created_at', 'DESC');
    }
    public function companyrel()
    {
        return $this->hasMany(ContactContactRel::class,'parent_contact_id')->whereNull('deleted_at')->orderBy('created_at', 'DESC');
    }
    public function getFullNameAttribute()
    {
        $full_name="";
        $full_name .=empty($this->attributes['prefix'])?'':$this->attributes['prefix'] . ' ';
        $full_name .=empty($this->attributes['fname'])?'':$this->attributes['fname'] . ' ';
        $full_name .=empty($this->attributes['mname'])?'':$this->attributes['mname'] . ' ';
        $full_name .=empty($this->attributes['lname'])?'':$this->attributes['lname'];
        
        return $this->attributes['full_name']=$full_name ;
    }

    public function getEmailAttribute()
    {
        if(Auth::user() && Auth::user()->is_superadmin == 0)
        {
            if(isset($this->attributes['hide_email']) && $this->attributes['hide_email'])
            {
                return $this->attributes['email']="XXX@XXX.XXX";
            }
            else
            {
                return $this->attributes['email']=$this->attributes['email'];
            }
        }
        else
            return $this->attributes['email']=$this->attributes['email'];
       
    }
    public function getPhoneAttribute()
    {
        if(Auth::user() && Auth::user()->is_superadmin == 0)
        {
            if(isset($this->attributes['hide_phone']) && $this->attributes['hide_phone'])
            {
                return $this->attributes['phone']="XXXXXXXXXX";
            }
            else
            {
                return $this->attributes['phone']=$this->attributes['phone'];
            }
        }
        else
            return $this->attributes['phone']=$this->attributes['phone'];
    }

    protected static function boot() 
    {
        parent::boot();
        
        self::creating(function($model){
          		            
		
        });

        self::created(function($model){
            
        });

        self::updating(function($model){
            
        });

        self::updated(function($model){
            
        });

        self::deleting(function($model){
           
        });

        self::deleted(function($model){
            $model->phones()->delete();
            $model->emails()->delete();
            $model->links()->delete();
            $model->address()->delete();
            $model->files()->delete();

            if($model->type == 'individual')
            {
                $model->contactrel()->delete();
            }
           
            
        });

       
    }
}
