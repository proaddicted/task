<?php

namespace Modules\ContactManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Models\MasterType;

class ContactContactRel extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait;
    protected $fillable = ['contact_id','designation_id','is_access','parent_contact_id','is_notification'];
    
    protected $searchableColumns = [];

    public function designation()
    {
        return $this->belongsTo(MasterType::class,'designation_id');
    }
}
