<?php

namespace Modules\ContactManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Modules\ResourceManager\Entities\Employee;
use Modules\ContactManager\Entities\Group;

class SubGroup extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;

    protected $fillable = ['name','description','emp_id','group_id','status'];
    
    protected $searchableColumns = ['name','description','employees.fname','groups.name'];

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }

    public function employee()
    {
        return $this->belongsTo(Employee::class,'emp_id');
    }

    public function group()
    {
        return $this->belongsTo(Group::class,'group_id');
    }
}
