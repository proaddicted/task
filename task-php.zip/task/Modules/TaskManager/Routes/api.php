<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
Route::any('knowlarity_data_push',[Modules\TaskManager\Http\Controllers\TaskController::class,'knowlarity_data_push']);
Route::any('store_all_comments',[Modules\TaskManager\Http\Controllers\CommunicationController::class,'store_all_comments']);//12/09/2024
Route::any('store_all_comment_recipients',[Modules\TaskManager\Http\Controllers\CommunicationController::class,'store_all_comment_recipients']);//12/09/2024
Route::any('store_all_comment_reads',[Modules\TaskManager\Http\Controllers\CommunicationController::class,'store_all_comment_reads']);

Route::any('store_all_tickets',[Modules\TaskManager\Http\Controllers\TaskController::class,'store_all_tickets']);
Route::any('store_all_activities',[Modules\TaskManager\Http\Controllers\TaskController::class,'store_all_activities']);
Route::any('store_all_ist',[Modules\TaskManager\Http\Controllers\TaskController::class,'store_all_ist']);

Route::middleware(['masterauth'])->group(function () {
    Route::any('check_user_availability',[Modules\TaskManager\Http\Controllers\UserAvailabilityController::class,'check_user_availability']);
    Route::any('get_available_users',[Modules\TaskManager\Http\Controllers\UserAvailabilityController::class,'get_available_users']);
    Route::any('meeting_request',[Modules\TaskManager\Http\Controllers\TaskController::class,'meeting_request']);

});
Route::middleware(['auth:api','masterauth'])->group(function () {

    Route::resource('custom_template',CustomTemplateController::class);
    Route::get('custom_template_headers',[Modules\TaskManager\Http\Controllers\CustomTemplateController::class,'headers']);
    Route::any('custom_template_actionall',[Modules\TaskManager\Http\Controllers\CustomTemplateController::class,'actionall']);

    Route::resource('check_list',CheckListController::class);
    Route::get('check_list_headers',[Modules\TaskManager\Http\Controllers\CheckListController::class,'headers']);
    Route::any('check_list_actionall',[Modules\TaskManager\Http\Controllers\CheckListController::class,'actionall']);

    Route::resource('task',TaskController::class);
    Route::get('task_getlist',[Modules\TaskManager\Http\Controllers\TaskController::class,'getlist']);
    Route::get('task_headers',[Modules\TaskManager\Http\Controllers\TaskController::class,'headers']);
    Route::any('task_actionall',[Modules\TaskManager\Http\Controllers\TaskController::class,'actionall']);
    Route::any('task_change_log/{id}/',[Modules\TaskManager\Http\Controllers\TaskController::class,'change_log']);
    Route::get('task_view/{id}/',[Modules\TaskManager\Http\Controllers\TaskController::class,'view']);
    Route::any('task_create_note/{id}/',[Modules\TaskManager\Http\Controllers\TaskController::class,'create_note']);
    Route::any('task_delete_note/{id}/',[Modules\TaskManager\Http\Controllers\TaskController::class,'delete_note']);
    Route::any('task_note_change_log/{id}/',[Modules\TaskManager\Http\Controllers\TaskController::class,'note_change_log']);
    Route::any('task_create_check_list/{id}/',[Modules\TaskManager\Http\Controllers\TaskController::class,'create_check_list']);
    Route::any('task_check_check_list/{id}/',[Modules\TaskManager\Http\Controllers\TaskController::class,'check_check_list']);
    Route::any('task_reject_check_list/{id}/',[Modules\TaskManager\Http\Controllers\TaskController::class,'reject_check_list']);
    Route::any('task_delete_check_list/{id}/',[Modules\TaskManager\Http\Controllers\TaskController::class,'delete_check_list']);
    Route::any('task_request_check_list/{id}/',[Modules\TaskManager\Http\Controllers\TaskController::class,'request_check_list']);
    Route::any('task_check_list_change_log/{id}',[Modules\TaskManager\Http\Controllers\TaskController::class,'check_list_change_log']);
    Route::get('sub_tasks_by_id/{id}',[Modules\TaskManager\Http\Controllers\TaskController::class,'sub_tasks_by_id']);
    Route::any('reschedule_task/{id}/',[Modules\TaskManager\Http\Controllers\TaskController::class,'reschedule_task']);
    Route::any('save_inspector_of_phonenumbers',[Modules\TaskManager\Http\Controllers\TaskController::class,'save_inspector_of_phonenumbers']);//24/08/2024
    Route::get('crd_getlist',[Modules\TaskManager\Http\Controllers\TaskController::class,'crd_getlist']);
    Route::get('info_view/{id}/',[Modules\TaskManager\Http\Controllers\TaskController::class,'info_view']);
    Route::any('save_new_info_request',[Modules\TaskManager\Http\Controllers\TaskController::class,'save_new_info_request']);
    Route::any('update_info_request/{id}/',[Modules\TaskManager\Http\Controllers\TaskController::class,'update_info_request']);
    
    Route::get('meeting_request_list',[Modules\TaskManager\Http\Controllers\TaskController::class,'meeting_request_list']);
    Route::any('meeting_request_update/{id}/',[Modules\TaskManager\Http\Controllers\TaskController::class,'meeting_request_update']);
    Route::any('task_calender/{id}/',[Modules\TaskManager\Http\Controllers\TaskController::class,'task_calender']);
    
    Route::get('my_meetings',[Modules\TaskManager\Http\Controllers\TaskController::class,'my_meetings']);
    Route::any('meeting_history_update/{id}/',[Modules\TaskManager\Http\Controllers\TaskController::class,'meeting_history_update']);
    Route::any('ist_change_log/{id}/',[Modules\TaskManager\Http\Controllers\TaskController::class,'ist_change_log']);
    Route::get('task_department_info/{id}/',[Modules\TaskManager\Http\Controllers\TaskController::class,'task_department_info']);
    Route::any('task_officer_update/{id}/',[Modules\TaskManager\Http\Controllers\TaskController::class,'task_officer_update']);
    Route::any('get_task_by_company/{id}',[Modules\TaskManager\Http\Controllers\TaskController::class,'get_task_by_company']);
    Route::any('knowlarity_place_call',[Modules\TaskManager\Http\Controllers\TaskController::class,'knowlarity_place_call']);
    Route::any('call_list',[Modules\TaskManager\Http\Controllers\TaskController::class,'call_list']);//30/08/2024
    Route::any('call_list_headers',[Modules\TaskManager\Http\Controllers\TaskController::class,'call_list_headers']);//30/08/2024
    Route::any('knowlarity_call_rating',[Modules\TaskManager\Http\Controllers\TaskController::class,'knowlarity_call_rating']);//30/08/2024
    Route::any('knowlarity_getlist',[Modules\TaskManager\Http\Controllers\TaskController::class,'knowlarity_getlist']);//31/08/2024
    
    Route::any('fetch_sahaj_invoice/{id}',[Modules\TaskManager\Http\Controllers\TaskController::class,'fetch_sahaj_invoice']);//31/08/2024
    Route::any('schedule_calls',[Modules\TaskManager\Http\Controllers\TaskController::class,'schedule_calls']);//05/09/2024
    Route::any('knowlarity_schedule_calldata',[Modules\TaskManager\Http\Controllers\TaskController::class,'knowlarity_schedule_calldata']);//05/09/2024
    
    Route::any('knowlarity_call_move',[Modules\TaskManager\Http\Controllers\TaskController::class,'knowlarity_call_move']);//31/08/2024
    Route::get('fetch_phone_numbers',[Modules\TaskManager\Http\Controllers\TaskController::class,'fetch_phone_numbers']);
    Route::any('task_excel_export',[Modules\TaskManager\Http\Controllers\TaskController::class,'export']);
    Route::any('change_logs_by_task/{id}/',[Modules\TaskManager\Http\Controllers\TaskController::class,'change_log_records']);
    Route::any('tasks_by_id/{id}/',[Modules\TaskManager\Http\Controllers\UserDashBoardController::class,'tasks_by_id']);
    
    Route::any('get_task_by_type/{id}',[Modules\TaskManager\Http\Controllers\TaskController::class,'get_task_by_type']);
    Route::any('mirror_file_ticket',[Modules\TaskManager\Http\Controllers\TaskController::class,'mirror_file_ticket']);
    Route::any('move_file_ticket',[Modules\TaskManager\Http\Controllers\TaskController::class,'move_file_ticket']);

    Route::any('call_list_actionall',[Modules\TaskManager\Http\Controllers\TaskController::class,'call_actionall']);
    Route::any('call_log_export',[Modules\TaskManager\Http\Controllers\TaskController::class,'call_log_export']);
    Route::any('store_all_tickets',[Modules\TaskManager\Http\Controllers\TaskController::class,'store_all_tickets']);
    
    Route::resource('communication',CommunicationController::class);
    Route::get('communication_getlist',[Modules\TaskManager\Http\Controllers\CommunicationController::class,'getlist']);
    Route::get('inbox',[Modules\TaskManager\Http\Controllers\CommunicationController::class,'inbox']);
    Route::get('outbox',[Modules\TaskManager\Http\Controllers\CommunicationController::class,'outbox']);
    Route::get('archive',[Modules\TaskManager\Http\Controllers\CommunicationController::class,'archive']);
    Route::any('communication_archive/{id}/',[Modules\TaskManager\Http\Controllers\CommunicationController::class,'communication_archive']);
    Route::any('communication_unarchive/{id}/',[Modules\TaskManager\Http\Controllers\CommunicationController::class,'communication_unarchive']);
    Route::any('read_communication/{id}/',[Modules\TaskManager\Http\Controllers\CommunicationController::class,'read_communication']);
    Route::any('unread_communication/{id}/',[Modules\TaskManager\Http\Controllers\CommunicationController::class,'unread_communication']);

    
    

    Route::get('user_analytics_dashboard',[Modules\TaskManager\Http\Controllers\UserDashBoardController::class,'user_analytics_dashboard']);
    Route::get('tasks_by_user',[Modules\TaskManager\Http\Controllers\UserDashBoardController::class,'tasks_by_user']);
    Route::get('tasks_tree_by_user',[Modules\TaskManager\Http\Controllers\UserDashBoardController::class,'tasks_tree_by_user']);
    Route::get('performance_data_by_user/{id}/',[Modules\TaskManager\Http\Controllers\UserDashBoardController::class,'performance_data_by_user']);
    Route::get('all_tasks_by_user',[Modules\TaskManager\Http\Controllers\UserDashBoardController::class,'all_tasks_by_user']);
    Route::get('all_tasks_by_user_headers',[Modules\TaskManager\Http\Controllers\UserDashBoardController::class,'all_tasks_by_user_headers']);
    Route::get('get_all_tasks',[Modules\TaskManager\Http\Controllers\TaskController::class,'get_all_tasks']);

    Route::resource('information_item',InformationItemController::class);
    Route::get('information_item_getlist',[Modules\TaskManager\Http\Controllers\InformationItemController::class,'getlist']);
    Route::get('information_item_headers',[Modules\TaskManager\Http\Controllers\InformationItemController::class,'headers']);
    Route::any('information_item_actionall',[Modules\TaskManager\Http\Controllers\InformationItemController::class,'actionall']);

    Route::resource('information_sub_group',InformationSubGroupController::class);
    Route::get('information_sub_group_getlist',[Modules\TaskManager\Http\Controllers\InformationSubGroupController::class,'getlist']);
    Route::get('information_sub_group_headers',[Modules\TaskManager\Http\Controllers\InformationSubGroupController::class,'headers']);
    Route::any('information_sub_group_actionall',[Modules\TaskManager\Http\Controllers\InformationSubGroupController::class,'actionall']);


    Route::resource('information_group',InformationGroupController::class);
    Route::get('information_group_getlist',[Modules\TaskManager\Http\Controllers\InformationGroupController::class,'getlist']);
    Route::get('information_group_headers',[Modules\TaskManager\Http\Controllers\InformationGroupController::class,'headers']);
    Route::any('information_group_actionall',[Modules\TaskManager\Http\Controllers\InformationGroupController::class,'actionall']);


    Route::resource('user_availability',UserAvailabilityController::class);
    Route::get('user_availability_getlist',[Modules\TaskManager\Http\Controllers\UserAvailabilityController::class,'getlist']);
    Route::get('user_availability_headers',[Modules\TaskManager\Http\Controllers\UserAvailabilityController::class,'headers']);
    Route::any('user_availability_actionall',[Modules\TaskManager\Http\Controllers\UserAvailabilityController::class,'actionall']);
    
    Route::resource('department_type', DepartmentTypeController::class);
    Route::any('department_type_getlist',[Modules\TaskManager\Http\Controllers\DepartmentTypeController::class,'getlist']);
    Route::any('department_type_headers',[Modules\TaskManager\Http\Controllers\DepartmentTypeController::class,'headers']);
    Route::any('department_type_actionall',[Modules\TaskManager\Http\Controllers\DepartmentTypeController::class,'actionall']);

    Route::resource('officer', OfficerController::class);
    Route::any('officer_getlist',[Modules\TaskManager\Http\Controllers\OfficerController::class,'getlist']);
    Route::any('officer_headers',[Modules\TaskManager\Http\Controllers\OfficerController::class,'headers']);
    Route::any('officer_actionall',[Modules\TaskManager\Http\Controllers\OfficerController::class,'actionall']);

    Route::resource('task_flag', TaskFlagController::class);
    Route::get('task_flag_headers',[Modules\TaskManager\Http\Controllers\TaskFlagController::class,'headers']);
    Route::get('task_flag_getlist',[Modules\TaskManager\Http\Controllers\TaskFlagController::class,'getlist']);
    Route::any('task_flag_actionall',[Modules\TaskManager\Http\Controllers\TaskFlagController::class,'actionall']);

    Route::resource('ticket_stages',TicketStageController::class);
    Route::get('ticket_stages_headers',[Modules\TaskManager\Http\Controllers\TicketStageController::class,'headers']);
    Route::any('ticket_stages_actionall',[Modules\TaskManager\Http\Controllers\TicketStageController::class,'actionall']);
   
    
});    
