<?php

namespace Modules\TaskManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;

class TaskHistory extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;

    protected $fillable = ['task_id','user_id','office_out_time','office_out_longitude','office_out_latitude','office_out_address','meeting_in_time','meeting_in_longitude','meeting_in_latitude','meeting_in_address','meeting_out_time','meeting_out_longitude','meeting_out_latitude','meeting_out_address','office_in_time','office_in_longitude','office_in_latitude','office_in_address'];

    protected $searchableColumns = ['task_id'];
    
   
}
