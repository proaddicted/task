<?php

namespace Modules\TaskManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Modules\TaskManager\Entities\OfficerDepartment;
use App\Models\Phone;
use App\Models\Email;
use App\Models\Address;
use Illuminate\Support\Facades\Auth;

class Officer extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;

    protected $fillable = ['fname','mname','lname','phone','email','profile','status','remarks','hide_phone','hide_email','link_contact_id'];

    protected $appends = ['full_name'];

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }
    public function setHideEmailAttribute($value)
    {
        $this->attributes['hide_email'] = (int) $value;
    }
    public function setHidePhoneAttribute($value)
    {
        $this->attributes['hide_phone'] = (int) $value;
    }

    public function emails()
    {
        return $this->hasMany(Email::class,"main_id","id")->where('identifier','officer')->whereNull('deleted_at');
    }
    public function phones()
    {
        return $this->hasMany(Phone::class,"main_id","id")->where('identifier','officer')->whereNull('deleted_at');
    }
  
    public function address()
    {
        return $this->hasMany(Address::class,"main_id","id")->where('identifier','officer')->whereNull('deleted_at');
    }
    public function departments()
    {
        return $this->hasMany(OfficerDepartment::class,"officer_id","id")->whereNull('deleted_at')->orderBy('is_default','desc');
    }

    public function getFullNameAttribute()
    {
        $full_name="";
        $full_name .=empty($this->attributes['prefix'])?'':$this->attributes['prefix'] . ' ';
        $full_name .=empty($this->attributes['fname'])?'':$this->attributes['fname'] . ' ';
        $full_name .=empty($this->attributes['mname'])?'':$this->attributes['mname'] . ' ';
        $full_name .=empty($this->attributes['lname'])?'':$this->attributes['lname'];
        
        return $this->attributes['full_name']=$full_name ;
    }
    public function getEmailAttribute()
    {
        if(Auth::user() && Auth::user()->is_superadmin == 0)
        {
            if(isset($this->attributes['hide_email']) && $this->attributes['hide_email'])
            {
                return $this->attributes['email']="XXX@XXX.XXX";
            }
            else
            {
                return $this->attributes['email']=$this->attributes['email'];
            }
        }
        else
            return $this->attributes['email']=$this->attributes['email'];
       
    }
    public function getPhoneAttribute()
    {
        if(Auth::user() && Auth::user()->is_superadmin == 0)
        {
            if(isset($this->attributes['hide_phone']) && $this->attributes['hide_phone'])
            {
                return $this->attributes['phone']="XXXXXXXXXX";
            }
            else
            {
                return $this->attributes['phone']=$this->attributes['phone'];
            }
        }
        else
            return $this->attributes['phone']=$this->attributes['phone'];
    }


    protected static function boot() 
    {
        parent::boot();
        
        self::creating(function($model){
          		            
		
        });

        self::created(function($model){
            
        });

        self::updating(function($model){
            
        });

        self::updated(function($model){
            
        });

        self::deleting(function($model){
           
        });

        self::deleted(function($model){
            $model->phones()->delete();
            $model->emails()->delete();
            $model->departments()->delete();
            $model->address()->delete();
        });

       
    }
   
}
