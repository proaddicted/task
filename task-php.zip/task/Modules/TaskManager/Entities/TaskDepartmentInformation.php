<?php

namespace Modules\TaskManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use App\Models\MasterType;

class TaskDepartmentInformation extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;

    protected $fillable = ['purpose_id','type_id','mode_id','location','task_id'];
    
    protected $searchableColumns = ['location'];

    protected $appends = ['type','mode'];


    public function purpose()
    {
        return $this->belongsTo(MasterType::class,"purpose_id");
    }

    public function getTypeAttribute()
    {
        if(isset($this->attributes['type_id']))
        {
            $department_task_types=array_column($this->department_task_types,'name', 'id'); 
        
            return $this->attributes['type'] = $department_task_types[$this->attributes['type_id']];
        }
    }
    
    public function getModeAttribute()
    {
        if(isset($this->attributes['mode_id']))
        {
            $department_task_modes=array_column($this->department_task_modes,'name', 'id'); 
        
            return $this->attributes['mode'] = $department_task_modes[$this->attributes['mode_id']];
        }
    }


}
