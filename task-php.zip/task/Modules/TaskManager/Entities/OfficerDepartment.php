<?php

namespace Modules\TaskManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Modules\TaskManager\Entities\DepartmentType;

class OfficerDepartment extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;

    protected $fillable = ['officer_id','department_type_id','designation','l1','l2','l3','state','city','location','block_no','floor_no','room_no','is_default'];

    public function setIsDefaultAttribute($value)
    {
        $this->attributes['is_default'] = (int) $value;
    }
    public function department_type()
    {
        return $this->belongsTo(DepartmentType::class,"department_type_id")->with('parent');
    }
    
    
}
