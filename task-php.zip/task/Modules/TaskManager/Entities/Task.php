<?php

namespace Modules\TaskManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Modules\TaskManager\Entities\TaskCheckList;
use Modules\TaskManager\Entities\TaskChangeLog;
use Modules\TaskManager\Entities\TaskNote;
use Modules\TaskManager\Entities\Communication;
use App\Models\File;
use Modules\ContactManager\Entities\Contact;
use Modules\ContactManager\Entities\Group;
use App\Models\Service;
use App\Models\User;
use Modules\ResourceManager\Entities\Employee;
use Illuminate\Support\Facades\Auth;
use App\Traits\EmployeeTrait;
use Modules\TaskManager\Entities\InformationItem;
use Modules\TaskManager\Entities\InformationSubGroup;
use Modules\TaskManager\Entities\TaskInvitie;
use Modules\TaskManager\Entities\TaskHistory;
use Modules\TaskManager\Entities\TaskDepartmentInformation;
use Modules\TaskManager\Entities\Officer;
use Illuminate\Support\Facades\DB;
use Modules\TaskManager\Entities\TaskFlag;
use Modules\TaskManager\Entities\TicketStage;
use App\Models\MasterType; 
use Carbon\Carbon;

class Task extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;

    protected $fillable = ['name','description','status','type','priority','parent_id','start_date','received_date','due_date','ecd','completed_date','start_period','end_period','referral_id','recursive_type','recursive_end_date','recursive_days','recursive_task_id','recursive_last_created','standard_time','description_id','main_id','remarks','meeting_type','duration','meeting_start_url','meeting_invite_url','ist_type','location','group_id','purpose_id','type_id','mode_id'];
    
    protected $searchableColumns = ['name','description'];

    protected $appends = ['status_name','priority_name','ist_type_name','display_name','type_name','recursive_type_name','fiscal_year','department_type_name','department_mode_name'];

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }
    public function setPriorityAttribute($value)
    {
        $this->attributes['priority'] = (int) $value;
    }

    public function getDepartmentTypeNameAttribute()
    {
        if(isset($this->attributes['type_id']))
        {
            $department_types=array_column($this->department_task_types,'name', 'id'); 
        
            return $this->attributes['department_type_name'] = $department_types[$this->attributes['type_id']];
        }
            
    }
    public function getDepartmentModeNameAttribute()
    {
        if(isset($this->attributes['mode_id']))
        {
            $department_modes=array_column($this->department_task_modes,'name', 'id'); 
        
            return $this->attributes['department_mode_name'] = $department_modes[$this->attributes['mode_id']];
        }
            
    }
  
    public function services()
    {
        return $this->belongsToMany(Service::class,"task_services","task_id","service_id")->wherePivot('deleted_at',NULL)->orderBy('services.parent_id','asc')->withTimestamps()->with('parent');
    }
    public function contacts()
    {
       return $this->belongsToMany(Contact::class,'task_contacts','task_id','contact_id')->wherePivot('deleted_at',NULL)->withTimestamps();
    }
    public function companies()
    {
       return $this->belongsToMany(Contact::class,'task_companies','task_id','company_id')->wherePivot('deleted_at',NULL)->withTimestamps();
    }
    public function employees()
    {
	
        return $this->belongsToMany(User::class,"task_users","task_id","user_id")->wherePivot('deleted_at',NULL)->wherePivotIn('type',['employee','supervisor','manager'])->withTimestamps()->withPivot('type','is_default','is_notification','main_id','identifier');
    }
   
    public function members()
    {
	
        return $this->belongsToMany(User::class,"task_users","task_id","user_id")->wherePivot('deleted_at',NULL)->wherePivot('type','employee')->withTimestamps()->withPivot('type','is_default','is_notification','main_id','identifier');
    }
    public function supervisor()
    {
	
        
        return $this->belongsToMany(User::class,"task_users","task_id","user_id")->wherePivot('deleted_at',NULL)->wherePivot('type','supervisor')->withTimestamps()->withPivot('type','is_default','is_notification','main_id','identifier');
    }
   
    public function manager()
    {
	
        return $this->belongsToMany(User::class,"task_users","task_id","user_id")->wherePivot('deleted_at',NULL)->wherePivot('type','manager')->withTimestamps()->withPivot('type','is_default','is_notification','main_id','identifier');
    }

    public function unique_employees()
    {
	
        return $this->belongsToMany(User::class,"task_users","task_id","user_id")->wherePivot('deleted_at',NULL)->wherePivotIn('type',['employee','supervisor','manager'])->groupBy('users.id')->withTimestamps()->withPivot('type','is_default','is_notification','main_id','identifier');
    }

    public function contact_users()
    {
	
        return $this->belongsToMany(User::class,"task_users","task_id","user_id")->wherePivot('deleted_at',NULL)->wherePivot('type','contact')->withTimestamps()->withPivot('type','is_default','is_notification','main_id','identifier');
    }
    
    public function files()
    {
        return $this->hasMany(File::class,"main_id","id")->where('identifier','task')->whereNull('deleted_at');
    }
    public function check_lists()
    {
        return $this->hasMany(TaskCheckList::class,"task_id","id")->whereNull('deleted_at');
    }
    public function notes()
    {
        return $this->hasMany(TaskNote::class,"task_id","id")->whereNull('deleted_at');
    }

    public function change_logs()
    {
        return $this->hasMany(TaskChangeLog::class,"task_id","id")->whereNull('deleted_at')->orderby('created_at','desc');
    }
    public function getStatusNameAttribute()
    {
        if(isset($this->attributes['status']) && isset($this->attributes['type']))
        {
            if($this->attributes['type'] == 'regular-ticket' || $this->attributes['type'] == 'help-ticket' || $this->attributes['type'] == 'memorized-ticket' || $this->attributes['type'] == 'crd')
                $statuses=array_column($this->ticket_statuses,'name', 'id'); 
            else if($this->attributes['type'] == 'call' || $this->attributes['type'] == 'meeting' || $this->attributes['type'] == 'todo' || $this->attributes['type'] == 'department-task')
                $statuses=array_column($this->task_statuses,'name', 'id'); 
            else if($this->attributes['type'] == 'ist')
                $statuses=array_column($this->ist_statuses,'name', 'id'); 

            return $this->attributes['status_name'] = $statuses[$this->attributes['status']];
        }
               
    }
    public function getDisplayNameAttribute()
    {
        if(isset($this->attributes['id']))
        {
            if(isset($this->attributes['type']) && $this->attributes['type'] == 'regular-ticket')
            {
                return $this->attributes['display_name'] = "RT".$this->attributes['id'];
            }
            
        }
    }    
    public function children()
    {
        return $this->hasMany(Task::class, 'parent_id')->whereIn('type',['meeting','call','todo','crd','help-ticket','regular-ticket','department-task'])->with('children');
    }
    public function children_by_logged_user()
    {
        $authuser = request()->userid > 0 ? User::find(request()->userid) : Auth::user();
       
        return $this->hasMany(Task::class, 'parent_id')->whereIn('type',['meeting','call','todo','crd','help-ticket','regular-ticket','department-task'])->orderBy('start_date','desc')->with(['children_by_logged_user'=> function($q) use ($authuser)
        { 
            $q->whereHas('employees', function($q2) use ($authuser)
            {
                $q2->where('task_users.user_id',$authuser->id);
            });
        }])->with('services','contacts','companies','employees','files','supervisor');
    }
    public function sub_tasks()
    {
        return $this->hasMany(Task::class, 'main_id')->whereIn('type',['meeting','call','todo','crd','help-ticket','regular-ticket','department-task'])->where('parent_id',0)->with('children');
    }
    public function main_task()
    {
        return $this->belongsTo(Task::class,'main_id');

    }
    public function group()
    {
        return $this->belongsTo(Group::class,'group_id');

    }

    public function calls()
    {
        return $this->hasMany(Task::class, 'main_id')->where('type','call');
    }
    public function meetings()
    {
        return $this->hasMany(Task::class, 'main_id')->where('type','meeting');
    }
    public function todos()
    {
        return $this->hasMany(Task::class, 'main_id')->where('type','todo');
    }
    public function help_tickets()
    {
        return $this->hasMany(Task::class, 'main_id')->where('type','help-ticket');
    }
    public function department_tasks()
    {
        return $this->hasMany(Task::class, 'main_id')->where('type','department-task');
    }
    public function crds()
    {
        return $this->hasMany(Task::class, 'main_id')->where('type','crds');
    }
    
    public function communications()
    {
        return $this->hasMany(Communication::class, 'main_id','id')->where('identifier','task')->where('parent_id',0)->orderBy('date','desc');
    }
    public function invities()
    {
        return $this->hasMany(TaskInvitie::class, 'task_id','id');
    }
    public function history()
    {
        return $this->hasMany(TaskHistory::class, 'task_id','id');
    }
    public function department_info()
    {
        return $this->hasOne(TaskDepartmentInformation::class, 'task_id','id');
    }

    public function department_purpose()
    {
        return $this->belongsTo(MasterType::class,'purpose_id');
    }
    
    public function officers()
    {
       return $this->belongsToMany(Officer::class,'task_officers','task_id','officer_id')->wherePivot('deleted_at',NULL)->withTimestamps();
    }
    
    public function task_flags()
    {
       return $this->belongsToMany(TaskFlag::class,'task_flag_lists','task_id','task_flag_id')->wherePivot('deleted_at',NULL)->withTimestamps();
    }

    public function referral()
    {
        return $this->belongsTo(Contact::class,'referral_id');
    }

    /*Information Request Section Code */

    public function information_items()
    {
	
        return $this->belongsToMany(InformationItem::class,"task_information_items","task_id","information_item_id")->wherePivot('deleted_at',NULL)->wherePivot('identifier','information_item')->withTimestamps()->withPivot('is_multiple','is_required','order_no','description','name','value','type','identifier','information_sub_group_id','id');
    }
    public function information_sub_groups()
    {
	
        return $this->belongsToMany(InformationSubGroup::class,"task_information_items","task_id","information_sub_group_id")->wherePivot('deleted_at',NULL)->wherePivot('identifier','information_sub_group')->withTimestamps()->withPivot('is_multiple','is_required','order_no','description','name','value','type','identifier','information_item_id');
    }
    public function information_sub_items()
    {
	
        return $this->belongsToMany(InformationItem::class,"task_information_items","task_id","information_item_id")->wherePivot('deleted_at',NULL)->wherePivot('identifier','information_sub_group_item')->withTimestamps()->withPivot('is_multiple','is_required','order_no','description','name','value','type','identifier','information_sub_group_id');
    }

    public function recursive_week()
    {
        return $this->hasMany(TaskSchedule::class,"task_id","id")->whereNull('deleted_at');
    }
    
    public function ticket_stages() 
    {
       return $this->belongsToMany(TicketStage::class,'ticket_stages_lists','task_id','ticket_stages_id')->wherePivot('deleted_at',NULL)->withTimestamps();
    }

     /*Information Request Section Code End */

    public function getPriorityNameAttribute()
    {
        if(isset($this->attributes['priority']))
        {
            $priorities=array_column($this->ticket_priorities,'name', 'id'); 
        
            return $this->attributes['priority_name'] = $priorities[$this->attributes['priority']];
        }
               
    }
    public function getTypeNameAttribute()
    {
        if(isset($this->attributes['type']))
        {
            $types=array_column($this->task_types,'name', 'id'); 
        
            return $this->attributes['type_name'] = $types[$this->attributes['type']];
        }
               
    }
    public function getIstTypeNameAttribute()
    {
        if(isset($this->attributes['ist_type']))
        {
            $priorities=array_column($this->ist_types,'name', 'id'); 
        
            return $this->attributes['ist_type_name'] = $priorities[$this->attributes['ist_type']];
        }
               
    }

    public function getRecursiveTypeNameAttribute()
    {
        if(isset($this->attributes['type']) && $this->attributes['type'] == 'memorized-ticket')
        {
            if(isset($this->attributes['recursive_type']))
            {
                $priorities=array_column($this->recursive_types,'name', 'id'); 
            
                return $this->attributes['recursive_type_name'] = $priorities[$this->attributes['recursive_type']];
            }
        }
       
               
    }

   public function getFiscalYearAttribute()
   {

    if(isset($this->attributes['start_period']) && isset($this->attributes['end_period']))
    {
        if(($this->attributes['start_period']!=""|| $this->attributes['start_period']!= null || !empty($this->attributes['start_period'])) && ($this->attributes['end_period']!=""|| $this->attributes['end_period']!= null || !empty($this->attributes['end_period'])) 
        )
        {
            $year=Carbon::createFromFormat('m/Y', $this->attributes['start_period'])->format('y');
            $strmon=explode('/',$this->attributes['start_period']);
            $year2=Carbon::createFromFormat('m/Y', $this->attributes['end_period'])->format('y');
            $endmon2=explode('/',$this->attributes['end_period']);

            $fiscalPeriod=array();
            if(intval($strmon[0])>3){
                $startfiscalyear=strval($year); 
                $startendfiscalyear=strval($year+1);
            }
            else{
                $startfiscalyear=strval($year-1); 
                $startendfiscalyear=strval($year);
            }
            if(intval($endmon2[0])>3){
                $endstartfiscalyear=strval($year2); 
                $endfiscalyear=strval($year2+1);
            }
            else{
                $endstartfiscalyear=strval($year2-1); 
                $endfiscalyear=strval($year2);
            }
            array_push( $fiscalPeriod,'['.$startfiscalyear.'-'.$startendfiscalyear.']');
            if(($startfiscalyear != $endstartfiscalyear) && ($startendfiscalyear !=$endfiscalyear )){
            for ($i=intval($startfiscalyear)+1; $i <intval($endfiscalyear)-1 ; $i++) { 
                $e=$i+1;
                array_push( $fiscalPeriod,'['.$i.'-'.$e.']');
            }
            
            array_push( $fiscalPeriod,'['.$endstartfiscalyear.'-'.$endfiscalyear.']');
            
            }
            // $tickets[$key]['start_end_period_fiscal_year'] = $fiscalPeriod;
            return $this->attributes['fiscal_year'] = implode(',', $fiscalPeriod);
        }
    }
       
    
   }
    /**
     * This is a public function which is used for permission checking of index/listing function for task section
     * @param $query query builder reference
     * @return string or boolean or query
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */
    public function scopetaskCheckPermission($query)
    {
        $user = Auth::user();
        if($user->is_superadmin == 0)
        {
            $employee_info = $this->employee_info($user);
            $res = $this->checkAccessType(5);
    
           // $this->result  = $res;
            if(count($res) > 0)
            {
                
                if($res[0]->access == 0)     /* No Access */
                    $query->whereRaw('1=2');
                elseif($res[0]->access == 1) /* Self Access */
                {
                    $query->whereHas('employees', function ($q) use ($user){
                        $q->where('user_id',$user->id);
                    });
                }
                elseif($res[0]->access == 2) /* Hierarchy Access */
                {
                    
                    $query->whereHas('employees', function ($q) use ($employee_info){
                        $q->whereIn('user_id',$employee_info->hierarchy_users);
                    });
                   // $query->whereIn($column,$employee_info->hierarchy_users);
                }
                elseif($res[0]->access == 3) /* Branch Access */
                {
                   
                    $query->whereHas('employees', function ($q) use ($employee_info){
                        $q->whereIn('user_id',$employee_info->branch_users);
                    });
                }
                elseif($res[0]->access == 4) /* Department Access */
                {
                   
                    $query->whereHas('employees', function ($q) use ($employee_info){
                        $q->whereIn('user_id',$employee_info->branch_users);
                    });
                } 
                elseif($res[0]->access == 5) /* All Access */
                    $query->whereRaw('1=1');
                else
                    $query->whereRaw('1=2');    
            }
            else
                $query->whereRaw('1=2');

       }

        return $query;
    }

    /**
     * This is a public function which is used for permission checking of self task
     * @param $query query builder reference
     * @return string or boolean or query
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */
    public function scopetaskSelfCheckPermission($query)
    {
        $user = Auth::user();
       
        $query->whereHas('employees', function ($q2) use ($user){
            $q2->where('task_users.user_id',$user->id);
        });
        return $query;
    }


    /**
     * This is a public function which is used for advanced search of index/listing function for task section
     * @param $query query builder reference
     * @param $advance_params array of data
     * @return string or boolean or query
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     */
    
     public function scopetaskadvanceSearch($query,$advance_params,$table,$task_type)
    {
       if(!empty($advance_params) && count($advance_params) > 0)
        { 
            foreach ($advance_params as $key => $value) {
                
                $parm = explode('-',$key);
                if(count($parm) >= 2)
                {
                    $tableColumn = $table.".".$parm[0];

                    if ($parm[1] == 'like')
                    {    
                        if($parm[0] == 'company')
                        {
                            $query->whereHas('companies', function ($q) use ($value){
                                $q->where('contacts.id',"LIKE","%".$value."%");
                            });
                        }
                        else if($parm[0] == 'contact')
                        {
                            $query->whereHas('contacts', function ($q) use ($value){
                                $q->where('contacts.id',"LIKE","%".$value."%");
                            });
                        }
                        else if($parm[0] == 'group_id')
                        {
                            $query->whereHas('group', function ($q) use ($value){
                                $q->where('groups.id',"LIKE","%".$value."%");
                            });
                        }
                        else if($parm[0] == 'flag')
                        {
                            $query->whereHas('task_flags', function ($q) use ($value){
                                $q->where('task_flags.id',"LIKE","%".$value."%");
                            });
                        }
                        else if($parm[0] == 'stage')
                        {
                            $query->whereHas('ticket_stages', function ($q) use ($value){
                                $q->where('ticket_stages.id',"LIKE","%".$value."%");
                            });
                        }
                        else if($parm[0] == 'employee')
                        {
                            $query->whereHas('members', function ($q) use ($value){
                                $q->where('users.id',"LIKE","%".$value."%");
                            });
                        }
                        else if($parm[0] == 'manager')
                        {
                            $query->whereHas('manager', function ($q) use ($value){
                                $q->where('users.id',"LIKE","%".$value."%");
                            });
                        }
                        else if($parm[0] == 'supervisor')
                        {
                            $query->whereHas('supervisor', function ($q) use ($value){
                                $q->where('users.id',"LIKE","%".$value."%");
                            });
                        }
                        else if($parm[0] == 'officer')
                        {
                            if($task_type=='department-task')
                            {
                                $query->whereRaw("tasks.id in (select distinct task_id from task_officers where officer_id like '%".$value."%' and deleted_at is null)");
                            }
                            else if ($task_type=='regular-ticket') {
                                $query->whereRaw("tasks.id in (select distinct parent_id from tasks where type = 'department-task' and id in (select distinct task_id from task_officers where officer_id like '%".$value."%' and deleted_at is null) and deleted_at is null) ");
                            }
                        }
                        else if($parm[0] == 'fiscal_year')
                        {
                            $get_year=explode('-',$value);
                            $fiscalYearStart='20'.$get_year[0].'-04-01';
                            $fiscalYearEnd='20'.$get_year[1].'-03-31';
                            $tickets = DB::table('tasks')->select('id')->where(function($query) use ($fiscalYearStart, $fiscalYearEnd) {
                                $query->whereBetween(DB::raw("STR_TO_DATE(start_period, '%m/%Y')"), [$fiscalYearStart, $fiscalYearEnd])
                                    ->orWhereBetween(DB::raw("STR_TO_DATE(end_period, '%m/%Y')"), [$fiscalYearStart, $fiscalYearEnd])
                                    ->orWhere(function($query) use ($fiscalYearStart, $fiscalYearEnd) {
                                        $query->where(DB::raw("STR_TO_DATE(start_period, '%m/%Y')"), '<=', $fiscalYearStart)
                                                ->where(DB::raw("STR_TO_DATE(end_period, '%m/%Y')"), '>=', $fiscalYearEnd);
                                    });
                            })->groupBy('id')->get()->toArray();

                            if(count($tickets)>0)
                            {
                                $query->whereIn('id',array_column($tickets,'id'));
                            }
                            else
                            {
                                $query->whereRaw('1=2');
                            }
                        }
                        else if($parm[0] == 'service')
                        {
                            $services = array();
                            $services = $this->child_services($value);
                            if (is_array($services) && !empty($services)) {
                                $query->whereHas('services', function ($q) use ($services) {
                                    $q->whereIn('services.id', $services);
                                });
                            }
                        }
                        else
                        {
                            if($parm[0]=='location' && $task_type=='regular-ticket')
                            {
                                $query->whereRaw("tasks.id in (select distinct parent_id from tasks where type = 'department-task' and location like '%".$value."%')");
                            }
                            else
                            $query->where($tableColumn,"LIKE","%".$value."%");
                        }
                       
                    }
                    else if ($parm[1] == 'nlike')
                    {
                        if($parm[0]== 'company')
                        {
                            $query->whereHas('companies', function ($q) use ($value){
                                $q->where('contacts.fname',"NOT LIKE","%".$value."%");
                            });
                        }
                        else if($parm[0]== 'contact')
                        {
                            $query->whereHas('contacts', function ($q) use ($value){
                                $q->where('contacts.fname',"NOT LIKE","%".$value."%");
                            });
                        }
                        else if($parm[0] == 'group_id')
                        {
                            $query->whereHas('group', function ($q) use ($value){
                                $q->where('groups.id', "NOT LIKE","%".$value."%");
                            });
                        }
                        else if($parm[0] == 'flag')
                        {
                            $query->whereHas('task_flags', function ($q) use ($value){
                                $q->where('task_flags.name', "NOT LIKE","%".$value."%");
                            });
                        }
                        else if($parm[0] == 'stage')
                        {
                            $query->whereHas('ticket_stages', function ($q) use ($value){
                                $q->where('ticket_stages.name', "NOT LIKE","%".$value."%");
                            });
                        }
                        else if($parm[0] == 'employee')
                        {
                            $query->whereHas('members', function ($q) use ($value){
                                $q->where('users.name',"NOT LIKE","%".$value."%");
                            });
                        }
                        else if($parm[0]== 'supervisor')
                        {
                            $query->whereHas('supervisor', function ($q) use ($value){
                                $q->where('users.name',"NOT LIKE","%".$value."%");
                            });
                        }
                        else if($parm[0]== 'manager')
                        {
                            $query->whereHas('manager', function ($q) use ($value){
                                $q->where('users.name',"NOT LIKE","%".$value."%");
                            });
                        }
                        else if($parm[0] == 'officer')
                        {
                            if($task_type=='department-task')
                            {
                                $query->whereRaw("tasks.id in (select distinct task_id from task_officers where officer_id not like '%".$value."%' and deleted_at is null)");
                            }
                            elseif ($task_type=='regular-ticket') {
                               $query->whereRaw("tasks.id not in (select distinct parent_id from tasks where type = 'department-task' and id in (select distinct task_id from task_officers where officer_id  like '%".$value."%' and deleted_at is null) and deleted_at is null) ");
                           }
                        }
                        else if($parm[0] == 'fiscal_year')
                        {
                            $get_year=explode('-',$value);
                            $fiscalYearStart='20'.$get_year[0].'-04-01';
                            $fiscalYearEnd='20'.$get_year[1].'-03-31';
                            $tickets = DB::table('tasks')->select('id')->where(function($query) use ($fiscalYearStart, $fiscalYearEnd) {
                                $query->whereBetween(DB::raw("STR_TO_DATE(start_period, '%m/%Y')"), [$fiscalYearStart, $fiscalYearEnd])
                                    ->orWhereBetween(DB::raw("STR_TO_DATE(end_period, '%m/%Y')"), [$fiscalYearStart, $fiscalYearEnd])
                                    ->orWhere(function($query) use ($fiscalYearStart, $fiscalYearEnd) {
                                        $query->where(DB::raw("STR_TO_DATE(start_period, '%m/%Y')"), '<=', $fiscalYearStart)
                                                ->where(DB::raw("STR_TO_DATE(end_period, '%m/%Y')"), '>=', $fiscalYearEnd);
                                    });
                            })->groupBy('id')->get()->toArray();

                            if(count($tickets)>0)
                            {
                                $query->whereNotIn('id',array_column($tickets,'id'));
                            }
                            else
                            {
                                $query->whereRaw('1=2');
                            }
                        }
                        else if ($parm[0] == 'service') 
                        {
                            $services = array();
                            $services = $this->child_services($value);
                            if (is_array($services) && !empty($services)) {
                                $query->whereDoesntHave('services', function ($q) use ($services) {
                                    $q->whereIn('services.id', $services);
                                });
                            }
                        }
                        else
                        {
                            if($parm[0]=='location' && $task_type=='regular-ticket')
                            {
                                $query->whereRaw("tasks.id not in (select distinct parent_id from tasks where type = 'department-task' and location like '%".$value."%')");
                            }
                            else
                            $query->where($tableColumn,"NOT LIKE","%".$value."%");

                        }
                    }
                    else if($parm[1]=='eq')
                    {
                        if($parm[0] == 'company')
                        {
                            $query->whereHas('companies', function ($q) use ($value){
                                $q->where('contacts.id',$value);
                            });
                        }
                        else if($parm[0] == 'contact')
                        {
                            $query->whereHas('contacts', function ($q) use ($value){
                                $q->where('contacts.id',$value);
                            });
                        }
                        else if($parm[0] == 'group_id')
                        {
                            $query->whereHas('group', function ($q) use ($value){
                                $q->where('groups.id', $value);
                            });
                        }
                        else if($parm[0] == 'flag')
                        {
                            $query->whereHas('task_flags', function ($q) use ($value){
                                $q->where('task_flags.id', $value);
                            });
                        }
                        else if($parm[0] == 'stage')
                        {
                            $query->whereHas('ticket_stages', function ($q) use ($value){
                                $q->where('ticket_stages.id', $value);
                            });
                        }
                        else if($parm[0] == 'employee')
                        {
                            $query->whereHas('members', function ($q) use ($value){
                                $q->where('users.id',$value);
                            });
                        }
                        else if($parm[0] == 'manager')
                        {
                            $query->whereHas('manager', function ($q) use ($value){
                                $q->where('users.id',$value);
                            });
                        }
                        else if($parm[0] == 'supervisor')
                        {
                            $query->whereHas('supervisor', function ($q) use ($value){
                                $q->where('users.id',$value);
                            });
                        }
                        else if($parm[0] == 'officer')
                        {
                            if($task_type=='department-task')
                            {
                                $query->whereRaw("tasks.id in (select distinct task_id from task_officers where officer_id =".$value." and deleted_at is null)");
                            }
                            elseif ($task_type=='regular-ticket') {
                                $query->whereRaw("tasks.id in (select distinct parent_id from tasks where type = 'department-task' and id in (select distinct task_id from task_officers where officer_id =".$value." and deleted_at is null) and deleted_at is null) ");
                            }
                        }
                        else if($parm[0] == 'fiscal_year')
                        {
                            $get_year=explode('-',$value);
                            $fiscalYearStart='20'.$get_year[0].'-04-01';
                            $fiscalYearEnd='20'.$get_year[1].'-03-31';
                            $tickets = DB::table('tasks')->select('id')->where(function($query) use ($fiscalYearStart, $fiscalYearEnd) {
                                $query->whereBetween(DB::raw("STR_TO_DATE(start_period, '%m/%Y')"), [$fiscalYearStart, $fiscalYearEnd])
                                    ->orWhereBetween(DB::raw("STR_TO_DATE(end_period, '%m/%Y')"), [$fiscalYearStart, $fiscalYearEnd])
                                    ->orWhere(function($query) use ($fiscalYearStart, $fiscalYearEnd) {
                                        $query->where(DB::raw("STR_TO_DATE(start_period, '%m/%Y')"), '<=', $fiscalYearStart)
                                                ->where(DB::raw("STR_TO_DATE(end_period, '%m/%Y')"), '>=', $fiscalYearEnd);
                                    });
                            })->groupBy('id')->get()->toArray();

                            if(count($tickets)>0)
                            {
                                $query->whereIn('id',array_column($tickets,'id'));
                            }
                            else
                            {
                                $query->whereRaw('1=2');
                            }
                        }
                        else if($parm[0] == 'service')
                        {
                            $services = array();
                            $services = $this->child_services($value, $services);
                            $query->whereHas('services', function ($q) use ($services){
                                $q->whereIn('services.id',$services);
                            });
                        }
                        else{
                            if($parm[0]=='location' && $task_type=='regular-ticket')
                            {
                                $query->whereRaw("tasks.id in (select distinct parent_id from tasks where type = 'department-task' and location = '".$value."')");
                            }
                            else
                            $query->where($tableColumn,$value);
                        }   
                    }
                    else if ($parm[1] == 'neq') 
                    {
                        if($parm[0] == 'company')
                        {
                            $query->whereHas('companies', function ($q) use ($value){
                                $q->where('contacts.id','<>',$value);
                            });
                        }
                        else if($parm[0] == 'contact')
                        {
                            $query->whereHas('contacts', function ($q) use ($value){
                                $q->where('contacts.id','<>',$value);
                            });
                        }
                        else if($parm[0] == 'flag')
                        {
                            $query->whereHas('task_flags', function ($q) use ($value){
                                $q->where('task_flags.id', '<>',$value);
                            });
                        }
                        else if($parm[0] == 'stage')
                        {
                            $query->whereHas('ticket_stages', function ($q) use ($value){
                                $q->where('ticket_stages.id', '<>',$value);
                            });
                        }
                        else if($parm[0] == 'employee')
                        {
                            $query->whereHas('members', function ($q) use ($value){
                                $q->where('users.id','<>',$value);
                            });
                        }
                        else if($parm[0] == 'officer')
                        {
                            if($task_type=='department-task')
                            {
                                $query->whereRaw("tasks.id in (select distinct task_id from task_officers where officer_id !=".$value." and deleted_at is null)");
                            }
                            elseif ($task_type=='regular-ticket') {
                               $query->whereRaw("tasks.id not  in (select distinct parent_id from tasks where type = 'department-task' and id in (select distinct task_id from task_officers where officer_id =".$value." and deleted_at is null) and deleted_at is null) ");
                           }
                        }
                        else if($parm[0] == 'fiscal_year')
                        {
                            $get_year=explode('-',$value);
                            $fiscalYearStart='20'.$get_year[0].'-04-01';
                            $fiscalYearEnd='20'.$get_year[1].'-03-31';
                            $tickets = DB::table('tasks')->select('id')->where(function($query) use ($fiscalYearStart, $fiscalYearEnd) {
                                $query->whereBetween(DB::raw("STR_TO_DATE(start_period, '%m/%Y')"), [$fiscalYearStart, $fiscalYearEnd])
                                    ->orWhereBetween(DB::raw("STR_TO_DATE(end_period, '%m/%Y')"), [$fiscalYearStart, $fiscalYearEnd])
                                    ->orWhere(function($query) use ($fiscalYearStart, $fiscalYearEnd) {
                                        $query->where(DB::raw("STR_TO_DATE(start_period, '%m/%Y')"), '<=', $fiscalYearStart)
                                                ->where(DB::raw("STR_TO_DATE(end_period, '%m/%Y')"), '>=', $fiscalYearEnd);
                                    });
                            })->groupBy('id')->get()->toArray();

                            if(count($tickets)>0)
                            {
                                $query->whereNotIn('id',array_column($tickets,'id'));
                            }
                            else
                            {
                                $query->whereRaw('1=2');
                            }
                        }
                        else if($parm[0] == 'manager')
                        {
                            $query->whereHas('manager', function ($q) use ($value){
                                $q->where('users.id','<>',$value);
                            });
                        }
                        else if($parm[0] == 'supervisor')
                        {
                            $query->whereHas('supervisor', function ($q) use ($value){
                                $q->where('users.id','<>',$value);
                            });
                        }
                        else if($parm[0] == 'service')
                        {
                            $query->whereHas('services', function ($q) use ($value){
                                $q->where('services.id','<>',$value);
                            });
                        }
                        else{
                            if($parm[0]=='location' && $task_type=='regular-ticket')
                            {
                                $query->whereRaw("tasks.id not in (select distinct parent_id from tasks where type = 'department-task' and location  ='".$value."')");
                            }
                            else
                            $query->where($tableColumn,"<>",$value);
                        }
                    }
                    else if ($parm[1] == 'in') 
                    {
                        if ($parm[0] == 'company') 
                        {
                            $query->whereHas('companies', function ($q) use ($value) {
                                $q->where('contacts.id', $value); 
                            });  
                        }
                        else if ($parm[0] == 'contact') 
                        {
                            $query->whereHas('contacts', function ($q) use ($value) {
                                $q->where('contacts.id', $value); 
                            });
                        }
                         else if($parm[0] == 'group_id')
                         {
                             $query->whereHas('group', function ($q) use ($value) {
                                 $q->where('groups.id', $value); 
                             });
                         }
                        else if($parm[0] == 'flag')
                        {
                            $query->whereHas('task_flags', function ($q) use ($value){
                                $q->where('task_flags.id',$value);
                            });
                        }
                        else if($parm[0] == 'stage')
                        {
                            $query->whereHas('ticket_stages', function ($q) use ($value){
                                $q->where('ticket_stages.id',$value);
                            });
                        }
                        else if ($parm[0] == 'employee') 
                        {
                            $query->whereHas('members', function ($q) use ($value) {
                                $q->where('users.id', $value); 
                            });
                        }
                        else if ($parm[0] == 'supervisor') 
                        {
                            $query->whereHas('supervisor', function ($q) use ($value) {
                                $q->where('users.id', $value); 
                            });
                        }
                        else if ($parm[0] == 'manager') 
                        {
                            $query->whereHas('manager', function ($q) use ($value) {
                                $q->where('users.id', $value); 
                            }); 
                        }
                        else if($parm[0] == 'officer')
                        {
                            if($task_type=='department-task')
                            {
                                $query->whereRaw("tasks.id in (select distinct task_id from task_officers where officer_id in (".$value.") and deleted_at is null)");
                            }
                            elseif ($task_type=='regular-ticket'){
                            $query->whereRaw("tasks.id in (select distinct parent_id from tasks where type = 'department-task' and id in (select distinct task_id from task_officers where officer_id in (".$value.") and deleted_at is null) and deleted_at is null) ");
                            }
                        }
                        else if($parm[0] == 'fiscal_year')
                        {
                            $get_year=explode('-',$value);
                            $fiscalYearStart='20'.$get_year[0].'-04-01';
                            $fiscalYearEnd='20'.$get_year[1].'-03-31';
                            $tickets = DB::table('tasks')->select('id')->where(function($query) use ($fiscalYearStart, $fiscalYearEnd) {
                                $query->whereBetween(DB::raw("STR_TO_DATE(start_period, '%m/%Y')"), [$fiscalYearStart, $fiscalYearEnd])
                                    ->orWhereBetween(DB::raw("STR_TO_DATE(end_period, '%m/%Y')"), [$fiscalYearStart, $fiscalYearEnd])
                                    ->orWhere(function($query) use ($fiscalYearStart, $fiscalYearEnd) {
                                        $query->where(DB::raw("STR_TO_DATE(start_period, '%m/%Y')"), '<=', $fiscalYearStart)
                                                ->where(DB::raw("STR_TO_DATE(end_period, '%m/%Y')"), '>=', $fiscalYearEnd);
                                    });
                            })->groupBy('id')->get()->toArray();

                            if(count($tickets)>0)
                            {
                                $query->whereIn('id',array_column($tickets,'id'));
                            }
                            else
                            {
                                $query->whereRaw('1=2');
                            }
                        }
                        else if($parm[0] == 'service')
                        {
                            $services = array();
                            $services = $this->child_services($value);
                            if (is_array($services) && !empty($services)) {
                                $query->whereHas('services', function ($q) use ($services) {
                                    $q->whereIn('services.id', $services);
                                });
                            }
                        }
                        else
                        {
                            if($parm[0]=='location' && $task_type=='regular-ticket')
                            {
                                $query->whereRaw("tasks.id in (select distinct parent_id from tasks where type = 'department-task' and location  =".$value.")");
                            }
                            else
                            $query->whereIn($tableColumn,explode(',',$value));

                        }
                    }
                    else if ($parm[1] == 'nin') 
                    {
                        if($parm[0] == 'company')
                        {
                            $query->whereDoesntHave('companies', function ($q) use ($value){
                                $q->where('contacts.id',$value);
                            });
                        }
                        else if ($parm[0] == 'contact') 
                        {
                            $query->whereDoesntHave('contacts', function ($q) use ($value) {
                                $q->where('contacts.id', $value); 
                            });     
                        }
                        else if($parm[0] == 'group_id')
                        {
                            $query->whereDoesntHave('group', function ($q) use ($value) {
                                $q->where('groups.id', $value); 
                            }); 
                        }
                        else if($parm[0] == 'flag')
                        {
                            $query->whereDoesntHave('task_flags', function ($q) use ($value){
                                $q->where('task_flags.id',$value);
                            });
                        }
                        else if($parm[0] == 'stage')
                        {
                            $query->whereDoesntHave('ticket_stages', function ($q) use ($value){
                                $q->where('ticket_stages.id',$value);
                            });
                        }
                        else if ($parm[0] == 'employee') 
                        {
                            $query->whereDoesntHave('members', function ($q) use ($value) {
                                $q->where('users.id', $value); 
                            });   
                        }
                        else if ($parm[0] == 'supervisor') 
                        {
                            $query->whereDoesntHave('supervisor', function ($q) use ($value) {
                                $q->where('users.id', $value); 
                            });  
                        }
                        else if ($parm[0] == 'manager') 
                        {
                            $query->whereDoesntHave('manager', function ($q) use ($value) {
                                $q->where('users.id', $value); 
                            }); 
                        }
                        else if($parm[0] == 'officer')
                        {
                            if($task_type=='department-task')
                            {
                                $query->whereRaw("tasks.id in (select distinct task_id from task_officers where officer_id not in (".$value.") and deleted_at is null)");
                            }
                            else if ($task_type=='regular-ticket') 
                            {
                            $query->whereRaw("tasks.id not in (select distinct parent_id from tasks where type = 'department-task' and id in (select distinct task_id from task_officers where officer_id  in (".$value.") and deleted_at is null) and deleted_at is null) ");
                            }   
                        }
                        else if($parm[0] == 'fiscal_year')
                        {
                            $get_year=explode('-',$value);
                            $fiscalYearStart='20'.$get_year[0].'-04-01';
                            $fiscalYearEnd='20'.$get_year[1].'-03-31';
                            $tickets = DB::table('tasks')->select('id')->where('type',$task_type)->where(function($query) use ($fiscalYearStart, $fiscalYearEnd) {
                                $query->whereBetween(DB::raw("STR_TO_DATE(start_period, '%m/%Y')"), [$fiscalYearStart, $fiscalYearEnd])
                                    ->orWhereBetween(DB::raw("STR_TO_DATE(end_period, '%m/%Y')"), [$fiscalYearStart, $fiscalYearEnd])
                                    ->orWhere(function($query) use ($fiscalYearStart, $fiscalYearEnd) {
                                        $query->where(DB::raw("STR_TO_DATE(start_period, '%m/%Y')"), '<=', $fiscalYearStart)
                                                ->where(DB::raw("STR_TO_DATE(end_period, '%m/%Y')"), '>=', $fiscalYearEnd);
                                    });
                            })->groupBy('id')->get()->toArray();

                            if(count($tickets)>0)
                            {
                                $query->whereNotIn('id',array_column($tickets,'id'));
                            }
                            else
                            {
                                $query->whereRaw('1=2');
                            }
                        }
                        else if ($parm[0] == 'service') 
                        {
                            $services = array();
                            $services = $this->child_services($value);
                            if (is_array($services) && !empty($services)) {
                                $query->whereDoesntHave('services', function ($q) use ($services) {
                                    $q->whereIn('services.id', $services);
                                });
                            }
                        }
                        else
                        {
                            if($parm[0]=='location' && $task_type=='regular-ticket')
                            {
                                $query->whereRaw("tasks.id not in (select distinct parent_id from tasks where type = 'department-task' and location  =".$value.")");
                            }
                            else
                            $query->whereNotIn($tableColumn,explode(',',$value));

                        }
                    }
                    else if ($parm[1] == 'between')
                    {
                        if(is_array($value) && count($value) == 2)
                            $query->whereBetween($tableColumn,[$value[0],$value[1]]);
                        elseif (!empty($value) && count(explode(',',$value))) {
                            if($parm[0] == 'created_at' || $parm[0] == 'updated_at' || $parm[0] == 'date' || $parm[0] == 'start_date' || $parm[0] == 'received_date' || $parm[0] == 'due_date' || $parm[0] == 'ecd' || $parm[0] == 'completed_date')
                            {
                                $values = explode(',',$value);
                                $query->whereRaw('DATE('.$tableColumn.') BETWEEN ? and ?',[$values[0],$values[1]]);
                            }
                        }
                        else    
                            $query->whereRaw('1=1');    
                    } 
                    else if (isset($parm[1]) && $parm[1] == 'file_attached') 
                    {
                        if ($parm[0] == 'yes') 
                        {
                            $query->whereNotNull($tableColumn); 
                        } 
                        else if ($parm[0] == 'no') 
                        {
                            $query->whereNull($tableColumn);
                        } 
                        else 
                        {
                            $query->whereRaw('1=1');
                        }
                    }            
                    else
                    {
                        $query->whereRaw('1=1');
                    }
                }
                
            }

            return $query;
       }
       else
        return $query;
    }
    
    protected static function boot() 
    {
        parent::boot();
        
        self::creating(function($model){
           
           
        });

        self::created(function($model){
            if(isset($model->type) && isset($model->id))
            {
                $fiscalyear=DB::table('fiscal_years')->where('status',1)->get();

                if($model->type  == 'department-task')
                    $model->name =  'DT/'.$fiscalyear[0]->name."/".date('m')."/".date('dmy')."/".$model->id ;
                elseif($model->type  == 'regular-ticket')
                    $model->name = 'RT/'.$fiscalyear[0]->name."/".date('m')."/".date('dmy')."/".$model->id ;
                elseif($model->type  == 'meeting')
                    $model->name = 'MEET/'.$fiscalyear[0]->name."/".date('m')."/".date('dmy')."/".$model->id ;
                elseif($model->type  == 'todo')
                    $model->name = 'TODO/'.$fiscalyear[0]->name."/".date('m')."/".date('dmy')."/".$model->id ;
                elseif($model->type  == 'call')
                    $model->name = 'CALL/'.$fiscalyear[0]->name."/".date('m')."/".date('dmy')."/".$model->id ;
                elseif($model->type  == 'crd')
                    $model->name = 'CRD/'.$fiscalyear[0]->name."/".date('m')."/".date('dmy')."/".$model->id ;
                elseif($model->type  == 'memorized-ticket')
                    $model->name = 'MT/'.$fiscalyear[0]->name."/".date('m')."/".date('dmy')."/".$model->id ;
                elseif($model->type  == 'ist')
                    $model->name = 'IST/'.$fiscalyear[0]->name."/".date('m')."/".date('dmy')."/".$model->id ;
                elseif($model->type  == 'help-ticket')
                    $model->name = 'HT/'.$fiscalyear[0]->name."/".date('m')."/".date('dmy')."/".$model->id ;

                $model->save();
            }
        });

        self::updating(function($model){
            
        });

        self::updated(function($model){
            
        });

        self::deleting(function($model){
           
        });

        self::deleted(function($model){
            $model->services()->detach();
            $model->companies()->detach();
            $model->contacts()->detach();
            $model->employees()->detach();
            $model->change_logs()->delete();
            $model->history()->delete();
            $model->invities()->delete();
            $model->communications()->delete();
            $model->notes()->delete();
            $model->check_lists()->delete();
            $model->files()->delete();
            $model->contact_users()->detach();
        });

       
    }
}
