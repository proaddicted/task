<?php

namespace Modules\TaskManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use App\Models\File;

class InformationItem extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;

    protected $fillable = ['name','description','status','is_multiple','is_required','type','value'];
    
    protected $searchableColumns = ['name','description','value'];

    protected $appends = ['values','type_name'];

    public function setValueAttribute($value)
    {
        $this->attributes['value'] = json_encode(array_filter($value));
    }
    public function getValuesAttribute()
    {
        return $this->attributes['values'] = (Array)json_decode($this->attributes['value'],TRUE);
    }
    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }
    public function setIsMultipleAttribute($value)
    {
        $this->attributes['is_multiple'] = (int) $value;
    }
    public function setIsRequiredAttribute($value)
    {
        $this->attributes['is_required'] = (int) $value;
    }
    // public function task_files()
    // {
    //     return $this->hasMany(File::class,"main_id","id")->where('identifier','task')->whereNull('deleted_at');
    // }
    public function getTypeNameAttribute()
    {
        if(isset($this->attributes['type']))
        {
            $information_field_types=array_column($this->information_field_types,'name', 'id'); 
        
            return $this->attributes['type_name'] = $information_field_types[$this->attributes['type']];
        }
               
    }
}
