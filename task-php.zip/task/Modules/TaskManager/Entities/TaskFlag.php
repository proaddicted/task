<?php

namespace Modules\TaskManager\Entities;

use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Models\User;

class TaskFlag extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;

    protected $fillable = ['name','amount','status'];

    protected $searchableColumns = ['name','amount'];

    public function employees()
    {
        return $this->belongsToMany(User::class,"task_flag_employees","task_flag_id","user_id")->wherePivot('deleted_at',NULL)->wherePivotIn('type',['employee'])->withTimestamps()->withPivot('main_id','type','identifier');
    }
    
    protected $appends = [];

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }
}
