<?php

namespace Modules\TaskManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Modules\TaskManager\Entities\Task;
class CallLog extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;

    protected $fillable = ['main_id','identifier','call_type','call_date','call_time','caller_number','called_number','call_status','menu','agent_list','agent_number','call_transfer_status','caller_duration','recording_url','call_uuid','bridge_number','bridge_extension','voicemail_url','menu_extension'];
    
    protected $searchableColumns = [];

    protected $appends = ['call_move_status'];
    public function taskcall()
    {
        return $this->hasOne(Task::class, 'call_log_id','id');

    }
    // protected $fillable = [];
    public function getCallMoveStatusAttribute()
    {
        if($this->attributes['is_move']>0)
        return $this->attributes['call_move_status'] ='Moved' ;
        else
        return $this->attributes['call_move_status'] =  'Movement Pending';
    }
   
}
