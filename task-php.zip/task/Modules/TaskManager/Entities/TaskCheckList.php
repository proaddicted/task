<?php

namespace Modules\TaskManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Modules\ResourceManager\Entities\Employee;
use App\Models\User;

class TaskCheckList extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;

    protected $fillable = ['user_id','description','checked_by','checked_on','rejected_by','rejected_on','status','is_restrict'];

    protected $searchableColumns = ['description'];

    public function employee()
    {
        return $this->belongsTo(User::class,'user_id');

    }
    public function checked_employee()
    {
        return $this->belongsTo(User::class,'checked_by');

    }
    public function rejected_employee()
    {
        return $this->belongsTo(User::class,'rejected_by');

    }
    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }

    public function setIsRestrictAttribute($value)
    {
        $this->attributes['is_restrict'] = (int) $value;
    }

    
   
}
