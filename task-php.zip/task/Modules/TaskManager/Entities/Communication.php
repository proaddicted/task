<?php

namespace Modules\TaskManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use App\Models\File;
use App\Models\User;
use Modules\TaskManager\Entities\CommunicationRecipient;
use Modules\TaskManager\Entities\CommunicationSchedule;
use Carbon\Carbon;

class Communication extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;
    protected $fillable = ['date','from_id','main_id','identifier','subject','comment','parent_id','type','is_schedule','recursive_type','recursive_end_date','recursive_days','recursive_communication_id','recursive_last_created'];
    
    protected $searchableColumns = ['date','identifier','comment'];

    protected $appends = ['time_ago'];

    public function from()
    {
        return $this->belongsTo(User::class,'from_id');

    }
    public function parent()
    {
        return $this->belongsTo(Communication::class,'parent_id');

    }
    public function tasks()
    {
        return $this->belongsTo(Task::class,'main_id');
    }
    public function replies()
    {
        return $this->hasMany(Communication::class,"parent_id","id")->whereNull('deleted_at')->orderBy('date','desc');
    }
    public function files()
    {
        return $this->hasMany(File::class,"main_id","id")->where('identifier','communication')->whereNull('deleted_at');
    }
    public function schedules()
    {
        return $this->hasMany(CommunicationSchedule::class,"communication_id","id")->whereNull('deleted_at');
    }
    public function recipients()
    {
        return $this->belongsToMany(User::class,"communication_recipients","communication_id","user_id")->wherePivot('deleted_at',NULL)->withTimestamps()->withPivot('type');
    }

    public function reads()
    {
        return $this->belongsToMany(User::class,"communication_reads","communication_id","user_id")->wherePivot('deleted_at',NULL)->withTimestamps()->withPivot('is_read');
    }
    public function getTimeAgoAttribute()
    {
        $now = Carbon::now();
        $date = new Carbon($this->attributes['date']);
        
        if($now->format('Y-m-d') == $date->format('Y-m-d'))
            return $this->attributes['time_ago'] = $date->diffForHumans($now);
        else
            return $this->attributes['time_ago'] = $date->format("d/m/Y h:i A");
    }

    public function scopenotArchivedTask($query,$user_id)
    {
        if($user_id > 0)
        {
            $query->whereRaw('id not in (select communication_id from communication_archives where user_id = ? and deleted_at is null group by communication_id)',[$user_id]);
        }
    }
    public function scopearchivedTask($query,$user_id)
    {
        if($user_id > 0)
        {
            $query->whereRaw('id in (select communication_id from communication_archives where user_id = ? and deleted_at is null group by communication_id)',[$user_id]);
        }
    }
    protected static function boot() 
    {
        parent::boot();
        static::deleting(function(Communication $communication) {

            $communication->recipients()->delete();
            $communication->files()->delete();
        });

    }
}
