<?php

namespace Modules\TaskManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Modules\TaskManager\Entities\InformationItem;
use Modules\TaskManager\Entities\InformationSubGroup;

class InformationGroup extends Model
{
   
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;

    protected $fillable = ['name','description','status','type'];

    protected $searchableColumns = ['name','description'];

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }

    public function information_items()
    {
	
        return $this->belongsToMany(InformationItem::class,"information_group_items","information_group_id","information_item_id")->wherePivot('deleted_at',NULL)->wherePivot('identifier','information_item')->withTimestamps()->withPivot('is_multiple','is_required','order_no','description','name','value','type','identifier','information_sub_group_id');
    }
    public function information_sub_groups()
    {
	
        return $this->belongsToMany(InformationSubGroup::class,"information_group_items","information_group_id","information_sub_group_id")->wherePivot('deleted_at',NULL)->wherePivot('identifier','information_sub_group')->withTimestamps()->withPivot('is_multiple','is_required','order_no','description','name','value','type','identifier','information_item_id');
    }
    public function information_sub_items()
    {
	
        return $this->belongsToMany(InformationItem::class,"information_group_items","information_group_id","information_item_id")->wherePivot('deleted_at',NULL)->wherePivot('identifier','information_sub_group_item')->withTimestamps()->withPivot('is_multiple','is_required','order_no','description','name','value','type','identifier','information_sub_group_id');
    }

    protected static function boot() 
    {
        parent::boot();
        static::deleting(function(InformationGroup $information_group) {

            $information_group->information_sub_groups()->detach();
            $information_group->information_items()->detach();
            $information_group->information_sub_items()->detach();


        });

    }
    
}
