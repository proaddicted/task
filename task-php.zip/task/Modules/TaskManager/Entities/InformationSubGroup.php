<?php

namespace Modules\TaskManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Modules\TaskManager\Entities\InformationItem;

class InformationSubGroup extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;

    protected $fillable = ['name','description','status','is_multiple','is_required'];

    protected $searchableColumns = ['name','description'];

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }
    public function setIsMultipleAttribute($value)
    {
        $this->attributes['is_multiple'] = (int) $value;
    }
    public function setIsRequiredAttribute($value)
    {
        $this->attributes['is_required'] = (int) $value;
    }
    public function information_items()
    {
	
        return $this->belongsToMany(InformationItem::class,"information_sub_group_items","information_sub_group_id","information_item_id")->wherePivot('deleted_at',NULL)->withTimestamps()->withPivot('is_multiple','is_required','order_no','description','name');
    }
    public function information_group_items()
    {
	
        return $this->belongsToMany(InformationItem::class,"information_group_items","information_sub_group_id","information_item_id")->wherePivot('deleted_at',NULL)->wherePivot('identifier','information_sub_group_item')->withTimestamps()->withPivot('is_multiple','is_required','order_no','description','name','value','type','identifier','information_group_id');
    }

    public function information_task_items()
    {
	
        return $this->belongsToMany(InformationItem::class,"task_information_items","information_sub_group_id","information_item_id")->wherePivot('deleted_at',NULL)->wherePivot('identifier','information_sub_group_item')->withTimestamps()->withPivot('is_multiple','is_required','order_no','description','name','value','type','identifier','information_group_id','task_id','id');
    }

    protected static function boot() 
    {
        parent::boot();
        static::deleting(function(InformationSubGroup $information_sub_group) {

            $information_sub_group->information_items()->detach();

        });

    }

}
