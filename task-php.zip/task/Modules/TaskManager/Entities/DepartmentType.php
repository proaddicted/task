<?php

namespace Modules\TaskManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;

class DepartmentType extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;

    protected $fillable = ['name','code','order_no','status','parent_id','description','officer_name','range_name','commissionerate_name','division_name'];    
    
    protected $searchableColumns = ['name','code','parent_id'];

    protected $appends = ['value'];

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }
    public function setParentIdAttribute($value)
    {
        $this->attributes['parent_id'] = (int) $value > 0 ? (int) $value : 0 ;
    }
    public function children()
    {
        return $this->hasMany(DepartmentType::class, 'parent_id')->with('children');
    }
    public function parent()
    {
        return $this->belongsTo(DepartmentType::class,'parent_id')->with('parent');
    }
    public function getValueAttribute()
    {
        return $this->attributes['value'] = $this->attributes['id'];
    }

}
