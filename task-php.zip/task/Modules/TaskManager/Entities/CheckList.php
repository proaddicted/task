<?php

namespace Modules\TaskManager\Entities;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Modules\TaskManager\Entities\CheckListItem;

class CheckList extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;

    protected $fillable = ['name','description','status','identifier'];
    
    protected $searchableColumns = ['name','description'];

    protected $appends = [];

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }


    public function items()
    {
         return $this->hasMany(CheckListItem::class,"check_list_id")->orderBy('order_no','asc');
    }

    protected static function boot() 
    {
        parent::boot();
        static::deleting(function(CheckList $checklist) {

            $checklist->items()->delete();

        });

    }
}
