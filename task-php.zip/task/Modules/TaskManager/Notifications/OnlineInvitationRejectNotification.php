<?php

namespace Modules\TaskManager\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Support\Facades\DB;
use App\Mail\SendGrid;

class OnlineInvitationRejectNotification extends Notification
{
    use Queueable;
    public $data;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($data)
    {
       
        $this->data = $data;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param mixed $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['database','mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param mixed $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
     

        $dd = DB::table('notifications')->latest()->first();
        $this->data['variables'] = array();

        $this->data['variables']['[NAME]'] = $this->data['name'];
      
        $this->data['variables']['[REMARKS]'] = $this->data['remarks'];
        $this->data['variables']['[EMPLOYEE_EMAIL]'] = $this->data['employee_email'];

        $headerData = ['unique_args' => ['notification_id' => $dd->id]];
        $this->data['header'] = $headerData;
        $this->data['notification_id'] = $dd->id;

        return (new SendGrid($this->data))->to($notifiable->routes['mail'])->cc('anupam@rnjcs.co.in');
    }

    /**
     * Get the array representation of the notification.
     *
     * @param mixed $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
}
