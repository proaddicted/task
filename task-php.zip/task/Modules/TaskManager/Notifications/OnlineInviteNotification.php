<?php

namespace Modules\TaskManager\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Support\Facades\DB;
use App\Mail\SendGrid;

class OnlineInviteNotification extends Notification
{
    use Queueable;
    public $data;
    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($data)
    {
        $this->data = $data;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param mixed $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['database','mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param mixed $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        $dd = DB::table('notifications')->latest()->first();
        $this->data['variables'] = array();

        $this->data['variables']['[NAME]'] = isset($notifiable->name) ? $notifiable->name : $notifiable->full_name ;
        $this->data['variables']['[LINK]'] = $this->data['meeting_invite_url'];
        $this->data['variables']['[START_DATE]'] = $this->data['start_date'];
        $this->data['variables']['[HOST]'] = $this->data['host'];
        $this->data['variables']['[AGENDA]'] = $this->data['agenda'];

        $headerData = ['unique_args' => ['notification_id' => $dd->id]];
        $this->data['header'] = $headerData;
        $this->data['notification_id'] = $dd->id;

        return (new SendGrid($this->data))->to($notifiable->email);
    }

    /**
     * Get the array representation of the notification.
     *
     * @param mixed $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            'to'=>$notifiable->email
        ];
    }
}
