<?php

namespace Modules\TaskManager\Console;

use Illuminate\Console\Command;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputArgument;
use App\Models\User;
use App\Models\NotificationTemplate;
use App\Notifications\SendSmsNotification;
// use App\Notifications\SendCronNotification;
use App\Notifications\SendNotification;
use App\Traits\CommonTrait;
use Illuminate\Support\Facades\Notification;
use App\Models\NotificationLog;
use Illuminate\Support\Facades\Mail;
use App\Mail\MailChimp;
use Illuminate\Support\Facades\Auth;
use Modules\LeaveManager\Entities\LeaveApplication;
use Modules\AttendanceManager\Entities\DailyAttendance;
use Modules\AttendanceManager\Entities\Holiday;
use Modules\ResourceManager\Entities\EmployeeTiming;
use Modules\ResourceManager\Entities\Employee;
use Modules\TaskManager\Entities\Task;
use Illuminate\Support\Facades\DB;

class PendingTicketEmployee extends Command
{
    use CommonTrait;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    public $notification_batch_id=0,$template_body='';

   
    protected $signature = 'pending:task';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {

        if($template = DB::table('notification_templates')->where('name','pending-ticket-report-employees')->where('status',1)->first())
        {
            $not=DB::table('notifications')->max('batch_id');
            $this->notification_batch_id=$not+1;


            // $employees=Users::where('status',1)->get()->toArray();
            $employees=DB::table('employees')->where('status',1)->where('user_id','>',0)->get();
            if(count($employees) > 0)
            {
                foreach($employees as $employee)
                    {
    
                        $holiday = Holiday::where('date',date('Y-m-d'))->where('master_id',$employee->master_id)->where('status',1)->count();
    
                            
                        $leave = LeaveApplication::where('employee_id',$employee->id)->where('status',1)->whereRaw('? between start_date and end_date',[date('Y-m-d')])->count();
    
    
                        $employee_timing=EmployeeTiming::where('emp_id',$employee->id)->where('day','=',date('N'))->where('is_holiday',1)->count();
    
                        $weekmonth = (date('W',strtotime(date('Y-m-d')))-date('W',strtotime(date('Y-m-01'))))+1;
    
                        $alternative=EmployeeTiming::where('emp_id',$employee->id)->where('type',2)->where('day','=',date('N'))->get();
                        if(count($alternative)>0)
                        {
                            $alter=DailyAttendance::where('date',date('Y-m-d', strtotime('-7 days') ))->where('status',2)->where('user_id',$employee->id)->get();
                        }
    
    
                        $custom=EmployeeTiming::where('emp_id',$employee->id)->where('type',3)->where('day',date('N'))->whereRaw('week REGEXP  "&quot;'.$weekmonth.'&quot;"')->get();
    
                            
                        if($holiday==0 && $leave==0 && $employee_timing==0  && count($custom)==0 &&(count($alternative)==0 || (count($alternative)>0 && count($alter)==1)))
                        { 
                            $user=User::find($employee->user_id);
                            if($user)
                            {
                                $tasks=DB::table('tasks')->where('master_id',$employee->master_id)->where('status',0)->whereRaw('tasks.id in (select distinct task_id from task_users where user_id='.$user->id.' and deleted_at is null)')->orderBy('priority','desc')->orderBy(DB::raw('ABS(DATEDIFF(due_date, NOW()))'))->get();
                                
                                $task_str="";
                                if(count($tasks)>0)
                                {
                                    // $help=ucwords(str_replace('-',' ','meeting'));
                                    // dd($help);
                                    $task_str .='<div class="tax-table">';
                                    $task_str .="<table class='table-report'>";
                                    $task_str .='<thead>';
                                    $task_str .="<tr>";
                                    $task_str .="<th class='special'>Task Type</th>";
                                    $task_str .="<th class='special'>Company</th>";
                                    $task_str .="<th class='special'>Contact</th>";

                                    $task_str .="<th class='special'>Service</th>";
                                    
                                    $task_str .="<th class='special'>Due Date</th>";
                                    $task_str .="<th class='special'>Priority</th>";
                                    $task_str .="</tr>";
                                    $task_str .="</thead>";
                                    $task_str .='<tbody>';
                                    foreach($tasks as $task) 
                                        {
                                            $task_str .="<tr>";
                                            
                                            $task_str .="<td>".ucwords(str_replace('-',' ',$task->type))."</td>";//task type 

                                            //for task companies
                                            $companies=DB::table('contacts')->where('master_id',$employee->master_id)->where('type','company')->whereRaw('contacts.id in (select distinct company_id from task_companies where task_id='.$task->id.' and deleted_at is null)')->get();
                                            
                                            $comp=[];
                                            if(count($companies)>0)
                                            {
                                                foreach($companies as $val)
                                                    $comp[]=$val->fname;
                                            }

                                            // dd(count($comp)>0?implode(',', $comp):'d');
                                            $task_str .="<td><a href='".env('HTML_URL')."ticket-view/".$task->id."'>".implode(',', $comp)."</a></td>";

                                            // for task contacts
                                            $contacts=DB::table('contacts')->where('master_id',$employee->master_id)->where('type','individual')->whereRaw('contacts.id in (select distinct contact_id from task_contacts where task_id='.$task->id.' and deleted_at is null)')->get();

                                            $cons=[];
                                            if(count($contacts)>0)
                                            {
                                                foreach($contacts as $val)
                                                    $cons[]=$val->fname;
                                            }
                                            
                                            $task_str .="<td>".implode(',', $cons)."</td>";

                                            $services=DB::table('services')->where('master_id',$employee->master_id)->whereRaw('services.id in (select distinct service_id from task_services where task_id='.$task->id.' and deleted_at is null)')->orderBy('services.id','ASC')->get();
                                            $serv=[];
                                            if(count($services)>0)
                                            {
                                                foreach($services as $val)
                                                    $serv[]=$val->name;
                                            }

                                            $task_str .="<td>".implode(',', $serv)."</td>";

                                            $due_date=!empty($task->due_date)?date('dS M Y',strtotime($task->due_date)):"";
                                            $task_str .="<td>".$due_date."</td>";//due date
                                            
                                            $priority=array_column($this->ticket_priorities,'name', 'id'); 
                                            $task_str .="<td>".$priority[$task->priority]."</td>"; //priority
                                            $task_str .="</tr>";
                                        }
                                    $task_str .="</tbody>";        
                                    $task_str .="</table>";
                                    $task_str .="</div>";      
                                    $data=array();
                                   
                                    
                                    $notification_data['content']=$task_str;
                                    $notification_data['template'] = $template;
                                    $notification_data['template_subject'] =$template->subject;
                                    $notification_data['start_date']=date('dS F Y');
                                    $notification_data['link'] =env('HTML_URL');
                                    
                                    $recipients[]=array('email'=>$user->email,'name'=>$user->name,'mail_type'=>'to');

                                    // dd($data);
                                    Notification::send($user, new SendNotification($notification_data,'',$recipients,'daily-attendance',$this->notification_batch_id));//old
                                    
                                    $this->sendMailFunc($this->notification_batch_id,$template->email_body); //24/05/24

                                  //  app(\App\Http\Controllers\SendNotificationController::class)->processnotification($template,$data);
                                    // echo "hi";
                                    $this->notification_batch_id=$this->notification_batch_id+1;
                                }
                            }
                        }    
    
                    }
            }

        }

        
    }
    public function sendMailFunc($batch_id,$template_body)
    {
        $notifications=NotificationLog::where('batch_id',$this->notification_batch_id)->where('status',0)->get()->toArray();
        if(count($notifications)>0)
         Mail::send(new MailChimp($notifications,$template_body,0,'daily-attendance',''));
    }
  
}
