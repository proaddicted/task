<?php

namespace Modules\TaskManager\Console;

use Illuminate\Console\Command;


use Modules\TaskManager\Entities\Task;
use Modules\TaskManager\Entities\TaskNote;
use Modules\TaskManager\Entities\TaskCheckList;
use DB;
use App\Models\Service;
use Modules\ContactManager\Entities\Contact;
use Modules\ResourceManager\Entities\Employee;

use Carbon\Carbon;
use Illuminate\Http\Request;

class RecursiveTask extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'recursive:task';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle(Request $request)
    {
        // echo "hii"; exit;
        // DB::enableQueryLog();

        $quaterly_tasks=Task::with('services','employees','contacts')->where('master_id',1)->where('type','memorized-ticket')->where('recursive_type',5)->whereRaw("(DATE_FORMAT(start_date, '%d %m') = ? or DATE_FORMAT(DATE_ADD(DATE_FORMAT(start_date, '%Y-%m-%d'),INTERVAL 6 MONTH),'%d %m') = ? or DATE_FORMAT(DATE_ADD(DATE_FORMAT(start_date, '%Y-%m-%d'),INTERVAL 9 MONTH),'%d %m') = ? or DATE_FORMAT(DATE_ADD(DATE_FORMAT(start_date, '%Y-%m-%d'),INTERVAL 3 MONTH),'%d %m') = ?)",[date('d m'),date('d m'),date('d m'),date('d m')])->whereRaw("CASE WHEN recursive_last_created IS NOT NULL THEN ? > DATE_FORMAT(recursive_last_created, '%Y%m%d') ELSE 1=1 END",[date('Ymd')])->whereRaw("CASE WHEN recursive_end_date IS NOT NULL THEN ? < DATE_FORMAT(recursive_end_date,'%Y%m%d') ELSE 1=1 END",[date('Ymd')])->get()->toArray();
        // dd(DB::getQueryLog());
        // print_r($quaterly_tasks); exit;
        if(count($quaterly_tasks)>0) //replace count > 0
        {
            $this->create_task($quaterly_tasks);

        }
       /* else
        {
            echo "no quaterly task found";
        }*/


        //half yearly
        // DB::enableQueryLog();
        $half_yearly_tasks=Task::with('services','employees','contacts')->where('master_id',1)->where('type','memorized-ticket')->where('recursive_type',6)->whereRaw("(DATE_FORMAT(start_date, '%d %m') = ? or DATE_FORMAT(DATE_ADD(DATE_FORMAT(start_date, '%Y-%m-%d'),INTERVAL 6 MONTH),'%d %m') = ?)",[date('d m'),date('d m')])->whereRaw("CASE WHEN recursive_last_created IS NOT NULL THEN ? > DATE_FORMAT(recursive_last_created, '%Y%m%d') ELSE 1=1 END",[date('Ymd')])->whereRaw("CASE WHEN recursive_end_date IS NOT NULL THEN ? < DATE_FORMAT(recursive_end_date,'%Y%m%d') ELSE 1=1 END ",[date('Ymd')])->get()->toArray();
        //dd(DB::getQueryLog());
        //print_r($half_yearly_tasks); exit;
        if(count($half_yearly_tasks)>0) //replace count > 0
        {
            $this->create_task($half_yearly_tasks);
        }
        /*else
        {
            echo "no half yearly task found";
        }*/

        
        // yearly
       // DB::enableQueryLog(); 
        $yearly_tasks=Task::with('services','employees','contacts')->where('master_id',1)->where('type','memorized-ticket')->where('recursive_type',1)->whereRaw("DATE_FORMAT(start_date, '%d %m') = ? ",[date('d m')])->whereRaw("CASE WHEN recursive_last_created IS NOT NULL THEN ? > DATE_FORMAT(recursive_last_created, '%Y%m%d') ELSE 1=1 END",[date('Ymd')])->whereRaw("CASE WHEN recursive_end_date IS NOT NULL THEN ? < DATE_FORMAT(recursive_end_date,'%Y%m%d') ELSE 1=1 END ",[date('Ymd')])->get()->toArray();
        //dd(DB::getQueryLog());
            //    dd($yearly_tasks);

        if(count($yearly_tasks)>0) //replace count > 0
        {
            $this->create_task($yearly_tasks);
            
        }
        /*else
        {
            echo "no yearly task found";
        }*/

        //monthly recursive
	    //DB::enableQueryLog();
        $monthly_tasks=Task::with('services','employees','contacts')->where('master_id',1)->where('type','memorized-ticket')->where('recursive_type',2)->whereRaw("DATE_FORMAT(start_date, '%d') = ? ",[date('d')])->whereRaw("CASE WHEN recursive_last_created IS NOT NULL THEN ? > DATE_FORMAT(recursive_last_created, '%Y%m%d') ELSE 1=1 END",[date('Ymd')])->whereRaw("CASE WHEN recursive_end_date IS NOT NULL THEN ? < DATE_FORMAT(recursive_end_date,'%Y%m%d') ELSE 1=1 END ",[date('Ymd')])->get()->toArray();
        //dd(DB::getQueryLog());
        //print_r($monthly_tasks); exit;
        if(count($monthly_tasks)>0) //replace count > 0
        {
            $this->create_task($monthly_tasks);
            
        }
        /*else
        {
            echo "no monthly task found";
        }*/

        //weekly
        $weekly_tasks=Task::with('services','employees','contacts')->whereHas('recursive_week',function($q)
              {
                  $q->where('week_no',date('N'));
              })->where('master_id',1)->where('type','memorized-ticket')->where('recursive_type',3)->whereRaw("CASE WHEN recursive_last_created IS NOT NULL THEN ? > DATE_FORMAT(recursive_last_created, '%Y%m%d') ELSE 1=1 END",[date('Ymd')])->whereRaw("CASE WHEN recursive_end_date IS NOT NULL THEN ? < DATE_FORMAT(recursive_end_date,'%Y%m%d') ELSE 1=1 END ",[date('Ymd')])->get()->toArray();
        //print_r($weekly_taskts); exit;
        if(count($weekly_tasks)>0) //replace count > 0
        {
           $this->create_task($weekly_tasks);

        }
        /*else
        {
            echo "no weekly task found";
        }*/ 


        //custom
        $custom_tasks=Task::with('services','employees','contacts')->whereHas('recursive_week',function($q)
              {
                  $q->where('day',date('d'))->where('month',date('m'));
              })->where('master_id',1)->where('type','memorized-ticket')->where('recursive_type',7)->whereRaw("CASE WHEN recursive_last_created IS NOT NULL THEN ? > DATE_FORMAT(recursive_last_created, '%Y%m%d') ELSE 1=1 END",[date('Ymd')])->whereRaw("CASE WHEN recursive_end_date IS NOT NULL THEN ? < DATE_FORMAT(recursive_end_date,'%Y%m%d') ELSE 1=1 END ",[date('Ymd')])->get()->toArray();
        //print_r($custom_tasks); exit;
        if(count($custom_tasks)>0) //replace count > 0
        {
            $this->create_task($custom_tasks);
           
        }
        /*else
        {
            echo "no custom task found";
        }*/


        //daily recursive ->whereRaw("DATE_FORMAT(start_date, '%d') = ? ",[date('d')])
        $daily_tasks=Task::with('services','employees','contacts')->where('master_id',1)->where('type','memorized-ticket')->where('recursive_type',4)->whereRaw("CASE WHEN recursive_last_created IS NOT NULL THEN ? > DATE_FORMAT(recursive_last_created, '%Y%m%d') ELSE 1=1 END",[date('Ymd')])->whereRaw("CASE WHEN recursive_end_date IS NOT NULL THEN ? < DATE_FORMAT(recursive_end_date,'%Y%m%d') ELSE 1=1 END ",[date('Ymd')])->get()->toArray();
        //dd(DB::getQueryLog());
        // dd($daily_tasks);
        if(count($daily_tasks)>0)
        {
            $this->create_task($daily_tasks);
            
        }
        /*else
        {
            echo "no daily task found";
        }*/
        //One Time Task
        $onetime_tasks=Task::with('services','employees','contacts')->where('master_id',1)->where('type','memorized-ticket')->where('recursive_type',8)->whereRaw("DATE(start_date) = ? ",[date('Y-m-d')])->whereNull('recursive_last_created')->get()->toArray();
        if(count($onetime_tasks)>0)
        {
            $this->create_task($onetime_tasks);
        }
        /*else
        {
            echo "no one time task found";
        }*/
        

    }

    public function create_task($tasks)
    {
	    // echo "hibye"; exit;
        foreach ($tasks as $key => $value) 
        {
            $task=new Task;
            $task->master_id=$value['master_id'];
            $task->referral_id=intval($value['referral_id']>0)?$value['referral_id']:0;
            $task->start_date=date('Y-m-d H:i:s');
           
           if($value['recursive_days']>0)
           {
                $start_date=new Carbon($task->start_date); 
                $task->due_date=$start_date->addDays($value['recursive_days'])->format('Y-m-d H:i:s');
           }
           
           $task->received_date=$value['received_date'];

           $task->start_period=$value['start_period'];
           $task->end_period=$value['end_period'];
          
      
           $task->standard_time=$value['standard_time'];
      
           $task->type=$value['type'];
           $task->recursive_task_id=$value['id'];

           if(isset($value['description']))
           {
                $task->description=$value['description'];
           }
           if(isset($value['description_id']))
           {
            $task->description_id=$value['description_id'];

           }
           //fetch recursive task employee,superadmin and manager
           $employee=array();
           $manager=array();
           $supervisor=array();
           if(count($value['employees'])>0)
           {
              
	           $i=0; 
               $j=0;
               $k=0;

                foreach ($value['employees'] as $key => $emps)
                {
                    $chk_emp=Employee::find($emps['id']);

                    if($chk_emp && $chk_emp->status == 1)
                    {
                        if($emps['pivot']['type']=='employee')
                        {
                            $employee[$i]=$emps['id'];
                            $i++;
                        }
                        
                        if($emps['pivot']['type']=='manager')
                        {
                            $manager[$j]=$emps['id'];
                            $j++;
                        }
                        
                        if($emps['pivot']['type']=='supervisor')
                        {
                            $supervisor[$k]=$emps['id'];
                            $k++;
                        }
                    }   
                }
           }
           
           //end of employees fetch 
          
           //fetch services of recursive task
           $service_array=array();
           if(count($value['services'])>0)
           {
                foreach ($value['services'] as $key1 => $service) 
               {
                 $service_array[$key1]=$service['id']; 
               }
           }
           
           //fetch contacts
           $contact_array=array();
           if(count($value['contacts'])>0)
           {
                foreach ($value['contacts'] as $key2 => $contacts) 
               {
                   $contact_array[$key2]=$contacts['id'];
               }
           }

            $task->priority=$value['priority'];
            
            $task->recursive_type=$value['recursive_type'];
           
           //print_r($description_array);exit();

         
           // echo $value['id'];
           if($task->save())
           {    
                
               
                $task->save();
               
                /****************Contact Save****************/
                if(isset($contact_array) && count($contact_array)>0)
                {
                    $task->contacts()->attach($contact_array,[
                    'master_id'=>$task->master_id,'created_by' => $task->created_by, 'updated_by' => $task->updated_by]);
                }
                /************Service****************/

                if(isset($service_array) && count($service_array)>0)
                {
                        
                    $task->services()->attach($service_array, ['master_id' => $task->master_id, 'created_by' => $task->created_by, 'updated_by' => $task->updated_by]);
                      
                }

                /*****************Employee******************/
                if(isset($employee) && count($employee)>0)
                {   


                   
                    $task->employees()->attach($employee, ['master_id' => $task->master_id, 'type'=>'employee', 'created_by' => $task->created_by, 'updated_by' => $task->updated_by]);
                    // $this->task_add_notification_employee($task->id);
                   
                }
                /*************Supervisor*****************/
                if(isset($supervisor) && count($supervisor)>0 )
                {
                   
                    $task->employees()->attach($supervisor, ['master_id' => $task->master_id, 'type'=>'supervisor', 'created_by' => $task->created_by, 'updated_by' => $task->updated_by]);
                    //  $this->task_add_notfication_supervisor($task->id);
                }

                /***************Manager*****************/
                if(isset($manager) && count($manager)>0 )
                {
                   
                    $task->employees()->attach($manager, ['master_id' => $task->master_id, 'type'=>'manager', 'created_by' => $task->created_by, 'updated_by' => $task->updated_by]);
                    // $this->task_add_notfication_manager($task->id);
                }


                //'identifier' => 'task',


                /**************Notes**********************/
                $notes=TaskNote::where('master_id',1)->where('task_id',$value['id'])->get()->toArray();
                if(count($notes)>0)
                {
                  foreach ($notes as $note) 
                  {
                    $task_note=new TaskNote;
                    $task_note->master_id=$task->master_id;
                    $task_note->task_id=$task->id;
                    $task_note->note=$note['note'];
                    $task_note->save();
                  }
                }
                
                /**********Checklist*********************/
                $checklists=TaskCheckList::where('master_id',1)->where('task_id',$value['id'])->get()->toArray();
                if(count($checklists)>0)
                {
                  foreach ($checklists as $checklist) 
                  {
                      $task_checklist=new TaskCheckList;
                      $task_checklist->master_id=$task->master_id;
                      $task_checklist->task_id=$task->id;
                      $task_checklist->description=$checklist['description'];
                      $task_checklist->user_id=$checklist['user_id'];
                      $task_checklist->save();
                  }
                }
                

               
                $main_task=Task::find($value['id']);
                $main_task->recursive_last_created=date('Y-m-d H:i:s');
                $main_task->save();

                //echo "Successfully Task Created";
           }

        }

        return TRUE;
    }

  
}
