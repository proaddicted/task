<?php

namespace Modules\TaskManager\Console;

use Illuminate\Console\Command;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputArgument;
use App\Models\User;
use App\Models\NotificationTemplate;
use App\Notifications\SendSmsNotification;
// use App\Notifications\SendCronNotification;
use App\Notifications\SendNotification;
use Illuminate\Support\Facades\Notification;
use App\Models\NotificationLog;
use Illuminate\Support\Facades\Mail;
use App\Mail\MailChimp;
use Illuminate\Support\Facades\Auth;
use Modules\ResourceManager\Entities\Employee;
use Illuminate\Support\Facades\DB;

class DueMailTicket extends Command
{
    public $notification_batch_id=0,$template_body='';
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'ticket:duemails';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {

        if($template = DB::table('notification_templates')->where('name','send-due-ticket-mail')->where('status',1)->first())
        {
            $not=DB::table('notifications')->max('batch_id');
            $this->notification_batch_id=$not+1;
                $task_str="";
                $currentDate =date('Y-m-d');
                
                $group=[];
                $company=[];
                $employee=[];
                $regular_task=[];
                $department_task=[];
                
                /****************TODAY TICKETS******************* */
                $enterd_rows=[];
                
                $today_due_tasks=[];
                
                //for RT with today due dates
                $regular_tasks=DB::table('tasks')->select('id')->whereNotIn('status',[2])->where('type','regular-ticket')->whereRaw('DATE(due_date) = ?',[$currentDate])->whereNull('deleted_at')->get();

                foreach($regular_tasks as $rt)
                {
                    $today_due_tasks[]=$rt->id;
                }

                //for DT parent RTs with today due dates
                $department_tasks_parent=DB::table('tasks')->select('parent_id')->whereNotIn('status',[2])->where('type','department-task')->whereRaw('DATE(due_date) = ?',[$currentDate])->whereNull('deleted_at')->get();
                foreach($department_tasks_parent as $dt)
                {
                    $today_due_tasks[]=$dt->parent_id;
                }

                $today_due_tasks=array_unique($today_due_tasks);//unique array of rt ids 

                // $todaytasks=Ticket::with('company.address','employee_element','service')->whereIn('id', $today_due_tasks)->get()->toArray();
                $todaytasks=DB::table('tasks')->whereIn('id', $today_due_tasks)->get();

                if(count($todaytasks)>0)
                {

                    foreach($todaytasks as $key=> $tick)
                    {
                        // dd($tick->id);
                        $duedates=[];
                        $enterd_rows[$key]['main_task']=$tick;


                        $tdchild=DB::table('tasks')->where('parent_id',$tick->id)->whereNull('deleted_at')->whereRaw('DATE(due_date)  BETWEEN ? AND ?',[$currentDate,'2050-01-01'])->where('status',0)->where('type','department-task')->get();

                    
                        $enterd_rows[$key]['child_task']= $tdchild;

                        foreach($tdchild as $val)
                        {
                            $duedates[]=date('Y-m-d', strtotime($val->due_date));
                        }
                        $enterd_rows[$key]['due_dates']=$duedates;
                        // dd($enterd_rows);
                    }
                }

                // dd($enterd_rows);
                if(count($enterd_rows)>0 )
                {
                    $r=0;
                    $task_str.="<h2 style='margin-top:2rem;'>List of Today Due Date Tickets</h2>";

                    $task_str .="<table class='table-report' style='width:100%;border:1px solid #e3e3e3;border-collapse: collapse;'>";
                        $task_str .='<thead style="border-right:1px solid #c7c7c7;border-left:1px solid #c7c7c7;">';
                        $task_str .="<tr>";
                        $task_str .="<th class='special' style='border-left: 1px solid #dedede;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;background: #eeeeee;width:30%!important'>Ticket Name</th>";
                        $task_str .="<th class='special' style='border-left: 1px solid #dedede;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;background: #eeeeee;width:17.5%!important'>Company</th>";
                        $task_str .="<th class='special' style='border-left: 1px solid #dedede;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;background: #eeeeee;width:17.5%!important'>Service</th>";

                        // $task_str .="<th class='special' style='border-left: 1px solid #dedede;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;background: #eeeeee;width:17.5%!important'>GSTIN</th>";
                        // $task_str .="<th class='special' style='border-left: 1px solid #dedede;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;background: #eeeeee;width:17.5%!important'>State</th>";
                        $task_str .="<th class='special' style='border-left: 1px solid #dedede;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;background: #eeeeee;width:17.5%!important'>Employee</th>";
                        $task_str .="</tr>";
                        $task_str .="</thead>";
                        $task_str .='<tbody style="width:100%;border:1px solid #e3e3e3;border-collapse: collapse;">';
                    foreach($enterd_rows as $tdtask)
                    {

                        // dd($tdtask['main_task']);
                        if((date('Y-m-d', strtotime($tdtask['main_task']->due_date))==$currentDate &&  $tdtask['main_task']->status==0) || (count($tdtask['child_task'])>0 && in_array($currentDate, $tdtask['due_dates'])))
                        {
                            $r=1;
                            $task_str .="<tr style='background: #eeeeee;border: 1px solid #c7c7c7;'>";
                            

                                if($tdtask['main_task']->status==0)
                                    {
                                        $color='#d9534f';
                                        
                                    }
                                    elseif($tdtask['main_task']->status==1)
                                    {
                                        $color='#5cb85c';
                                    
                                    }
                                    else
                                    {
                                        $color='#0275d8';
                                    
                                    }
                                    //dd($color);
                                //task name 
                                $task_str .="<td style='border-left: 1px solid #dedede;border-bottom: 1px solid #dedede; color:#555555; font-size:12px;padding:10px 10px 10px 10px;background:#fff;width:30%!important'><a style='color:".$color."' href='".env('HTML_URL')."task-view/".$tdtask['main_task']->id."'>".$tdtask['main_task']->name."</a>";
                                if(date('Y-m-d', strtotime($tdtask['main_task']->due_date)) == $currentDate) 
                                {
                                    $task_str .= "<span style='background-color: #2994f1;color: #fff;padding: 3px;border-radius: 3px;margin-left: 1rem;'>R</span> ";//for showing if in respect of Regular Ticket
                                }
                                $task_str .= "<br><span><b>[".$tdtask['main_task']->due_date."]</b></span>";//for showing due date of Regular Ticket
                                $task_str .="</td>";

                                


                                //company name    
                                $companies=DB::table('contacts')->where('master_id',$tdtask['main_task']->master_id)->where('type','company')->whereRaw('contacts.id in (select distinct company_id from task_companies where task_id='.$tdtask['main_task']->id.' and deleted_at is null)')->get();
                                $comp_name=[];
                                if(count($companies)>0)
                                {
                                    foreach($companies as $val)
                                        $comp_name[]=$val->fname;
                                }

                                if(count($comp_name)>0)

                                $task_str .="<td style='border-left: 1px solid #dedede;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;word-break: break-all;background:#fff;width:17.5%!important'>".implode(',',$comp_name)."</td>";
                                else
                                $task_str .="<td style='border-left: 1px solid #dedede;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;background:#fff;width:17.5%!important'></td>";


                                //services
                                $services=DB::table('services')->where('master_id',$tdtask['main_task']->master_id)->whereRaw('services.id in (select distinct service_id from task_services where task_id='.$tdtask['main_task']->id.' and deleted_at is null)')->orderBy('services.id','ASC')->get();
                                $service_name=[];
                                if(count($services)>0)
                                {
                                    foreach($services as $val)
                                        $service_name[]=$val->name;
                                }

                                if(count($service_name)>0)
                                {
                                    $task_str .="<td style='border-left: 1px solid #dedede;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;background:#fff;word-break: break-all;width:17.5%!important'>".implode('->',$service_name)."</td>";
                                }
                                else
                                {
                                    $task_str .="<td style='border-left: 1px solid #dedede;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;background:#fff;width:17.5%!important'></td>";
                                }
                                
                                //company address    

                            /*  if(isset($tdtask['main_task']['company']['address']) && count($tdtask['main_task']['company']['address'])>0)
                                {
                                    //company gstin    

                                    $task_str .="<td style='border-left: 1px solid #dedede;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;word-break: break-all;background:#fff;width:17.5%!important'>".$tdtask['main_task']['company']['address'][0]['gst_code']."</td>";

                                    //company state    

                                    $task_str .="<td style='border-left: 1px solid #dedede;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;background:#fff;word-break: break-all;width:17.5%!important'>".$tdtask['main_task']['company']['address'][0]['state']."</td>";
                                }
                                else
                                {
                                    //company gstin 
                                    $task_str .="<td style='border-left: 1px solid #dedede;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;background:#fff;width:17.5%!important'></td>";

                                    //company state
                                    $task_str .="<td style='border-left: 1px solid #dedede;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;background:#fff;width:17.5%!important'></td>";
                                }*/


                                //employees name    
                                $users=DB::table('users')->whereRaw('id in (select distinct user_id from task_users where task_id='.$tdtask['main_task']->id.' and deleted_at is null)')->get();
                                $user_name=[];
                                if(count($users)>0)
                                {
                                    foreach($users as $emp)
                                        $user_name[]=$emp->name;
                                }
                                if(count($user_name)>0)
                                {
                                    $task_str .="<td style='border-left: 1px solid #dedede;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;background:#fff;width:17.5%!important'>".implode(',',$user_name)."</td>";
                                }
                                else{
                                    $task_str .="<td style='border-left: 1px solid #dedede;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;background:#fff;width:17.5%!important'></td>";
                                }

                                $task_str .="</tr>";
                                if(count($tdtask['child_task'])>0)
                                {
                                
                                    foreach($tdtask['child_task'] as $childs)
                                    {
                                        // dd($childs);
                                
                                    $task_str .="<tr style='background: #eeeeee;border: 1px solid #c7c7c7;'>";
                                
                                    $task_str .="<td colspan='6' style='border-left: 1px solid #dedede;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;background:#fff;width:100%!important'>";
                                    $task_str .="<table style='border-collapse: collapse; width: 100%' border='0' cellspacing='0' cellpadding='0'>";
                                    $task_str .="<tbody style='border: 0'>";
                                    $task_str .="<tr style='border: 0'>";
                                    $task_str .="<td style='width: 2%; border: 0'>";
                                    $task_str .="<span style='font-size: 20px'>&#8627;</span>";
                                    $task_str .="</td>";
                                    $task_str .="<td style='width: 98%; border: 0'>";
                                    $task_str .="<p><strong>Case No. :-</strong>".$childs->name;
                                
                                    $task_str .= "<span style='background-color: #c9ba15;color: #fff;padding: 3px;border-radius: 3px;margin: 0px 10px;'>C</span></p>";

                                    //  if(isset($childs['depttask_purpose']) && count($childs['depttask_purpose'])>0){
                                        $task_str .="<p> <strong>Case Matter :-</strong><strong>[- ".$childs->due_date." ]</strong></p>";
                                    //  }
                                    //  else{
                                    
                                    //  $task_str .="<p> <strong>Case Matter :-</strong>
                                    //  </p>";
                                    //   }
                                    //  if(count($childs['employee_element'])>0)
                                    //  {
                                        $employees=[];
                                        $childusers=DB::table('users')->whereRaw('id in (select distinct user_id from task_users where task_id='.$tdtask['main_task']->id.' and deleted_at is null)')->get();
                                        foreach($childusers as $emp)
                                        {
                                            $employees[]=$emp->name;
                                        }
                                        $task_str .=" <p>
                                        <strong>Employee :-</strong>".implode(',',$employees)."</p>";
                                    //  }
                                    
                                    $task_str .="</td>";
                                    $task_str .="</tr>";
                                    $task_str .="</tbody>";
                                    $task_str .="</table>";
                                    $task_str .="</td>";
                                    $task_str .="</tr>";
                                    }
                                }
                        }
                        

                    }
                    if($r==0)
                    {
                        $task_str .="<tr style='background: #eeeeee;border: 1px solid #c7c7c7;'><td colspan='6' style='text-align:center'><b>No Records Found</b></td></tr>";
                    }
                    $task_str .="</tbody>";
                    $task_str .="</table>";
                }
                /**********END*********** */


                // Get upcoming 15 days
            $upcoming_days=[];
                for ($i = 1; $i <= 15; $i++) {
                    $nextDate = date('Y-m-d', strtotime("$currentDate +$i day"));
                    array_push($upcoming_days,$nextDate);
                }
                // dd($upcoming_days);
            
                $rows=[];

                $tasks=DB::table('tasks')->select('id')->whereNotIn('status',[2])->where('type','regular-ticket')->whereRaw('DATE(due_date) BETWEEN ? AND ?',[$upcoming_days[0],$upcoming_days[count($upcoming_days)-1]])->whereNull('deleted_at')->get();
            
                $all_duedates=[];
                $regular_task_duedates=[];

                if(count($tasks)>0 )
                {
                    foreach($tasks as $key=> $tick)
                    {
                        $duedates=[];
                        $rows[$key]['main_task']=$tick;


                        $upchild=DB::table('tasks')->where('parent_id',$tick->id)->whereNull('deleted_at')->whereRaw('DATE(due_date)  BETWEEN ? AND ?',[$upcoming_days[0],'2050-01-01'])->where('status',0)->where('type','department-task')->get();
                    
                        $enterd_rows[$key]['child_task']= $upchild;

                        foreach($upchild as $val)
                        {
                            $duedates[]=date('Y-m-d', strtotime($val->due_date));
                        }
                        $enterd_rows[$key]['due_dates']=$duedates;

                       
                        if(count($upchild)>0 || (count($upchild)==0 && $tick->status==0))
                        {
                            $duedates[]=date('Y-m-d', strtotime($tick->due_date));
                            $all_duedates[]=date('Y-m-d', strtotime($tick->due_date));
                        }
                        
                        $regular_task_duedates[]=date('Y-m-d', strtotime($tick->due_date));

                        foreach($upchild as $val)
                        {
                            $duedates[]=date('Y-m-d', strtotime($val->due_date));
                            $all_duedates[]=date('Y-m-d', strtotime($val->due_date));
                        }
                        $rows[$key]['due_dates']=$duedates;
                        // $duedates=array_merge($duedates,array_column($dept_ticks,'due_date'));
                            // dd(min($duedates));
                        dd($rows);
                    }
                }

                /******************UPCOMING 15 DAY'S TICKETS******************** */
             if(count($rows)>0)
                {
                    $task_str.="<h2 style='margin-top:2rem;'>List of Upcoming 15days Due Date Tickets</h2>";
                    foreach($upcoming_days as $dates)
                    {
                        if(in_array($dates, $all_duedates))
                        {
                            $task_str .="<table class='table-report' style='width:100%;border:1px solid #e3e3e3;border-collapse: collapse;margin-top:1rem;'>";
                            $task_str .='<thead style="border-right:1px solid #c7c7c7;border-left:1px solid #c7c7c7;">';
                            $task_str .="<tr  style='text-align:right;background: #eeeeee;border: 1px solid #c7c7c7;'><td colspan='6' style='border-left: 1px solid #dedede;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;background:#fff;width:100%!important'><h3>Date:-".date('d/m/Y', strtotime($dates))."</td></h3></tr>";
                            $task_str .="<tr>";
                            $task_str .="<th class='special' style='border-left: 1px solid #dedede;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;background: #eeeeee;width:30%!important'>Ticket Name</th>";
                            $task_str .="<th class='special' style='border-left: 1px solid #dedede;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;background: #eeeeee;width:17.5%!important'>Company</th>";
                            $task_str .="<th class='special' style='border-left: 1px solid #dedede;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;background: #eeeeee;width:17.5%!important'>Service</th>";


                            // $task_str .="<th class='special'>Date</th>";
                          /*  $task_str .="<th class='special' style='border-left: 1px solid #dedede;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;background: #eeeeee;width:17.5%!important'>GSTIN</th>";
                            $task_str .="<th class='special' style='border-left: 1px solid #dedede;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;background: #eeeeee;width:17.5%!important'>State</th>";*/
                            $task_str .="<th class='special' style='border-left: 1px solid #dedede;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;background: #eeeeee;width:17.5%!important'>Employee</th>";
                            $task_str .="</tr>";
                            $task_str .="</thead>";
                            $task_str .='<tbody style="width:100%;border:1px solid #e3e3e3;border-collapse: collapse;">';
            
                            foreach($rows as $uptask)
                            {
                                
                                // in_array($dates, $uptask['due_dates']);
                                // dd($uptask['due_dates']);
                                if(in_array($dates, $uptask['due_dates'])) 
                                {
                                    $task_str .="<tr style='background: #eeeeee;border: 1px solid #c7c7c7;'>";

                                    if($uptask['main_task']->status==0)
                                    {
                                        $color='#d9534f';
                                    }
                                    elseif($uptask['main_task']->status==1)
                                    {
                                        $color='#5cb85c';
                                    }
                                    else
                                    {
                                        $color='#0275d8';
                                    }
            
                                    //task name 
                                    $task_str .="<td style='border-left: 1px solid #dedede;color:#fff;border-bottom: 1px solid #dedede;font-size:12px;padding:10px 10px 10px 10px;background:#fff;width:30%!important'><a style='color:".$color.";' href='".env('HTML_URL')."task-view/".$uptask['main_task']->id."'>".$uptask['main_task']->name."</a>";
                                    
                                    // dd(date('Y-m-d', strtotime($uptask['main_task']['due_date'])));
                                    // dd($dates);
                                

                                    if(date('Y-m-d', strtotime($uptask['main_task']->due_date)) == $dates) 
                                    {
                                        $task_str .= "<span style='background-color: #2994f1;color: #fff;padding: 3px;border-radius: 3px;margin-left: 1rem;'>R</span
                                        > ";//for showing if in respect of Regular Ticket
                                    }
                                    $task_str .= "<br><span><b>[".$uptask['main_task']->due_date."]</b></span>";//for showing due date of Regular Ticket

                                
                                    $task_str .="</td>";
                                    // $task_str .=;//main task

                                    $companies=DB::table('contacts')->where('master_id',$uptask['main_task']->master_id)->where('type','company')->whereRaw('contacts.id in (select distinct company_id from task_companies where task_id='.$uptask['main_task']->id.' and deleted_at is null)')->get();
                                    $comp_name=[];
                                    if(count($companies)>0)
                                    {
                                        foreach($companies as $val)
                                            $comp_name[]=$val->fname;
                                    }

                                    // company name    
                                    if(count($comp_name)>0)
                                    $task_str .="<td style='border-left: 1px solid #dedede;word-break: break-all;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;background:#fff;width:17.5%!important'>".implode(',',$comp_name)."</td>";
                                    else
                                    $task_str .="<td style='border-left: 1px solid #dedede;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;background:#fff;width:17.5%!important'></td>";


                                    //service
                                    $services=DB::table('services')->where('master_id',$uptask['main_task']->master_id)->whereRaw('services.id in (select distinct service_id from task_services where task_id='.$uptask['main_task']->id.' and deleted_at is null)')->orderBy('services.id','ASC')->get();
                                    $service_name=[];
                                    if(count($services)>0)
                                    {
                                        foreach($services as $val)
                                            $service_name[]=$val->name;
                                    }
    


                                    if(count($service_name)>0)
                                    {
                                        $task_str .="<td style='border-left: 1px solid #dedede;word-break: break-all;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;background:#fff;width:17.5%!important'>".implode('->',$service_name)."</td>";
                                    }
                                    else
                                    {
                                        $task_str .="<td style='border-left: 1px solid #dedede;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;background:#fff;width:17.5%!important'></td>";
                                    }

                                    
                                    // $task_str .="<td>".date($i.'/m/d')."</td>";
                                    //company address    
                                  /*  if(isset($uptask['main_task']['company']['address']) && count($uptask['main_task']['company']['address'])>0)
                                    {
                                        //company gstin    
                                        $task_str .="<td style='border-left: 1px solid #dedede;word-break: break-all;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;background:#fff;width:17.5%!important'>".$uptask['main_task']['company']['address'][0]['gst_code']."</td>";
            
                                        //company state    
                                        $task_str .="<td style='border-left: 1px solid #dedede;word-break: break-all;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;background:#fff;width:17.5%!important'>".$uptask['main_task']['company']['address'][0]['state']."</td>";
                                    }
                                    else
                                    {
                                        //company gstin 
                                        $task_str .="<td style='border-left: 1px solid #dedede;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;background:#fff;width:17.5%!important'></td>";
            
                                        //company state
                                        $task_str .="<td style='border-left: 1px solid #dedede;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;background:#fff;width:17.5%!important'></td>";
                                    }*/
                                    //employees name    
                                    $users=DB::table('users')->whereRaw('id in (select distinct user_id from task_users where task_id='.$tdtask['main_task']->id.' and deleted_at is null)')->get();
                                    $user_name=[];
                                    if(count($users)>0)
                                    {
                                        foreach($users as $emp)
                                            $user_name[]=$emp->name;
                                    }
                                    if(count($user_name)>0)
                                    {
                                        $emp_name=[];
                                        foreach($uptask['main_task']['employee_element'] as $emp)
                                        {
                                            array_push($emp_name,$emp['full_name']);
                                        }
                                        $task_str .="<td style='border-left: 1px solid #dedede;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;background:#fff;width:17.5%!important'>".implode(',',$user_name)."</td>";
                                    }
                                    else{
                                        $task_str .="<td style='border-left: 1px solid #dedede;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;background:#fff;width:17.5%!important'></td>";
                                    }
                                    $task_str .="</tr>";
            
                                    if(count($uptask['child_task'])>0)
                                    {
                                        foreach($uptask['child_task'] as $childs)
                                        {
                                        
                                        //array_push($child_id, $childs['id']);
                                        //if(!in_array($childs['id'], $child_id)){

                                            //if(date('Y-m-d', strtotime($childs['due_date'])) == $dates) 
                                            //{  
                                                $task_str .="<tr style='background: #eeeeee;border: 1px solid #c7c7c7;'>";
                                            
                                                $task_str .="<td colspan='6' style='border-left: 1px solid #dedede;border-bottom: 1px solid #dedede;color:#555555;font-size:12px;padding:10px 10px 10px 10px;background:#fff;width:100%!important'>";
                                                $task_str .="<table style='border-collapse: collapse; width: 100%' border='0' cellspacing='0' cellpadding='0'>";
                                                $task_str .="<tbody style='border: 0'>";
                                                $task_str .="<tr style='border: 0'>";
                                                $task_str .="<td style='width: 5.26035%; border: 0'>";
                                                $task_str .="<span style='font-size: 20px'>&#8627;</span>";
                                                $task_str .="</td>";
                                                $task_str .="<td style='width: 94.6701%; border: 0'>";
                                                $task_str .="<p><strong>Case No. :-</strong>".$childs['name'];
                                                
                                                // if(date('Y-m-d', strtotime($childs['due_date'])) == $dates) 
                                                // {
                                                    $task_str .= "<span style='background-color: #c9ba15;color: #fff;padding: 3px;border-radius: 3px;margin: 0px 10px;'>C</span
                                                    ></p>";
                                                // }
                                                
                                                if(isset($childs->due_date)){
                                                // $updue = DepartmentTicketPurposeElement::where('main_id',$childs['id'])->where('identifier','task')->whereNull('deleted_at')->get()->toArray();


                                                $task_str .="<p> <strong>Case Matter :-</strong><strong>[ ".$childs->due_date."
                                                ]</strong></p>";

                                                }
                                            
                                                else{
                                                $task_str .="<p> <strong>Case Matter :-</strong>
                                                </p>";
                                                }
                    
                                                if(count($childs['employee_element'])>0)
                                                {
                                                    $employees=[];
                                                    $childusers=DB::table('users')->whereRaw('id in (select distinct user_id from task_users where task_id='.$tdtask['main_task']->id.' and deleted_at is null)')->get();
                                                    foreach($childusers as $emp)
                                                    {
                                                        $employees[]=$emp->name;
                                                    }
                                                    $task_str .=" <p>
                                                    <strong>Employee :-</strong>".implode(',',$employees)."</p>";
                                                }
                                                
                                                $task_str .="</td>";
                                                $task_str .="</tr>";
                                                $task_str .="</tbody>";
                                                $task_str .="</table>";
                                                $task_str .="</td>";
                                                $task_str .="</tr>";
                                        // }
                                        //}
                                    }
                                    }
                                }
                            }
                            $task_str .="</tbody>";
                            $task_str .="</table>";
                        }
                    }
                }
                
                
                $employee=DB::table('employees')->where('user_id','>',0)->where('status',1)->groupBy('id')->get();
            // dd($employee);
                if(count($employee)>0)
                {
                    foreach($employee as $emp)
                    {
                        $user=User::find($emp->user_id);
                        if($user)
                        {
                            $notification_data['content']=$task_str;
                            $notification_data['template'] = $template;
                            $notification_data['template_subject'] =$template->subject;
                            $notification_data['start_date']=date('d/m/Y');
                            $notification_data['end_date']=date('d/m/Y', strtotime('+15 days', strtotime($currentDate)));


                            $recipients[]=array('email'=>$user->email,'name'=>$user->name,'mail_type'=>'to');
                            // dd($recipients);

                            Notification::send($user, new SendNotification($notification_data,'',$recipients,'daily-attendance',$this->notification_batch_id));//old
                            
                            $this->sendMailFunc($this->notification_batch_id,$template->email_body); //24/05/24
                            $this->notification_batch_id=$this->notification_batch_id+1;
                        }
                    }
                }
               
        }
       
    }
    public function sendMailFunc($batch_id,$template_body)
    {
        $notifications=NotificationLog::where('batch_id',$this->notification_batch_id)->where('status',0)->get()->toArray();
        if(count($notifications)>0)
         Mail::send(new MailChimp($notifications,$template_body,0,'daily-attendance',''));
    }
   
}
