<?php

namespace Modules\TaskManager\Transformers;

use Illuminate\Http\Resources\Json\JsonResource;
class TaskCheckListResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request
     * @return array
     */
    public function toArray($request)
    {
        $main = parent::toArray($request);
        return array_merge($main,['employee'=>$this->employee,'checked_employee'=>$this->checked_employee,'rejected_employee'=>$this->rejected_employee]);
    }
}
