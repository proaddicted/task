<?php

namespace Modules\TaskManager\Transformers;

use Illuminate\Http\Resources\Json\JsonResource;

class CustomTemplateResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request
     * @return array
     */
    public function toArray($request)
    {
        return parent::toArray($request);
    }
}
