<?php

namespace Modules\TaskManager\Transformers;

use Illuminate\Http\Resources\Json\JsonResource;

class CommunicationResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request
     * @return array
     */
    public function toArray($request)
    {
        $main = parent::toArray($request);
        return array_merge($main,['replies'=>$this->replies,'recipients'=>$this->recipients,'from'=>$this->from,'files'=>$this->files]);
    }
}
