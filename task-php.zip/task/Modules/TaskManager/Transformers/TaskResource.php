<?php

namespace Modules\TaskManager\Transformers;

use Illuminate\Http\Resources\Json\JsonResource;
use Modules\TaskManager\Transformers\TaskCheckListResource;

class TaskResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request
     * @return array
     */
    public function toArray($request)
    {
        $main = parent::toArray($request);
        return array_merge($main,['companies'=>$this->companies,'contacts'=>$this->contacts,'services'=>$this->services,'check_lists'=>TaskCheckListResource::collection($this->check_lists),'files'=>$this->files,'employees'=>$this->employees,'supervisor'=>$this->supervisor,'recursive_week'=>$this->recursive_week,'manager'=>$this->manager,'notes'=>$this->notes,'task_flags'=>$this->task_flags,'ticket_stages'=>$this->ticket_stages,'group'=>$this->group,'referral'=>$this->referral,'department_purpose'=>$this->department_purpose,'officers'=>$this->officers,'change_logs'=>$this->change_logs,'creator'=>$this->creator,'updator'=>$this->updator,'main_task'=>new TaskResource($this->main_task)]);
    }
}
