<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCallLogsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('call_logs', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('master_id')->nullable();

            $table->unsignedBigInteger('main_id')->nullable();
            $table->string('identifier')->nullable();

            $table->text('call_type')->nullable(); 
            $table->text('call_date')->nullable(); 
            $table->text('call_time')->nullable(); 
            $table->text('caller_number')->nullable(); 


            $table->text('called_number')->nullable(); 
            $table->text('call_status')->nullable(); 
            $table->text('menu')->nullable(); 
            $table->text('agent_list')->nullable(); 

            $table->text('agent_number')->nullable(); 
            $table->text('call_transfer_status')->nullable(); 
            $table->text('caller_duration')->nullable(); 
            $table->text('conversation_duration')->nullable(); 

            $table->text('recording_url')->nullable(); 
            $table->text('call_uuid')->nullable(); 
            $table->text('bridge_number')->nullable(); 
            $table->text('bridge_extension')->nullable(); 

            $table->text('voicemail_url')->nullable(); 
            $table->text('menu_extension')->nullable(); 


            $table->softDeletes();
            $table->timestamps();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->unsignedBigInteger('deleted_by')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('call_logs');
    }
}
