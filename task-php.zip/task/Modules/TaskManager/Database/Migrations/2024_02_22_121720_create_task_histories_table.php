<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTaskHistoriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('task_histories', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('master_id')->nullable();
            $table->unsignedBigInteger('task_id')->nullable();
            $table->unsignedBigInteger('user_id')->nullable();
            
            $table->string('office_out_time')->nullable();
            $table->string('office_out_longitude')->nullable();
            $table->string('office_out_latitude')->nullable();
            $table->string('office_out_address')->nullable();

            $table->string('meeting_in_time')->nullable();
            $table->string('meeting_in_longitude')->nullable();
            $table->string('meeting_in_latitude')->nullable();
            $table->string('meeting_in_address')->nullable();

            $table->string('meeting_out_time')->nullable();
            $table->string('meeting_out_longitude')->nullable();
            $table->string('meeting_out_latitude')->nullable();
            $table->string('meeting_out_address')->nullable();

            $table->string('office_in_time')->nullable();
            $table->string('office_in_longitude')->nullable();
            $table->string('office_in_latitude')->nullable();
            $table->string('office_in_address')->nullable();
           
            $table->softDeletes();
            $table->timestamps();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->unsignedBigInteger('deleted_by')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('task_histories');
    }
}
