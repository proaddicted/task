<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCommunicationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('communications', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('master_id')->nullable();
            $table->dateTime('date')->nullable();

            $table->unsignedBigInteger('from_id')->nullable()->comment('user id');

            $table->unsignedBigInteger('main_id')->nullable()->default(0);
            $table->string('identifier')->nullable(); 

            $table->longText('comment')->nullable(); 
            $table->unsignedBigInteger('parent_id')->nullable()->comment('communications id');
            $table->tinyInteger('is_schedule')->nullable()->default(0);

            $table->softDeletes();
            $table->timestamps();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->unsignedBigInteger('deleted_by')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('communications');
    }
}
