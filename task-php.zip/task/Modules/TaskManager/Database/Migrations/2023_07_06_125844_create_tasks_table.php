<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTasksTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tasks', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('master_id')->nullable();
            $table->string('name')->nullable();
            $table->unsignedBigInteger('description_id')->nullable();
            $table->longText('description')->nullable(); 
            $table->string('type')->nullable();
            $table->tinyInteger('status')->default(0);
            $table->tinyInteger('priority')->default(0);
            $table->unsignedBigInteger('parent_id')->nullable();

            $table->dateTime('start_date')->nullable();
            $table->dateTime('received_date')->nullable();
            $table->dateTime('due_date')->nullable();
            $table->dateTime('ecd')->nullable();
            $table->dateTime('completed_date')->nullable();
            $table->string('standard_time')->nullable();
           

            $table->string('start_period')->nullable();
            $table->string('end_period')->nullable();

            $table->unsignedBigInteger('referral_id')->nullable();

            $table->tinyInteger('recursive_type')->nullable()->default(0);
            $table->dateTime('recursive_end_date')->nullable();
            $table->integer('recursive_days')->nullable();
            $table->unsignedBigInteger('recursive_task_id')->nullable();
            $table->dateTime('recursive_last_created')->nullable();


            $table->softDeletes();
            $table->timestamps();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->unsignedBigInteger('deleted_by')->nullable();
           
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tasks');
    }
}
