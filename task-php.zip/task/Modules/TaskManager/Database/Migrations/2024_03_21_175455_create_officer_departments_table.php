<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateOfficerDepartmentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('officer_departments', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('master_id')->nullable();

            $table->unsignedBigInteger('officer_id')->nullable();

            $table->unsignedBigInteger('department_type_id')->nullable();
            $table->string('designation')->nullable();

            $table->string('l1')->nullable()->comment('Commissionerate/L1');
            $table->string('l2')->nullable()->comment('Division/Circle/L2');
            $table->string('l3')->nullable()->comment('Range/Charge/L3');

            $table->string('state')->nullable();
            $table->string('city')->nullable();
            $table->string('location')->nullable();

            $table->string('block_no')->nullable();
            $table->string('floor_no')->nullable();
            $table->string('room_no')->nullable();

            $table->tinyInteger('is_default')->default(0);

            $table->softDeletes();
            $table->timestamps();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->unsignedBigInteger('deleted_by')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('officer_departments');
    }
}
