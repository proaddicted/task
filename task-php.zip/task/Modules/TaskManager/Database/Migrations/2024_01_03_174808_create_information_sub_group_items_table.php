<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateInformationSubGroupItemsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('information_sub_group_items', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('master_id')->nullable();

            $table->unsignedBigInteger('information_item_id')->nullable();
            $table->unsignedBigInteger('information_sub_group_id')->nullable();


            $table->string('name')->nullable();
            $table->tinyInteger('is_multiple')->default(0);
            $table->tinyInteger('is_required')->default(0);
            $table->integer('order_no')->default(0);
            $table->longText('description')->nullable();
             
            $table->softDeletes();
            $table->timestamps();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->unsignedBigInteger('deleted_by')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('information_sub_group_items');
    }
}
