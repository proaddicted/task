<?php

namespace Modules\TaskManager\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Request;
use Geocoder;
use Exception;
use Illuminate\Support\Facades\Auth;

class TaskHistoryUpdateRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'user_id' => 'required',
            
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    protected function prepareForValidation()
    {
        $user = Auth::user();

        if($this->is_office_out)
        {
            $office_out_address = "";
            if($this->office_out_longitude != "" &&  $this->office_out_latitude != "")
            {
                if(env('GEOCODE_ENABLE'))
                {
                    try {
                        $geocode = Geocoder::getAddressForCoordinates($this->office_out_latitude,$this->office_out_longitude);
                    
                        if(!empty($geocode) && is_array($geocode))
                            $office_out_address = $geocode['formatted_address'];
                    } catch (Exception $ex) {
                        $office_out_address = $ex->getMessage();
                    }
                }    
            
            }      
            $this->merge([
                'user_id'=>$user->id,
                'office_out_time'=>!empty($this->office_out_time) ? $this->office_out_time : date('H:i:s'),
                'office_out_longitude'=>!empty($this->office_out_longitude) ? $this->office_out_longitude : '',
                'office_out_latitude'=>!empty($this->office_out_latitude) ? $this->office_out_latitude : '',
                'office_out_address'=>$office_out_address,
            ]);
        }
        if($this->is_meeting_in)
        {
            $meeting_in_address = "";
            if($this->meeting_in_longitude != "" &&  $this->meeting_in_latitude != "")
            {
                if(env('GEOCODE_ENABLE'))
                {
                    try {
                        $geocode = Geocoder::getAddressForCoordinates($this->meeting_in_latitude,$this->meeting_in_longitude);
                    
                        if(!empty($geocode) && is_array($geocode))
                            $meeting_in_address = $geocode['formatted_address'];
                    } catch (Exception $ex) {
                        $meeting_in_address = $ex->getMessage();
                    }
                }    
            
            }      
            $this->merge([
                'user_id'=>$user->id,
                'meeting_in_time'=>!empty($this->meeting_in_time) ? $this->meeting_in_time : date('H:i:s'),
                'meeting_in_longitude'=>!empty($this->meeting_in_longitude) ? $this->meeting_in_longitude : '',
                'meeting_in_latitude'=>!empty($this->meeting_in_latitude) ? $this->meeting_in_latitude : '',
                'meeting_in_address'=>$meeting_in_address,
            ]);
        }
        if($this->is_meeting_out)
        {
            $meeting_out_address = "";
            if($this->meeting_out_longitude != "" &&  $this->meeting_out_latitude != "")
            {
                if(env('GEOCODE_ENABLE'))
                {
                    try {
                        $geocode = Geocoder::getAddressForCoordinates($this->meeting_out_latitude,$this->meeting_out_longitude);
                    
                        if(!empty($geocode) && is_array($geocode))
                            $meeting_out_address = $geocode['formatted_address'];
                    } catch (Exception $ex) {
                        $meeting_out_address = $ex->getMessage();
                    }
                }    
            
            }      
            $this->merge([
                'user_id'=>$user->id,
                'meeting_out_time'=>!empty($this->meeting_out_time) ? $this->meeting_out_time : date('H:i:s'),
                'meeting_out_longitude'=>!empty($this->meeting_out_longitude) ? $this->meeting_out_longitude : '',
                'meeting_out_latitude'=>!empty($this->meeting_out_latitude) ? $this->meeting_out_latitude : '',
                'meeting_out_address'=>$meeting_out_address,
            ]);
        }
        if($this->is_office_in)
        {
            $office_in_address = "";
            if($this->office_in_longitude != "" &&  $this->office_in_latitude != "")
            {
                if(env('GEOCODE_ENABLE'))
                {
                    try {
                        $geocode = Geocoder::getAddressForCoordinates($this->office_in_latitude,$this->office_in_longitude);
                    
                        if(!empty($geocode) && is_array($geocode))
                            $office_in_address = $geocode['formatted_address'];
                    } catch (Exception $ex) {
                        $office_in_address = $ex->getMessage();
                    }
                }    
            
            }      
            $this->merge([
                'user_id'=>$user->id,
                'office_in_time'=>!empty($this->office_in_time) ? $this->office_in_time : date('H:i:s'),
                'office_in_longitude'=>!empty($this->office_in_longitude) ? $this->office_in_longitude : '',
                'office_in_latitude'=>!empty($this->office_in_latitude) ? $this->office_in_latitude : '',
                'office_in_address'=>$office_in_address,
            ]);
        }    
    }

    protected function failedValidation(\Illuminate\Contracts\Validation\Validator $validator)
    {
        
        $response = new JsonResponse(['data' => array(),'success'=>false,'message' => $validator->errors()], 422);

        throw new \Illuminate\Validation\ValidationException($validator, $response);
    
    }
}
