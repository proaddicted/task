<?php

namespace Modules\TaskManager\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class CommunicationRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'comment'  => 'required',
            'from_id' => 'required'
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    protected function prepareForValidation()
    {
        $recipients = [];
        $reads = [];

        if($this->communication_type == 'mail')
        {
            $tos  = [];
            $ccs  = [];
            $bccs  = [];

            $to_reads  = [];
            $cc_reads  = [];
            $bcc_reads  = [];

            if($this->to && count($this->to)>0)
            {
               
                foreach ($this->to as $key => $value) {
                    $tos[$key]['user_id'] = $value;
                    $tos[$key]['type'] = 'to';

                    $to_reads[$key]['user_id'] = $value;
                    $to_reads[$key]['is_read'] = 0;
                }
            }
            if($this->cc && count($this->cc)>0)
            {
                
                foreach ($this->cc as $key => $value) {
                    $ccs[$key]['user_id'] = $value;
                    $ccs[$key]['type'] = 'cc';

                    $cc_reads[$key]['user_id'] = $value;
                    $cc_reads[$key]['is_read'] = 0;
                }
            }
            if($this->bcc && count($this->bcc)>0)
            {
                
                foreach ($this->bcc as $key => $value) {
                    $bccs[$key]['user_id'] = $value;
                    $bccs[$key]['type'] = 'bcc';
                    
                    $bcc_reads[$key]['user_id'] = $value;
                    $bcc_reads[$key]['is_read'] = 0;
                }
            }
            $recipients = array_merge_recursive( $tos, $ccs, $bccs );

            $reads = array_merge_recursive( $to_reads, $cc_reads, $bcc_reads );
           // dd(array_merge_recursive( $tos, $ccs, $bccs ));
        }
       
        $this->merge([
            'parent_id'=>$this->parent_id > 0 ? $this->parent_id : 0 ,
            'master_id'=>request()->master_id,
            'date'=>!empty($this->date) ? $this->date : date('Y-m-d H:i:s'),
            'type'=>$this->communication_type,
            'is_schedule'=>$this->recursive_type > 0 ? 1 : 0,
            'recipients'=>$recipients ,
            'reads'=>$reads ,
            'weekly'=>$this->recursive_weeks,
            'custom_date'=>$this->custom_date
            
        ]);
    }
    protected function failedValidation(\Illuminate\Contracts\Validation\Validator $validator)
    {
        
        $response = new JsonResponse(['data' => array(),'success'=>false,'message' => $validator->errors()], 422);

        throw new \Illuminate\Validation\ValidationException($validator, $response);
    
    }
}
