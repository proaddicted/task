<?php

namespace Modules\TaskManager\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class InformationGroupRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name'  => 'required',
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    protected function prepareForValidation()
    {
        $information_sub_groups = [];
        $information_inner_items = [];
        $information_items = [];
        if(count($this->information_sub_groups))
        {
            $i = 0;
           
            foreach ($this->information_sub_groups as $key => $sub_group) 
            {
                $information_sub_groups[$key]=[
                    'information_sub_group_id'=>$sub_group['information_sub_group_id'],
                    'is_multiple'=>$sub_group['is_multiple'],
                    'is_required'=>$sub_group['is_required'],
                    'description'=>$sub_group['description'],
                    'order_no'=>$sub_group['order_no']
                ];
                if(count($sub_group['information_items']))
                {
                    foreach ($sub_group['information_items'] as $key2 => $information_item) 
                    {
                        $information_inner_items[$i]=[
                        'information_sub_group_id'=>$sub_group['information_sub_group_id'],
                        'information_item_id'=>$information_item['information_item_id'],
                        'is_multiple'=>$information_item['is_multiple'],
                        'is_required'=>$information_item['is_required'],
                        'description'=>$information_item['description'],
                        'order_no'=>$information_item['order_no'],
                        'type'=>$information_item['type'],
                        'value'=>$information_item['value']
                        ];
                        $i++;
                    }
                }
            }

        }
        if(count($this->information_items))
        {
            foreach ($this->information_items as $key => $value) 
            {
                $information_items[$key]=[
                    'information_item_id'=>$value['information_item_id'],
                    'is_multiple'=>$value['is_multiple'],
                    'is_required'=>$value['is_required'],
                    'description'=>$value['description'],
                    'order_no'=>$value['order_no'],
                    'type'=>$value['type'],
                    'value'=>$value['value']
                    ];
            }
        }

        $this->merge([
            'master_id'=>request()->master_id,
            'information_items'=> $information_items,
            'information_inner_items'=>$information_inner_items,
            'information_sub_groups'=>$information_sub_groups
            
        ]);
    }
    protected function failedValidation(\Illuminate\Contracts\Validation\Validator $validator)
    {
        
        $response = new JsonResponse(['data' => array(),'success'=>false,'message' => $validator->errors()], 422);

        throw new \Illuminate\Validation\ValidationException($validator, $response);
    
    }
}
