<?php

namespace Modules\TaskManager\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Carbon\Carbon;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;
use Modules\TaskManager\Entities\Task;
use Modules\TaskManager\Transformers\TaskResource;
use Modules\TaskManager\Transformers\TaskCheckListResource;
use App\Notifications\KnowlarityNotification;//24/08/2024
use Modules\TaskManager\Entities\CallViewTrack;//24/08/2024
use App\Models\Service;
use App\Models\User;
use Modules\ContactManager\Entities\Group;
use Modules\ContactManager\Entities\Contact;
use Modules\TaskManager\Entities\CheckList;
use App\Models\MasterType;
use Modules\ResourceManager\Entities\Employee;
use Modules\TaskManager\Entities\TaskCheckList;
use Modules\TaskManager\Entities\TaskChangeLog;
use App\Models\TempFile;
use App\Models\File;
use App\Exports\CallLogExcelExport;
use Modules\TaskManager\Entities\CustomTemplate;
use Modules\TaskManager\Entities\TaskNote;
use Modules\AttendanceManager\Entities\DailyAttendanceReport;
use Modules\AttendanceManager\Entities\DailyAttendance;
use Modules\AttendanceManager\Entities\DailyAttendanceLog;
use App\Traits\EmployeeTrait;

use Modules\TaskManager\Entities\InformationItem;
use Modules\TaskManager\Entities\InformationSubGroup;
use Modules\TaskManager\Entities\InformationGroup;

use Modules\TaskManager\Entities\MeetingRequest;
use Modules\TaskManager\Entities\TaskInvitie;
use Modules\TaskManager\Entities\Communication;

use Illuminate\Support\Facades\Notification;
use App\Models\NotificationTemplate;
use Modules\TaskManager\Notifications\OnlineInviteNotification;
use Modules\TaskManager\Notifications\OnlineInvitationRejectNotification;
use App\Notifications\SendNotification;
use Modules\TaskManager\Http\Requests\TaskHistoryUpdateRequest;
use Modules\TaskManager\Entities\TaskHistory;

use Modules\TaskManager\Entities\TaskIstChangeRequest;

use Modules\TaskManager\Entities\TaskDepartmentInformation;
use Modules\TaskManager\Entities\Officer;

use App\Models\Phone;
use App\Exports\TaskExcelExport;
use Maatwebsite\Excel\Facades\Excel;
use Modules\TaskManager\Entities\CallLog;
use Modules\TaskManager\Entities\TaskSchedule;
use Illuminate\Support\Facades\Mail;
use App\Models\NotificationLog;
use App\Notifications\SendSmsNotification;
use App\Mail\MailChimp;
use App\Models\FiscalYear;


use Modules\TaskManager\Entities\TaskFlag;
use Modules\TaskManager\Entities\TicketStage;
use phpDocumentor\Reflection\Types\Null_;

class TaskController extends Controller
{
    use PermissionTrait,CommonTrait,EmployeeTrait;
    public $notification_batch_id=0,$template_body='';

    public function headers(Request $request)
    {
        if($request->type == 'regular-ticket')
        {
            $headers = array(
                array('column_name'=>'name','display_name'=>'Name','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
                array('column_name'=>'group','display_name'=>'Group','is_display'=>1,'is_default'=>1,'is_sortable'=>0 , 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'),
                array('column_name'=>'companies','display_name'=>'Company','is_display'=>1,'is_default'=>1,'is_sortable'=>0,'is_multiple'=>1,'child_column'=>'fname'), 
                array('column_name'=>'contacts','display_name'=>'Contacts','is_display'=>1,'is_default'=>1,'is_sortable'=>0,'is_multiple'=>1,'child_column'=>'full_name'), 
                array('column_name'=>'services','display_name'=>'Services','is_display'=>1,'is_default'=>1,'is_sortable'=>0,'is_multiple'=>1,'child_column'=>'name'), 
                array('column_name'=>'start_date','display_name'=>'Start Date','is_display'=>1,'is_default'=>1,'is_sortable'=>1), //15/07/2024
                array('column_name'=>'due_date','display_name'=>'Due Date','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
                // array('column_name'=>'ecd','display_name'=>'ECD','is_display'=>1,'is_default'=>0,'is_sortable'=>1), //15/07/2024
                array('column_name'=>'standard_time','display_name'=>'Standard Time','is_display'=>1,'is_default'=>0,'is_sortable'=>1), //15/07/2024
                array('column_name'=>'employees','display_name'=>'Employees','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
                array('column_name'=>'status_name','display_name'=>'Status','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
                array('column_name'=>'priority_name','display_name'=>'Priority','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
                array('column_name'=>'task_flag','display_name'=>'Task Flags','is_display'=>1,'is_default'=>0,'is_sortable'=>0,'is_multiple'=>1), //15/07/2024
                array('column_name'=>'ticket_stages','display_name'=>'Ticket Stages','is_display'=>1,'is_default'=>0,'is_sortable'=>0,'is_multiple'=>1), //15/07/2024
                array('column_name'=>'referral','display_name'=>'Referral','is_display'=>1,'is_default'=>0,'is_sortable'=>0,'is_multiple'=>0), //15/07/2024
             
                array('column_name'=>'creator','display_name'=>'Created By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
                array('column_name'=>'editor','display_name'=>'Updated By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
                array('column_name'=>'updated_at','display_name'=>'Updated On','is_display'=>1,'is_default'=>1,'is_sortable'=>1), 
                array('column_name'=>'created_at','display_name'=>'Added On','is_display'=>1,'is_default'=>0,'is_sortable'=>1)         
            );
        }
        elseif($request->type == 'ist')
        {
            $headers = array(
                array('column_name'=>'name','display_name'=>'Name','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            
             
                array('column_name'=>'start_date','display_name'=>'Start Date','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
                array('column_name'=>'description','display_name'=>'Description','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
                array('column_name'=>'ist_type_name','display_name'=>'Type','is_display'=>1,'is_default'=>1,'is_sortable'=>1),

                array('column_name'=>'members','display_name'=>'Employee','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
                array('column_name'=>'supervisor','display_name'=>'HR Manager','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
                array('column_name'=>'manager','display_name'=>'Manager','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
              
                array('column_name'=>'status_name','display_name'=>'Status','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
                array('column_name'=>'priority_name','display_name'=>'Priority','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
                array('column_name'=>'creator','display_name'=>'Created By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
                array('column_name'=>'editor','display_name'=>'Updated By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
                array('column_name'=>'updated_at','display_name'=>'Updated On','is_display'=>1,'is_default'=>1,'is_sortable'=>1), 
                array('column_name'=>'created_at','display_name'=>'Added On','is_display'=>1,'is_default'=>0,'is_sortable'=>1)          
            );
        }
        elseif($request->type == 'memorized-ticket')
        {
            $headers = array(
                array('column_name'=>'name','display_name'=>'Name','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
                array('column_name'=>'companies','display_name'=>'Company','is_display'=>1,'is_default'=>1,'is_sortable'=>0,'is_multiple'=>1,'child_column'=>'fname'), 
                array('column_name'=>'contacts','display_name'=>'Contacts','is_display'=>1,'is_default'=>1,'is_sortable'=>0,'is_multiple'=>1,'child_column'=>'full_name'), 
                array('column_name'=>'services','display_name'=>'Services','is_display'=>1,'is_default'=>1,'is_sortable'=>0,'is_multiple'=>1,'child_column'=>'name'), 
                array('column_name'=>'due_date','display_name'=>'Due Date','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
                array('column_name'=>'employees','display_name'=>'Employees','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
                array('column_name'=>'status_name','display_name'=>'Status','is_display'=>1,'is_default'=>0,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
                array('column_name'=>'priority_name','display_name'=>'Priority','is_display'=>0,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
                array('column_name'=>'recursive_type_name','display_name'=>'Recursive Type','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
                array('column_name'=>'creator','display_name'=>'Created By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
                array('column_name'=>'editor','display_name'=>'Updated By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
                array('column_name'=>'updated_at','display_name'=>'Updated On','is_display'=>1,'is_default'=>1,'is_sortable'=>1), 
                array('column_name'=>'created_at','display_name'=>'Added On','is_display'=>1,'is_default'=>0,'is_sortable'=>1)         
            );
        }
        elseif($request->type == 'call')
        {
            $headers = array(
                array('column_name'=>'name','display_name'=>'Name','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
                array('column_name'=>'employees','display_name'=>'Employee','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
                array('column_name'=>'description','display_name'=>'Description','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
                array('column_name'=>'start_date','display_name'=>'Start Date','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
                array('column_name'=>'group','display_name'=>'Group','is_display'=>1,'is_default'=>1,'is_sortable'=>0 , 'is_belongs'=>1,'child_column'=>'name'),
                array('column_name'=>'companies','display_name'=>'Company','is_display'=>1,'is_default'=>1,'is_sortable'=>0,'is_multiple'=>1,'child_column'=>'fname'), 
                array('column_name'=>'ticket_name','display_name'=>'Related Ticket','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),  // 26/09/2024 Jyoti 
                array('column_name'=>'contacts','display_name'=>'Contacts','is_display'=>1,'is_default'=>1,'is_sortable'=>0,'is_multiple'=>1,'child_column'=>'full_name'),
                array('column_name'=>'status_name','display_name'=>'Status','is_display'=>1,'is_default'=>1,'is_sortable'=>1,'is_belongs'=>0),
                array('column_name'=>'priority_name','display_name'=>'Priority','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_belongs'=>0),
                array('column_name'=>'creator','display_name'=>'Created By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_belongs'=>1,'child_column'=>'name'), 
                array('column_name'=>'editor','display_name'=>'Updated By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_belongs'=>1,'child_column'=>'name'), 
                array('column_name'=>'updated_at','display_name'=>'Updated On','is_display'=>1,'is_default'=>1,'is_sortable'=>1), 
                array('column_name'=>'created_at','display_name'=>'Added On','is_display'=>1,'is_default'=>0,'is_sortable'=>1)        
            );
        }
        elseif($request->type == 'meeting')
        {
            $headers = array(
                array('column_name'=>'name','display_name'=>'Name','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
                array('column_name'=>'employees','display_name'=>'Employee','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
                array('column_name'=>'description','display_name'=>'Description','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
                array('column_name'=>'start_date','display_name'=>'Start Date','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
                array('column_name'=>'location','display_name'=>'Location','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
                array('column_name'=>'standard_time','display_name'=>'Duration','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
                array('column_name'=>'remarks','display_name'=>'Remarks','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
                array('column_name'=>'meeting_type','display_name'=>'Meeting Type','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
                array('column_name'=>'group','display_name'=>'Group','is_display'=>1,'is_default'=>1,'is_sortable'=>0 , 'is_belongs'=>1,'child_column'=>'name'),
                array('column_name'=>'companies','display_name'=>'Company','is_display'=>1,'is_default'=>1,'is_sortable'=>0,'is_multiple'=>1,'child_column'=>'fname'), 
                array('column_name'=>'ticket_name','display_name'=>'Related Ticket','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),  // 26/09/2024 Jyoti 
                array('column_name'=>'contacts','display_name'=>'Contacts','is_display'=>1,'is_default'=>1,'is_sortable'=>0,'is_multiple'=>1,'child_column'=>'full_name'),
                array('column_name'=>'status_name','display_name'=>'Status','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
                array('column_name'=>'priority_name','display_name'=>'Priority','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
                array('column_name'=>'creator','display_name'=>'Created By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
                array('column_name'=>'editor','display_name'=>'Updated By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
                array('column_name'=>'updated_at','display_name'=>'Updated On','is_display'=>1,'is_default'=>1,'is_sortable'=>1), 
                array('column_name'=>'created_at','display_name'=>'Added On','is_display'=>1,'is_default'=>0,'is_sortable'=>1)  
            );
        }
        elseif($request->type == 'todo')
        {
            $headers = array(
                array('column_name'=>'name','display_name'=>'Name','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
                array('column_name'=>'employees','display_name'=>'Employee','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
                array('column_name'=>'description','display_name'=>'Description','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
                array('column_name'=>'start_date','display_name'=>'Start Date','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
                array('column_name'=>'group','display_name'=>'Group','is_display'=>1,'is_default'=>1,'is_sortable'=>0 , 'is_belongs'=>1,'child_column'=>'name'),
                array('column_name'=>'companies','display_name'=>'Company','is_display'=>1,'is_default'=>1,'is_sortable'=>0,'is_multiple'=>1,'child_column'=>'fname'), 
                array('column_name'=>'ticket_name','display_name'=>'Related Ticket','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),  // 26/09/2024 Jyoti 
                array('column_name'=>'contacts','display_name'=>'Contacts','is_display'=>1,'is_default'=>1,'is_sortable'=>0,'is_multiple'=>1,'child_column'=>'full_name'),
                array('column_name'=>'status_name','display_name'=>'Status','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
                array('column_name'=>'priority_name','display_name'=>'Priority','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
                array('column_name'=>'creator','display_name'=>'Created By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
                array('column_name'=>'editor','display_name'=>'Updated By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
                array('column_name'=>'updated_at','display_name'=>'Updated On','is_display'=>1,'is_default'=>1,'is_sortable'=>1), 
                array('column_name'=>'created_at','display_name'=>'Added On','is_display'=>1,'is_default'=>0,'is_sortable'=>1)  
            );
        }
        elseif($request->type == 'department-task')
        {
            $headers = array(
                array('column_name'=>'name','display_name'=>'Name','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
                array('column_name'=>'group','display_name'=>'Group','is_display'=>1,'is_default'=>1,'is_sortable'=>0 , 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'),
                array('column_name'=>'companies','display_name'=>'Company','is_display'=>1,'is_default'=>1,'is_sortable'=>0,'is_multiple'=>1,'child_column'=>'fname'), 
                array('column_name'=>'ticket_name','display_name'=>'Related Ticket','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),  // 26/09/2024 Jyoti 
                array('column_name'=>'contacts','display_name'=>'Contacts','is_display'=>1,'is_default'=>1,'is_sortable'=>0,'is_multiple'=>1,'child_column'=>'full_name'), 
                array('column_name'=>'services','display_name'=>'Services','is_display'=>1,'is_default'=>1,'is_sortable'=>0,'is_multiple'=>1,'child_column'=>'name'), 
                array('column_name'=>'start_date','display_name'=>'Start Date','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
                array('column_name'=>'due_date','display_name'=>'Due Date','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
                array('column_name'=>'ecd','display_name'=>'ECD','is_display'=>1,'is_default'=>0,'is_sortable'=>1), 
                array('column_name'=>'standard_time','display_name'=>'Standard Time','is_display'=>1,'is_default'=>0,'is_sortable'=>1), 
                array('column_name'=>'employees','display_name'=>'Employees','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
                array('column_name'=>'location','display_name'=>'Location','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
                
                array('column_name'=>'officers','display_name'=>'Officers','is_display'=>1,'is_default'=>1,'is_sortable'=>0,'is_multiple'=>1,'child_column'=>'name'), 
                array('column_name'=>'status_name','display_name'=>'Status','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
                array('column_name'=>'priority_name','display_name'=>'Priority','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
                array('column_name'=>'creator','display_name'=>'Created By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
                array('column_name'=>'editor','display_name'=>'Updated By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
                array('column_name'=>'updated_at','display_name'=>'Updated On','is_display'=>1,'is_default'=>1,'is_sortable'=>1), 
                array('column_name'=>'created_at','display_name'=>'Added On','is_display'=>1,'is_default'=>0,'is_sortable'=>1)  
            );
        }
        

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    public function getlist(Request $request)
    {

        $data['groups'] = Group::where('status',1)->get();
        $data['employees'] = User::where('type','employee')->select('id','name','profile','email')->get();
        $data['externals'] = User::whereNull('type')->select('id','name','profile','email')->get();
        $data['services'] = Service::with('children')->where('status',1)->orderBy('name','asc')->where('parent_id',0)->get();
        $data['companies']=Contact::where('status',1)->where('type','company')->select('fname','mname','lname','id','profile','phone','email','group_id')->get();
        $data['contacts']=Contact::where('status',1)->where('type','individual')->select('fname','mname','lname','id','profile','phone','email')->get();
        $data['officers']=Officer::where('status',1)->select('fname','mname','lname','id','phone','email','hide_phone','hide_email')->get();
        $data['check_lists']=CheckList::select('id','name')->with('items')->where('status',1)->get();
        $data['custom_templates']=CustomTemplate::select('id','name','identifier','body')->where('status',1)->whereIn('identifier',['description','sms','email'])->get();
        $data['ticket_statuses']= $this->ticket_statuses;
        $data['task_statuses']= $this->task_statuses;
        $data['ticket_priorities']= $this->ticket_priorities;
        $data['ist_statuses']= $this->ist_statuses;
        $data['department_task_types']= $this->department_task_types;
        $data['department_task_modes']= $this->department_task_modes;
        $data['master_types'] = MasterType::where('status',1)->whereIn('identifier',['expense','document','file-stage','file-source-1','file-source-2','file-source-3','department-purpose'])->select('id','name','identifier')->get();
        $data['attendance_statuses'] = $this->attendance_report_status;
        $data['recursive_types']= $this->recursive_types;
        $data['recursive_weeks']= $this->recursive_weeks;
        $data['ist_types']= $this->ist_types;
        $data['task_types']= $this->task_types;
        $data['attendance_report_status'] = $this->attendance_report_status;
        $data['task_flags'] = TaskFlag::where('status',1)->get();
        $data['ticket_stages'] = TicketStage::where('status',1)->get();
        $data['task_change_log']=DB::table('task_change_logs')->selectRaw("column_name as name,CONCAT(UPPER(REPLACE(REPLACE(column_name, '_', ' '), '-', ' '))) AS formatted_name")->where('column_name','!=',null)->groupBy('column_name')->whereNull('deleted_at')->get();//14/09/2024
        $data['fiscal_years']=FiscalYear::get();

        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
   
    /**
     * Excel Export for Tasks
     * @author Debargha Chakraborty <debargha.chakraborty01@gmail.com>
     * @copyright Copyright (c) 2024, Debargha Chakraborty 
     * @return \Illuminate\Http\Response
     */
    public function export(Request $request)
    {
        parse_str($request->filter, $output); 
        $result = ['per_page' => $request->per_page, 'page' => $request->page, 'search' => $request->search, 'sort' => $request->sort, 'filter' => $output['filter'], 'advfilter' => isset($output['advfilter'])?$output['advfilter']:[], 'page_url' =>$request->page_url]; 
        
        if($request->type=='regular-ticket')
        {
            $excel_name='Regular Ticket';
            $headings=[
                'Name',
                'Company', 
                'Contacts', 
                'Services', 
                'Due Date',
                'Employees',
                'Status',
                'Priority',
                'Updated On',
                'Added On',    
            ];
        }
        $saved_excel_name=$excel_name.'_'.date('d-m-Y H:i:s').'.xlsx';
        $save_file=Excel::store(new TaskExcelExport($result,$headings),$saved_excel_name);

        if($save_file && file_exists(storage_path('/app/'.$saved_excel_name)))
        {
            $file = storage_path('/app/'.$saved_excel_name);
            return  response()->file($file);
        }
        else
            return response(['data' => array(),'success'=>false,'message' => "Invalid File Path"], 500);    
    }

    /**
     * all task list
     * @author Debargha Chakraborty <debargha.chakraborty01@gmail.com>
     * @copyright Copyright (c) 2024, Debargha Chakraborty  20/09/2024
     * @return \Illuminate\Http\Response
     */   
    public function get_all_tasks(Request $request)
    {
        $authuser = Auth::user();

        $query=Task::with('companies', 'contacts', 'services')->whereNotNull('name');

        if($authuser->is_superadmin==0)
        {
            $query->whereHas('employees', function ($q) use ($authuser) {
                $q->where('task_users.user_id', $authuser->id);
            });
        }
    
        $tasks=$query->where('status', 0)->get()->toArray();

        return response(['data' => $tasks, 'success' => true, 'message' => 'Data Retrived Successfully'], 200);
    }
     

     /**
     * store all tickets from old sahaj
     * 10/08/2024 04/10/2024
     * @author Debargha Chakraborty <debargha.chakraborty01@gmail.com>
     * @copyright Copyright (c) 2024, Debargha Chakraborty 
     * @return \Illuminate\Http\Response
     */
    public function store_all_tickets(Request $request)
    {
        $task = new Task;
        $task->id = $request->id;
        $task->name = $request->name;
        $task->master_id = $request->master_id;
        $task->parent_id = $request->parent_id;
        $task->start_date = $request->start_date;
        $task->due_date = $request->due_date;
        $task->status = $request->status;
        $task->priority = $request->priority;
        $task->start_period = $request->start_period;
        $task->end_period = $request->end_period;
        $task->referral_id = $request->referral_id;
        $task->recursive_task_id = $request->recursive_ticket_id;
        $task->recursive_last_created = $request->recursive_last_created;
        $task->recursive_type = $request->recursive_type;
        $task->recursive_end_date = $request->recursive_end_date;
        $task->recursive_days = $request->recursive_days;
        $task->ecd = $request->ecd;
        $task->received_date = $request->received_date;
        $task->created_at = $request->created_at;
        $task->updated_at = $request->updated_at;
        $task->created_by = $request->created_by;
        $task->updated_by = $request->updated_by;
        $task->deleted_at = $request->deleted_at;

        if ($request->type == 0)
            $task->type = 'regular-ticket';
        elseif ($request->type == 1)
            $task->type = 'sub-ticket';
        elseif ($request->type == 2)
            $task->type = 'help-ticket';
        elseif ($request->type == 3 || $request->type == 5)
            $task->type = 'department-task';
        elseif ($request->type == 4)
            $task->type = 'memorized-ticket';

        $task->save();
            DB::table('tasks')->where('id',$task->id)->update(['master_id'=>1]);
        /*****Company,Group******/
        if (isset($request->company['id'])) 
        {
            $task->companies()->detach();
            $task->companies()->attach([$request->company['id']], ['master_id' => $task->master_id, 'created_by' => 1, 'updated_by' =>1, 'created_at' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s')]);
            /*****Group******/
            if (count($request->company['group'])) {
                DB::table('tasks')->where('id',$task->id)->update(['group_id'=>$request->company['group'][0]['id']]);
            }
        }
        /*****Employee******/
        if (isset($request->employee) && count($request->employee) > 0)
        {
            $employee = [];
            foreach ($request->employee as $key => $value) 
            {
                if ($emp = Employee::where('id', $value['id'])->first())
                    $employee[$key] = ['user_id' => $emp->user_id, 'main_id' => $emp->id];
            }
            if(count($employee))
            {
                $task->employees()->attach($employee, ['master_id' => 1, 'type' => 'employee', 'identifier' => 'employee', 'created_by' => 1, 'updated_by' => 1, 'created_at' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s')]);
            }
        }
        /*****Manager******/
        if (isset($request->manager) && count($request->manager) > 0) 
        {
            $manager = [];
            foreach ($request->manager as $key => $value) 
            {
                if ($emp = Employee::where('id', $value['id'])->first())
                    $manager[$key] = ['user_id' => $emp->user_id, 'main_id' => $emp->id];
            }
            if(count($manager))
            {
                $task->employees()->attach($manager, ['master_id' => 1, 'type' => 'manager', 'identifier' => 'employee', 'created_by' => 1, 'updated_by' => 1, 'created_at' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s')]);
            }
        }
        /*****Supervisor******/
        if (isset($request->supervisor) && count($request->supervisor) > 0) 
        {
            $supervisor = [];

            foreach ($request->supervisor as $key => $value) 
            {
                if ($emp = Employee::where('id', $value['id'])->first())
                    $supervisor[$key] = ['user_id' => $emp->user_id, 'main_id' => $emp->id];
            }
            if(count($supervisor))
            {
                $task->employees()->attach($supervisor, ['master_id' => 1, 'type' => 'supervisor', 'identifier' => 'employee', 'created_by' => 1, 'updated_by' => 1, 'created_at' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s')]);
            }
        }
        /*****Contact******/
        if (isset($request->contact_rel) && count($request->contact_rel) > 0) 
        {
            $contact=[];
            foreach ($request->contact_rel as $key => $value) 
            {
                if ($cons = Contact::where('id', $value['id'])->first())
                    $contact[$key] = $value['id'];
            }
            if(count($contact))
            {
                $task->contacts()->detach();
                $task->contacts()->attach($contact, ['master_id' => 1, 'created_by' => 1, 'updated_by' => 1, 'created_at' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s')]);
            }
            
        }

        /*****Service******/
        if (isset($request->service) && count($request->service) > 0) 
        {
            $services=[];
            
            foreach ($request->service as $key => $value) 
            {
                if ($serv = Service::where('id', $value['id'])->first())
                    $services[$key] = $value['id'];
            }
            // print_r($services);
            // echo end($services);exit;
            if(count($services)>0)
            {
                $task->services()->detach();
                $task->services()->attach(end($services), ['master_id' => 1, 'created_by' => 1, 'updated_by' => 1, 'created_at' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s')]);
            }
        }
        /*****Flag******/
        if (isset($request->department_flag) && count($request->department_flag) > 0) 
        {
            $flags=[];
            foreach ($request->department_flag as $key => $value) 
            {
                if ($flag = TaskFlag::where('id', $value['id'])->first())
                    $flags[$key] = $value['id'];
            }
            if(count($flags)>0)
            {
                $task->task_flags()->detach();
                $task->task_flags()->attach($flags,['master_id'=>1,'created_by'=>1,'updated_by'=>1,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
            }
        }
        /**********Officers***********/
        if (isset($request->ticket_officer) && count($request->ticket_officer )) 
        {
            $task->officers()->detach();
            foreach($request->ticket_officer as $officer)
            {
                $task->officers()->attach($officer['id'], ['master_id' => 1, 'created_by' => $officer['pivot']['created_by'], 'updated_by' => $officer['pivot']['created_by'], 'created_at' =>  $officer['pivot']['created_at'], 'updated_at' => $officer['pivot']['updated_at']]);
            }
        }
    }    

    //08/10/2024 for activity task
    public function store_all_activities(Request $request)
    {
        $task = new Task;
        $task->master_id = $request->master_id;
        $task->main_id = $request->main_id;
        $task->start_date = $request->start_date;
        // $task->due_date = $item['due_date;
        $task->status = $request->status;
        $task->type = $request->type;
        $task->location = $request->location;
        $task->remarks = $request->remarks;
        $task->description = $request->description;
        $task->created_at = $request->created_at;
        $task->updated_at = $request->updated_at;
        $task->created_by = $request->created_by;
        $task->updated_by = $request->updated_by;
        $task->deleted_at = $request->deleted_at;
        if($task->save()==TRUE)
        {
            DB::table('tasks')->where('id',$task->id)->update(['master_id'=>1]);
            /*****Company******/
            if($request->company_id>0)
            {
                $task->companies()->detach();
                $task->companies()->attach([$request->company_id], ['master_id' => $task->master_id, 'created_by' => 1, 'updated_by' =>1, 'created_at' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s')]);
            }

            /*********task invities starts******** */
            if($request->type=='meeting')
            {
                if ($request->invitie_employee && count($request->invitie_employee)) 
                {
                    foreach ($request->invitie_employee as $key => $emp) {

                        $employee=Employee::find($emp['id']);

                        if(isset($employee->user_id) && $employee->user_id>0)
                        {
                            $data['user_id'] = $employee->user_id;
                            $data['type'] = 'employee';
                            $data['main_id'] = 0;
                            $object = new TaskInvitie($data);
                            $task->invities()->save($object);

                            /**********task users**********/
                            if ($employee->user_id == $request->created_by) 
                            {
                                $task->employees()->attach(['user_id' => $employee->user_id, 'main_id' => $employee->id], ['master_id' => 1, 'type' => 'supervisor', 'identifier' => 'employee', 'created_by' => 1, 'updated_by' => 1, 'created_at' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s')]);
                            }
                            else
                            {
                                $task->employees()->attach(['user_id' => $employee->user_id, 'main_id' => $employee->id], ['master_id' => 1, 'type' => 'employee', 'identifier' => 'employee', 'created_by' =>1, 'updated_by' => 1, 'created_at' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s')]);
                            }


                        }
                    }
                }
                if ($request->invitie_contact && count($request->invitie_contact)) 
                {
                    foreach ($request->invitie_contact as $key => $con) {

                        $contact=Contact::find($con['id']);

                        if(isset($contact->user_id) && $contact->user_id>0)
                        {
                            $data['user_id'] = $contact->user_id;
                            $data['type'] = 'contact';
                            $data['main_id'] = 0;
                            $object = new TaskInvitie($data);
                            $task->invities()->save($object);

                            
                        /**********task contacts********* */
                            $task->contacts()->detach();
                            $task->contacts()->attach($contact->id, ['master_id' => 1, 'created_by' => 1, 'updated_by' => 1, 'created_at' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s')]);
                        }
                        

                    }
                }
            }
            /*********task invities ends******** */
            elseif ($request->type=='call')
            {
                if ($request->invitie_employee && count($request->invitie_employee)) 
                {
                    foreach ($request->invitie_employee as $key => $emp) {

                        $employee=Employee::find($emp['id']);

                        if(isset($employee->user_id) && $employee->user_id>0)
                        {
                            /**********task users**********/
                            if ($employee->user_id == $request->created_by) 
                            {
                                $task->employees()->attach(['user_id' => $employee->user_id, 'main_id' => $employee->id], ['master_id' => 1, 'type' => 'supervisor', 'identifier' => 'employee', 'created_by' => 1, 'updated_by' => 1, 'created_at' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s')]);
                            }
                            else
                            {
                                $task->employees()->attach(['user_id' => $employee->user_id, 'main_id' => $employee->id], ['master_id' => 1, 'type' => 'employee', 'identifier' => 'employee', 'created_by' =>1, 'updated_by' => 1, 'created_at' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s')]);
                            }


                        }
                    }
                }
                if ($request->invitie_contact && count($request->invitie_contact)) 
                {
                    foreach ($request->invitie_contact as $key => $con) 
                    {
                        $contact=Contact::find($con['id']);
                        if(isset($contact->user_id) && $contact->user_id>0)
                        {
                            /**********task contacts**********/
                            $task->contacts()->detach();
                            $task->contacts()->attach($contact->id, ['master_id' => 1, 'created_by' => 1, 'updated_by' => 1, 'created_at' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s')]);
                        }
                    }
                }
            }
            elseif ($request->type=='todo')
            {
                if ($request->emp_id && count($request->emp_id)) 
                {
                        $employee=Employee::find($request->emp_id);

                        if(isset($employee->user_id) && $employee->user_id>0)
                        {
                                $task->employees()->attach(['user_id' => $employee->user_id, 'main_id' => $employee->id], ['master_id' => 1, 'type' => 'supervisor', 'identifier' => 'employee', 'created_by' => 1, 'updated_by' => 1, 'created_at' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s')]);
                        }
                }
            }
        }
    }

    public function store_all_ist(Request $request)
    {
        $task = new Task;
        $task->master_id = $request->master_id;
        $task->start_date = $request->created_at;
        $task->received_date = $request->created_at;

        // $task->due_date = $item['due_date'];
        $task->status = $request->status;
        $task->type = 'ist';
        // $task->remarks = $item->remarks;
        // $task->description = $item['description;
        $task->created_at = $request->created_at;
        $task->updated_at = $request->updated_at;
        $task->created_by = $request->created_by;
        $task->updated_by = $request->updated_by;
        $task->deleted_at = $request->deleted_at;
        
        if($task->save()==TRUE)
        {
            DB::table('tasks')->where('id',$task->id)->update(['master_id'=>1]);
            if(count($request->department)>0)
            {
                foreach($request->department as $dept)
                {
                    $data=[];
                    $data['master_id']=$dept['master_id'];
                    $data['main_id']=$task->id;
                    $data['ist_department_id']=$dept['pivot']['ist_department_id'];
                    $data['identifier']=$dept['pivot']['identifier'];
                    $data['old_sahaj_ist_id']=$request->id;
                    $data['created_at']=$dept['pivot']['created_at'];
                    $data['updated_at']=$dept['pivot']['updated_at'];
                    $data['created_by']=$dept['pivot']['created_by'];
                    $data['updated_by']=$dept['pivot']['updated_by'];
                    DB::table('internalsupportticket_department_rel')->insert($data);
                    
                }
            }
            if(count($request->internalsupportticket_employee_rel)>0)
            {
                $employee = [];
                $manager=[];
                foreach ($request->internalsupportticket_employee_rel as $key => $value) 
                {
                    if ($emp = Employee::where('id', $value['id'])->first())
                    {
                            $manager[$key] = ['user_id' => $emp->user_id, 'main_id' => $emp->id];
                    }
                }
                $creator=Employee::where('user_id',$request->created_by)->first();
                if(isset($creator->user_id))
                {
                    $employee[$key] = ['user_id' => $creator->user_id, 'main_id' => $creator->id];
                    $task->employees()->attach($employee, ['master_id' => 1, 'type' => 'employee', 'identifier' => 'employee', 'created_by' => 1, 'updated_by' => 1, 'created_at' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s')]);
                }
                if(count($manager))
                {
                    $task->employees()->attach($manager, ['master_id' => 1, 'type' => 'employee', 'identifier' => 'manager', 'created_by' => 1, 'updated_by' => 1, 'created_at' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s')]);
                }
            }

        }
    }


    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index(Request $request)
    {
        $query = QueryBuilder::for(Task::class)->allowedFilters(['name','description', AllowedFilter::exact('parent_id')->ignore(null), AllowedFilter::exact('status')->ignore(null), AllowedFilter::exact('priority')->ignore(null), AllowedFilter::exact('type')->ignore(null), AllowedFilter::exact('ist_type')->ignore(null)])->defaultSort('-created_at')->allowedSorts('name','description','start_date','received_date','due_date','ecd','completed_date','start_period','end_period','recursive_end_date','recursive_days','recursive_last_created','status','type','priority','ist_type');

        $query->search(!empty($request->search)?$request->search:"");

        $task_type='';
        if(isset($request->filter['type']))
            $task_type=$request->filter['type'];

        $tasks = $query->taskadvanceSearch($request->advfilter,'tasks', $task_type)->with('group','services','contacts','companies','employees','files','check_lists','members','supervisor','manager','change_logs','change_logs.creator', 'ticket_stages', 'referral', 'task_flags','officers','department_tasks','creator','editor','main_task')->withCount('calls','meetings','todos','help_tickets','department_tasks','crds','communications')->taskCheckPermission()->paginate($request->per_page); // 26/09/2024 Jyoti

        /*->with( ['department_tasks'=> function($q){
            $q->whereIn('status',[0,1,2,]);
       }])*/

        $this->saveAdvanceSearchData($request);
        
        return response(['data' => $tasks,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    /**
     * For old CRM Attendance Report
     * @author Debargha Chakraborty <debargha.chakraborty01@gmail.com>
     * @copyright Copyright (c) 2024, Debargha Chakraborty 
     * @return \Illuminate\Http\Response
     */   
    public function add_sahaj_attendance($attendance_report_id)
    {
        $attendance_report=DailyAttendanceReport::with('tasks.invities')->where('id',$attendance_report_id)->first();
        $ch = curl_init(env('OLD_SAHAJ_LINK').'add_newcrm_attendance?master=dost');
        $jsonData = json_encode($attendance_report);
       
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Content-Length: ' . strlen($jsonData)
        ]);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);

        $response = curl_exec($ch);

        if ($response === false) {
            $error = curl_error($ch);
            curl_close($ch);
            throw new Exception("cURL error: $error");
        }

        curl_close($ch);
    }
    /**
     * For old CRM IST request
     * @author Debargha Chakraborty <debargha.chakraborty01@gmail.com>
     * @copyright Copyright (c) 2024, Debargha Chakraborty 
     * @return \Illuminate\Http\Response
     */   
     public function add_ist_request(Request $request,$id)
     {
        $ch = curl_init(env('OLD_SAHAJ_LINK').'store_ist_new_crm/'.$id.'?master=dost'); 

        $jsonData = json_encode($request->toArray());
        // print_r($jsonData);
       // dd('stop');
       curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
       curl_setopt($ch, CURLOPT_POST, true);
       curl_setopt($ch, CURLOPT_HTTPHEADER, [
           'Content-Type: application/json',
           'Content-Length: ' . strlen($jsonData)
       ]);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);

        $response = curl_exec($ch);
        //print_r($response);
        //dd('stop');
        if ($response === false) {
           $error = curl_error($ch);
           curl_close($ch);
           throw new Exception("cURL error: $error");
       }
       
        curl_close($ch);
     }

     /**
     * Activity Log for Tasks
     * @author Debargha Chakraborty <debargha.chakraborty01@gmail.com>
     * @copyright Copyright (c) 2024, Debargha Chakraborty 
     * @return \Illuminate\Http\Response
     */

     public function change_log_records(Request $request,$id)
     {
        // echo '<pre>'; print_r($request->toArray()); echo '</pre>';
        // exit;
        $task=Task::find($id);
         $query=TaskChangeLog::with('creator')->where('task_id',$id);
         if($request->users!=null && $request->users!='null' && $request->users!='' && $request->users!='undefined' )
         {
             $query->whereIn('created_by',explode(',',$request->users));
         }
         if($request->column_name!=null && $request->column_name!='null' && $request->column_name!='' && $request->column_name!='undefined')
         {
             $query->whereIn('column_name',explode(',',$request->column_name));
         }
         
         if($request->date_range!=null && $request->date_range!='null' && $request->date_range!='' && $request->date_range!='undefined')
         {
            $date=explode(',',$request->date_range);
           
            $query->whereRaw('DATE(created_at) BETWEEN ? and ?',[$date[0],$date[1]]);
         }
         if($request->action!='' && $request->action!='null' && $request->action!='undefined')
         {
             $query->where('action',$request->action);
         }
         $task_change_logs=$query->orderBy('created_at','desc')->get()->toArray();
 
 
         foreach($task_change_logs as $key=>$value)
         {
         
             if(isset($value['new_value']) && isset($value['column_name']))
             {
                 $activity=[];
                 if($value['column_name'] == 'call' || $value['column_name'] == 'meeting' || $value['column_name'] == 'todo' || $value['column_name'] == 'department-task')
                 {
                     $task=Task::find($value['new_value']);
                     $activity['new_value']=isset($task->id)?$task->name:'';
                     $activity['old_value']=NULL;
                 }
                 else if($value['column_name'] == 'file')
                 {
                     $file=File::withTrashed()->find($value['new_value']);
                     $activity['new_value']=isset($file->id)?$file->file_name:'';
                     $activity['old_value']=NULL;
                 }
                 else if($value['column_name'] == 'task_flag' && $value['new_value'] != '')
                 {
                     if(is_array(json_decode($value['new_value'])) && count(json_decode($value['new_value']))>0)
                     {
                         $new_users=TaskFlag::whereIn('id',json_decode($value['new_value']))->get()->toArray();
                         if(count($new_users))
                             $activity['new_value']=implode(',',array_column($new_users,'name'));
                     }
                     else if($value['new_value']!=null && $value['new_value']!='')
                     {
                         $new_users=TaskFlag::whereIn('id',explode(',',$value['new_value']))->get()->toArray();
                         if(count($new_users))
                             $activity['new_value']=implode(',',array_column($new_users,'name'));
                     }
                     else
                         $activity['new_value'] =''; 
     
                     if(is_array(json_decode($value['old_value'])) && count(json_decode($value['old_value']))>0){
                         $old_users=TaskFlag::whereIn('id',json_decode($value['old_value']))->get()->toArray();
                         if(count($old_users))
                             $activity['old_value']=implode(',',array_column($old_users,'name'));
                     }
                     else if($value['old_value']!=null && $value['old_value']!='')
                     {
                         $old_users
                         =TaskFlag::whereIn('id',explode(',',$value['old_value']))->get()->toArray();
                         if(count($old_users
                         ))
                             $activity['old_value']=implode(',',array_column($old_users
                         ,'name'));
                     }
                     else
                         $activity['old_value'] =''; 
                 }
     
                 else if($value['column_name'] == 'ticket_stages' && $value['new_value'] != '')
                 {
                     if(is_array(json_decode($value['new_value'])) && count(json_decode($value['new_value']))>0)
                     {
                         $new_users=TicketStage::whereIn('id',json_decode($value['new_value']))->get()->toArray();
                         if(count($new_users))
                             $activity['new_value']=implode(',',array_column($new_users,'name'));
                     }
                     else if($value['new_value']!=null && $value['new_value']!='')
                     {
                         $new_users=TicketStage::whereIn('id',explode(',',$value['new_value']))->get()->toArray();
                         if(count($new_users))
                             $activity['new_value']=implode(',',array_column($new_users,'name'));
                     }
                     else
                         $activity['new_value'] =''; 
     
                     if(is_array(json_decode($value['old_value'])) && count(json_decode($value['old_value']))>0){
                         $old_users=TicketStage::whereIn('id',json_decode($value['old_value']))->get()->toArray();
                         if(count($old_users))
                             $activity['old_value']=implode(',',array_column($old_users,'name'));
                     }
                     else if($value['old_value']!=null && $value['old_value']!='')
                     {
                         $old_users
                         =TicketStage::whereIn('id',explode(',',$value['old_value']))->get()->toArray();
                         if(count($old_users
                         ))
                             $activity['old_value']=implode(',',array_column($old_users
                         ,'name'));
                     }
                     else
                         $activity['old_value'] =''; 
                 }
                 //14/09/2024
                 else if($value['column_name'] == 'referral_id' && $value['new_value'] != '')
                 {
                    $new_referral=Contact::where('type','individual')->withTrashed()->find($value['new_value']);
                    $old_referral=Contact::where('type','individual')->withTrashed()->find($value['old_value']);

                    $activity['new_value']=isset($new_referral->id)?$new_referral->full_name:'';
                    $activity['old_value']=isset($old_referral->id)?$old_referral->full_name:'';
                 }
                 else if($value['column_name'] == 'employee' && $value['new_value'] != '')
                 {
     
                     if(is_array(json_decode($value['new_value'])) && count(json_decode($value['new_value']))>0)
                     {
                         $new_users=User::whereIn('id',json_decode($value['new_value']))->get()->toArray();
                         if(count($new_users))
                             $activity['new_value']=implode(',',array_column($new_users,'name'));
                     }
                     else if($value['new_value']!=null && $value['new_value']!='')
                     {
                         $new_users=User::whereIn('id',explode(',',$value['new_value']))->get()->toArray();
                         if(count($new_users))
                             $activity['new_value']=implode(',',array_column($new_users,'name'));
                     }
                     else
                         $activity['new_value'] =''; 
     
                     if(is_array(json_decode($value['old_value'])) && count(json_decode($value['old_value']))>0){
                         $old_users=User::whereIn('id',json_decode($value['old_value']))->get()->toArray();
                         if(count($old_users))
                             $activity['old_value']=implode(',',array_column($old_users,'name'));
                     }
                     else if($value['old_value']!=null && $value['old_value']!='')
                     {
                         $old_users
                         =User::whereIn('id',explode(',',$value['old_value']))->get()->toArray();
                         if(count($old_users
                         ))
                             $activity['old_value']=implode(',',array_column($old_users
                         ,'name'));
                     }
                     else
                         $activity['old_value'] =''; 
                 }
                 else if($value['column_name'] == 'manager' && $value['new_value'] != '')
                 {
     
                     if(is_array(json_decode($value['new_value'])) && count(json_decode($value['new_value']))>0)
                     {
                         $new_users=User::whereIn('id',json_decode($value['new_value']))->get()->toArray();
                         if(count($new_users))
                             $activity['new_value']=implode(',',array_column($new_users,'name'));
                     }
                     else if($value['new_value']!=null && $value['new_value']!='')
                     {
                         $new_users=User::whereIn('id',explode(',',$value['new_value']))->get()->toArray();
                         if(count($new_users))
                             $activity['new_value']=implode(',',array_column($new_users,'name'));
                     }
                     else
                         $activity['new_value'] =''; 
     
                     if(is_array(json_decode($value['old_value'])) && count(json_decode($value['old_value']))>0){
                         $old_users=User::whereIn('id',json_decode($value['old_value']))->get()->toArray();
                         if(count($old_users))
                             $activity['old_value']=implode(',',array_column($old_users,'name'));
                     }
                     else if($value['old_value']!=null && $value['old_value']!='')
                     {
                         $old_users
                         =User::whereIn('id',explode(',',$value['old_value']))->get()->toArray();
                         if(count($old_users
                         ))
                             $activity['old_value']=implode(',',array_column($old_users
                         ,'name'));
                     }
                     else
                         $activity['old_value'] =''; 
                 }
                 else if($value['column_name'] == 'supervisor' && $value['new_value'] != '')
                 {
     
                     if(is_array(json_decode($value['new_value'])) && count(json_decode($value['new_value']))>0)
                     {
                         $new_users=User::whereIn('id',json_decode($value['new_value']))->get()->toArray();
                         if(count($new_users))
                             $activity['new_value']=implode(',',array_column($new_users,'name'));
                     }
                     else if($value['new_value']!=null && $value['new_value']!='')
                     {
                         $new_users=User::whereIn('id',explode(',',$value['new_value']))->get()->toArray();
                         if(count($new_users))
                             $activity['new_value']=implode(',',array_column($new_users,'name'));
                     }
                     else
                         $activity['new_value'] =''; 
     
                     if(is_array(json_decode($value['old_value'])) && count(json_decode($value['old_value']))>0){
                         $old_users=User::whereIn('id',json_decode($value['old_value']))->get()->toArray();
                         if(count($old_users))
                             $activity['old_value']=implode(',',array_column($old_users,'name'));
                     }
                     else if($value['old_value']!=null && $value['old_value']!='')
                     {
                         $old_users
                         =User::whereIn('id',explode(',',$value['old_value']))->get()->toArray();
                         if(count($old_users
                         ))
                             $activity['old_value']=implode(',',array_column($old_users
                         ,'name'));
                     }
                     else
                         $activity['old_value'] =''; 
                 }
                 else if(($value['column_name'] == 'contact' || $value['column_name'] == 'contact_id') && $value['new_value'] != '')
                 {
                     if(is_array(json_decode($value['new_value'])) && count(json_decode($value['new_value']))>0){
                         $new_users=Contact::whereIn('id',json_decode($value['new_value']))->get()->toArray();
                         
                         if(count($new_users))
                             $activity['new_value']=implode(',',array_column($new_users,'full_name'));
                     }
                     else if($value['new_value']!=null && $value['new_value']!='')
                     {
                         $new_users=Contact::whereIn('id',explode(',',$value['new_value']))->get()->toArray();
                         // dd($new_users);
                         if(count($new_users))
                             $activity['new_value']=implode(',',array_column($new_users,'full_name'));
                     }
                     else
                         $activity['new_value'] =''; 
     
                     if((is_array(json_decode($value['old_value'])) && count(json_decode($value['old_value']))>0)  || ($value['old_value']!=null && $value['old_value']!='')){
                         $old_users=Contact::whereIn('id',json_decode($value['old_value']))->get()->toArray();
                         if(count($old_users))
                             $activity['old_value']=implode(',',array_column($old_users,'full_name'));
                     }
                     else if($value['old_value']!=null && $value['old_value']!='')
                     {
                         $old_users
                         =Contact::whereIn('id',explode(',',$value['old_value']))->get()->toArray();
                         if(count($old_users
                         ))
                             $activity['old_value']=implode(',',array_column($old_users
                         ,'full_name'));
                     }
                     else
                         $activity['old_value'] =''; 
                     
                 }
                 else if($value['column_name'] == 'communication'  && $value['new_value'] != '')
                 {
                     if($value['new_value']!=null)  
                     {
                         $new_comment=Communication::withTrashed()->find($value['new_value']);
                 
                         if(isset($new_comment->id))
                             $activity['new_value'] =$new_comment->comment; 
                         else
                             $activity['new_value'] ='';
                     }
 
                     if($value['old_value']!=null)  
                     {
                         $old_comment=Communication::withTrashed()->find($value['old_value']);
                 
                         if(isset($old_comment->id))
                             $activity['old_value'] =$old_comment->comment; 
                         else
                             $activity['old_value'] ='';
                     }
                             
                     
                 }
                 else if($value['column_name'] == 'status')
                 { 
                     if($task->type=='regular-ticket'|| $task->type=='help-ticket' || $task->type=='memorized-ticket')
                         $change_status=$this->ticket_statuses;
                     elseif ($task->type=='ist') 
                         $change_status=$this->ist_statuses;
                     else
                         $change_status=$this->task_statuses;	    
                 
                     $statuses=array_column($change_status,'name', 'id'); 
                     $activity['new_value']=$statuses[$value['new_value']];
                     $activity['old_value']=$statuses[$value['old_value']];
                 }    
                 else if($value['column_name'] == 'priority')
                 {
                     $priorities=array_column($this->ticket_priorities,'name', 'id'); 
                     $activity['new_value']=$priorities[$value['new_value']];
                     $activity['old_value']=$priorities[$value['old_value']];
                 }
                 else if ($value['column_name'] == 'attendance-report') {
                    $attendance_report = DailyAttendanceReport::with('tasks')->findOrFail($value['new_value']);
                    $remarks='';
                    if(isset($attendance_report->tasks->name))
                    $remarks=$attendance_report->tasks->name.'-'.$attendance_report->description;
                    $activity['new_value'] =$remarks;
                    $activity['old_value'] = $value['old_value'];
                } 
                 else
                 {
                     $activity['new_value']=$value['new_value'];
                     $activity['old_value']=$value['old_value'];
                 }
     
                 $task_change_logs[$key]['activity']=$activity;
             }
                     
         
         }
         
         return response(['data' => $task_change_logs,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
     }



    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create()
    {
    }
    /**
     * Store a newly created task  in sahaj.
     * @author Debargha
     * @param Request $request
     * @return Response
     */
    public function add_rt_in_old($ticket_id)
    {
        $ticket=Task::with('files','contacts','companies','services','check_lists','employees')->where('id',$ticket_id)->first();

        if($ticket->type=='regular-ticket' || $ticket->type=='department-task' || $ticket->type=='memorized-ticket')
        {
            $ch = curl_init(env('OLD_SAHAJ_LINK').'store_ticket_in_sahaj?master=dost'); 
            $jsonData = json_encode($ticket);
            
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json',
                'Content-Length: ' . strlen($jsonData)
            ]);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);

                $response = curl_exec($ch);
       //         print_r($response);
         //       dd('stop');
                if ($response === false) {
                    $error = curl_error($ch);
                    curl_close($ch);
                    throw new Exception("cURL error: $error");
                }
                curl_close($ch);
        }
    
       
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        $not=DB::table('notifications')->max('batch_id');
        $this->notification_batch_id=$not+1;

        // if(!$this->checkStoreAccess())
        //     return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403); 

        if($request->type == 'regular-ticket' || $request->type == 'memorized-ticket')
        {
            $validator = Validator::make($request->all(), [
          	    'description'=>'required', 
                'employee' => 'required_without_all:manager,supervisor',
                'manager' => 'required_without_all:employee,supervisor',
                'supervisor' => 'required_without_all:employee,manager', 
            ]);
        }
        elseif ($request->type == 'ist') {
            $validator = Validator::make($request->all(), [
                'description'=>'required', 
                'ist_type'=>[
                    'required',
                    function ($attribute, $value, $fail) use ($request) {
                        if ($value == 'wfh-request') {

                            if(DailyAttendance::where('user_id',$request->employee[0])->where('date',date('Y-m-d',strtotime($request->start_date)))->count())
                            {
                                $fail('You Have Already Logged In For The Date');
                            }

                           
                        }
                    },
                ],
            ]);
        }
        else
        {
            $validator = Validator::make($request->all(), [
                'description'=>'required', 
            ]);
        }
       
        $recipients=[];
        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            $task = Task::create($request->except('check_list','files','employee','service','manager','supervisor','company','contact'));

            if(isset($request->main_id) && intval($request->main_id)>0)
                TaskChangeLog::create(['action'=>'add','task_id'=>$task->main_id,'column_name'=>$request->type,'new_value'=>$task->id]);

            if($request->input('check_list') != null && count($request->input('check_list'))>0)
            {
                $task->check_lists()->delete();

                foreach ($request->input('check_list') as $data) 
                {
                    if(!empty($data['description']))
                    {
                        if(intval($data['id']) > 0)
                        {
                            if($object = TaskCheckList::withTrashed()->find($data['id']))
                            {
                                $object->restore();
                                $object->fill($data);
                            }
                            else
                                $object = new TaskCheckList($data);
                        }
                        else
                            $object = new TaskCheckList($data);
                        
                        
                        $task->check_lists()->save($object);
                       
                    }        
                }
            }
            if($request->input('files') && count($request->input('files')) > 0)
            {
                foreach ($request->input('files') as $data) 
                {
                    
                    $data['identifier']=isset($data['identifier'])?$data['identifier']:"task";

                    if(intval($data['id']) > 0 || intval($data['temp_id']) > 0)
                    {
                        if($object = File::withTrashed()->find($data['id']))
                        {
                            $object->restore();
                            $object->fill($data);
                        }
                        else
                        {
                            if($tempobject = TempFile::find($data['temp_id']))
                            {  
                                $object = new File($data);
                            }
                        }
                            
                        $task->files()->save($object);
                    }
                }
            }
            if($request->input('service') && $request->input('service') > 0)
            {
                $task->services()->detach();
                $task->services()->attach($request->input('service'),['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
            }
            if($request->input('company') && count($request->input('company')) > 0)
            {
                $task->companies()->detach();
                $task->companies()->attach($request->input('company'),['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
            }
            if($request->input('officer') && count($request->input('officer')) > 0)
            {
                $task->officers()->detach();
                $task->officers()->attach($request->input('officer'),['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
            }
            if($request->input('contact') && count($request->input('contact')) > 0)
            {
                $task->contacts()->detach();
                $task->contacts()->attach($request->input('contact'),['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
            }
            $task->employees()->detach();

            if($request->input('employee') && count($request->input('employee')) > 0)
            {
                $employee = [];
                foreach ($request->input('employee') as $key => $value) 
                {
                    if($emp = Employee::where('user_id',$value)->first())
                        $employee[$key] = ['user_id'=>$value,'main_id'=>$emp->id];
                    else
                        $employee[$key] = ['user_id'=>$value,'main_id'=>0];
                }
                $task->employees()->attach($employee,['master_id'=>$request->master_id,'type'=>'employee','identifier'=>'employee','created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
            }
            if($request->input('manager') && $request->input('manager') > 0)
            {
                $manager = [];
                if($emp = Employee::where('user_id',$request->input('manager'))->first())
                    $manager[] = ['user_id'=>$request->input('manager'),'main_id'=>$emp->id];
                else
                    $manager[] = ['user_id'=>$request->input('manager'),'main_id'=>0];

                $task->employees()->attach($manager,['master_id'=>$request->master_id,'identifier'=>'employee','type'=>'manager','created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
            }
            if($request->input('supervisor') && $request->input('supervisor') > 0)
            {
                $supervisor = [];
                if($emp = Employee::where('user_id',$request->input('supervisor'))->first())
                    $supervisor[] = ['user_id'=>$request->input('supervisor'),'main_id'=>$emp->id];
                else
                    $supervisor[] = ['user_id'=>$request->input('supervisor'),'main_id'=>0];

                $task->employees()->attach($supervisor,['master_id'=>$request->master_id,'type'=>'supervisor','identifier'=>'employee','created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
            }
            if($request->type =='regular-ticket' || $request->type=='department-task' || $request->type=='memorized-ticket')
                $this->add_rt_in_old($task->id);
            if($request->type == 'meeting')
            {
                if($request->input('employee') && count($request->input('employee')))
                {
                    foreach ($request->input('employee') as $key => $emp) {
                        $data['user_id'] = $emp;
                        $data['type'] = 'employee';
                        $data['main_id'] = 0;
                        $object = new TaskInvitie($data);
                        $task->invities()->save($object);
                    }
                }
                if($request->input('contact') && count($request->input('contact')))
                {
                    foreach ($request->input('contact') as $key => $con) 
                    {
                        if($contact = Contact::find($con))
                            $data['user_id'] = $contact->user_id > 0 ? $contact->user_id : 0;
                        
                        $data['type'] = 'contact';
                        $data['main_id'] = $con;
                        $object = new TaskInvitie($data);
                        $task->invities()->save($object);
                    }
                }
                if($request->input('external') && count($request->input('external')))
                {
                    foreach ($request->input('external') as $key => $ext) {
                        $data['user_id'] = $ext;
                        $data['type'] = 'external';
                        $data['main_id'] = 0;
                        $object = new TaskInvitie($data);
                        $task->invities()->save($object);
                    }
                }
                if($task->meeting_type == 'online' && $task->status == 0)
                {
                    $zoom_api_info = $this->create_zoom_meeting($task);
                    $task->update([
                        'meeting_external_id'=>$zoom_api_info['id'],
                        'meeting_start_url'=>$zoom_api_info['start_url'],
                        'meeting_invite_url'=>$zoom_api_info['join_url']
                    ]);
                   
                    if($template = NotificationTemplate::where('name','online-meeting-invitation')->where('status',1)->first())
                    {
                        $notification_data['meeting_invite_url'] = $task->meeting_invite_url;
                        $notification_data['template'] = $template;
                        $notification_data['host'] = $task->supervisor[0]->name;
                        $notification_data['agenda'] = $task->description;
                        $notification_data['start_date'] = date('d/m/Y H:i A',strtotime($task->start_date));
                        $inv_users = [];
                        $inv_contacts = [];
                        $invities=[];
                        foreach ($task->invities as $key => $value) 
                        {
                           if($value->user_id > 0)
                           {
                            $inv_users[]=$value->user_id;
                            $invities[]=$value->user_id;
                           }
                           elseif ($value->main_id > 0 && $value->type == 'contact') 
                           {
                            $inv_contacts[]=$value->main_id;
                            $invities[]=$value->main_id;
                           }
                        }
                        foreach($invities as $user_id){
                            $getuser=User::find($user_id);
                            if($getuser!=null)
                             $recipients[]=array('email'=>$getuser->email,'name'=>$getuser->name,'mail_type'=>'to');
                        }
                        if($inv_users && count($inv_users))
                        {
                            $invitie_users = User::whereIn('id',$inv_users)->get();
                            foreach( $invitie_users as $user)
                            {
                                $phoneNumber = $user->phone; // The phone number to send the SMS to
                                $message = 'Dear '.$user->name.', this is your SMS message!';
                                $user->notify(new SendSmsNotification($phoneNumber, $message));
                            }
                            Notification::send($invitie_users, new SendNotification($notification_data,$task,$recipients,$request->type,$this->notification_batch_id));
                            //24/05/24
                            if(isset($notification_data['template']) && isset($notification_data['template']['email_body']))
                            $this->template_body=$notification_data['template']['email_body'];
                        }    
                    }
                }

                if($task->status == 2)
                {
                    $task->remarks = $task->description;
                    $task->save();
                    
                    if(TaskHistory::where('task_id',$task->id)->where('user_id',Auth::user()->id)->count() == 0)
                    {
                        TaskHistory::create([
                            'task_id'=>$task->id,
                            'user_id'=>Auth::user()->id,
                            'meeting_in_time'=>$request->in_time,
                            'meeting_out_time'=>$request->out_time
                        ]);
                    }

                    if(count($task->unique_employees))
                    {
                        foreach ($task->unique_employees as $key => $emp) {
                          
                            $history = TaskHistory::where('task_id',$task->id)->where('user_id',$emp->id)->first();

    
                            $attendance_report=DailyAttendanceReport::create([
                                'task_id'=>$task->id,
                                'time'=> !empty($history) ? $this->time_diff($history->meeting_in_time,$history->meeting_out_time) : $this->time_diff($request->in_time,$request->out_time),
                                'user_id'=>$emp->id,
                                'emp_id'=>$emp->pivot->main_id,
                                'auto_entry'=>1,
                                'date'=>date('Y-m-d'),
                                'reason'=>$task->type_name,
                                'description'=>$task->description
                            ]);
                            $this->add_sahaj_attendance($attendance_report->id);
                        }
                    }
                    
                }
            }
            if($request->type == 'crd')
            {
                $information_sub_groups = [];
                $information_inner_items = [];
                $information_items = [];
                if(count($request->information_sub_groups))
                {
                    $i = 0;
                   
                    foreach ($request->information_sub_groups as $key => $sub_group) 
                    {
                        $information_sub_groups[$key]=[
                            'information_sub_group_id'=>$sub_group['information_sub_group_id'],
                            'name'=>$sub_group['name'],
                            'is_multiple'=>$sub_group['is_multiple'],
                            'is_required'=>$sub_group['is_required'],
                            'description'=>$sub_group['description'],
                            'order_no'=>$sub_group['order_no']
                        ];
                        if(count($sub_group['information_items']))
                        {
                            foreach ($sub_group['information_items'] as $key2 => $information_item) 
                            {
                                $information_inner_items[$i]=[
                                'information_sub_group_id'=>$sub_group['information_sub_group_id'],
                                'information_item_id'=>$information_item['information_item_id'],
                                'name'=>$information_item['name'],
                                'is_multiple'=>$information_item['is_multiple'],
                                'is_required'=>$information_item['is_required'],
                                'description'=>$information_item['description'],
                                'order_no'=>$information_item['order_no'],
                                'type'=>$information_item['type'],
                                'value'=>$information_item['value']
                                ];
                                $i++;
                            }
                        }
                    }
        
                }
                if(count($request->information_items))
                {
                    foreach ($request->information_items as $key => $value) 
                    {
                        $information_items[$key]=[
                            'information_item_id'=>$value['information_item_id'],
                            'is_multiple'=>$value['is_multiple'],
                            'name'=>$value['name'],
                            'is_required'=>$value['is_required'],
                            'description'=>$value['description'],
                            'order_no'=>$value['order_no'],
                            'type'=>$value['type'],
                            'value'=>$value['value']
                            ];
                    }
                }

                if($information_items && count($information_items) > 0)
                {
                    $task->information_items()->detach();
                    $task->information_items()->attach($information_items,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s'),'identifier'=>'information_item']); 
                }
                if($information_sub_groups && count($information_sub_groups) > 0)
                {
                    $task->information_sub_groups()->detach();
                    $task->information_sub_groups()->attach($information_sub_groups,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s'),'identifier'=>'information_sub_group']); 
                }
                if($information_inner_items && count($information_inner_items) > 0)
                {
                    $task->information_sub_items()->detach();
                    $task->information_sub_items()->attach($information_inner_items,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s'),'identifier'=>'information_sub_group_item']); 
                }
            }
            if($request->type == 'ist')
            {
                // dd($request->toArray());
                if($request->ist_type == 'attendance-request')
                {
                    $emp_id = 0;
                    $this->add_ist_request($request,$task->id);
                    if(Auth::user()->type == 'employee')
                    {
                        $employee = Employee::where('user_id',Auth::user()->id)->first();
                        $emp_id = $employee->id;
                    } 

                    TaskIstChangeRequest::create([
                        'user_id'=>Auth::user()->id,
                        'emp_id'=>$emp_id,
                        'task_id'=>$task->id,
                        'date'=>date('Y-m-d'),
                        'change_table_name'=>'daily_attendances',
                        'change_column_name'=>'start_time',
                        'requested_value'=>date('H:i:s'),
                        'changed_value'=>date('H:i:s')

                    ]);
                    
                    if($template = NotificationTemplate::where('name','ist-office-in-request')->where('status',1)->first())
                    {

                        $user=User::find(Auth::user()->id);

                        $notification_data['template'] = $template;
                        $notification_data['host'] =isset($user->name)?$user->name:'';
                        $notification_data['agenda'] = $request->description;
                        $notification_data['start_date'] = date('d/m/Y H:i A');

                        $user_ids=[];
                        if(intval($request->supervisor)>0)
                            $user_ids[]=$request->supervisor;
                        if(intval($request->manager)>0)
                            $user_ids[]=$request->manager;
                        // $users=User::whereIn('id',$user_ids)->get()->toArray();
                        $recipients=[];
                        foreach(array_unique($user_ids) as $user_id){
                            $getuser=User::find($user_id);
                            // dd($getuser);
                            if($getuser!=null)
                            $recipients[]=array('email'=>$getuser->email,'name'=>$getuser->name,'mail_type'=>'to');
                        }
                        //just to test
                        $dd = DB::table('notifications')->latest()->first();
                        if($user_ids && count($user_ids)>0)
                        {
                            $invitie_users = User::whereIn('id',array_unique($user_ids))->get();
                            foreach( $invitie_users as $user)
                            {
                                $phoneNumber = $user->phone; // The phone number to send the SMS to
                                $message = 'Dear '.$user->name.', this is your SMS message!';
                                $user->notify(new SendSmsNotification($phoneNumber, $message));
                            }
                            Notification::send($invitie_users, new SendNotification($notification_data,$task,$recipients,$request->type,$this->notification_batch_id));
                            //24/05/24
                            if(isset($notification_data['template']) && isset($notification_data['template']['email_body']))
                            $this->template_body=$notification_data['template']['email_body'];
                        }  

                    }
                }
               
            }
            if($request->type == 'call' && $task->duration != null)
            {
                if($task->status == 2)
                {
                    if($task->supervisor && count($task->supervisor))
                    {
                        $attendance_report= DailyAttendanceReport::create([
                            'task_id'=>$task->id,
                            'time'=> $task->duration,
                            'user_id'=>$task->supervisor[0]->id,
                            'emp_id'=>$task->supervisor[0]->pivot->main_id,
                            'auto_entry'=>1,
                            'date'=>date('Y-m-d'),
                            'reason'=>$task->type_name,
                            'description'=>$task->description
                        ]);
                        $this->add_sahaj_attendance($attendance_report->id);
                    }
                  
                }
            }
            /*
            //If Meeting is Similar To Department Visit Then No Need
            if($request->type == 'department-task')
            {
                if($request->input('employee') && count($request->input('employee')))
                {
                    foreach ($request->input('employee') as $key => $emp) {
                        $data['user_id'] = $emp;
                        $data['type'] = 'employee';
                        $data['main_id'] = 0;
                        $object = new TaskInvitie($data);
                        $task->invities()->save($object);
                    }
                }
                if($request->input('contact') && count($request->input('contact')))
                {
                    foreach ($request->input('contact') as $key => $con) 
                    {
                        if($contact = Contact::find($con))
                            $data['user_id'] = $contact->user_id > 0 ? $contact->user_id : 0;
                        
                        $data['type'] = 'contact';
                        $data['main_id'] = $con;
                        $object = new TaskInvitie($data);
                        $task->invities()->save($object);
                    }
                }
                if($request->input('officer') && count($request->input('officer')))
                {
                    foreach ($request->input('officer') as $key => $officer) 
                    {
                       
                        $data['user_id'] = 0;
                        $data['type'] = 'officer';
                        $data['main_id'] = $officer;
                        $object = new TaskInvitie($data);
                        $task->invities()->save($object);
                    }

                    $task->officers()->attach($request->input('officer'),['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
                }

                if($request->input('external') && count($request->input('external')))
                {
                    foreach ($request->input('external') as $key => $ext) {
                        $data['user_id'] = $ext;
                        $data['type'] = 'external';
                        $data['main_id'] = 0;
                        $object = new TaskInvitie($data);
                        $task->invities()->save($object);
                    }
                }
                TaskDepartmentInformation::create([
                    'task_id'=>$task->id,
                    'purpose_id'=>$request->purpose_id,
                    'mode_id'=>$request->mode_id,
                    'type_id'=>$request->type_id,
                    'location'=>$request->location
                ]);


                
                if($template = NotificationTemplate::where('name','online-meeting-invitation')->where('status',1)->first())
                {
                    $notification_data['template'] = $template;
                    $notification_data['host'] = $task->supervisor[0]->name;
                    $notification_data['agenda'] = $task->description;
                    $notification_data['start_date'] = date('d/m/Y H:i A',strtotime($task->start_date));
                    $inv_users = [];
                    $inv_contacts = [];
                    $invities=[];
                    foreach ($task->invities as $key => $value) 
                    {
                        if($value->user_id > 0)
                        {
                        $inv_users[]=$value->user_id;
                        $invities[]=$value->user_id;
                        }
                        elseif ($value->main_id > 0 && $value->type == 'contact') 
                        {
                        $inv_contacts[]=$value->main_id;
                        $invities[]=$value->main_id;
                        }
                    }
                    
                    $recipients=[];
                    foreach($invities as $user_id){
                        $getuser=User::find($user_id);
                        if($getuser!=null)
                            $recipients[]=array('email'=>$getuser->email,'name'=>$getuser->name,'mail_type'=>'to');
                    }
                    if($inv_users && count($inv_users))
                    {
                        $invitie_users = User::whereIn('id',$inv_users)->get();
                        foreach( $invitie_users as $user)
                        {
                            $phoneNumber = $user->phone; 
                            $message = 'Dear '.$user->name.', this is your SMS message!';
                            $user->notify(new SendSmsNotification($phoneNumber, $message));
                        }
                        Notification::send($invitie_users, new SendNotification($notification_data,$task,$recipients,$request->type,$this->notification_batch_id));
                        if(isset($notification_data['template']) && isset($notification_data['template']['email_body']))
                        $this->template_body=$notification_data['template']['email_body'];
                    }    
                }


                if($task->status == 2)
                {
                    $task->remarks = $task->description;
                    $task->save();

                    if(TaskHistory::where('task_id',$task->id)->where('user_id',Auth::user()->id)->count() == 0)
                    {
                        TaskHistory::create([
                            'task_id'=>$task->id,
                            'user_id'=>Auth::user()->id,
                            'meeting_in_time'=>$request->in_time,
                            'meeting_out_time'=>$request->out_time
                        ]);
                    }
                    if(count($task->unique_employees))
                    {
                        foreach ($task->unique_employees as $key => $emp) {
                          
                            $history = TaskHistory::where('task_id',$task->id)->where('user_id',$emp->id)->first();

    
                            DailyAttendanceReport::create([
                                'task_id'=>$task->id,
                                'time'=> !empty($history) ? $this->time_diff($history->meeting_in_time,$history->meeting_out_time) : $this->time_diff($request->in_time,$request->out_time),
                                'user_id'=>$emp->id,
                                'emp_id'=>$emp->pivot->main_id,
                                'auto_entry'=>1,
                                'date'=>date('Y-m-d'),
                                'reason'=>$task->type_name,
                                'description'=>$task->description
                            ]);
                        }
                    }
                    


                }
            }
            */

            $this->sendMailFunc($this->notification_batch_id,$this->template_body,$task->id); //24/05/24
            
            DB::commit();
            
            return response(['data' => new TaskResource($task),'success'=>true,'message' => 'Task Updated Created Successfully'], 200);
        }
        catch (Exception $ex) {
            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }
    /**
     * Send mail via mailchimp
     * @author Debargha
     * @param Request $request
     * @return Response
     */
    public function sendMailFunc($batch_id,$template_body,$task_id)
    {
       /* $notifications=NotificationLog::where('batch_id',$batch_id)->where('status',0)->get()->toArray();
        if(count($notifications)>0)
         Mail::send(new MailChimp($notifications,$template_body,$task_id,'task',User::find(Auth::user()->id)));*/
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Response
     */
    public function show($id)
    {
        return response(['data' =>new TaskResource(Task::findOrFail($id)),'success'=>true,'message' => 'Task Retrived Successfully'], 200);
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Response
     */
    public function edit($id)
    {
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
        $task=Task::find($id);
        $old_status=$task->status;
        // if(!$this->checkTaskUpdateAccess($task))
        //     return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403); 

       
        if($request->type == 'regular-ticket' || $request->type == 'memorized-ticket')
        {
            $validator = Validator::make($request->all(), [
            
                'employee' => 'required_without_all:manager,supervisor',
                'manager' => 'required_without_all:employee,supervisor',
                'supervisor' => 'required_without_all:employee,manager', 
            ]);
        }
        else
        {
            $validator = Validator::make($request->all(), [
            

            ]);
        }

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            
            $task->update($request->except('check_list','files','employee','service','manager','supervisor','company','contact'));

            if($task->type == 'meeting' || $task->type == 'call' || $task->type == 'todo' || $task->type == 'department-task')
            {
                TaskChangeLog::create(['action'=>'update','task_id'=>$task->id,'remarks'=>$request->remarks,'column_name'=>'status','old_value'=>$old_status,'new_value'=>$request->status]);
            }else{
                TaskChangeLog::create(['action'=>'update','task_id'=>$task->id]);
            }

            if($request->input('check_list') != null && count($request->input('check_list'))>0)
            {
                $task->check_lists()->delete();

                foreach ($request->input('check_list') as $data) 
                {
                    if(!empty($data['description']))
                    {
                        if(intval($data['id']) > 0)
                        {
                            if($object = TaskCheckList::withTrashed()->find($data['id']))
                            {
                                $object->restore();
                                $object->fill($data);
                            }
                            else
                                $object = new TaskCheckList($data);
                        }
                        else
                            $object = new TaskCheckList($data);
                        
                        
                        $task->check_lists()->save($object);
                    
                    }        
                }
            }
            if($request->input('files') && count($request->input('files')) > 0)
            {
                $task->files()->delete();
                foreach ($request->input('files') as $data) 
                {
                    
                    $data['identifier']=isset($data['identifier'])?$data['identifier']:"task";

                    if(intval($data['id']) > 0 || intval($data['temp_id']) > 0)
                    {
                        if($object = File::withTrashed()->find($data['id']))
                        {
                            $object->restore();
                            $object->fill($data);
                        }
                        else
                        {
                            if($tempobject = TempFile::find($data['temp_id']))
                            {
                                
                                $object = new File($data);
                            }
                        }
                            
                        $task->files()->save($object);
                    }
                }
            }
            if($request->input('service') && $request->input('service') > 0)
            {
                $task->services()->detach();   
                $task->services()->attach($request->input('service'),['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
            }
            if($request->input('company') && count($request->input('company')) > 0)
            {
                $task->companies()->detach();
                $task->companies()->attach($request->input('company'),['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
            }
            if($request->input('contact') && count($request->input('contact')) > 0)
            {
                $contacts = [];
                foreach ($request->input('contact') as $key => $value) {
                    if($contact = Contact::find($value))
                        $contacts[$key] = ['main_id'=>$value,'user_id'=> $contact->user_id > 0 ? $contact->user_id : 0];
                }
                $task->contacts()->detach();
                $task->contacts()->attach($request->input('contact'),['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
                
                $task->contact_users()->detach();
                $task->contact_users()->attach(  $contacts,['master_id'=>$request->master_id,'type'=>'contact','identifier'=>'contact','created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
            }

            

            if($request->input('employee') && count($request->input('employee')) > 0)
            {
                $task->members()->detach();
                $employee = [];
                foreach ($request->input('employee') as $key => $value) 
                {
                    if($emp = Employee::where('user_id',$value)->first())
                        $employee[$key] = ['user_id'=>$value,'main_id'=>$emp->id];
                    else
                        $employee[$key] = ['user_id'=>$value,'main_id'=>0];
                }
                $task->employees()->attach($employee,['master_id'=>$request->master_id,'type'=>'employee','identifier'=>'employee','created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
            }
            if($request->input('manager') && $request->input('manager') > 0)
            {
                $task->manager()->detach();
                $manager = [];
                if($emp = Employee::where('user_id', $request->input('manager'))->first())
                    $manager[] = ['user_id'=>$request->input('manager'),'main_id'=>$emp->id];
                else
                    $manager[] = ['user_id'=>$request->input('manager'),'main_id'=>0];

                $task->employees()->attach($manager,['master_id'=>$request->master_id,'identifier'=>'employee','type'=>'manager','created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
            }
            if($request->input('supervisor') && $request->input('supervisor') > 0)
            {
                $task->supervisor()->detach();
                $supervisor = [];
                if($emp = Employee::where('user_id', $request->input('supervisor'))->first())
                    $supervisor[] = ['user_id'=>$request->input('supervisor'),'main_id'=>$emp->id];
                else
                    $supervisor[] = ['user_id'=>$request->input('supervisor'),'main_id'=>0];

                $task->employees()->attach($supervisor,['master_id'=>$request->master_id,'type'=>'supervisor','identifier'=>'employee','created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
            }

            if($task->type == 'meeting')
            {
                if($task->status == 2)
                {
                    if(TaskHistory::where('task_id',$task->id)->where('user_id',Auth::user()->id)->count() == 0)
                    {
                        TaskHistory::create([
                            'task_id'=>$task->id,
                            'user_id'=>Auth::user()->id,
                            'meeting_in_time'=>$request->in_time,
                            'meeting_out_time'=>$request->out_time
                        ]);
                    }
                    if(count($task->unique_employees))
                    {
                        foreach ($task->unique_employees as $key => $emp) {
                          
                            $history = TaskHistory::where('task_id',$task->id)->where('user_id',$emp->id)->first();

    
                            $attendance_report=DailyAttendanceReport::create([
                                'task_id'=>$task->id,
                                'time'=> !empty($history) ? $this->time_diff($history->meeting_in_time,$history->meeting_out_time) : $this->time_diff($request->in_time,$request->out_time),
                                'user_id'=>$emp->id,
                                'emp_id'=>$emp->pivot->main_id,
                                'auto_entry'=>1,
                                'date'=>date('Y-m-d'),
                                'reason'=>$task->type_name,
                                'description'=>$task->description
                            ]);
                            $this->add_sahaj_attendance($attendance_report->id);
                        }
                    }
                }

            }
            
            DB::commit();
            
            return response(['data' => new TaskResource($task),'success'=>true,'message' => 'Task Updated Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Response
     */
    public function destroy($id)
    {
        $task=Task::find($id);
        
        if(!$this->checkTaskDeleteAccess($task))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);
        
        DB::beginTransaction();
        try {
            
            $task->delete();
            DB::commit();
            return response(['data' => array(),'success'=>true,'message' => 'Task Deleted Successfully'], 200);
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }
    }

    /**
     * Bulk Action function of footer (pass 6  for delete and 3 for update)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function actionall()
    {
        
        $access = request()->action == 'delete' ? 6 : 3;

        if(!$this->checkBulkAcess( $access))
            return response(['data' => array(),'success'=>false,'message' =>"You Don't Have Access For Bulk Action"], 200);

        DB::beginTransaction();
        try {
           
            if($access == 6)
            {
                Task::whereIn('id',request()->ids)->get()->each(function($task) 
                {
                    $task->delete();
                });
            }
            elseif($access == 3 && request()->action == 'change-status')
            {

                Task::whereIn('id',request()->ids)->get()->each(function($task) 
                {
                 TaskChangeLog::create(['action'=>'edit','task_id'=>$task->id,'column_name'=>request()->column_name,'new_value'=>request()->new_value,'old_value'=>$task[request()->column_name]]);
                });
                Task::whereIn('id',request()->ids)->update(['status'=> request()->new_value]);

            }
            elseif($access == 3 && (request()->action == 'change-priority'))
            {

                Task::whereIn('id',request()->ids)->get()->each(function($task) 
                {
                 TaskChangeLog::create(['action'=>'edit','task_id'=>$task->id,'column_name'=>request()->column_name,'new_value'=>request()->new_value,'old_value'=>$task[request()->column_name]]);
                });
                Task::whereIn('id',request()->ids)->update(['priority'=> request()->new_value]);
            }
            elseif($access == 3 && (request()->action == 'change-due-date'))
            {
                Task::whereIn('id',request()->ids)->get()->each(function($task) 
                {
                    TaskChangeLog::create(['action'=>'edit','task_id'=>$task->id,'column_name'=>request()->column_name,'new_value'=>Carbon::parse(request()->new_value)->format('Y-m-d H:i:s'),'old_value'=>$task[request()->column_name]]);
                });
                Task::whereIn('id',request()->ids)->update(['due_date'=> request()->new_value]);
            }
            elseif($access == 3 && (request()->action == 'change-ecd'))
            {
                Task::whereIn('id',request()->ids)->get()->each(function($task) 
                {
                    TaskChangeLog::create(['action'=>'edit','task_id'=>$task->id,'column_name'=>request()->column_name,'new_value'=>Carbon::parse(request()->new_value)->format('Y-m-d H:i:s'),'old_value'=>$task[request()->column_name]]);
                });
                Task::whereIn('id',request()->ids)->update(['ecd'=> request()->new_value]);
            }
            elseif($access == 3 && request()->action == 'assign-employee')
            {
                Task::whereIn('id',request()->ids)->get()->each(function($task) 
                {
                    $members = [];

                    if(count(request()->new_value))
                    {
                        foreach (request()->new_value as $key => $value) {

                            if($employee = User::find($value))
                                $members[$key] = ['main_id'=>$value,'user_id'=> $employee->user_id > 0 ? $employee->user_id : 0];
                        }

                        $task->members()->attach(request()->new_value,['master_id'=>request()->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);
                      
                        TaskChangeLog::create(['action'=>'edit','task_id'=>$task->id,'column_name'=>request()->column_name,'new_value'=>implode(',',request()->new_value)]);
                        
                        if(count($members))
                            $task->contact_users()->attach(  $members,['master_id'=>request()->master_id,'type'=>'employee','identifier'=>'employee','created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
                    }
                      
                });
                   
            }
            elseif($access == 3 && request()->action == 'reset-employee')
            {
                Task::whereIn('id',request()->ids)->get()->each(function($task) 
                {
                    $task->members()->detach();
                    $employee = [];
                    foreach (request()->employee as $key => $value) 
                    {
                        if($emp = Employee::where('user_id',$value)->first())
                            $employee[$key] = ['user_id'=>$value,'main_id'=>$emp->id];
                        else
                            $employee[$key] = ['user_id'=>$value,'main_id'=>0];
                    }
                    $task->employees()->attach($employee,['master_id'=>request()->master_id,'type'=>'employee','identifier'=>'employee','created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 

                    $task->manager()->detach();
                    $manager = [];
                    if($emp = Employee::where('user_id', request()->manager)->first())
                        $manager[] = ['user_id'=>request()->manager,'main_id'=>$emp->id];
                    else
                        $manager[] = ['user_id'=>request()->manager,'main_id'=>0];
    
                    $task->employees()->attach($manager,['master_id'=>request()->master_id,'identifier'=>'employee','type'=>'manager','created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 

                    $task->supervisor()->detach();
                    $supervisor = [];
                    if($emp = Employee::where('user_id', request()->supervisor)->first())
                        $supervisor[] = ['user_id'=>request()->supervisor,'main_id'=>$emp->id];
                    else
                        $supervisor[] = ['user_id'=>request()->supervisor,'main_id'=>0];
    
                    $task->employees()->attach($supervisor,['master_id'=>request()->master_id,'identifier'=>'employee','type'=>'supervisor','created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
                });
            }
            elseif($access == 3 && request()->action == 'assign-contact')
            {
                Task::whereIn('id',request()->ids)->get()->each(function($task) 
                {
                    $contacts = [];

                    if(count(request()->new_value))
                    {
                        foreach (request()->new_value as $key => $value) {

                            if($contact = Contact::find($value))
                                $contacts[$key] = ['main_id'=>$value,'user_id'=> $contact->user_id > 0 ? $contact->user_id : 0];
                        }

                        $task->contacts()->attach(request()->new_value,['master_id'=>request()->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);
                      
                        TaskChangeLog::create(['action'=>'edit','task_id'=>$task->id,'column_name'=>request()->column_name,'new_value'=>implode(',',request()->new_value)]);
                        
                        if(count($contacts))
                            $task->contact_users()->attach(  $contacts,['master_id'=>request()->master_id,'type'=>'contact','identifier'=>'contact','created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
                    }
                    
                    
                   
                });
            }
            elseif($access == 3 && request()->action == 'assign-flag')
            {
                Task::whereIn('id',request()->ids)->get()->each(function($task) 
                {
                    $flags = [];

                    if(count(request()->new_value))
                    {
                        foreach (request()->new_value as $key => $value) {

                            if($flag = TaskFlag::find($value))
                                $flags[$key] = ['main_id'=>$value,'user_id'=> $flag->user_id > 0 ? $flag->user_id : 0];
                        }

                        $task->task_flags()->attach(request()->new_value,['master_id'=>request()->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);

                         
                    }
                                       
                });
            }
            elseif($access == 3 && request()->action == 'assign-ticket-stage')
            {
                Task::whereIn('id',request()->ids)->get()->each(function($task) 
                {
                    $ticket_stages = [];

                    if(count(request()->new_value))
                    {
                        foreach (request()->new_value as $key => $value) {

                            if($ticket_stage = TicketStage::find($value))
                                $ticket_stages[$key] = ['main_id'=>$value,'user_id'=> $ticket_stage->user_id > 0 ? $ticket_stage->user_id : 0];
                        }

                        $task->ticket_stages()->attach(request()->new_value,['master_id'=>request()->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);

                         
                    }
                                       
                });
            }
            elseif($access == 3 && request()->action == 'reset-service')
            {
                Task::whereIn('id',request()->ids)->get()->each(function($task) 
                {
                    $task->services()->detach(); 
                    $task->services()->attach(request()->new_value,['master_id'=>request()->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);
                });
            }
            else
                Task::whereIn('id',request()->ids)->update([request()->column => request()->status]);

            DB::commit();
            return response(['data' => array(),'success'=>true,'message' => 'Updated successfully'], 200);
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        
    }

    /**
     * update olf sahaj ticket
     * @author Debargha Chakraborty <debargha.chakraborty01@gmail.com>
     * @copyright Copyright (c) 2024, Debargha Chakraborty
     * @return \Illuminate\Http\Response
     */
    public function update_sahaj_ticket(Request $request,$id)
    {
        $ch = curl_init(env('OLD_SAHAJ_LINK').'update_sahaj_ticket/'.$id.'?master=dost');
        $request->merge([
            'updator' => Auth::user()->id
        ]);
        $jsonData = json_encode($request->toArray());
       
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Content-Length: ' . strlen($jsonData)
        ]);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);

        $response = curl_exec($ch);

        if ($response === false) {
            $error = curl_error($ch);
            curl_close($ch);
            throw new Exception("cURL error: $error");
        }

        curl_close($ch);
    }

    /**
     * Function used for inline edits
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra 06/09/2024
     * @return \Illuminate\Http\Response
     */
    public function change_log(Request $request,$id)
    {

        $not=DB::table('notifications')->max('batch_id');
        $this->notification_batch_id=$not+1;

        DB::beginTransaction();
        try {
            
            $task=Task::find($id);
            
            //30/07/2024
            if (request()->column_name == 'employee') {

                $task_users=DB::table('task_users')->where('task_id',$id)->where('type','!=',request()->column_name)->count();
                if((request()->column_value!='' &&  !is_array(request()->column_value)) || (is_array(request()->column_value) &&  count(request()->column_value)>0) || $task_users){
                    TaskChangeLog::create(['action' => 'edit', 'task_id' => $id, 'remarks' => request()->remarks, 'column_name' => request()->column_name, 'new_value' => json_encode(request()->column_value), 'old_value' => count($task->members) ? json_encode(array_column($task->members->toArray(), 'id')) : json_encode([])]);
                    $task->members()->detach();
                    $task->members()->attach(request()->column_value, ['master_id' => $request->master_id, 'type' => 'employee', 'created_by' => Auth::user()->id, 'updated_by' => Auth::user()->id, 'created_at' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s')]);
                }
                else
                return response()->json(['data' => array(), 'success' => false, 'message' => 'Atleast One of the Employee,Supervisor,Team Leader field is required!'], 502);

                
            } 
            elseif (request()->column_name == 'supervisor') {
                
                $task_users=DB::table('task_users')->where('task_id',$id)->where('type','!=',request()->column_name)->count();
                if(request()->column_value!='' || $task_users){
                    TaskChangeLog::create(['action' => 'edit', 'task_id' => $id, 'remarks' => request()->remarks, 'column_name' => request()->column_name, 'new_value' => json_encode(request()->column_value), 'old_value' => count($task->supervisor) ? json_encode(array_column($task->supervisor->toArray(), 'id')) : json_encode([])]);
                    $task->supervisor()->detach();
                    $task->supervisor()->attach(request()->column_value, ['master_id' => $request->master_id, 'type' => 'supervisor', 'created_by' => Auth::user()->id, 'updated_by' => Auth::user()->id, 'created_at' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s')]);
                }
                else
                return response()->json(['data' => array(), 'success' => false, 'message' => 'Atleast One of the Employee,Supervisor,Team Leader field is required!'], 502);
                
            }
             elseif (request()->column_name == 'manager') {
                $task_users=DB::table('task_users')->where('task_id',$id)->where('type','!=',request()->column_name)->count();
                if(request()->column_value!='' || $task_users){
                    TaskChangeLog::create(['action' => 'edit', 'task_id' => $id, 'remarks' => request()->remarks, 'column_name' => request()->column_name, 'new_value' => json_encode(request()->column_value), 'old_value' => count($task->manager) ? json_encode(array_column($task->manager->toArray(), 'id')) : json_encode([])]);

                    $task->manager()->detach();
                    $task->manager()->attach(request()->column_value, ['master_id' => $request->master_id, 'type' => 'manager', 'created_by' => Auth::user()->id, 'updated_by' => Auth::user()->id, 'created_at' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s')]);
                }
                else
                return response()->json(['data' => array(), 'success' => false, 'message' => 'Atleast One of the Employee,Supervisor,Team Leader field is required!'], 502);
                
            }
            //30/07/2024
            elseif(request()->column_name == 'regular-ticket-employee')
            {
                if(isset($request->employee) && count($request->employee)>0)
                {
                    TaskChangeLog::create(['task_id'=>$id,'remarks'=>'','column_name'=>'employee','new_value'=> json_encode($request->employee),'old_value'=> count($task->members) ? json_encode(array_column($task->members->toArray(),'id')) : json_encode([]) ]);
    
                    $task->members()->detach();
                    $task->members()->attach($request->employee,['master_id'=>$request->master_id,'type'=>'employee','created_by'=>$request->user_id,'updated_by'=>$request->user_id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
                  
                }
                if(isset($request->supervisor) && intval($request->supervisor)>0)
                {
                     
                    TaskChangeLog::create(['task_id'=>$id,'remarks'=>'','column_name'=>'supervisor','new_value'=> json_encode($request->supervisor),'old_value'=> count($task->supervisor) ? json_encode(array_column($task->supervisor->toArray(),'id')) : json_encode([]) ]);
    
                    $task->supervisor()->detach();
                    $task->supervisor()->attach($request->supervisor,['master_id'=>$request->master_id,'type'=>'supervisor','created_by'=>$request->user_id,'updated_by'=>$request->user_id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
                }
                if(isset($request->manager) && intval($request->manager)>0)
                {
                    TaskChangeLog::create(['task_id'=>$id,'remarks'=>'','column_name'=>'manager','new_value'=> json_encode($request->manager),'old_value'=> count($task->manager) ? json_encode(array_column($task->manager->toArray(),'id')) : json_encode([]) ]);
    
                    $task->manager()->detach();
                    $task->manager()->attach($request->manager,['master_id'=>$request->master_id,'type'=>'manager','created_by'=>$request->user_id,'updated_by'=>$request->user_id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
                }
            }
            elseif(request()->column_name == 'task_flag') //18/06/2024
            {

                TaskChangeLog::create(['action'=>'edit','task_id'=>$id,'remarks'=>request()->remarks,'column_name'=>request()->column_name,'new_value'=> json_encode(request()->column_value),'old_value'=> count($task->task_flags) ? json_encode(array_column($task->task_flags->toArray(),'id')) : json_encode([]) ]);

                $task->task_flags()->detach();
                $task->task_flags()->attach(request()->column_value,['master_id'=>$request->master_id,'created_by'=>$request->user_id,'updated_by'=>$request->user_id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
            }
            elseif(request()->column_name == 'contact')
            {
                
                TaskChangeLog::create(['action'=>'edit','task_id'=>$id,'remarks'=>request()->remarks,'column_name'=>request()->column_name,'new_value'=> json_encode(request()->column_value),'old_value'=> count($task->contacts) ? json_encode(array_column($task->contacts->toArray(),'id')) : json_encode([]) ]);

                $task->contacts()->detach();
                $task->contacts()->attach(request()->column_value,['master_id'=>$request->master_id,'created_by'=>$request->user_id,'updated_by'=>$request->user_id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
            }

            elseif(request()->column_name == 'officer') 
            {
                TaskChangeLog::create(['action'=>'edit','task_id'=>$id,'remarks'=>request()->remarks,'column_name'=>request()->column_name,'new_value'=> json_encode(request()->column_value),'old_value'=> count($task->officers) ? json_encode(array_column($task->officers->toArray(),'id')) : json_encode([]) ]);

                $task->officers()->detach();
                $task->officers()->attach(request()->column_value,['master_id'=>$request->master_id,'created_by'=>$request->user_id,'updated_by'=>$request->user_id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
            }
            
            elseif(request()->column_name == 'ticket_stages')
            {
                TaskChangeLog::create(['action'=>'edit','task_id'=>$id,'remarks'=>request()->remarks,'column_name'=>request()->column_name,'new_value'=> json_encode(request()->column_value),'old_value'=> count($task->ticket_stages) ? json_encode(array_column($task->ticket_stages->toArray(),'id')) : json_encode([]) ]);

                $task->ticket_stages()->detach();
                $task->ticket_stages()->attach(request()->column_value,['master_id'=>$request->master_id,'created_by'=>$request->user_id,'updated_by'=>$request->user_id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);    
            }
            else
            { 
                 TaskChangeLog::create(['action'=>'edit','task_id'=>$id,'remarks'=>request()->remarks,'column_name'=>request()->column_name,'new_value'=>request()->column_value,'old_value'=>$task->{request()->column_name}]);

                $task->update([$request->column_name => $request->column_value]);

                if($request->column_name == 'status' && $task->type == 'ist' && $task->ist_type == 'attendance-request')
                {
                    if($request->column_value == 2)
                    {
                        $changes = TaskIstChangeRequest::where('task_id',$task->id)->get();

                        foreach ($changes as $key => $value) {

                            if($value->change_column_name == 'start_time')
                            {
                                $employee = Employee::with([
                                    'employee_timings' => function ($query) use ($value){
                                        $query->where('day','=',date('N',strtotime($value->date)));
                                    }
                                ])->where('user_id',$value->user_id)->first();
                                
                                if(count($employee->employee_timings))
                                {
                                    $employee->schedule_in_time = $employee->employee_timings[0]->in;
                                    $employee->schedule_out_time = $employee->employee_timings[0]->out;
                                    $employee->schedule_lunch_time = $employee->employee_timings[0]->lunch;
                                    $employee->schedule_grace_time = $employee->employee_timings[0]->grace;
                                }
                                
                                DailyAttendance::where('user_id',$value->user_id)->where('date',$value->date)->delete();
                                DailyAttendanceLog::where('user_id',$value->user_id)->where('date',$value->date)->delete();

                                $attendance = DailyAttendance::create([
                                    'user_id'=>$value->user_id,
                                    'emp_id'=>$value->emp_id,
                                    'schedule_in' =>$employee->schedule_in_time,
                                    'schedule_out' =>$employee->schedule_out_time,
                                    'schedule_break'=> $employee->schedule_lunch_time,
                                    'schedule_grace'=>$employee->schedule_grace_time,
                                    'date'=>$value->date,
                                    'start_time'=>$value->changed_value,
                                    'start_date_time'=>$value->date." ".$value->changed_value,
                                    'status'=>1,
                                    'is_ist'=>1, // 25/09/2024 Jyoti
                                    'task_id'=>$task->id // 25/09/2024 Jyoti
                                ]);

                                DailyAttendanceLog::create([
                                    'daily_attendance_id' => $attendance->id,
                                    'user_id'=>$value->user_id,
                                    'emp_id'=>$value->emp_id,
                                    'schedule_in' =>$employee->schedule_in_time,
                                    'schedule_out' =>$employee->schedule_out_time,
                                    'schedule_break'=> $employee->schedule_lunch_time,
                                    'schedule_grace'=>$employee->schedule_grace_time,
                                    'date'=>$value->date,
                                    'start_time'=>$value->changed_value,
                                    'start_date_time'=>$value->date." ".$value->changed_value,
                                    'status'=>1
                                ]);
                            }
                            
                        }

                        if($template = NotificationTemplate::where('name','ist-approval-notification')->where('status',1)->first())
                        {
                            $user=User::find($request->user_id);
                            $notification_data['template'] = $template;
                            $notification_data['host'] =isset($user->name)?$user->name:'';
                            $notification_data['agenda'] = $request->remarks;
                            $notification_data['status_name'] = 'Approved';
                            $notification_data['start_date'] = date('d/m/Y H:i A');
                            $recipients=[];
                            $requested_user=User::find($task->created_by);
                                if($requested_user!=null)
                                 $recipients[]=array('email'=>$requested_user->email,'name'=>$requested_user->name,'mail_type'=>'to');
                            if($requested_user)
                            {
                              
                                $phoneNumber = $requested_user->phone; // The phone number to send the SMS to
                                $message = 'Dear '.$requested_user->name.', this is your SMS message!';
                                $requested_user->notify(new SendSmsNotification($phoneNumber, $message));

                                Notification::send($requested_user, new SendNotification($notification_data,$task,$recipients,$request->type,$this->notification_batch_id));
                                //24/05/24
                                if(isset($notification_data['template']) && isset($notification_data['template']['email_body']))
                                $this->template_body=$notification_data['template']['email_body'];
                            }  

                            $this->sendMailFunc($this->notification_batch_id,$this->template_body,$task->id); //24/05/24
    
                        }
                        if($template2 = NotificationTemplate::where('name','ist-approval-employees')->where('status',1)->first())
                        {
                            $user=User::find($request->user_id);
                            $requestee=User::find($task->created_by);
                            $user_ids=[];

                            $taskusers=DB::table('task_users')->where('type','!=','employee')->where('task_id',$task->id)->get();
               
                            foreach($taskusers as $users){
                                $user_ids[]=$users->user_id;
                            }
                            $user_ids=count($user_ids)>0?array_unique($user_ids):$user_ids;
                            $notification_data2['template'] = $template2;
                            $notification_data2['host'] =isset($user->name)?$user->name:'';
                            $notification_data2['agenda'] = $request->remarks;
                            $notification_data2['status_name'] = 'Approved';
                            $notification_data2['requestee_name'] = isset($requestee->name)?$requestee->name:'';
                            $notification_data2['start_date'] = date('d/m/Y H:i A');
                          
                            $users=User::whereIn('id',$user_ids)->get()->toArray();
                            $recipients=[];
                          
                            if(count($users)>0)
                            {
                                foreach($users as $reci)
                                {
                                    $recipients[]=array('email'=>$reci['email'],'name'=>$reci['name'],'mail_type'=>'to');
                                }
                            }
                            if($user_ids && count($user_ids)>0)
                            {
                                $invitie_users = User::whereIn('id',$user_ids)->get();
                                foreach( $invitie_users as $user)
                                {
                                    $phoneNumber = $user->phone; // The phone number to send the SMS to
                                    $message = 'Dear '.$user->name.', this is your SMS message!';
                                    $user->notify(new SendSmsNotification($phoneNumber, $message));
                                }
                                Notification::send($invitie_users, new SendNotification($notification_data,$task,$recipients,$request->type,$this->notification_batch_id));
                                //24/05/24
                                if(isset($notification_data2['template']) && isset($notification_data2['template']['email_body']))
                                $this->template_body=$notification_data2['template']['email_body'];
                            }  
                            $this->sendMailFunc($this->notification_batch_id,$this->template_body,$task->id); //24/05/24
                        }


                    }
                }
            }


            
            DB::commit();

            /******for change the old sahaj ticket ********** */
            if(request()->column_name =='supervisor'  || request()->column_name =='manager' || request()->column_name =='employee' || request()->column_name =='contact' ||  request()->column_name =='status' )
                $this->update_sahaj_ticket($request,$id);

            $task = Task::with('change_logs.creator','change_logs.editor')->find($id);
            return response(['data' =>  new TaskResource($task),'success'=>true,'message' => 'Task Updated Successfully'], 200);

        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }
    }

     /**
     * Function used for Task View
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function view(Request $request,$id)
    {
        $task=Task::with('communications.from','communications.replies','communications.replies.from','communications.replies.files','communications.replies.recipients','communications.files','communications.recipients','files.file_sources','task_flags','change_logs','change_logs.creator','referral','ticket_stages','notes.creator','notes.updator','members','supervisor','manager','officers','department_purpose')->withCount('calls','meetings','todos','help_tickets','department_tasks','crds','communications')->find($id);

        if($task->type == 'ist')
            $task->change_requests = TaskIstChangeRequest::with('user')->where('task_id',$task->id)->get();

        // if(!$this->checkViewAccess($task))
        //     return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        $attendances = DailyAttendanceReport::withSum('expenses as given_expense', 'daily_attendance_expenses.given_cost')->withSum('expenses as approved_expense', 'daily_attendance_expenses.approved_cost')->with('employee','company','service','expenses','files')->where('task_id',$id)->get();

        return response(['data' =>  new TaskResource($task), 'attendances'=>$attendances,'success'=>true,'message' => 'Task Updated Successfully'], 200);

    }
   
     /**
     * Function used for Task View
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */

     /**
     * Function used for Create Notes In Ticket View
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @param $id = Task Id
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function create_note(Request $request,$id)
    {
        $task = Task::find($id);

        $validator = Validator::make($request->all(), [
            'note' => 'required',

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }
        

        DB::beginTransaction();
        try {

            $data = ['note'=>$request->note];

            $object = new TaskNote($data);

            $task->notes()->save($object);

            DB::commit();
        
            return response(['data' => new TaskResource($task),'success'=>true,'message' => 'Note Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

     /**
     * Function used for Delete Note In Ticket View
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @param $id = Task Note Id (task_notes table id)
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function delete_note(Request $request,$id)
    {
        DB::beginTransaction();
        try {

            //TaskNote::where('id',$id)->delete();
            
            TaskNote::destroy($id);
            
            DB::commit();
        
            return response(['data' => [],'success'=>true,'message' => 'Note Deleted Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }
    /**
     * Function used for Inline Edit Note In Ticket View
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @param $id = Task Note Id (task_notes table id)
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function note_change_log(Request $request,$id)
    {
        DB::beginTransaction();
        try {
            
            $task_note=TaskNote::find($id);

            $task_note->update([$request->column_name => $request->column_value]);
            
            DB::commit();
            return response(['data' =>  $task_note,'success'=>true,'message' => 'Task Note Updated Successfully'], 200);

        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }
    }

    /**
     * Function used for Add Check List In Ticket View
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @param $id = Task Id
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function create_check_list(Request $request,$id)
    {
        $task = Task::find($id);

        $validator = Validator::make($request->all(), [
            'description' => 'required',

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }
        

        DB::beginTransaction();
        try {


            $object = new TaskCheckList($request->all());

            $check_list = $task->check_lists()->save($object);

            DB::commit();
        
            return response(['data' =>new TaskCheckListResource($check_list),'success'=>true,'message' => 'Check List Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }
     /**
     * Function used for Marking Checked for Check List In Ticket View
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @param $id = Task Check List Id (task_check_lists table id)
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function check_check_list(Request $request,$id)
    {
        DB::beginTransaction();
        try {

            $task_check_list = TaskCheckList::find($id);
            $task_check_list->update(['checked_by'=> Auth::user()->id,'checked_on'=>date('Y-m-d H:i:s'),'status'=>1]);
            DB::commit();
        
            return response(['data' => new TaskCheckListResource($task_check_list),'success'=>true,'message' => 'Check List Checked Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }
    /**
     * Function used for Marking Rejected for Check List In Ticket View
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @param $id = Task Check List Id (task_check_lists table id)
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function reject_check_list(Request $request,$id)
    {
        DB::beginTransaction();
        try {

            
            $task_check_list = TaskCheckList::find($id);
            $task_check_list->update(['rejected_by'=> Auth::user()->id,'rejected_on'=>date('Y-m-d H:i:s'),'status'=>2]);
            DB::commit();
        
            return response(['data' => new TaskCheckListResource($task_check_list),'success'=>true,'message' => 'Check List Rejected Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Function used for Delete Check List In Ticket View
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @param $id = Task Check List Id (task_check_lists table id)
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function delete_check_list(Request $request,$id)
    {
        DB::beginTransaction();
        try {

            //TaskNote::where('id',$id)->delete();
            
            TaskCheckList::destroy($id);
            
            DB::commit();
        
            return response(['data' => [],'success'=>true,'message' => 'Check List Deleted Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }
    /**
     * Function used for Request Check List In Ticket View
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @param $id = Task Id (tasks table id)
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function request_check_list(Request $request,$id)
    {
        $task = Task::find($id);

        $validator = Validator::make($request->all(), [

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }
        

        DB::beginTransaction();
        try {

            if($request->input('check_list') != null && count($request->input('check_list'))>0)
            {
               
                foreach ($request->input('check_list') as $data) 
                {
                    if(!empty($data['description']))
                    {
                        if(intval($data['id']) > 0)
                        {
                            if($object = TaskCheckList::withTrashed()->find($data['id']))
                            {
                                $object->restore();
                                $object->fill($data);
                            }
                            else
                                $object = new TaskCheckList($data);
                        }
                        else
                            $object = new TaskCheckList($data);
                        
                        
                        $task->check_lists()->save($object);
                    
                    }        
                }
            }
            

            DB::commit();
        
            return response(['data' =>new TaskResource($task),'success'=>true,'message' => 'Check List Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

     /**
     * Function used for inline edits in check list
     * @param $id =  Task Check List Id (task_check_lists table id)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function check_list_change_log(Request $request,$id)
    {
        DB::beginTransaction();
        try {
            
            $task_check_list=TaskCheckList::find($id);

            $task_check_list->update([$request->column_name => $request->column_value]);
            
            DB::commit();
            return response(['data' =>  new TaskCheckListResource($task_check_list),'success'=>true,'message' => 'Task Check List Updated Successfully'], 200);

        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }
    }
    /**
     * Function used to retrive sub tasks of a Ticket
     * @param $id =  Task Id (tasks table id)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function sub_tasks_by_id(Request $request,$id)
    {
        $task=Task::findOrFail($id);
        
        return response(['data' =>TaskResource::collection($task->sub_tasks),'task'=>new TaskResource($task),'success'=>true,'message' => 'Data Retrived Successfully'], 200);

    }

    /**
     * Function used to reschedule a task
     * @param $id =  Task Id (tasks table id)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function reschedule_task(Request $request,$id)
    {
        $task=Task::with('check_lists','files','services','companies','contacts','contact_users','employees')->find($id);

        $old_status=$task->status; 

        $validator = Validator::make($request->all(), [
           

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {

            $task->status = $request->status;
            $task->remarks = $request->description;
            $task->save();

            $new_task = $task->replicate();
            $new_task->status = 0;
            $new_task->parent_id = $task->id;
            $new_task->description = $request->description;
            $new_task->start_date = $request->start_date;
            $new_task->save();
            
            // 25/09/2024 Jyoti
            TaskChangeLog::create(['action'=>'update','task_id'=>$task->id,'remarks'=>$task->remarks,'column_name'=>'status','old_value'=>$old_status,'new_value'=>$request->status]);

            if($task->check_lists && count($task->check_lists))
            {
                $check_list_data = [];
                foreach ($task->check_lists as $check_list) 
                {
                    if(!empty($check_list->description))
                    {
                        
                        $check_list_data['description']  = $check_list->description;
                        $check_list_data['user_id']  = $check_list->user_id;
                        $check_list_data['is_restrict']  = $check_list->is_restrict;

                        
                        $object = new TaskCheckList($check_list_data);
                        
                        
                        $new_task->check_lists()->save($object);
                    
                    }        
                }
            }
            if($task->files && count($task->files))
            {
                $file_data = [];
                foreach ($task->files  as $file) 
                {
                    
                    $file_data['identifier']=isset($file->identifier)?$file->identifier:"task";
                    $file_data['file_path']=$file->file_path;
                    $file_data['file_name']=$file->file_name;
                    $file_data['file_extension']=$file->file_extension;
                    $file_data['file_size']=$file->file_size;

                    $file_data['file_description']=$file->file_description;
                    $file_data['file_type_id']=$file->file_type_id;
                    $file_data['is_client_access']=$file->is_client_access;
                    $file_data['file_stage_id']=$file->file_stage_id;

                    $file_data['start_date']=$file->start_date;
                    $file_data['end_date']=$file->end_date;
                    $file_data['document_date']=$file->document_date;


                    $object = new File($file_data);    
                    $new_task->files()->save($object);
                }
            }
            if($task->services && count($task->services))
            {
                $new_task->services()->attach($task->services->pluck('id')->toArray(),['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
            }
            if($task->companies && count($task->companies) > 0)
            {
                $new_task->companies()->attach($task->companies->pluck('id')->toArray(),['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
            }
            if($task->contacts && count($task->contacts) > 0)
            {
                $contacts = [];
                foreach ($task->contacts as $key => $value) {
                    if($contact = Contact::find($value->id))
                        $contacts[$key] = ['main_id'=>$value->id,'user_id'=> $contact->user_id > 0 ? $contact->user_id : 0];
                }
                $new_task->contacts()->attach($task->contacts->pluck('id')->toArray(),['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
                
                $new_task->contact_users()->attach(  $contacts,['master_id'=>$request->master_id,'type'=>'contact','identifier'=>'contact','created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
            }
            if($task->members && count($task->members) > 0)
            {
                $employee = [];
                foreach ($task->members as $key => $value) 
                {
                    if($emp = Employee::where('user_id',$value->id)->first())
                        $employee[$key] = ['user_id'=>$value->id,'main_id'=>$emp->id];
                    else
                        $employee[$key] = ['user_id'=>$value->id,'main_id'=>0];
                }
                $new_task->employees()->attach($task->members->pluck('id')->toArray(),['master_id'=>$request->master_id,'type'=>'employee','identifier'=>'employee','created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
            }
            if($task->manager && count($task->manager) > 0)
            {
                $manager = [];
                if($emp = Employee::where('user_id', $task->manager[0]->id)->first())
                    $manager[] = ['user_id'=>$task->manager[0]->id,'main_id'=>$emp->id];
                else
                    $manager[] = ['user_id'=>$task->manager[0]->id,'main_id'=>0];

                $new_task->employees()->attach($task->manager->pluck('id')->toArray(),['master_id'=>$request->master_id,'identifier'=>'employee','type'=>'manager','created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
            }
            if($task->supervisor && count($task->supervisor) > 0)
            {
                $supervisor = [];
                if($emp = Employee::where('user_id', $task->supervisor[0]->id)->first())
                    $supervisor[] = ['user_id'=>$task->supervisor[0]->id,'main_id'=>$emp->id];
                else
                    $supervisor[] = ['user_id'=>$task->supervisor[0]->id,'main_id'=>0];

                $new_task->employees()->attach($task->supervisor->pluck('id')->toArray(),['master_id'=>$request->master_id,'identifier'=>'employee','type'=>'supervisor','created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
            }
            
            $new_task->save();

            DB::commit();
            
            return response(['data' => new TaskResource($new_task),'success'=>true,'message' => 'Task Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /***********************Information Section Related Code*************************/
     /**
     * Function used to Generate View for Information Upload
     * @param $id =  Task Id (tasks table id)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2024, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function info_view(Request $request,$id)
    {
        $task=Task::with('information_items','information_sub_groups','files')->with(['information_sub_groups.information_task_items'=> function($q) use ($id){  
                $q->where('task_information_items.task_id',$id);
        }])->find($id);

        if(count($task->information_items))
        {
            foreach ($task->information_items as $key => $value) 
            {
                $task->information_items[$key]->files = File::where('identifier','task')->where('main_id',$id)->where('task_information_item_id',$value->pivot->id)->get();
                if(count($task->information_items[$key]->files) == 0)
                {
                    $task->information_items[$key]->files = [
                        [
                            'isEdit'=>true,
                            'file_name'=>''
                        ]
                    ];
                }
            }
        }

        $task_subarray = [];
        if(count($task->information_sub_groups))
        {
            foreach ($task->information_sub_groups as $key => $value) 
            {
               
             
               if(count($value->information_task_items))
               {
                    $counter = 0;
                    do
                    {
                        
                        
                        foreach ($value->information_task_items as $itemkey => $itemvalue) 
                        {
                            $max_index_file_sub = DB::table('files')
                            ->select(DB::raw('MAX(information_sub_group_index) as max_index'))->where('main_id',$id)->where('identifier','task')->where('information_sub_group_id',$value->id)->whereNull('deleted_at')
                           ->get();
                            $task_subarray['information_sub_group'][$counter]['id'] = $value->id;
                            $task_subarray['information_sub_group'][$counter]['pivot'] = $value->pivot;
                            $task_subarray['information_sub_group'][$counter]['information_items'][$itemkey]['id']=$itemvalue->id;
                            $task_subarray['information_sub_group'][$counter]['information_items'][$itemkey]['type']=$itemvalue->type;
                            $task_subarray['information_sub_group'][$counter]['information_items'][$itemkey]['pivot']=$itemvalue->pivot;
                           // DB::enableQueryLog();
                            $task_subarray['information_sub_group'][$counter]['information_items'][$itemkey]['files'] = File::where('identifier','task')->where('main_id',$id)->where('task_information_item_id',$itemvalue->pivot->id)->where('information_sub_group_id',$value->id)->where('information_sub_group_index',$counter)->get()->toArray();
                            //dd(DB::getQueryLog());
                            if(count( $task_subarray['information_sub_group'][$counter]['information_items'][$itemkey]['files']) == 0)
                            {
                                $task_subarray['information_sub_group'][$counter]['information_items'][$itemkey]['files'] = [
                                    [
                                        'isEdit'=>true,
                                        'file_name'=>''
                                    ]
                                ];
                            }
                        }
                       
                        $counter++;
                    }
                    while($counter<=$max_index_file_sub[0]->max_index);
                }
            }

            $task->information_subgroup =   $task_subarray['information_sub_group'];
        }
        //dd($task_subarray['information_sub_group']); exit;
        

        return response(['data' =>  new TaskResource($task),'success'=>true,'message' => 'Task Updated Successfully'], 200);
    }
      /**
     * Function used to Generate Data For Information Request
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2024, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function crd_getlist(Request $request)
    {
        $data['information_groups'] = InformationGroup::with('information_items','information_sub_groups.information_group_items')->where('status',1)->get();
        $data['information_sub_groups'] = InformationSubGroup::with('information_group_items')->where('status',1)->get();
        $data['information_items'] = InformationItem::where('status',1)->get();
        
        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
      /**
     * Function used to Save Data For Information Request
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2024, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function save_new_info_request(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'file_name' => 'required'

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }
        

        DB::beginTransaction();
        try {

            $file = File::create($request->all());


            DB::commit();
        
            return response(['data' =>$file,'success'=>true,'message' => 'File Updated Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }
      /**
     * Function used to Save Data For Information Request
     * @param $id =  File Id (files table id)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2024, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function update_info_request(Request $request,$id)
    {
        $file = File::find($id);

        $validator = Validator::make($request->all(), [
            'file_name' => 'required'

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }
        

        DB::beginTransaction();
        try {

           
            $file->update($request->all());

            DB::commit();
        
            return response(['data' =>$file,'success'=>true,'message' => 'File Updated Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }


     /**
     * Function used to Create Meeting Request From Frontend(Appointment)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2024, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function meeting_request(Request $request)
    {
        $validator = Validator::make($request->all(), [

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }
        

        DB::beginTransaction();
        try {

            $slot = explode('-',$request->input('slot'));
            MeetingRequest::create(
                [
                    'user_id'=>$request->input('user_id'),
                    'date'=>$request->input('start_date'),
                    'start_time'=>$slot[0],
                    'end_time'=>$slot[1],
                    'name'=>$request->input('name'),
                    'email'=>$request->input('email'),
                    'phone'=>$request->input('phone'),
                    'description'=>$request->input('description'),
                    'status'=>0
                ]
            );

            DB::commit();
        
            return response(['data' =>[],'success'=>true,'message' => 'Your Request Has Been Sent,You Will Be Notified Shortly'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Function used to generate meeting request list in dashboard
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2024, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function meeting_request_list(Request $request)
    {
        $query = QueryBuilder::for(MeetingRequest::class)->allowedFilters(['name','email','phone','description','date','start_time','end_time'])->defaultSort('-created_at')->allowedSorts('name','email','phone','description','date','start_time','end_time');

        $query->search(!empty($request->search)?$request->search:"");

        $meeting_requests = $query->advanceSearch($request->advfilter,'meeting_requests')->where('status',0)->checkPermission('user_id')->get();

        $this->saveAdvanceSearchData($request);

        return response(['data' => $meeting_requests,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Function used to generate meeting request update in dashboard
     * @param $id -- Meeting Request ID
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2024, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function meeting_request_update(Request $request, $id)
    {
        $meeting_request=MeetingRequest::find($id);
        
        /*if(!$this->checkUpdateAccess($meeting_request))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);
        */

        $validator = Validator::make($request->all(), [

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {

            $meeting_request->update([$request->column_name => $request->column_value,'remarks'=>$request->remarks]);

            if($request->column_name == 'status' && $request->column_value == 1)
            {
                $task = Task::create([
                    'description'=>$meeting_request->description,
                    'status'=>0,
                    'type'=>'meeting',
                    'start_date'=>date('Y-m-d H:i:s',strtotime($meeting_request->date." ".$meeting_request->start_time)),
                    'received_date'=>$meeting_request->created_at,
                    'meeting_type'=>'online',
                ]);

                $supervisor = [];
                if($emp = Employee::where('user_id',$meeting_request->user_id)->first())
                    $supervisor[] = ['user_id'=>$meeting_request->user_id,'main_id'=>$emp->id];
                else
                    $supervisor[] = ['user_id'=>$meeting_request->user_id,'main_id'=>0];

                $task->employees()->attach($supervisor,['master_id'=>$request->master_id,'type'=>'supervisor','identifier'=>'employee','created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);

                if($user=User::where('email',$meeting_request->email)->first())
                {
                    TaskInvitie::create([
                        'user_id'=>$user->id,
                        'task_id'=>$task->id
                    ]);
                }
                else
                {
                    $user=new User;
                    $user->name = $meeting_request->name;
                    $user->email = $meeting_request->email;

                    $user->password = Hash::make('1234');

                    $user->is_superadmin = 0;

                    $user->status = 0;    
                    $user->save();

                    TaskInvitie::create([
                        'user_id'=>$user->id,
                        'task_id'=>$task->id,
                        'type' => 'external'

                    ]);
                }
               
                $zoom_api_info = $this->create_zoom_meeting($task);
                $task->update([
                    'meeting_external_id'=>$zoom_api_info['id'],
                    'meeting_start_url'=>$zoom_api_info['start_url'],
                    'meeting_invite_url'=>$zoom_api_info['join_url']
                ]);

                if($template = NotificationTemplate::where('name','online-meeting-invitation')->where('status',1)->first())
                {
                    $notification_data['template'] = $template;
                    $notification_data['meeting_invite_url'] = $task->meeting_invite_url;
                    $notification_data['host'] = $task->supervisor[0]->name;
                    $notification_data['agenda'] = $task->description;
                    $notification_data['start_date'] = date('d/m/Y H:i A',strtotime($task->start_date));

                    Notification::send($user, new SendNotification($notification_data,$task,$recipients,$request->type,$this->notification_batch_id));
                }

                DB::commit();
                
            }
            elseif($request->column_name == 'status' && $request->column_value == 2)
            {
                // if(!$user=User::where('email',$meeting_request->email)->first())
                // {
                //     $user=new User;
                //     $user->name = $meeting_request->name;
                //     $user->email = $meeting_request->email;

                //     $user->password = Hash::make('1234');

                //     $user->is_superadmin = 0;

                //     $user->status = 0;    
                //     $user->save();
                // }
                $employee = User::find($meeting_request->user_id);    
                if($template = NotificationTemplate::where('name','online-meeting-invitation-reject')->where('status',1)->first())
                {
                    $notification_data['template'] = $template;
                    $notification_data['name'] = $meeting_request->name;
                    $notification_data['remarks'] = $meeting_request->remarks;
                    $notification_data['employee_email'] = $employee->email;

                   // Notification::send($meeting_request->email, new OnlineInvitationRejectNotification($notification_data));  
                   Notification::route('mail', $meeting_request->email)->notify(new OnlineInvitationRejectNotification($notification_data));              
                }

                DB::commit();
            }

            DB::commit();
            
            return response(['data' => $meeting_request,'success'=>true,'message' => 'Request Updated Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Function used to update task history data
     * @param $id -- Task Id
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2024, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function meeting_history_update(TaskHistoryUpdateRequest $request, $id)
    {
        $validator = Validator::make($request->all(), [

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {

            $request->merge([
                'task_id' => $id
            ]);

            if($task_history = TaskHistory::where('user_id',Auth::user()->id)->where('task_id',$id)->first())
            {
                $task_history->update($request->all());
            }
            else
            {
                $task_history = TaskHistory::create($request->all());
            }
            

            DB::commit();
            return response(['data' => $task_history,'success'=>true,'message' => 'Request Updated Successfully'], 200);

        }catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }
    /**
     * Function used to fetch meetings of the day
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2024, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function my_meetings(Request $request)
    {
        $authuser = Auth::user();

        $query = Task::where('status',0)->whereIn('type',['meeting','department-task']);

        $query->whereHas('employees', function ($q) use ($authuser){
            $q->where('task_users.user_id',$authuser->id);
        });

        $query->whereRaw('DATE(start_date) = ?',[$request->date ? $request->date : date('Y-m-d')]);

        $meetings = $query->with('contacts','companies','employees','files')->with( ['history'=> function($q) use ($authuser){
                $q->where('user_id',$authuser->id);
        }])->get();

        
        return response(['data' => $meetings,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

     /**
     * Function used for ist change request update
     * @param $id -- Task IST Change Request Id
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2024, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function ist_change_log(Request $request,$id)
    {
        $validator = Validator::make($request->all(), [

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {

            $task_change_req = TaskIstChangeRequest::find($id);
            $task_change_req->update([$request->column_name=>$request->column_value]);

            DB::commit();
            return response(['data' => $task_change_req,'success'=>true,'message' => 'Request Updated Successfully'], 200);

        }catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

     /**
     * Function used for ist change request update
     * @param $id -- Task IST Change Request Id
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2024, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function task_department_info(Request $request,$id)
    {
        $task = Task::with('officers.address','officers.departments.department_type','department_info.purpose')->find($id);
        return response(['data' => $task,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }


     /**
     * Function used to update officer information in ticket view
     * @param $id -- Task IST Change Request Id
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2024, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function task_officer_update(Request $request,$id)
    {
        $validator = Validator::make($request->all(), [

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {

            $task = Task::find($id);
          
            if($request->input('officer') && count($request->input('officer')))
            {
                $task->officers()->detach();
                $task->officers()->attach($request->input('officer'),['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
            }
           

            DB::commit();
            return response(['data' => Task::with('officers.address','officers.departments.department_type')->find($id),'success'=>true,'message' => 'Request Updated Successfully'], 200);

        }catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

      /**
     * Function used to show tasks by ticket id (For Mobile App)
     * @param $id -- Task IST Change Request Id
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2024, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */

     public function task_calender(Request $request,$id)
     {
      
        $data = Task::where('main_id',$id)->with('services','contacts','companies','employees','files','supervisor')->whereIn('type',['meeting','call','todo','crd','help-ticket','department-task'])->where('status',0)->get();

       

        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
     }



      /**
     * Function used to show tasks by company id (For Mobile App)
     * @param $id -- Company Id
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2024, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function get_task_by_company(Request $request,$id)
    {
        $authuser = Auth::user();
        
        $data = Task::whereHas('companies', function ($q) use ($id){
            $q->where('contacts.id',$id);
        })->whereHas('employees', function ($q) use ($authuser){
            $q->where('task_users.user_id',$authuser->id);
        })->with('services','contacts','companies','employees','files','supervisor')->whereIn('type',['regular-ticket'])->where('status',0)->get();

        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);


    }

    /**
     * Function used to get schedule call list
     * @param Request $request
     * @author Debargha Chakaborty <debargha.chakraborty01@gmail.com>
     * @copyright  Copyright (c) 2024, Debargha Chakaborty
     * @return \Illuminate\Http\Response
     */
    public function schedule_calls(Request $request)
    {
        $task=Task::with('contacts','employees')->where('type','call')->where('status','!=',2)->whereRaw('DATE(start_date) = ?', [date('Y-m-d')])->get()->toArray();
        return response(['data' => $task, 'success' => true, 'message' => 'Data Retrived Successfully'], 200);
    }

   /**
     * Function used to call schedule calls
     * @param Request $request
     * @author Debargha Chakaborty <debargha.chakraborty01@gmail.com>
     * @copyright  Copyright (c) 2024, Debargha Chakaborty
     * @return \Illuminate\Http\Response
     */
    public function knowlarity_schedule_calldata(Request $request)
    {
        if(count($request->contacts)>0 && intval($request->employees)>0)
        {
            DB::beginTransaction();
            try
            {
                $employee=Employee::where('user_id',$request->employees[0]['id'])->first();//04/09/2024
                $newrequest = new Request();
                $newrequest->merge([
                    'customer_number' => $request->contacts[0]['phone'],
                    'agent_number' => $employee->phone,
                    'identifier'=>'task',
                    'task_id'=>$request->id,
                ]);
                $this->knowlarity_place_call($newrequest);
                Task::where('id',$request->id)->update(['status'=>2]);
                $task=Task::find($request->id);
                DB::commit();
                return response(['data' => $task, 'success' => true, 'message' => 'Data Retrived Successfully'], 200);
            } catch (Exception $ex) {

                DB::rollBack();
                return response(['data' => array(), 'success' => true, 'message' =>  $ex->getMessage()], 500);
            }

        } 
       
    }

     /**
     * Function used push knowlarity data
     * @param Request $request
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2024, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */

    public function knowlarity_data_push(Request $request)
    {
	  DB::table('sendgrid_perse')->insert(
	  [
	      'value'=>'data is coming'
	  ]
	 );

	 DB::table('sendgrid_perse')->insert(
            [
              'value'=>json_encode($request->toArray())
            ]
        );
        $data = array();
        $emp_id = "";
        $retutn_id = '';
        $agent_number = $this->validate_mobile($request->agent_number);
         DB::table('sendgrid_perse')->insert(
		           [
				                 'value'=>'data is coming2'
						           ]
							            );

        if (!empty($agent_number)) {
            $phone = Phone::where('phone_no', $agent_number)->where('identifier', 'employee')->first();
            if ($phone)
                $employee = Employee::find($phone->main_id);
            else
                $employee = Employee::where('phone', $agent_number)->first();


            if ($employee)
                $emp_id = $employee->id;
        }

        DB::beginTransaction();
        try {

            if (isset($request->type) && $request->type == 'incoming') 
            {
                $file_name = "";

                if (env('KNOWLARITY_BLOCK_NUMBER') != '') {
                    $block_arr = explode(",", env('KNOWLARITY_BLOCK_NUMBER'));

                    if (!in_array($request->caller_number, $block_arr)) {

                        $retutn_id = DB::table('call_logs')->insertGetId(
                            array(

                                'master_id' => 1,
                                'call_type' => $request->type,
                                'call_date' => $request->call_date,
                                'call_time' => $request->call_time,
                                'caller_number' => $request->caller_number,
                                'called_number' => $request->called_number,
                                'call_status' => $request->call_status,
                                'menu' => $request->menu_extension,
                                'agent_list' => $request->legs_data,
                                'agent_number' => $request->agent_number,
                                'call_transfer_status' => $request->call_transfer_status,
                                'caller_duration' => $request->caller_duration,
                                'conversation_duration' => $request->conversation_duration,
                                'recording_url' => $request->recording_url,
                                'call_uuid' => $request->call_uuid,
                                'created_by' => 1,
                                'updated_by' => 1,
                                'emp_id' => $emp_id,
                                'created_at' => date('Y-m-d H:i:s'),
                                'updated_at' => date('Y-m-d H:i:s')
                            )
                        );

                      /*  if(isset($request->mst_var3))
                        {
                            DB::table('call_log_tracks')->where('task_id',$request->mst_var3)->update(
                                [
                                    'call_status' => $request->call_status,
                                    'call_transfer_status' => $request->call_transfer_status
                                ]
                            );
			}*/

                    }
                } else {
                    $retutn_id = DB::table('call_logs')->insertGetId(
                        array(

                            'master_id' => 1,
                            'call_type' => $request->type,
                            'call_date' => $request->call_date,
                            'call_time' => $request->call_time,
                            'caller_number' => $request->caller_number,
                            'called_number' => $request->called_number,
                            'call_status' => $request->call_status,
                            'menu' => $request->menu_extension,
                            'agent_list' => $request->legs_data,
                            'agent_number' => $request->agent_number,
                            'call_transfer_status' => $request->call_transfer_status,
                            'caller_duration' => $request->caller_duration,
                            'conversation_duration' => $request->conversation_duration,
                            'recording_url' => $request->recording_url,
                            'call_uuid' => $request->call_uuid,
                            'created_by' => 1,
                            'updated_by' => 1,
                            'emp_id' => $emp_id,
                            'created_at' => date('Y-m-d H:i:s'),
                            'updated_at' => date('Y-m-d H:i:s')
                        )
                    );
              /*      if(isset($request->mst_var3))
                    {
                        DB::table('call_log_tracks')->where('task_id',$request->mst_var3)->update(
                            [
                                'call_status' => $request->call_status,
                                'call_transfer_status' => $request->call_transfer_status
                            ]
                        );
		    }*/
                }
            } elseif (isset($request->type) && $request->type == 'outgoing') {

                $file_name = "";
                $retutn_id = DB::table('call_logs')->insertGetId(
                    array(
                        'master_id' => 1,
                        'call_type' => $request->type,
                        'call_date' => $request->call_date,
                        'call_time' => $request->call_time,
                        'caller_number' => $request->caller_number, //CLI No
                        'called_number' => $request->called_number, //Client No
                        'agent_number' => $request->agent_number,
                        'call_status' => $request->call_status, //Customer Status
                        'call_transfer_status' => $request->call_transfer_status, //Agent Status
                        'caller_duration' => $request->caller_duration, //Agent Call Duration
                        'conversation_duration' => $request->conversation_duration, //Customer Call Duration
                        'recording_url' => $request->recording_url,
                        'call_uuid' => $request->call_uuid,
                        'created_by' => 1,
                        'updated_by' => 1,
                        'emp_id' => $emp_id,
                        'created_at' => date('Y-m-d H:i:s'),
                        'updated_at' => date('Y-m-d H:i:s')
                    )
                );
                if(isset($request->mst_var3))
                {
                    DB::table('call_log_tracks')->where('task_id',$request->mst_var3)->update(
                        [
                            'call_status' => $request->call_status,
                            'call_transfer_status' => $request->call_transfer_status
                        ]
                    );
                }
            }

            $call_log=DB::table('call_logs')->where('id', $retutn_id)->first();
            if(intval($retutn_id)>0 && isset($request->mst_var3) && $request->type == 'outgoing')
            {
                   /* if($task=Task::find($request->mst_var3))
	    {*/
			    DB::table('tasks')->where('id',$request->mst_var3)->update(['call_log_id'=>$call_log->id,'duration' => $request->caller_duration]);
                        DB::table('call_logs')->where('id',$call_log->id)->update(['is_move'=>1]);
               //     }
                   /* else{
                        $task=Task::create([
                            'type'=>'call',
                            'master_id'=>1,
                            'call_log_id'=>$call_log->id,
                            'duration' => $request->caller_duration,
                        ]);
                        $task->save();
                    }*/
                  //  DB::table('call_logs')->where('id',$call_log->id)->update(['is_move'=>1]);
            }
            /**
             * Missed,Connected,Not Connected,None
             * * */
            /*    if($call_log->call_status=='Connected')
                {
                    $this->knowlarity_data_push_notification_caller($request, $retutn_id);
                    $this->knowlarity_data_push_notification_agent($request, $retutn_id);
	    }*/
            if($call_log->call_status=='Missed')
            {
                   $this->missed_call_notification_alert($request, $retutn_id);
                 $this->sorry_notification_alert($request, $retutn_id);

            }
            DB::commit();
            return response(['data' => array(), 'success' => true, 'message' => 'Data Retrived Successfully'], 200);
	} catch (Exception $ex) {
	    DB::table('sendgrid_perse')->insert(
		              [
				                    'value'=>'issue found'
						              ]
							               );

            DB::rollBack();
            return response(['data' => array(), 'success' => true, 'message' =>  $ex->getMessage()], 500);
        }
    }
    /********************MISSED CALL ALERT********************* */
    public function missed_call_notification_alert(Request $request,$id)
    {
        $not = DB::table('notifications')->max('batch_id');
        $this->notification_batch_id = $not + 1;
        $data = array();

        if($request->type=='incoming')
        {
           $agent_number=str_replace('+91', '', $request->called_number);
           $caller_number=str_replace('+91', '', $request->caller_number);
        }
        elseif($request->type=='outgoing')
        {
            $agent_number=str_replace('+91', '', $request->called_number);
            $caller_number=str_replace('+91', '', $request->agent_number);
        }

        $caller=User::where('phone',$caller_number)->first();
        if (!empty($request->agent_number) && isset($caller->name)) 
        {
            
            $data['[TO_SMS]'] = $agent_number;
            $data['[MASTER_ID]'] = 1;
            $mastername = DB::table('master')->where('id',1)->get();
            $data['[MASTERNAME]'] = $mastername[0]->name;
            $data['[CALLER_NAME]']=$caller->name;
            
            
            $missed_user= User::where('phone',$agent_number)->first();
            $data['[NAME]']=$missed_user->name;

            if ($template = NotificationTemplate::where('name', 'missed_call_notification')->where('status', 1)->first())
            { 
                Notification::send($missed_user, new KnowlarityNotification($data,$this->notification_batch_id,$template));
                 $this->sendMailFunc($this->notification_batch_id, $template->email_body, $id); //24/05/24
            }
            
        }
      
    }
   /***************SORRY NOTIFICATION********************* */
   public function sorry_notification_alert(Request $request,$id)
   {
       $not = DB::table('notifications')->max('batch_id');
       $this->notification_batch_id = $not + 1;
       $data = array();
       if($request->type=='incoming')
       {
           $agent_number=str_replace('+91', '', $request->called_number);
           $caller_number=str_replace('+91', '', $request->caller_number);
       }
       elseif($request->type=='outgoing')
       {
           $agent_number=str_replace('+91', '', $request->agent_number);
           $caller_number=str_replace('+91', '', $request->called_number);
       }
       $agent=User::where('phone',$agent_number)->first();
       if (!empty($agent_number) && isset($agent->name)) 
       {
           
           $data['[TO_SMS]'] = $caller_number;
           $data['[MASTER_ID]'] = 1;
           $mastername = DB::table('master')->where('id',1)->get();
           $data['[MASTERNAME]'] = $mastername[0]->name;
           $data['[AGENT_NAME]']=$agent->name;
           
           
           $client= User::where('phone',$caller_number)->first();
           $data['[NAME]']=$client->name;

           if(isset($client->id) && $client->identifier!='employee'){

               if ($template = NotificationTemplate::where('name', 'sorry_notification_client')->where('status', 1)->first())
               {   
                   Notification::send($client, new KnowlarityNotification($data,$this->notification_batch_id,$template));
                   $this->sendMailFunc($this->notification_batch_id, $template->email_body, $id); //24/05/24
               }
              
           }
        
       }

   }
    /***********************Ratings to cliet********************** */
    public function knowlarity_data_push_notification_caller(Request $request, $id)
    {
        $not = DB::table('notifications')->max('batch_id');
        $this->notification_batch_id = $not + 1;
        $data = array();

        if (!empty($request->caller_number)) {
            if (!empty($request->call_transfer_status) && $request->call_transfer_status == "Connected")
                $template_name = "knowlarity-thank-you-caller-notification";
            else
                $template_name = "knowlarity-missed-caller-notification";


            if (!empty($request->agent_number) && $request->agent_number != "False") {

                preg_match("/\d*(\d{10})/", $request->agent_number, $match);

                if (count($match) > 0) {
                    $phone = Phone::where('phone_no', $match[1])->where('identifier', 'employee')->where('master_id', $request->master_id)->first();
                    if ($phone)
                        $employee = Employee::find($phone->main_id);
                    else
                        $employee = Employee::where('phone', $match[1])->first();
                    $data['[RECEIVED_BY]'] = $employee->full_name;
                }
            }




            if ($template = NotificationTemplate::where('name', $template_name)->where('status', 1)->first()) {

                $called_user= User::where('phone',str_replace('+91', '', $request->caller_number))->first();
                preg_match("/\d*(\d{10})/", $request->caller_number, $caller_number);
                $data['[TO_SMS]'] = $caller_number[1];
                $data['[MASTER_ID]'] = $request->master_id;
                $mastername = DB::table('master')->where('id', $request->master_id)->get();
                $data['[MASTERNAME]'] = $mastername[0]->name;
                
                $data['[RATING1]'] = env('THANKYOU_URL') . "?master=" . $mastername[0]->code . "&main_id=" . $id . "&identifier=knowlarity-call&client_id=" . $id . "&rating=1";
                $data['[RATING2]'] = env('THANKYOU_URL') . "?master=" . $mastername[0]->code . "&main_id=" . $id . "&identifier=knowlarity-call&client_id=" . $id . "&rating=2";
                $data['[RATING3]'] = env('THANKYOU_URL') . "?master=" . $mastername[0]->code . "&main_id=" . $id . "&identifier=knowlarity-call&client_id=" . $id . "&rating=3";
                $data['[RATING4]'] = env('THANKYOU_URL') . "?master=" . $mastername[0]->code . "&main_id=" . $id . "&identifier=knowlarity-call&client_id=" . $id . "&rating=4";
                $data['[RATING5]'] = env('THANKYOU_URL') . "?master=" . $mastername[0]->code . "&main_id=" . $id . "&identifier=knowlarity-call&client_id=" . $id . "&rating=5";
                $link = env('THANKYOU_URL') . "?master=" . $mastername[0]->code . "&main_id=" . $id . "&identifier=knowlarity&callid=" . $id . "&rating=1";

                $bitly = 'http://api.bit.ly/shorten?version=2.0.1&longUrl=' . urlencode($link) . '&login=' . env('BITLY_LOGIN') . '&apiKey=' . env('BITLY_API_KEY') . '&format=json';
                $short_url = "";
                if ($file_content = file_get_contents($bitly)) {
                    $json = @json_decode($file_content, true);

                    if ($json['results'] && !empty($json['results'])) {
                        $short_url = $json['results'][$link]['shortUrl'];
                    }
                }

                $data['[SHORT_URL]'] = $short_url;
                Notification::send($called_user, new KnowlarityNotification($data,$this->notification_batch_id,$template));
                $this->sendMailFunc($this->notification_batch_id, $template->email_body, $id); //24/05/24

            }
        }

        return true;
    }
    /***********************Ratings to AGENT********************** */
    public function knowlarity_data_push_notification_agent(Request $request, $id)
    {
        $not = DB::table('notifications')->max('batch_id');
        $this->notification_batch_id = $not + 1;
        if(!empty($request->call_transfer_status) && $request->call_transfer_status != "Connected")
        {
            if(!empty($request->agent_list))
            {
                $agent_lists = explode(',', $request->agent_list);

                if(count($agent_lists) > 0)
                {
                    foreach ($agent_lists as $agent_no)
                    {
                        preg_match("/\d*(\d{10})/", $agent_no, $to_no);
                        $data['[TO_SMS]']=$to_no[1];
                        $data['[CALL_TIME]']=$request->call_time;
                        $data['[CALLER_NO]']=$request->caller_number;
                        $data['[MASTER_ID]']=$request->master_id;
                        $mastername=DB::table('master')->where('id',$request->master_id)->get();
                        $data['[MASTERNAME]']=$mastername[0]->name;

                        if(!empty($to_no[1]))
                        {
                        $validate_phone= $this->validate_mobile($to_no[1]);

                            $phone=Phone::where('phone_no',$validate_phone)->where('identifier','employee')->where('master_id',$request->master_id)->first();
                            if($phone)
                                $employee=Employee::find($phone->main_id);
                            else
                                $employee=Employee::where('phone',$validate_phone)->first();
                        if(!empty($employee)) 
                            $data['[AGENT]']=$employee->full_name;
                        }
                        if ($request->caller_number) 
                        {
                            $validate_number= $this->validate_mobile($request->caller_number);

                        $contact = Contact::with('company.group')->whereHas('phones', function( $query ) use ( $validate_number ){
                                        $query->where('phone_no', $validate_number);
                                    })->get()->toArray();
                        if (count($contact) > 0) 
                        {
                            $data['[CALLER_NAME]']=$contact[0]['full_name'];
                            if(isset($contact[0]['company'][0]['group'][0]))
                                    $data['[GROUP]']=$contact[0]['company'][0]['group'][0]['name'];
                        }
                        }

                        if ($template = NotificationTemplate::where('name', 'knowlarity-missed-agent-notification')->where('status', 1)->first()) {
                            $agent= User::where('phone',str_replace('+91', '', $request->agent_number))->first();
                        Notification::send($agent, new KnowlarityNotification($data,$this->notification_batch_id,$template));
                        $this->sendMailFunc($this->notification_batch_id, $template->email_body, $id); //24/05/24
                        }
                    }
                }
            }
        }
        return true;
    }
    /**
     * Function used to track viewer of caller number
     * @param Request $request
     * @author Debargha Chakaborty <debargha.chakraborty01@gmail.com>
     * @copyright  Copyright (c) 2024, Debargha Chakaborty
     * @return \Illuminate\Http\Response
     */
    public function save_inspector_of_phonenumbers(Request $request)
    {
        DB::beginTransaction();
        try{
            $identifier='';
            if(isset($request->searched_from))
            $identifier=$request->searched_from;
            $data=CallViewTrack::create(
                [
                    'user_id'=>Auth::user()->id,
                    'phone_number_id'=>$request->id,
                    'identifier'=>$identifier
                ]
            );
            DB::commit();
            return response(['data' => $data, 'success' => true, 'message' => 'Data Saved Successfully'], 200);
        } catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(), 'success' => true, 'message' =>  $ex->getMessage()], 500);
        }
    }

     /**
     * Function used to call knowlarity call API
     * @param Request $request
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2024, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */

     public function knowlarity_place_call(Request $request)
     {

        if(isset($request->given_number) && !empty($request->given_number))
        {
            $customer_number=$request->given_number;
            $find_phone=Phone::where('phone_no',$request->given_number)->count();
            if($find_phone==0)
            {
                Phone::create([
                    'phone_no'=>$request->given_number,
                    'identifier'=>'third_party',
                ]);
            }
        }
        else
        $customer_number=$request->customer_number;
       
         $data = array();
         $data['caller_id'] = env('KNOWLARITY_CALLER_ID');
         $data['k_number'] = env('KNOWLARITY_K_NUMBER');
         $data['agent_number']="+91".$this->validate_mobile($request->agent_number);
         $data['customer_number']="+91".$this->validate_mobile($customer_number);
         // $data['additional_params'] = array('mst_var1' => $request->identifier, 'mst_var2' => $request->main_id); 
 
         if (isset($request->page_url) && $request->page_url != '') {
             preg_match('/\/([^\/]+)\/[^\/]+$/', $request->page_url, $matches);
             $added_from_page= $matches[1];
         } 
         elseif (isset($request->identifier) && $request->identifier != '') {
             // code.../apps/call-manager/call-list
             $added_from_page = $request->identifier;
         }
         else
             $added_from_page = '';


        if(!isset($request->task_id))
        {
            $newtask=Task::create([
                'type'=>'call',
                'master_id'=>1,
            ]);
            $task_id=$newtask->id;
        }
        else
        $task_id=$request->task_id;     
 
         $call_track_id = DB::table('call_log_tracks')->insertGetId([
             'master_id' => $request->master_id,
             'identifier' => $added_from_page,
             'call_type' => 'outgoing',
             'call_date' => date('Y-m-d'),
             'call_time' => date('H:i:s'),
             'task_id'=>$task_id,
             'caller_number' => $data['caller_id'],
             'caller_number' => $data['caller_id'],

             'called_number' => $data['customer_number'],
             'agent_number' => $data['agent_number'],
             'created_by' => Auth::user()->id,
             'updated_by' => Auth::user()->id,
             'created_at' => date('Y-m-d H:i:s'),
             'updated_at' => date('Y-m-d H:i:s')
         ]);

        //  $data['call_track_id']=$call_track_id;
        

         $data['additional_params'] = array('mst_var1' => 'new-crm', 'mst_var2' => $added_from_page,'mst_var3'=>strval($task_id)); 
        //  $data['mst_var1'] = $added_from_page;
        //  $data['mst_var2'] =$call_track_id;
        //  $data['mst_var3'] =$task_id; 

         
         $ch = curl_init();
         curl_setopt($ch, CURLOPT_URL, "https://kpi.knowlarity.com/Basic/v1/account/call/makecall");
         curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
         curl_setopt($ch, CURLOPT_POST, true);
         curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
         curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
         curl_setopt($ch, CURLOPT_HTTPHEADER, array(
             'x-api-key: ' . env('KNOWLARITY_API_KEY'),
             'Authorization:' . env('KNOWLARITY_AUTH'),
             'content-type:application/json;'
         ));
         $result = curl_exec($ch);
         $data = json_decode($result, true);
         return response(['data' => $data, 'success' => true, 'message' => 'Data Retrived Successfully'], 200);
     }

     public function knowlarity_getlist(Request $request)
     {
         $data['groups'] = Group::where('status', 1)->get();
         $data['employees'] = User::where('type', 'employee')->select('id', 'name', 'profile', 'email')->get();
         $data['companies'] = Contact::where('status', 1)->where('type', 'company')->select('fname', 'mname', 'lname', 'id', 'profile', 'phone', 'email', 'group_id')->get();
         return response(['data' => $data, 'success' => true, 'message' => 'Data Retrived Successfully'], 200);
     }
     /**
     * Function used to call list  headers
     * @param Request $request
     * @author Debargha Chakaborty <debargha.chakraborty01@gmail.com>
     * @copyright  Copyright (c) 2024, Debargha Chakaborty
     * @return \Illuminate\Http\Response
     */
     public function call_list_headers(Request  $request)
     { 
         $headers = array(
                 array('column_name'=>'call_type','display_name'=>'Call Type','is_default'=>0,'is_display'=>1,'is_sortable'=>1,'is_array'=>0,'excel_column'=>'call_type'),
                 
                 array('column_name'=>'contact_group','display_name'=>'Group','is_default'=>0,'is_display'=>1,'is_sortable'=>0,'is_array'=>1,'child_column'=>array('fname'),'excel_column'=>'contact_group_excel'),
                 array('column_name'=>'company','display_name'=>'Company','is_default'=>0,'is_display'=>1,'is_sortable'=>0,'is_array'=>1,'child_column'=>array('fname'),'excel_column'=>'company','is_multiple'=>1,'excel_child_colum'=>'fname'),
                 array('column_name'=>'agent_number','display_name'=>'Agent Number','is_default'=>1,'is_display'=>1,'is_sortable'=>0,'is_array'=>1,'child_column'=>array('fname'),'excel_column'=>'employee_excell_details'),
                 array('column_name'=>'call_date','display_name'=>'Call Date','is_default'=>1,'is_display'=>1,'is_sortable'=>1,'is_array'=>0,'excel_column'=>'call_date'),
                  array('column_name'=>'called_number','display_name'=>'Caller Number','is_default'=>1,'is_display'=>1,'is_sortable'=>1,'is_array'=>0,'excel_column'=>'called_number'),
                 // array('column_name'=>'called_number','display_name'=>'Caller Details','is_default'=>1,'is_display'=>1,'is_sortable'=>1,'is_array'=>0,'excel_column'=>'caller_details'),
                 array('column_name'=>'call_transfer_status','display_name'=>'Call Transfer Status','is_default'=>1,'is_display'=>1,'is_sortable'=>1,'is_array'=>0,'excel_column'=>'call_transfer_status'),
 
                 array('column_name'=>'call_status','display_name'=>'Call Status','is_default'=>1,'is_display'=>1,'is_sortable'=>1,'is_array'=>0,'excel_column'=>'call_transfer_status'),
                 array('column_name'=>'conversation_duration','display_name'=>'Duration','is_default'=>0,'is_display'=>1,'is_sortable'=>0,'is_array'=>0,'excel_column'=>'conversation_duration'),
                 array('column_name'=>'rating','display_name'=>'Call Rating','is_default'=>1,'is_display'=>1,'is_sortable'=>0,'is_array'=>0,'excel_column'=>'rating'),
                 array('column_name'=>'rating_employee','display_name'=>'Rating Employee','is_default'=>0,'is_display'=>1,'is_sortable'=>0,'is_array'=>0,'excel_column'=>'rating_employee.full_name'),
                 array('column_name'=>'remarks','display_name'=>'Rating Remarks','is_default'=>0,'is_display'=>1,'is_sortable'=>0,'is_array'=>0,'is_array'=>1,'child_column'=>array('name'),'excel_column'=>'remarks','is_multiple'=>1,'excel_child_colum'=>'name'),
                 array('column_name'=>'others_remark','display_name'=>'Others Remarks','is_default'=>0,'is_display'=>1,'is_sortable'=>1,'is_array'=>0,'excel_column'=>'others_remark'),
                 array('column_name'=>'call_move_status','display_name'=>'Movement Status','is_default'=>1,'is_display'=>1,'is_sortable'=>1,'is_array'=>0,'excel_column'=>'call_move_status'),
                 array('column_name'=>'call_move_to','display_name'=>'Call Moved To','is_default'=>1,'is_display'=>1,'is_sortable'=>1,'is_array'=>0,'excel_column'=>'call_move_to'),
 
                 array('column_name'=>'recording_url','display_name'=>'Recording','is_default'=>0,'is_display'=>1,'is_sortable'=>0,'is_array'=>0,'excel_column'=>'recording_url'),
         );
         return response(['data' => $headers, 'success' => true, 'message' => 'Data Retrived Successfully'], 200);
     }

 
    /**
     * Function used to call list 
     * @param Request $request
     * @author Debargha Chakaborty <debargha.chakraborty01@gmail.com>
     * @copyright  Copyright (c) 2024, Debargha Chakaborty
     * @return \Illuminate\Http\Response
     */
    public function call_list(Request  $request)
    { 
        $page=explode('/',$request->page_url);
        $page_name=end($page);
        $filter_value='';
        $filter_column='';

        if($page_name=='missed-call-list')
        {
            $filter_column='call_status';
            $filter_value='Missed';
        }
        elseif($page_name=='connected-call-list')
        {
            $filter_column='call_status';
            $filter_value='Connected';
        } 
        elseif($page_name=='incoming-call-list')
        {
            $filter_column='call_type';
            $filter_value='incoming';
        } 
        elseif($page_name=='outgoing-call-list')
        {
            $filter_column='call_type';
            $filter_value='outgoing';
        } 

        $query = QueryBuilder::for(CallLog::class)->allowedFilters(['identifier','call_status','call_type'])->defaultSort('-created_at')->allowedSorts('identifier','call_status','call_type');

        $query->search(!empty($request->search)?$request->search:"");

        if($filter_value!='' &&  $filter_column!='')
            $query->where($filter_column,$filter_value);

        $table='call_logs';
        if(isset($request->advfilter))
        {
            foreach ($request->advfilter as $key => $value) {
                $parm = explode('-',$key);
                if(count($parm) >= 2)
                {
                    $tableColumn = $table.".".$parm[0];
                    if ($parm[1] == 'like')
                    {    
                        $query->where($tableColumn,"LIKE","%".$value."%");
                    }
                    elseif($parm[1]=='eq')
                    {
                        $query->where($tableColumn,$value);
                    }
                    elseif ($parm[1] == 'nlike')
                    {
                        $query->where($tableColumn,"NOT LIKE","%".$value."%");
                    }
                    elseif ($parm[1] == 'neq') 
                    {
                        $query->where($tableColumn,'<>',$value);
                    }
                    elseif ($parm[1] == 'in') 
                    {
                        $query->whereIn($tableColumn,[$value]);
                    }
                    elseif ($parm[1] == 'nin') 
                    {
                        $query->whereNotIn($tableColumn,[$value]);
                    }
                    elseif ($parm[1] == 'between')
                    {
                        if(is_array($value) && count($value) == 2)
                            $query->whereBetween($tableColumn,[$value[0],$value[1]]);
                        elseif (!empty($value) && count(explode(',',$value))) {
                            if($parm[0] == 'created_at' || $parm[0] == 'updated_at' || $parm[0] == 'date' || $parm[0] == 'start_date' || $parm[0] == 'received_date' || $parm[0] == 'due_date' || $parm[0] == 'ecd' || $parm[0] == 'completed_date')
                            {
                                $values = explode(',',$value);
                                $query->whereRaw('DATE('.$tableColumn.') BETWEEN ? and ?',[$values[0],$values[1]]);
                            }
                        }
                        else    
                            $query->whereRaw('1=1');    
                    }       
                    else
                    {
                        $query->whereRaw('1=1');
                    }
                }
                
            }
        }
        $check_lists = $query->checkPermission('created_by')->paginate($request->per_page);

        $this->saveAdvanceSearchData($request);

        return response(['data' => $check_lists,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

     /**
     * Function used to call ratings
     * @param Request $request
     * @author Debargha Chakaborty <debargha.chakraborty01@gmail.com>
     * @copyright  Copyright (c) 2024, Debargha Chakaborty
     * @return \Illuminate\Http\Response
     */
     public function knowlarity_call_rating(Request $request)
     {
         // echo '<pre>';print_r($request->toArray());echo '<pre>';
         // exit;
          $data = array();
          $system_user=Employee::where('user_id',$request->user_id)->first();
 
          $call_log = CallLog::find($request->call_log_id);
 
          if (!empty($call_log)) 
          {
              $call_log->rating = $request->ratings;
              $call_log->remarks = $request->remarks;
             //  $call_log->others_remark = $request->others_remark;
              $call_log->rating_emp_id = $system_user->id;
              $call_log->save();
 
              $status=1;
              $message="Successfully Updated";
          }
          else
          {
              $status=0;
              $message="Error !!";
          }
 
         $data['return_status']=$status;
         $data['return_message']=$message;
         return $data;
 
     }

     /**
     * Function used to call move
     * @param Request $request
     * @author Debargha Chakaborty <debargha.chakraborty01@gmail.com>
     * @copyright  Copyright (c) 2024, Debargha Chakaborty
     * @return \Illuminate\Http\Response
     */
    public function knowlarity_call_move(Request $request)
    {
	   // echo '<pre>';print_r($request->toArray());echo '</pre>';
	   // exit;
        DB::beginTransaction();
        try
        {
            $call_log = CallLog::find($request->call_log_id);
            if(isset($call_log->id))
            {   
                if($request->identifier=='task')
                {
                    //12/09/2024
			$checktask=Task::where('call_log_id',$call_log->id)->first();
		//	echo $checktask->id;exit;
                    if(isset($checktask->id))
                    {
                        $checktask->main_id=$request->task_id;
                        $checktask->save();
                    }
                    else
		    {
		       // echo 'else';exit;
                        $task=Task::create([
                            'main_id'=>$request->task_id,
                            'type'=>'call',
                            'master_id'=>$request->master_id,
                            'call_log_id'=>$call_log->id,
                        ]);
                    }
                    // $call_log->update(['is_move'=>1]);
                    DB::table('call_logs')->where('id',$request->call_log_id)->update(['is_move'=>1]);
                }
                else{
                    $this->send_call_to_invoice($call_log,$request->invoice_id);
                    DB::table('call_logs')->where('id',$request->call_log_id)->update(['invoice_id'=>$request->invoice_id,'is_move'=>1]);
                    // $call_log->update(['invoice_id'=>$request->invoice_id,'is_move'=>1]);
                }
            }

            DB::commit();
            return response(['data' => $call_log, 'success' => true, 'message' => 'Data Retrived Successfully'], 200);
        } catch (Exception $ex) {
            DB::rollBack();
            return response(['data' => array(), 'success' => true, 'message' =>  $ex->getMessage()], 500);
        }
    }

    public function call_actionall()
    {
        // echo '<pre>'; print_r(request()->toArray());   echo '</pre>';   
        // exit;
        $system_user=Employee::where('user_id',request()->user_id)->first();
        if(count(request()->ids))
        {
            DB::beginTransaction();
            try
            {
                foreach(request()->ids as $call_log_id)
                {
                    $call_log = CallLog::find($call_log_id);
                    if(isset($call_log->id))
                    {   
                        if(request()->action=='call-move')
                        {
                            if(request()->new_value['identifier']=='task')
                            {
                                $checktask=Task::where('call_log_id',$call_log->id)->first();
                                if(isset($checktask->id))
                                {
                                    $checktask->main_id=request()->new_value['task_id'];
                                    $checktask->save();
                                }
                                else
                                {
                                    $task=Task::create([
                                        'main_id'=>request()->new_value['task_id'],
                                        'type'=>'call',
                                        'master_id'=>request()->new_value['master_id'],
                                        'call_log_id'=>$call_log->id,
                                    ]);
                                }
                                // $call_log->update(['is_move'=>1]);
                                DB::table('call_logs')->where('id',$call_log_id)->update(['is_move'=>1]);
                            }
                            else{
                                $this->send_call_to_invoice($call_log,request()->new_value['invoice_id']);
                                DB::table('call_logs')->where('id',$call_log_id)->update(['invoice_id'=>request()->new_value['invoice_id'],'is_move'=>1]);
                            }
                        }
                        elseif (request()->action=='call-rating') {
                            $call_log->rating =request()->new_value['ratings'];
                            $call_log->remarks = request()->new_value['remarks'];
                            $call_log->rating_emp_id = $system_user->id;
                            $call_log->save();
                        }
                    
                    }
                }
                DB::commit();
                return response(['data' => $call_log, 'success' => true, 'message' => 'Data Retrived Successfully'], 200);
            } catch (Exception $ex) {
    
                DB::rollBack();
                return response(['data' => array(), 'success' => true, 'message' =>  $ex->getMessage()], 500);
            }
        }
       
    }
    //12/09/2024
     public function call_log_export(Request $request)
    {
        // echo '<pre>';print_r($request->page_url);echo '</pre>';exit;
        parse_str($request->filter, $output);
        $result = ['per_page' => $request->per_page, 'page' => $request->page, 'search' => $request->search, 'sort' => $request->sort, 'filter' =>isset($output['filter']) ? $output['filter'] : [], 'advfilter' => isset($output['advfilter']) ? $output['advfilter'] : [], 'page_url' => $request->page_url];
       
            $excel_name = 'Call Log';
            $headings = [
                'Call Type',
                'Call Date',
                'Task Name',
                'Caller Name',
                'Called Person',
                'Status',
                'Duration',
                'Call Rating',
                'Rating Employee',
                'Rating Remarks',
                'Movement Status',
                'Recording',
            ];
        $saved_excel_name = $excel_name . '_' . date('d-m-Y') . '.xlsx';
        $save_file = Excel::store(new CallLogExcelExport($result, $headings,$request->page_url), $saved_excel_name);

        if ($save_file && file_exists(storage_path('/app/' . $saved_excel_name))) {
            $file = storage_path('/app/' . $saved_excel_name);
            return  response()->file($file);
        } else
            return response(['data' => array(), 'success' => false, 'message' => "Invalid File Path"], 500);
    }

    /**
     * Function used to call move to old sahaj invoice
     * @param Request $request
     * @author Debargha Chakaborty <debargha.chakraborty01@gmail.com>
     * @copyright  Copyright (c) 2024, Debargha Chakaborty
     * @return \Illuminate\Http\Response
     */
    public function send_call_to_invoice($call_log,$invoice_id)
    {
        $ch = curl_init(env('OLD_SAHAJ_LINK') . 'move_call_to_invoice/' . $invoice_id . '?master=dost');
        $jsonData = json_encode($call_log);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Content-Length: ' . strlen($jsonData)
        ]);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);

        $response = curl_exec($ch);
       
        curl_close($ch);
    }

    public function fetch_sahaj_invoice(Request $request,$id)
    {
      
        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => env('OLD_SAHAJ_LINK') . 'get_all_invoice?company_id='.$id.'&master=dost',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                // 'Authorization: Bearer YOUR_API_TOKEN', // if needed
            ],
        ]);
        $response = curl_exec($curl);
       
        return response(['data' => json_decode($response, true), 'success' => true, 'message' => 'Data Retrived Successfully'], 200);
        $err = curl_error($curl);
        curl_close($curl);
    }

    /**
     * Function used to fetch phone numbers for knowlarity quick call
     * @param Request $request 20/09/2024
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2024, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function fetch_phone_numbers(Request $request)
    {
        $data = Phone::distinct('phone_no')->with('main','phone_type')->where('is_default',1)->get();
        $phones = [];
        $i = 0;
        foreach ($data as $key => $value) {
            if(!empty($value->phone_no))
            {
                $phones[$i] = $value;
                if( $value->main && !empty($value->main))
                    $phones[$i]['search_field'] = $value->main->full_name;
                else
                    $phones[$i]['search_field'] = substr($value->phone_no, 0, 6) . str_repeat('*', 4);
                $i++;
            }
        }
        return response(['data' => $phones,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }


    public function get_task_by_type(Request $request,$id)
    {
        $authuser = Auth::user();
        
        $company_id = $request->company;

        $data = Task::whereHas('companies', function ($q) use ($company_id){
            $q->where('contacts.id',$company_id);
        })->whereHas('employees', function ($q) use ($authuser){
            $q->where('task_users.user_id',$authuser->id);
        })->with('services','contacts','companies','employees','files','supervisor')->whereIn('type',[$id])->whereIn('status',[$request->status])->get()->toArray();

        // echo "<pre>"; print_r($data); echo "</pre>"; exit;

        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    public function mirror_file_ticket(Request $request)
    {
        $task = Task::where('id',$request->taskId)->first();
        $file_arr = explode(",",$request->file_ids);

        foreach($file_arr as $file_id){
            $file = File::find($file_id);

            $file_change=File::where('file_path', $file->file_path)->where('identifier', 'task')->where('main_id', $task['id'])->get();

            if (count($file_change) == 0){

                $clonefile = $file->replicate();
                $clonefile->identifier='task';
                $clonefile->main_id=$task->id;
                $clonefile->file_action= 'mirror';
                $clonefile->parent_task_id=$request->main_id;
                $clonefile->parent_task_name=$request->task_name; // 26/09/2024 Jyoti
                $clonefile->parent_file_id=$file_id;
                $clonefile->save();
                $status = 1;
                $message = 'Successfully Mirror';

            }else{
                $clonefile = 0;
                $status = 0;
                $message = 'File Alreday Exsist';
            }
        }
        return response(['data' => $clonefile,'success'=>$status,'message' => $message], 200);
    }

    public function move_file_ticket(Request $request) 
    {
        $task = Task::where('id',$request->taskId)->first();
        $file_arr = explode(",",$request->file_ids);

        foreach($file_arr as $file_id){
            $file = File::find($file_id);

            $file_change=File::where('file_path', $file->file_path)->where('identifier', 'task')->where('main_id', $task['id'])->get();
            
            if (count($file_change) == 0){
                $file->deleted_at = Carbon::now()->format('Y-m-d H:i:s');
                $file->save();

                if($file->save()==true){
    
                    $file_new = new File;
                    $file_new->main_id = $request->taskId;
                    $file_new->file_type_id = $file->file_type_id;
                    $file_new->file_path = $file->file_path;
                    $file_new->file_name = $file->file_name;
                    $file_new->file_extension =  $file->file_extension;
                    $file_new->file_size = $file->file_size;
                    $file_new->identifier = $file->identifier;
                    $file_new->is_client_access = $file->is_client_access;
                    $file_new->task_information_item_id = $file->task_information_item_id;
                    $file_new->information_sub_group_id = $file->information_sub_group_id;
                    $file_new->information_sub_group_index = $file->information_sub_group_index;
                    $file_new->file_stage_id = $file->file_stage_id;
                    $file_new->file_description = $file->file_description;

                    $file_new->file_action= 'move';
                    $file_new->parent_task_id=$request->main_id;
                    $file_new->parent_task_name=$request->task_name; // 26/09/2024 Jyoti
                    $file_new->parent_file_id=$file_id;
                    $file_new->save();
                    $status = 1;
                    $message = 'Successfully Moved';
                }
            }else{
                $file_new = 0;
                $status = 0;
                $message = 'File Alreday Exsist';
            }
        }

        return response(['data' => $file_new,'success'=>$status,'message' => $message], 200);

    }


    /**
     * Function used to track emails from old
     * @param Request $request
     * @author Debargha Chakraborty<debargha.chakraborty01@gmail.com>
     * @copyright Copyright (c) 2024, Debargha Chakraborty
     * @return \Illuminate\Http\Response
     */
    public function track_emails_from_old(Request $request)
    {
        if(isset($request->table) && $request->table!='' && $request->table!=null && isset($request->x_message_id) && $request->x_message_id!='' && $request->x_message_id!=null)
        {
            $table_name=$request->table.'s';//ex: notification_logs


            DB::table($table_name)->where('x_message_id',$request->x_message_id)->update([
                $request->column_name=>1,//ex: deliverd,open etc
                $request->column_time=>$request->column_date_time//ex: deliverd_date,opened_date etc
            ]);
        }   
    }
    /**
     * Function used to track emails in new crm
     * @param Request $request
     * @author Debargha Chakraborty<debargha.chakraborty01@gmail.com>
     * @copyright Copyright (c) 2024, Debargha Chakraborty
     * @return \Illuminate\Http\Response
     */
    public function track_emails(Request $request)
    {
        $mandrillEvents = json_decode($request['mandrill_events']);
        if(count($mandrillEvents))
        {
            foreach ($mandrillEvents as $key => $event) 
            {
                if(count($event->msg->tags)>1)
                {
                    $table=$event->msg->tags[1];
                }
                else
                $table=$event->msg->tags[0];

                if($table == 'bulk_notification_cron')
                    $email_column = 'client_email_id';
                elseif($table == 'individual_campaign_cron')
                    $email_column = 'client_email_id';
                elseif($table == 'notification_log')
                    $email_column = 'to';
                else
                    $email_column = 'email';


                $table_name=$table.'s';
                if($event->event=='open')
                {
                    if($table == 'bulk_notification_cron' )
                    {
                        DB::table($table_name)->where($email_column,$event->msg->email)->where('x_message_id',$event->_id)->where('bulk_notification_id',$event->msg->tags[0])->update([
                            'opened'=>1,
                            'opened_date'=>date('Y-m-d H:i:s'),
                            'event_status'=>$event->event
                        ]);
                    }
                    else
                    {
                        DB::table($table_name)->where($email_column,$event->msg->email)->where('x_message_id',$event->_id)->update([
                            'opened'=>1,
                            'opened_date'=>date('Y-m-d H:i:s'),
                            'event_status'=>$event->event
                        ]);
                    }
                }
                elseif ($event->event=='delivered') 
                {
                    if($table == 'bulk_notification_cron' )
                    {
                        DB::table($table_name)->where($email_column,$event->msg->email)->where('x_message_id',$event->_id)->where('bulk_notification_id',$event->msg->tags[0])->update([
                            'delivered'=>1,
                            'delivered_date'=>date('Y-m-d H:i:s'),
                            'event_status'=>$event->event
                        ]);
                    }
                    else
                    {
                        DB::table($table_name)->where($email_column,$event->msg->email)->where('x_message_id',$event->_id)->update([
                            'delivered'=>1,
                            'delivered_date'=>date('Y-m-d H:i:s'),
                            'event_status'=>$event->event
                        ]);
                    }
                }
                elseif ($event->event=='click') 
                {
                    if($table == 'bulk_notification_cron' )
                    {
                        DB::table($table_name)->where($email_column,$event->msg->email)->where('x_message_id',$event->_id)->where('bulk_notification_id',$event->msg->tags[0])->update([
                            'clicked'=>1,
                            'clicked_date'=>date('Y-m-d H:i:s'),
                            'event_status'=>$event->event
                        ]);
                    }
                    else
                    {
                        DB::table($table_name)->where($email_column,$event->msg->email)->where('x_message_id',$event->_id)->update([
                            'clicked'=>1,
                            'clicked_date'=>date('Y-m-d H:i:s'),
                            'event_status'=>$event->event
                        ]);
                    }
                }
                elseif ($event->event=='click') 
                {
                    if($table == 'bulk_notification_cron' )
                    {
                        DB::table($table_name)->where($email_column,$event->msg->email)->where('x_message_id',$event->_id)->where('bulk_notification_id',$event->msg->tags[0])->update([
                            'clicked'=>1,
                            'clicked_date'=>date('Y-m-d H:i:s'),
                            'event_status'=>$event->event
                        ]);
                    }
                    else
                    {
                        DB::table($table_name)->where($email_column,$event->msg->email)->where('x_message_id',$event->_id)->update([
                            'clicked'=>1,
                            'clicked_date'=>date('Y-m-d H:i:s'),
                            'event_status'=>$event->event
                        ]);
                    }
                }
                elseif ($event->event=='spamreport') 
                {
                    if($table == 'bulk_notification_cron' )
                    {
                        DB::table($table_name)->where($email_column,$event->msg->email)->where('x_message_id',$event->_id)->where('bulk_notification_id',$event->msg->tags[0])->update([
                            'spammed'=>1,
                            'spammed_date'=>date('Y-m-d H:i:s'),
                            'event_status'=>$event->event
                        ]);
                    }
                    else
                    {
                        DB::table($table_name)->where($email_column,$event->msg->email)->where('x_message_id',$event->_id)->update([
                            'spammed'=>1,
                            'spammed_date'=>date('Y-m-d H:i:s'),
                            'event_status'=>$event->event
                        ]);
                    }
                }
                elseif ($event->event=='processed') 
                {
                    if($table == 'bulk_notification_cron' )
                    {
                        DB::table($table_name)->where($email_column,$event->msg->email)->where('x_message_id',$event->_id)->where('bulk_notification_id',$event->msg->tags[0])->update([
                            'event_status'=>$event->event
                        ]);
                    }
                    else
                    {
                        DB::table($table_name)->where($email_column,$event->msg->email)->where('x_message_id',$event->_id)->update([
                            'event_status'=>$event->event
                        ]);
                    }
                }
                elseif ($event->event=="dropped" || $event->event=="bounce") 
                {
                    if($table == 'bulk_notification_cron' )
                    {
                        DB::table($table_name)->where($email_column,$event->msg->email)->where('x_message_id',$event->_id)->where('bulk_notification_id',$event->msg->tags[0])->update([
                            'event_status'=>$event->event,
                            'status'=>2,
                            'bounce_date'=>date('Y-m-d H:i:s'),
                        ]);
                    }
                    else
                    {
                        DB::table($table_name)->where($email_column,$event->msg->email)->where('x_message_id',$event->_id)->update([
                            'event_status'=>$event->event,
                            'status'=>2,
                            'bounce_date'=>date('Y-m-d H:i:s'),
                        ]);
                    }

                    $blockmail= DB::table('block_mail')->where('email',$event->msg->email)->count();
                    if( $blockmail)
                    {
                        DB::table('block_mail')->where($email_column,$event->msg->email)->update([
                            'event_status'=>$event->event,
                            'created_at'=>date('Y-m-d H:i:s'),
                            'updated_at'=>date('Y-m-d H:i:s'),
                            'updated_by'=>1,
                        ]); 
                    }
                    else
                    { 
                        DB::table('block_mail')->create([
                            'email'=>$event->msg->email,
                            'event_status'=>$event->event,
                            'created_at'=>date('Y-m-d H:i:s'),
                            'updated_at'=>date('Y-m-d H:i:s'),
                            'created_by'=>1,
                            'updated_by'=>1,
                        ]); 
                    }
                }
                else
                {
                    $url = $event->msg->reject;
                    $email = $event->msg->email;
                    $tomail=$event->msg->to[0][0];
                    $upfiles = [];
                    $uploaddir = 'application/public/uploads/';
                    $num_attachments =$event->msg->attachments;
                    if($num_attachments)
                    {
                        for($i = 1; $i <= $num_attachments; $i++) 
                        {
                        $attachment = $_FILES['attachment'.$i];
                        $uploadfile = $uploaddir . basename($attachment['name']);
                        $resout = move_uploaded_file($attachment['tmp_name'], $uploadfile);
                        $upfiles[] = "https://easycrm.in/gstdost/application/public/uploads/".basename($uploadfile);
                        }

                    }
                    $output = preg_replace('/[\n\r]/', '', $event->msg->text);
                    $outputText = preg_replace('/On(.*)/', '', $output);
                    if(!empty($outputText) && array_key_exists("from_name",$event->msg))
                    {
                        $post1 =[
                          'master'    => 'dost',
                          'reply_to'=>$tomail,
                          'email'=>$event->msg->from_email,
                          'subject'    =>$event->msg->subject,
                          'email_body_text'    =>$event->msg->text,
                          'email_body_html'    =>$event->msg->html,
                          'file_path'=>implode(',',$upfiles)
                        ];
                        $this->email_pipeline_push($post1);
                    }
                }
            }
        }
    }

    /**
     * Function used to push reply emails in new crm from sahaj
     * @param Request $request
     * @author Debargha Chakraborty<debargha.chakraborty01@gmail.com>
     * @copyright Copyright (c) 2024, Debargha Chakraborty
     * @return \Illuminate\Http\Response
     */

    public function pipeline_push_from_sahaj(Request $request)
    {
            $post1 =[
            'master'    => 'dost',
            'reply_to'=>$request->reply_to,
            'email'=>$request->email,
            'subject'    =>$request->subject,
            'email_body_text'    =>$request->email_body_text,
            'email_body_html'    =>$request->email_body_html,
            'file_path'=>$request->file_path
          ];
          $this->email_pipeline_push($post1);
    }

    /**
     * Function used to push reply emails in new crm
     * @param Request $request
     * @author Debargha Chakraborty<debargha.chakraborty01@gmail.com>
     * @copyright Copyright (c) 2024, Debargha Chakraborty
     * @return \Illuminate\Http\Response
     */
    public function email_pipeline_push($data)
    {
        $return_data=array();
        $replyto = preg_split("/[+\s:@]/", $data->reply_to);
        if(count($replyto) == 4 && intval($replyto[2]))
        {
            if($parent_comment = Communication::find($replyto[2]))
            {
              $user=User::where('email',$data->email)->first();
              $outputText = preg_replace('/On .*wrote:.*/s', '', $data->email_body_text);

                if(!empty($outputText))
                    $comment= $outputText ;
                else
                    $comment= $data->comment;


              $request =new Request();
              $request->merge([
                'parent_id' => $parent_comment->id,
                'communication_type' => 'mail',
                'communication_type' => 'mail',
                'recipients' => [
                    array('user_id'=>$user->id,'type'=>'to')
                ],
                'is_schedule'=>0,
                'master_id'=>1,
                'parent_type'=>'reply',
                'cc'=>'',
                'bcc'=>'',
                'subject'=>'Re: '.$parent_comment->subject,
                'main_id'=>'',
                'from_id'=>1,//need to update while live
                'comment'=>$comment,
                'to'=>[$user->id],
                'date'=>date('Y-m-d H:i:s'),
                'weekly'=>'',
                'custom_date'=>'',
            ]);

              if($parent_comment->identifier == 'task')
              {
                $comment_data=app(Communication::class)->store($request);
                if($comment_data['success'])
                {
                  if($comment=Communication::find($comment_data['data']['id']))
                  {
                      if(!empty($data->file_path))
                      {
                        $files = explode(',',$data->file_path);
                        if(isset($files) && count($files)>0)
                        {
                            foreach ($files as $file)         
                            {
                              $contents = file_get_contents($file);
                              $ext = pathinfo($file, PATHINFO_EXTENSION);
                              $size = strlen($contents);

                              $file_path = 'uploads/' . time().".".$ext;
                              file_put_contents($file_path, $contents);

                              $name = basename($file);
                              $data_file['master_id']=1;
                              $data_file['identifier']="comment";
                              $data_file['file_type_id']=0;
                              $data_file['main_id']=$comment->id;
                              $data_file['file_name'] = $name;
                              $data_file['file_path'] = $file_path;
                              $data_file['file_extension'] = $ext;
                              $data_file['file_size'] = $size;
                              $object = new File($data_file);
                                              
                              $comment->files()->save($object);
                            }
                        }
                      }
                  }
                  $status=1;
                  $message=$comment_data['message'];
                }
                else
                {
                  $status=0;
                  $message="Update Failed";
                }
              }
       
            }
            
        }
        else
        {
            $support_ticket_matches = array();
            $regular_ticket_matches = array();
            $lead_matches = array();
            preg_match('~(RT\w+)~',$data->subject,$regular_ticket_matches);
            if(count($regular_ticket_matches)>0) 
            {
              $ticket_id = substr($regular_ticket_matches[0],2);
              $user=User::where('email',$data->email)->first();
              $outputText = preg_replace('/On .*wrote:.*/s', '', $data->email_body_text);

              if(!empty($outputText) )
                 $comment= $outputText ;
              else
                 $comment= $data->comment;
            
              //echo $first_position;
              // echo $request->comment;
              // exit; 		
              if($ticket=Task::find($ticket_id))
              {
                $parent_comment = Communication::find($replyto[2]);

                $request =new Request();
                $request->merge([
                    'parent_id' => $parent_comment->id,
                    'communication_type' => 'mail',
                    'communication_type' => 'mail',
                    'recipients' => [
                        array('user_id'=>$user->id,'type'=>'to')
                    ],
                    'is_schedule'=>0,
                    'master_id'=>1,
                    'parent_type'=>'reply',
                    'cc'=>'',
                    'bcc'=>'',
                    'subject'=>'Re: '.$parent_comment->subject,
                    'main_id'=>$ticket_id,
                    'from_id'=>1,//need to update while live
                    'comment'=>$comment,
                    'to'=>[$user->id],
                    'date'=>date('Y-m-d H:i:s'),
                    'weekly'=>'',
                    'custom_date'=>'',
                ]);

                $comment_data=app(Communication::class)->store($request);
                if($comment_data['return_status'] > 0 )
                {
                  if($comment=Communication::find($comment_data['data']['id']))
                  {
                      if(!empty($data->file_path))
                      {
                        $files = explode(',',$data->file_path);
                        if(isset($files) && count($files)>0)
                        {
                            foreach ($files as $file)         
                            {
                              $contents = file_get_contents($file);
                              $ext = pathinfo($file, PATHINFO_EXTENSION);
                              $size = strlen($contents);

                              $file_path = 'uploads/' . time().".".$ext;
                              file_put_contents($file_path, $contents);

                              $name = basename($file);
                              $data_file['master_id']=1;
                              $data_file['identifier']="comment";
                              $data_file['file_type_id']=0;
                              $data_file['main_id']=$comment->id;
                              $data_file['file_name'] = $name;
                              $data_file['file_path'] = $file_path;
                              $data_file['file_extension'] = $ext;
                              $data_file['file_size'] = $size;
                              $object = new File($data_file);
                                              
                              $comment->files()->save($object);
                            }
                        }
                      }
                  }
                  $status=1;
                  $message=$comment_data['return_message'];
                }
                else
                {
                  $status=0;
                  $message="Update Failed";
                }
              }
              else
              {
                $status=0;
                $message="Update Failed";
              }
            
            }

        }

    }


}
