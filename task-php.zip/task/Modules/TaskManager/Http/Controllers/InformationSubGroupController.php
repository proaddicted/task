<?php

namespace Modules\TaskManager\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Carbon\Carbon;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;
use Modules\TaskManager\Entities\InformationItem;
use Modules\TaskManager\Entities\InformationSubGroup;
use Modules\TaskManager\Transformers\InformationSubGroupResource;

class InformationSubGroupController extends Controller
{
    use PermissionTrait,CommonTrait;

    public function getlist(Request $request)
    {
        $data['information_items']=InformationItem::where('status',1)->get();

        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);

    }


    public function headers()
    {
        $headers = array(
           
            array('column_name'=>'name','display_name'=>'Name','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'description','display_name'=>'Description','is_display'=>1,'is_default'=>0,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'creator','display_name'=>'Created By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
            array('column_name'=>'editor','display_name'=>'Updated By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
            array('column_name'=>'updated_at','display_name'=>'Updated On','is_display'=>1,'is_default'=>1,'is_sortable'=>1), 
            array('column_name'=>'created_at','display_name'=>'Added On','is_display'=>1,'is_default'=>0,'is_sortable'=>1)          );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index(Request $request)
    {
        $query = QueryBuilder::for(InformationSubGroup::class)->allowedFilters(['name','description'])->defaultSort('name')->allowedSorts('name','description','created_at','updated_at');

        $query->search(!empty($request->search)?$request->search:"");

        $information_sub_groups = $query->with('creator','editor')->advanceSearch($request->advfilter,'information_sub_groups')->checkPermission('created_by')->paginate($request->per_page);

        $this->saveAdvanceSearchData($request);

        return response(['data' => $information_sub_groups,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create()
    {
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        if(!$this->checkStoreAccess())
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403); 

        $validator = Validator::make($request->all(), [
            'name' => 'required'

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            $information_sub_group = InformationSubGroup::create($request->all());

            if($request->input('information_items') && count($request->input('information_items')) > 0)
            {
                $information_sub_group->information_items()->detach();
                $information_sub_group->information_items()->attach($request->input('information_items'),['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
            }

            DB::commit();
            return response(['data' => new InformationSubGroupResource($information_sub_group),'success'=>true,'message' => 'Information Sub Group Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Response
     */
    public function show($id)
    {
        return response(['data' =>new InformationSubGroupResource(InformationSubGroup::findOrFail($id)),'success'=>true,'message' => 'Information Sub Group Retrived Successfully'], 200);
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Response
     */
    public function edit($id)
    {
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
        $information_sub_group=InformationSubGroup::find($id);
        
        if(!$this->checkUpdateAccess($information_sub_group))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        $validator = Validator::make($request->all(), [
            'name' => 'required'

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            
            $information_sub_group->update($request->except('information_items'));

            if($request->input('information_items') && count($request->input('information_items')) > 0)
            {
                $information_sub_group->information_items()->detach();
                $information_sub_group->information_items()->attach($request->input('information_items'),['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
            }
            
            DB::commit();
            
            return response(['data' => new InformationSubGroupResource($information_sub_group),'success'=>true,'message' => 'Information Sub Group Updated Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Response
     */
    public function destroy($id)
    {
        $information_sub_group=InformationSubGroup::find($id);
        
        if(!$this->checkDeleteAccess($information_sub_group))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);
        
        DB::beginTransaction();
        try {
            
            $information_sub_group->delete();
            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Information Sub Group Deleted Successfully'], 200);
    }

     /**
     * Bulk Action function of footer (pass 6  for delete and 3 for update)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function actionall()
    {
        
        $access = request()->action == 'delete' ? 6 : 3;

        if(!$this->checkBulkAcess( $access))
            return response(['data' => array(),'success'=>false,'message' =>"You Don't Have Access For Bulk Action"], 200);

        DB::beginTransaction();
        try {
           
            if($access == 6)
                {
                    InformationSubGroup::whereIn('id',request()->ids)->get()->each(function($information_sub_group) 
                    {
                        $information_sub_group->delete();
                    });
                }
            elseif($access == 3)  
                InformationSubGroup::whereIn('id',request()->ids)->update([request()->column => request()->status]);

            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Updated successfully'], 200);
    }
}
