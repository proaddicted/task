<?php

namespace Modules\TaskManager\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;
use Modules\ContactManager\Entities\Contact;
use App\Models\Phone;
use App\Models\Email;
use App\Models\Address;
use App\Models\MasterType;
use Modules\TaskManager\Entities\OfficerDepartment;
use Modules\TaskManager\Entities\Officer;
use Modules\TaskManager\Transformers\OfficerResource;
use App\Models\Country;
use App\Models\State;
use Modules\TaskManager\Entities\DepartmentType;


class OfficerController extends Controller
{
    use PermissionTrait,CommonTrait;


    public function headers()
    {
        $headers = array(
            array('column_name'=>'full_name','display_name'=>'Name','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'phone','display_name'=>'Phone','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'email','display_name'=>'Email','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'creator','display_name'=>'Created By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
            array('column_name'=>'editor','display_name'=>'Updated By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
            array('column_name'=>'updated_at','display_name'=>'Updated On','is_display'=>1,'is_default'=>1,'is_sortable'=>1), 
            array('column_name'=>'created_at','display_name'=>'Added On','is_display'=>1,'is_default'=>0,'is_sortable'=>1)          );
        

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    public function getlist()
    {
        $data['master_types'] = MasterType::where('status',1)->whereIn('identifier',['title','phone','email','address'])->select('id','name','identifier')->get();

        $data['contacts']=Contact::where('status',1)->where('type','individual')->select('fname','mname','lname','id','profile','phone','email')->get();
        $data['states'] = State::where('status',1)->select('id','name')->get();
        $data['countries'] = Country::where('status',1)->select('id','name')->get();
        $data['department_types'] = DepartmentType::with('children')->where('status',1)->orderBy('name','asc')->where('parent_id',0)->get();

        
        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);

    }
    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index(Request $request)
    {
        $query = QueryBuilder::for(Officer::class)->allowedFilters(['fname','lname','mname',
        AllowedFilter::exact('phone')->ignore(null),AllowedFilter::exact('email')->ignore(null)])->defaultSort('fname')->allowedSorts('fname','lname','mname','created_at','phone','email','updated_at');

        $query->search(!empty($request->search)?$request->search:"");

        $officers = $query->with('creator','editor')->advanceSearch($request->advfilter,'officers')->checkPermission('created_by')->paginate($request->per_page);

        $this->saveAdvanceSearchData($request);

        return response(['data' => $officers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

   
    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        if(!$this->checkStoreAccess())
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403); 

        $validator = Validator::make($request->all(), [
            'fname' => 'required',

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            
            $officer = Officer::create($request->except('phone','email','link','address'));

            if($request->input('phone') != null && count($request->input('phone'))>0)
            {
                $officer->phones()->delete();

                foreach ($request->input('phone') as $data) 
                {
                    if(!empty($data['phone_no']))
                    {
                        $data['identifier']="officer";
                        if(intval($data['id']) > 0)
                        {
                            if($object = Phone::withTrashed()->find($data['id']))
                            {
                                $object->restore();
                                $object->fill($data);
                            }
                            else
                                $object = new Phone($data);
                        }
                        else
                            $object = new Phone($data);
                        
                        
                        $officer->phones()->save($object);
                        
                        if($data['is_default']==1)
                            $officer->phone = $data['phone_no'];
                    }        
                }
            }

            if($request->input('email') != null && count($request->input('email'))>0)
            {
                $officer->emails()->delete();

                foreach ($request->input('email') as $data) 
                {
                    if(!empty($data['email']))
                    {
                        $data['identifier']="officer";
                        if(intval($data['id']) > 0)
                        {
                            if($object = Email::withTrashed()->find($data['id']))
                            {
                                $object->restore();
                                $object->fill($data);
                            }
                            else
                                $object = new Email($data);
                        }
                        else
                            $object = new Email($data);
                        
                        
                        $officer->emails()->save($object);
                        
                        if($data['is_default']==1)
                            $officer->email = $data['email'];
                    }
                        
                        
                }
            }

            if($request->input('address') != null && count($request->input('address'))>0)
            {
                $officer->address()->delete();

                foreach ($request->input('address') as $data) 
                {
                        if(!empty($data['address_line1']))
                        {
                            $data['identifier']="officer";
                            if(intval($data['id']) > 0)
                            {
                                if($object = Address::withTrashed()->find($data['id']))
                                {
                                    $object->restore();
                                    $object->fill($data);
                                }
                                else
                                    $object = new Address($data);
                            }
                            else
                                $object = new Address($data);
                            
                            
                            $officer->address()->save($object);
                        }
                        
                        
                        
                }
            }

            if($request->input('department') != null && count($request->input('department'))>0)
            {
                $officer->departments()->delete();

                foreach ($request->input('department') as $data) 
                {
                        if(!empty($data['department_type_id']))
                        {
                            $data['identifier']="officer";
                            if(intval($data['id']) > 0)
                            {
                                if($object = OfficerDepartment::withTrashed()->find($data['id']))
                                {
                                    $object->restore();
                                    $object->fill($data);
                                }
                                else
                                    $object = new OfficerDepartment($data);
                            }
                            else
                                $object = new OfficerDepartment($data);
                            
                            
                            $officer->departments()->save($object);
                        }
                        
                        
                        
                }
            }
            $officer->save();

            DB::commit();
                
            return response(['data' => new OfficerResource($officer),'success'=>true,'message' => 'Officer Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Response
     */
    public function show($id)
    {
        return response(['data' =>new OfficerResource(Officer::findOrFail($id)),'success'=>true,'message' => 'Officer Retrived Successfully'], 200);
    }

    

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
        $officer=Officer::find($id);

        
        if(!$this->checkUpdateAccess($officer))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        $validator = Validator::make($request->all(), [
            'fname' => 'required',

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            
            $officer->update($request->except('phone','email','link','address'));

            if($request->input('phone') != null && count($request->input('phone'))>0)
            {
                $officer->phones()->delete();

                foreach ($request->input('phone') as $data) 
                {
                    if(!empty($data['phone_no']))
                    {
                        $data['identifier']="officer";
                        if(intval($data['id']) > 0)
                        {
                            if($object = Phone::withTrashed()->find($data['id']))
                            {
                                $object->restore();
                                $object->fill($data);
                            }
                            else
                                $object = new Phone($data);
                        }
                        else
                            $object = new Phone($data);
                        
                        
                        $officer->phones()->save($object);
                        
                        if($data['is_default']==1)
                            $officer->phone = $data['phone_no'];
                    }        
                }
            }

            if($request->input('email') != null && count($request->input('email'))>0)
            {
                $officer->emails()->delete();

                foreach ($request->input('email') as $data) 
                {
                    if(!empty($data['email']))
                    {
                        $data['identifier']="officer";
                        if(intval($data['id']) > 0)
                        {
                            if($object = Email::withTrashed()->find($data['id']))
                            {
                                $object->restore();
                                $object->fill($data);
                            }
                            else
                                $object = new Email($data);
                        }
                        else
                            $object = new Email($data);
                        
                        
                        $officer->emails()->save($object);
                        
                        if($data['is_default']==1)
                            $officer->email = $data['email'];
                    }
                        
                        
                }
            }

            if($request->input('address') != null && count($request->input('address'))>0)
            {
                $officer->address()->delete();

                foreach ($request->input('address') as $data) 
                {
                        if(!empty($data['address_line1']))
                        {
                            $data['identifier']="officer";
                            if(intval($data['id']) > 0)
                            {
                                if($object = Address::withTrashed()->find($data['id']))
                                {
                                    $object->restore();
                                    $object->fill($data);
                                }
                                else
                                    $object = new Address($data);
                            }
                            else
                                $object = new Address($data);
                            
                            
                            $officer->address()->save($object);
                        }
                        
                        
                        
                }
            }

            if($request->input('department') != null && count($request->input('department'))>0)
            {
                $officer->departments()->delete();

                foreach ($request->input('department') as $data) 
                {
                        if(!empty($data['department_type_id']))
                        {
                            $data['identifier']="officer";
                            if(intval($data['id']) > 0)
                            {
                                if($object = OfficerDepartment::withTrashed()->find($data['id']))
                                {
                                    $object->restore();
                                    $object->fill($data);
                                }
                                else
                                    $object = new OfficerDepartment($data);
                            }
                            else
                                $object = new OfficerDepartment($data);
                            
                            
                            $officer->departments()->save($object);
                        }
                        
                        
                        
                }
            }

            $officer->save();

            DB::commit();
                
            return response(['data' => new OfficerResource($officer),'success'=>true,'message' => 'Officer Updated Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Response
     */
    public function destroy($id)
    {
        $officer=Officer::find($id);
        
        if(!$this->checkDeleteAccess($officer))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);
        
        DB::beginTransaction();
        try {
            
            $officer->delete();
            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Officer Deleted Successfully'], 200);
    }

     /**
     * Bulk Action function of footer (pass 6  for delete and 3 for update)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function actionall()
    {
        
        $access = request()->action == 'delete' ? 6 : 3;

        if(!$this->checkBulkAcess( $access))
            return response(['data' => array(),'success'=>false,'message' =>"You Don't Have Access For Bulk Action"], 200);

        DB::beginTransaction();
        
        try {
           
            if($access == 6 && request()->action == 'delete')
            {
                Officer::whereIn('id',request()->ids)->get()->each(function($officer) 
                {
                    $officer->delete();
                });
            }
            elseif($access == 3 && request()->action == 'update')  
                Officer::whereIn('id',request()->ids)->update([request()->column => request()->status]);
           

            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Updated successfully'], 200);
    }
}
