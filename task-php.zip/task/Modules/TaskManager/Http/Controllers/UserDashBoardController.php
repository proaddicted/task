<?php

namespace Modules\TaskManager\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Carbon\Carbon;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;
use Modules\TaskManager\Entities\Task;

use App\Models\User;
use Modules\ContactManager\Entities\Contact;
use App\Traits\EmployeeTrait;

use Modules\AttendanceManager\Entities\DailyAttendance;
use Modules\AttendanceManager\Entities\Holiday;



class UserDashBoardController extends Controller
{
    use PermissionTrait,CommonTrait,EmployeeTrait;

    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function user_analytics_dashboard(Request $request)
    {
        $data = [];
        $authuser = $request->userid > 0 ? User::find($request->userid) : Auth::user();
        $employee_info = $this->employee_info($authuser);
        $hierchy_users = [];
        if(!empty($employee_info))
        {
            if(count($employee_info->hierarchy_users))
            {
                $i = 0;
                foreach ($employee_info->hierarchy_users as $key => $value) {
                    if($value != $authuser->id)
                    {
                        $user = User::find($value);
                        $user->is_present = DailyAttendance::where('user_id',$user->id)->where('date',date('Y-m-d'))->count();
                        $user->tasks = Task::whereHas('employees', function ($q) use ($user){
                                $q->where('task_users.user_id',$user->id);
                        })->with('services','contacts','companies','employees','files')->whereRaw('(DATE(start_date) = ? or DATE(due_date) = ?)',[date('Y-m-d'),date('Y-m-d')])->get();

                        $hierchy_users[$i] = $user;
                        $i++;
                    }
                }
            }
        }

        $data['hierchy_users'] = $hierchy_users;
        
        $yesterday = Carbon::yesterday();
        $tomorrow = Carbon::tomorrow();

        $data['tasks'] = Task::whereHas('employees', function ($q) use ($authuser){
                $q->where('task_users.user_id',$authuser->id);
        })->with('services','contacts','companies','employees','files')->whereRaw('(DATE(start_date) between ? and ? OR DATE(due_date)  between ? and ?)',[$yesterday->format('Y-m-d'),$tomorrow->format('Y-m-d'),$yesterday->format('Y-m-d'),$tomorrow->format('Y-m-d')])->whereIn('type',['meeting','call','todo','crd','help-ticket','regular-ticket','department-task'])->get();

        //, SUM(IF(type = meeting,1,0)) as meeting,SUM(IF(type = sms,1,0)) as sms,SUM(IF(type = todo,1,0)) as todo,SUM(IF(type = regular-ticket,1,0)) as regular-ticket,SUM(IF(type = help-ticket,1,0)) as help-ticket
        $data['counts'] = Task::select(DB::raw("SUM(IF(tasks.type = 'call',1,0)) as call_count,SUM(IF(tasks.type = 'meeting',1,0)) as meeting_count,SUM(IF(tasks.type = 'sms',1,0)) as sms_count,SUM(IF(tasks.type = 'regular-ticket',1,0)) as regular_ticket_count,SUM(IF(tasks.type = 'help-ticket',1,0)) as help_ticket_count,SUM(IF(tasks.type = 'todo',1,0)) as todo_count,SUM(IF(tasks.type = 'crd',1,0)) as information_request_count,SUM(IF(tasks.type = 'department-task',1,0)) as department_task_count,COUNT(*) as total_count"))->whereIn('type',['meeting','call','todo','crd','help-ticket','regular-ticket','department-task'])->whereHas('employees', function ($q) use ($authuser){
                $q->where('task_users.user_id',$authuser->id);
        })->where('status',0)->get();

        //$tasks = Task::with('children')->taskCheckPermission()->where('parent_id',0)->get();
        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    public function tasks_by_user(Request $request)
    {

        $authuser = $request->userid > 0 ? User::find($request->userid) : Auth::user();
      
        $data = Task::whereHas('employees', function ($q) use ($authuser){
                $q->where('task_users.user_id',$authuser->id);
        })->with('services','contacts','companies','employees','files','supervisor')->whereIn('type',['meeting','call','todo','crd','help-ticket','regular-ticket','department-task'])->where('status',0)->get();

       

        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    public function all_tasks_by_user(Request $request)
    {
        $authuser = Auth::user();
      
        $query =  QueryBuilder::for(Task::class)->allowedFilters(['name','description', AllowedFilter::exact('parent_id')->ignore(null), AllowedFilter::exact('status')->ignore(null), AllowedFilter::exact('priority')->ignore(null), AllowedFilter::exact('type')->ignore(null), AllowedFilter::exact('ist_type')->ignore(null)])->defaultSort('-created_at')->allowedSorts('name','description','start_date','received_date','due_date','ecd','completed_date','start_period','end_period','recursive_end_date','recursive_days','recursive_last_created','status','type','priority','ist_type')->with('services','contacts','companies','employees','files','supervisor','main_task')->whereIn('type',['meeting','call','todo','crd','help-ticket','regular-ticket','department-task']);  // 26/09/2024 Jyoti

       if($request->header('DEVICE-TYPE') && $request->header('DEVICE-TYPE') == 'mobile')
       {
            $data = $query->whereHas('employees', function ($q) use ($authuser){
                    $q->where('task_users.user_id',$authuser->id);
            })->taskadvanceSearch($request->advfilter,'tasks','')->orderBy('start_date','desc')->paginate($request->per_page); 
       }  
       else
       {

            $data = $query->with('change_logs','change_logs.creator','creator','editor')->taskadvanceSearch($request->advfilter,'tasks','')->taskCheckPermission()->orderBy('start_date','desc')->paginate($request->per_page);
            $this->saveAdvanceSearchData($request);

       }
         
        

        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    } 
    public function all_tasks_by_user_headers()
    {
        $headers = array(
            array('column_name'=>'name','display_name'=>'Name','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'companies','display_name'=>'Company','is_display'=>1,'is_default'=>1,'is_sortable'=>0,'is_multiple'=>1,'child_column'=>'fname'), 
            array('column_name'=>'ticket_name','display_name'=>'Related Ticket','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),  // 26/09/2024 Jyoti
            array('column_name'=>'type_name','display_name'=>'Type','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'contacts','display_name'=>'Contacts','is_display'=>1,'is_default'=>0,'is_sortable'=>0,'is_multiple'=>1,'child_column'=>'full_name'), 
            array('column_name'=>'services','display_name'=>'Services','is_display'=>1,'is_default'=>0,'is_sortable'=>0,'is_multiple'=>1,'child_column'=>'name'), 
            array('column_name'=>'due_date','display_name'=>'Due Date','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'employees','display_name'=>'Employees','is_display'=>1,'is_default'=>1,'is_sortable'=>1),

            array('column_name'=>'status_name','display_name'=>'Status','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'priority_name','display_name'=>'Priority','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'creator','display_name'=>'Created By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
            array('column_name'=>'editor','display_name'=>'Updated By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
            array('column_name'=>'updated_at','display_name'=>'Updated On','is_display'=>1,'is_default'=>1,'is_sortable'=>1), 
            array('column_name'=>'created_at','display_name'=>'Added On','is_display'=>1,'is_default'=>0,'is_sortable'=>1)       
        );
        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    public function tasks_tree_by_user(Request $request)
    {
        $authuser = $request->userid > 0 ? User::find($request->userid) : Auth::user();
      
        // $tasks =  Task::whereHas('employees', function ($q) use ($authuser){
        //         $q->where('task_users.user_id',$authuser->id);
        // })->where('parent_id',0)->whereIn('type',['meeting','call','todo','crd','help-ticket','regular-ticket','department-task'])->orderBy('start_date','desc')->get();

        // $data = Task::whereHas('employees', function ($q) use ($authuser){
        //         $q->where('task_users.user_id',$authuser->id);
        // })->with('services','contacts','companies','employees','files','supervisor')->with( ['children_by_logged_user'=> function($q) use ($authuser){
        //      $q->whereHas('employees', function($q2) use ($authuser)
        //      {
        //         $q2->where('task_users.user_id',$authuser->id);
        //     });
        // }])->where('parent_id',0)->whereIn('type',['meeting','call','todo','crd','help-ticket','regular-ticket','department-task'])->orderBy('start_date','desc')->get();



        $data = Task::whereHas('employees', function ($q) use ($authuser){
                $q->where('task_users.user_id',$authuser->id);
        })->where('status',0)->with('services','contacts','companies','employees','files','supervisor','change_logs.creator','group')->whereIn('type',['meeting','call','todo','crd','help-ticket','regular-ticket','department-task'])->orderBy('start_date','desc')->get();
            

        
            
       

        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    public function performance_data_by_user(Request $request,$id)
    {
       
       
        $system_user_id = $id > 0 ? $id : Auth::user()->id;
        

        if(!($request->start_date==" " || $request->start_date=="undefined" || $request->start_date==null) &&  !($request->end_date==" " || $request->end_date=="undefined" || $request->end_date==null))
        {

            $start_date=$request->start_date;
            $end_date=$request->end_date;
        }
        else
        {
            $start_date=date('Y-m-01');
            $end_date=date('Y-m-d');
        }

        $early_in=DailyAttendance::where('user_id',$system_user_id)->whereRaw("UNIX_TIMESTAMP(concat(concat(date,' '), start_time)) <= UNIX_TIMESTAMP(concat(concat(date,' '),schedule_in))")->where('status',1)->whereBetween('date',[$start_date,$end_date])->count();
        //late in

        $late_in=DailyAttendance::where('user_id',$system_user_id)->whereRaw("UNIX_TIMESTAMP(concat(concat(date,' '), start_time)) > (UNIX_TIMESTAMP(concat(concat(date,' '),schedule_in)) + (schedule_grace*60))")->where('status',1)->whereBetween('date',[$start_date,$end_date])->count();

        //early out
        $early_out=DailyAttendance::where('user_id',$system_user_id)->whereRaw("UNIX_TIMESTAMP(concat(concat(date,' '), end_time)) < UNIX_TIMESTAMP(concat(concat(date,' '),schedule_out))")->where('status',1)->whereBetween('date',[$start_date,$end_date])->count();
        //late out
        $late_out=DailyAttendance::where('user_id',$system_user_id)->whereRaw("UNIX_TIMESTAMP(concat(concat(date,' '), end_time)) > UNIX_TIMESTAMP(concat(concat(date,' '),schedule_out))")->where('status',1)->whereBetween('date',[$start_date,$end_date])->count();
        //absent
        $absent=DailyAttendance::where('user_id',$system_user_id)->whereIn('status',[0,3])->whereBetween('date',[$start_date,$end_date])->count();

       

        //System Time
        $system_time=DB::table('daily_attendance_logs')->select(DB::raw("sum(UNIX_TIMESTAMP(concat(concat(date,' '),end_time)) - UNIX_TIMESTAMP(concat(concat(date,' '),start_time))) as system_hour"))->where('master_id',$request->master_id)->where('user_id',$system_user_id)->whereBetween('date',[$start_date,$end_date])->whereNull('deleted_at')->get();
     
        $system_hour=sprintf('%02d',floor($system_time[0]->system_hour/3600) );
        $system_time=sprintf('%02d',intval(($system_time[0]->system_hour%3600)/60));

        $system_time=$system_hour.":".$system_time;

        // Expected Time
        $authuser = $request->userid > 0 ? User::find($request->userid) : Auth::user();
        $employee_info = $this->employee_info($authuser);

        $holiday=Holiday::where('branch_id', $employee_info->branch_id)->where('master_id',$request->master_id)->where('status',1)->whereBetween('date',[$start_date,$end_date])->get()->toArray();
        $holiday_dates=array_column($holiday,'date');
        $expected_time=DB::table('daily_attendances')->select(DB::raw("sum(UNIX_TIMESTAMP(concat(concat(date,' '),schedule_out)) - UNIX_TIMESTAMP(concat(concat(date,' '),schedule_in)) - TIME_TO_SEC(schedule_break)) as expected_hour"))->where('master_id',$request->master_id)->where('user_id',$system_user_id)->whereNotIn('date',$holiday_dates)->whereNotIn('status',[2,3])->whereBetween('date',[$start_date,$end_date])->whereNull('deleted_at')->get();

        $expected_hour=sprintf('%02d',floor($expected_time[0]->expected_hour/3600) );
        $expected_time=sprintf('%02d',intval(($expected_time[0]->expected_hour%3600)/60));

        $expected_time=$expected_hour.":".$expected_time;


        $effective_time=DB::table('daily_attendance_reports')->select(DB::raw('SUBSTRING(SEC_TO_TIME(sum(TIME_TO_SEC( time ))),1,5) as effective_hour'))->where('master_id',$request->master_id)->where('user_id',$system_user_id)->whereBetween('date',[$start_date,$end_date])->whereNull('deleted_at')->first();

        $effective_time=$effective_time->effective_hour?$effective_time->effective_hour:"00:00";

        $timing_chart_data=array(
            'early_in'=>$early_in,
            'late_out'=>$late_out,
            'late_in'=>$late_in,
            'early_out'=>$early_out,
            'absent'=>$absent,
            
        );

        $performance_data = array(
            'system_time'=>$system_time,
            'expected_time'=>$expected_time,
            'effective_time'=> $effective_time
        );
        

        return response(['data' => $timing_chart_data,'performance_data'=>$performance_data, 'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

     //19/07/2024 Jyoti
     public function tasks_by_id(Request $request,$id)
     {
         $data = Task::whereHas('employees', function ($q) use ($id){
             $q->where('task_users.user_id',$id);
         })->with('services','contacts','companies','employees','files','supervisor')->whereRaw('((date(start_date) between ? and ? ) or (date(due_date) between ? and ?))',[$request->start_date, $request->end_date, $request->start_date, $request->end_date])->whereIn('type',['meeting','call','todo','crd','help-ticket','regular-ticket','department-task'])->where('status',0)->get();
 
         //->whereBetween('start_date',["2024-06-04","2024-06-07"])
         //->whereRaw('((start_date between ? and ? ) or (due_date between ? and ?)',[$request->start_date,$request->end_date, $request->start_date, $request->end_date])
 
         return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
     }
     //19/07/2024 Jyoti
    
}
