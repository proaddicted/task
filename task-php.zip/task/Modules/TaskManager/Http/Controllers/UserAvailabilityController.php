<?php

namespace Modules\TaskManager\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Carbon\Carbon;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;
use App\Models\User;
use Modules\TaskManager\Entities\Task;
use Modules\TaskManager\Entities\UserAvailability;
use Modules\TaskManager\Entities\UserAvailabilitySlot;
use Modules\TaskManager\Transformers\UserAvailabilityResource;

class UserAvailabilityController extends Controller
{

    use PermissionTrait,CommonTrait;
    
    public function headers()
    {
        $headers = array(
            array('column_name'=>'user','display_name'=>'Employee','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'),
            array('column_name'=>'creator','display_name'=>'Created By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
            array('column_name'=>'editor','display_name'=>'Updated By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
            array('column_name'=>'updated_at','display_name'=>'Updated On','is_display'=>1,'is_default'=>1,'is_sortable'=>1), 
            array('column_name'=>'created_at','display_name'=>'Added On','is_display'=>1,'is_default'=>0,'is_sortable'=>1)       
        );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    public function getlist(Request $request)
    {
        $data['employees'] = User::where('type','employee')->select('id','name','profile')->get();
      

        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index(Request $request)
    {
        $query = QueryBuilder::for(UserAvailability::class)->allowedFilters(['updated_at','description',AllowedFilter::exact('user_id')->ignore(null)])->defaultSort('-created_at')->allowedSorts('updated_at','description');

        $query->search(!empty($request->search)?$request->search:"");

        $user_availabilities = $query->advanceSearch($request->advfilter,'user_availabilities')->with('slots','user','creator','editor')->checkPermission('user_id')->paginate($request->per_page);

        $this->saveAdvanceSearchData($request);

        return response(['data' => $user_availabilities,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Response
     */
    public function store(Request $request)
    {
 
        if(!$this->checkStoreAccess())
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403); 

        $validator = Validator::make($request->all(), [
            'user_id' => 'required',

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            $user_availability = UserAvailability::create($request->except('slot'));



            if($request->input('slot') != null && count($request->input('slot'))>0)
            {
                $user_availability->slots()->delete();

                foreach ($request->input('slot') as $data) 
                {
                    if(!empty($data['day']))
                    {
                        $data['user_id'] = $request->input('user_id');
                        if(intval($data['id']) > 0)
                        {
                            if($object = UserAvailabilitySlot::withTrashed()->find($data['id']))
                            {
                                $object->restore();
                                $object->fill($data);
                            }
                            else
                                $object = new UserAvailabilitySlot($data);
                        }
                        else
                            $object = new UserAvailabilitySlot($data);
                        
                        
                        $user_availability->slots()->save($object);
                       
                    }        
                }
            }

           
            
            DB::commit();
            
            return response(['data' => new UserAvailabilityResource($user_availability),'success'=>true,'message' => 'User Availability Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Response
     */
    public function show($id)
    {
        return response(['data' =>new UserAvailabilityResource(UserAvailability::findOrFail($id)),'success'=>true,'message' => 'User Availability Retrived Successfully'], 200);
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
        $user_availability = UserAvailability::find($id);
        
        if(!$this->checkUpdateAccess($user_availability))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        $validator = Validator::make($request->all(), [
            'user_id' => 'required',

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            $user_availability->update($request->except(['slot']));



            if($request->input('slot') != null && count($request->input('slot'))>0)
            {
                $user_availability->slots()->delete();

                foreach ($request->input('slot') as $data) 
                {
                    if(!empty($data['day']))
                    {
                        $data['user_id'] = $request->input('user_id');

                        if(intval($data['id']) > 0)
                        {
                            if($object = UserAvailabilitySlot::withTrashed()->find($data['id']))
                            {
                                $object->restore();
                                $object->fill($data);
                            }
                            else
                                $object = new UserAvailabilitySlot($data);
                        }
                        else
                            $object = new UserAvailabilitySlot($data);
                        
                        
                        $user_availability->slots()->save($object);
                       
                    }        
                }
            }

           
            
            DB::commit();
            
            return response(['data' => new UserAvailabilityResource($user_availability),'success'=>true,'message' => 'User Availability Updated Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Response
     */
    public function destroy($id)
    {
        $user_availability = UserAvailability::find($id);
        
        if(!$this->checkDeleteAccess($check_list))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);
        
        DB::beginTransaction();
        try {
            
            $user_availability->delete();
            DB::commit();
            return response(['data' => array(),'success'=>true,'message' => 'User Availability Deleted Successfully'], 200);
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }
    }

    /**
     * Bulk Action function of footer (pass 6  for delete and 3 for update)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2024, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function actionall()
    {
        
        $access = request()->action == 'delete' ? 6 : 3;

        if(!$this->checkBulkAcess( $access))
            return response(['data' => array(),'success'=>false,'message' =>"You Don't Have Access For Bulk Action"], 200);

        DB::beginTransaction();
        try {
           
            if($access == 6)
            {
                UserAvailability::whereIn('id',request()->ids)->get()->each(function($user_availability) 
                {
                    $user_availability->delete();
                });
            }
            elseif($access == 3)  
                UserAvailability::whereIn('id',request()->ids)->update([request()->column => request()->status]);

            DB::commit();
            return response(['data' => array(),'success'=>true,'message' => 'Updated successfully'], 200);
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        
    }

    public function check_user_availability(Request $request)
    {

        $tasks = Task::whereHas('employees', function ($q) use ($request){
                $q->where('task_users.user_id',$request->userid);
        })->whereRaw('DATE(start_date) = ?',[$request->date])->where('status',0)->get();

        $slots = UserAvailabilitySlot::where('user_id',$request->userid)->where('day',date('N',strtotime($request->date)))->get();

        return response(['data' => $slots,'success'=>true,'message' => 'Retrived Successfully'], 200);

    }

    public function get_available_users(Request $request)
    {
        $data['employees'] = User::where('type','employee')->Where('status',1)->select('id','name','profile')->get();
        return response(['data' => $data,'success'=>true,'message' => 'Retrived successfully'], 200);

    }
}
