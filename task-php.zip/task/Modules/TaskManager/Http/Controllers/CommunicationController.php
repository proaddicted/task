<?php

namespace Modules\TaskManager\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Carbon\Carbon;
use App\Mail\MailChimp;
use App\Mail\TestMailchimp;
use Modules\ContactManager\Entities\Contact;//19/09/2024
use Modules\ContactManager\Entities\Group;//19/09/2024
use App\Notifications\SendSmsNotification;
use App\Models\NotificationLog;
use App\Models\NotificationTemplate;
use Illuminate\Support\Facades\Notification;
use Modules\TaskManager\Notifications\MailSendNotification;
use App\Notifications\SendNotification;
use Illuminate\Support\Facades\Mail;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;
use Modules\TaskManager\Entities\Communication;
use Modules\TaskManager\Entities\CommunicationRecipient;
use Modules\TaskManager\Entities\CommunicationRead;
use Modules\TaskManager\Transformers\CommunicationResource;
use Modules\TaskManager\Http\Requests\CommunicationRequest;
use Modules\TaskManager\Entities\CommunicationSchedule;
use Modules\TaskManager\Entities\TaskChangeLog;
use App\Models\TempFile;
use App\Models\File;
use App\Models\User;
use App\Traits\EmployeeTrait;

class CommunicationController extends Controller
{
    use PermissionTrait,CommonTrait,EmployeeTrait;
    public $notification_batch_id=0,$template_body='';

    public function getlist(Request $request)
    {
        $data['users'] = User::select('id','name','profile','email')->where('id','<>',Auth::user()->id)->get();
        $data['recursive_types']= $this->recursive_types;
        $data['recursive_weeks']= $this->recursive_weeks;
        $data['companies'] = Contact::select('id','fname','mname','lname','group_id')->where('type','company')->get();//19/09/2024
        $data['groups'] = Group::select('id','name')->where('status',1)->get();//19/09/2024
        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index(Request $request)
    {
        $query = QueryBuilder::for(Communication::class)->allowedFilters(['comment','date', AllowedFilter::exact('parent_id')->ignore(null)])->defaultSort('-created_at')->allowedSorts('comment','identifier','date');

        $query->search(!empty($request->search)?$request->search:"");

        $communications = $query->advanceSearch($request->advfilter,'communications')->with('files','recipients')->paginate($request->per_page);
        
        $this->saveAdvanceSearchData($request);
        
        return response(['data' => $communications,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * attach task to comments
     * @author Debargha Chakraborty <debargha.chakraborty01@gmail.com>
     * @copyright Copyright (c) 2024, Debargha Chakraborty 
     * @return \Illuminate\Http\Response
     */
     public function comment_task_attach(Request $request,$id)
     {
         $communication=Communication::where('id',$id)->update(['main_id'=>$request->task_id]);
 
         return response(['data' => $communication,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
     }

  

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Response
     */
    public function store(CommunicationRequest $request)
    {
        if($request->from_id==null)
            $request->from_id=Auth::user()->id;

        $not=DB::table('notifications')->max('batch_id');
        $this->notification_batch_id=$not+1;
            $validator = Validator::make($request->all(), [
        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }
        

        DB::beginTransaction();
        try {
                $requestData=$request->except('weekly','custom_date');
                $requestData['from_id']=$request->from_id;
                $communication = Communication::create($requestData);

                if($communication->identifier=='task')
                {
                    TaskChangeLog::create(['action'=>'add','task_id'=>$communication->main_id,'column_name'=>'communication','new_value'=>$communication->id]);//11/07/2024
                }

            if($request->input('files') && count($request->input('files')) > 0)
            {
                foreach ($request->input('files') as $data) 
                {
                    
                    $data['identifier']=isset($data['identifier'])?$data['identifier']:"communication";
                    if(intval($data['id']) > 0 || intval($data['temp_id']) > 0)
                    {
                        if($object = File::withTrashed()->find($data['id']))
                        {
                            $object->restore();
                            $object->fill($data);
                        }
                        else
                        {
                            if($tempobject = TempFile::find($data['temp_id']))
                            {
                                
                                $object = new File($data);
                            }
                        }
                            
                        $communication->files()->save($object);
                    }
                }
            }
            if($request->recipients != null && count($request->recipients)>0)
            {
                $communication->recipients()->detach();
                $communication->recipients()->attach($request->recipients,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 

                if($template = NotificationTemplate::where('name','comment-notification')->where('status',1)->first())
                {
                  
                    $user=User::find(Auth::user()->id);
                    $notification_data['template'] = $template;
                    $notification_data['host'] =isset($user->name)?$user->name:'';
                    $notification_data['agenda'] = $request->comment;
                    $notification_data['template_subject'] =$request->subject;
                    $notification_data['requestee_name'] = isset($requestee->name)?$requestee->name:'';
                    $notification_data['start_date'] = date('d/m/Y H:i A');
                    $recipients=[];
                    foreach($request->recipients as $recip){
                        if(isset($recip['user_id']))
                        {
                            $getuser=User::find($recip['user_id']);
                            if(!isset($recip['type'])){
                                $recip['type']='to';
                            }
                            if($getuser!=null)
                             $recipients[]=array('email'=>$getuser->email,'name'=>$getuser->name,'mail_type'=>$recip['type']);
                        }
                    }
                    $inv_users=array_column($request->recipients,'user_id');

                    if($inv_users && count($inv_users))
                    {
                        $invitie_users = User::whereIn('id',array_unique($inv_users))->get();
                        foreach( $invitie_users as $user)
                        {
                            $phoneNumber = $user->phone; // The phone number to send the SMS to
                            $message = 'Dear '.$user->name.', this is your SMS message!';
                            $user->notify(new SendSmsNotification($phoneNumber, $message));
                        }
                        Notification::send($invitie_users, new SendNotification($notification_data,$communication,$recipients,$request->type,$this->notification_batch_id));//old
                        
                        if(isset($notification_data['template']) && isset($notification_data['template']['email_body']))
                        $this->template_body=$notification_data['template']['email_body'];
                    } 
                    $this->sendMailFunc($this->notification_batch_id,$this->template_body,$communication->id); //24/05/24
                }
               

            }
            if(isset($request->parent_type) && $request->parent_type==='reply')
            {
                $recipient_data=[];
                    if($request->to!=null && count($request->to)>0)
                    {
                        foreach($request->to as $to)
                         $recipient_data[]=$to.'-to';
                    }
                    if($request->cc!=null && count($request->cc)>0)
                    {
                        foreach($request->cc as $cc)
                        $recipient_data[]=$cc.'-cc';
                    }
                    if($request->bcc!=null && count($request->bcc)>0)
                    {
                        foreach($request->bcc as $bcc)
                        $recipient_data[]=$bcc.'-bcc';
                    }
                if($template = NotificationTemplate::where('name','comment-notification')->where('status',1)->first())
                {
                    $user=User::find(Auth::user()->id);
                    $notification_data['template'] = $template;
                    $notification_data['host'] =isset($user->name)?$user->name:'';
                    $notification_data['agenda'] = $request->comment;
                    $notification_data['template_subject'] =$request->subject;
                    $notification_data['requestee_name'] = isset($requestee->name)?$requestee->name:'';
                    $notification_data['start_date'] = date('d/m/Y H:i A');

                    $recipients=[];
                    $inv_users=[];
                    foreach($recipient_data as $recip){
                        // dd($recip);
                        $user=explode('-',$recip);
                        // dd($user);
                        if(count($user)>0)
                        {
                            $inv_users[]=$user[0];
                            $getuser=User::find($user[0]);
                            if(!isset($user[1])){
                                $user[1]='to';
                            }
                            if($getuser!=null)
                             $recipients[]=array('email'=>$getuser->email,'name'=>$getuser->name,'mail_type'=>$user[1]);
                        }
                    }
                    
                    if($inv_users && count($inv_users))
                    {
                        $invitie_users = User::whereIn('id',array_unique($inv_users))->get();
                        foreach( $invitie_users as $user)
                        {
                            $phoneNumber = $user->phone; // The phone number to send the SMS to
                            $message = 'Dear '.$user->name.', this is your SMS message!';
                            $user->notify(new SendSmsNotification($phoneNumber, $message));
                        }
                        Notification::send($invitie_users, new SendNotification($notification_data,$communication,$recipients,$request->type,$this->notification_batch_id));//old
                        
                        if(isset($notification_data['template']) && isset($notification_data['template']['email_body']))
                        $this->template_body=$notification_data['template']['email_body'];
                    } 
                    $this->sendMailFunc($this->notification_batch_id,$this->template_body,$communication->id); //24/05/24
                }

            }
            if($request->type == 'mail')
            {
                $communication->reads()->detach();
                $communication->reads()->attach($request->reads,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
            }

            if($communication->recursive_type==3|| $communication->recursive_type==7)
            {
                
                //weekly
                if($communication->recursive_type==3)
                {
                    if(isset($request->weekly) && count($request->weekly)>0)
                    {
                        $data = [];
                        foreach ($request->weekly as $week_data)
                        {
                            $data['week_no'] = $week_data;
                            $object=new CommunicationSchedule($data);
                            $communication->schedules()->save($object);
                        }
                    }
                }
                //custom
                elseif ($communication->recursive_type==7)
                {
                    if(isset($request->custom_date) && count($request->custom_date)>0)
                    {
                        foreach ($request->custom_date as $custom_data)
                        {
                            $date_arr=explode('/', $custom_data['date']);
                            if(count($date_arr) == 2)
                            {
                                $custom_data['day']=$date_arr[0];
                                $custom_data['month']=$date_arr[1];
                                $object=new CommunicationSchedule($custom_data);
                                $communication->schedules()->save($object);
                            }
                        }
                    }
                }
            }

            DB::commit();
            return response(['data' => new CommunicationResource($communication),'success'=>true,'message' => 'Communication Updated Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * For mail send via mailchimp
     * @param int $id
     * @author Debargha 
     * @return Response
     */
    public function sendMailFunc($batch_id,$template_body,$comment_id)
    {
        $notifications=NotificationLog::where('batch_id',$this->notification_batch_id)->where('status',0)->get()->toArray();
        if(count($notifications)>0)
         Mail::send(new MailChimp($notifications,$template_body,$comment_id,'comment',User::find(Auth::user()->id)));
    }


    /**
     * Show the specified resource.
     * @param int $id
     * @return Response
     */
    public function show($id)
    {
    }

    

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Response
     */
    public function destroy($id)
    {
        $communication=Communication::find($id);
        
        if(!$this->checkDeleteAccess($communication))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);
        
        DB::beginTransaction();
        try {
            
            $communication->delete();
            DB::commit();
            return response(['data' => array(),'success'=>true,'message' => 'Communication Deleted Successfully'], 200);
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }
    }

     /**
     * Inbox for mailbox
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2024, Prosanta Mitra
     * @return Response
     */
    public function inbox(Request $request)
    {
        //'communications.from','communications.replies','communications.replies.from','communications.replies.files','communications.replies.recipients','communications.files','communications.recipients','files.file_sources'

        $authuser = Auth::user();

        $query = QueryBuilder::for(Communication::class)->allowedFilters(['comment','date','type'])->defaultSort('-created_at')->allowedSorts('comment','identifier','date');

        $query->whereHas('recipients', function ($q) use ($authuser){
                $q->where('communication_recipients.user_id',$authuser->id)->whereIn('communication_recipients.type',['to','cc']);
        })->where('parent_id',0);

        $query->search(!empty($request->search)?$request->search:"");

        $communications = $query->notArchivedTask($authuser->id)->advanceSearch($request->advfilter,'communications')->with('files','recipients','replies.recipients','replies.from','replies.files','from','tasks')->with(['reads'=> function($q) use ( $authuser)
            { 
                $q->where('communication_reads.user_id', $authuser->id);
        }])->paginate($request->per_page);

        return response(['data' => $communications,'success'=>true,'message' => 'Data Retrived Successfully'], 200);

    }

    /**
     * Read Communication
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2024, Prosanta Mitra
     * @return Response
     */
    public function read_communication(Request $request,$id){
        
        
        DB::beginTransaction();
        try {
            
            CommunicationRead::where('communication_id',$id)->where('user_id',Auth::user()->id)->update(
                [
                    'is_read'=>1
                ]
            );

            DB::commit();
            return response(['data' => array(),'success'=>true,'message' => 'Communication Updated Successfully'], 200);
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }
    }

     /**
     * Read Communication
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2024, Prosanta Mitra
     * @return Response
     */
    public function unread_communication(Request $request,$id){
        
        
        DB::beginTransaction();
        try {
            
            CommunicationRead::where('communication_id',$id)->where('user_id',Auth::user()->id)->update(
                [
                    'is_read'=>0
                ]
            );

            DB::commit();
            return response(['data' => array(),'success'=>true,'message' => 'Communication Updated Successfully'], 200);
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }
    }

     /**
     * Outbox for mailbox
     * @param Request $request
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2024, Prosanta Mitra
     * @return Response
     */
    public function outbox(Request $request)
    {
       

        $authuser = Auth::user();

        $query = QueryBuilder::for(Communication::class)->allowedFilters(['comment','date','type'])->defaultSort('-created_at')->allowedSorts('comment','identifier','date');

        $query->where('from_id',$authuser->id)->where('parent_id',0);

        $query->search(!empty($request->search)?$request->search:"");

        $communications = $query->notArchivedTask($authuser->id)->advanceSearch($request->advfilter,'communications')->with('files','recipients','replies.recipients','replies.from','replies.files','from','tasks')->paginate($request->per_page);

        return response(['data' => $communications,'success'=>true,'message' => 'Data Retrived Successfully'], 200);

    }

     /**
     * Outbox for mailbox
     * @param Request $request
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2024, Prosanta Mitra
     * @return Response
     */
    public function archive(Request $request)
    {

        $authuser = Auth::user();

        $query = QueryBuilder::for(Communication::class)->allowedFilters(['comment','date','type'])->defaultSort('-created_at')->allowedSorts('comment','identifier','date');

        $query->where('parent_id',0);

        $query->search(!empty($request->search)?$request->search:"");

        $communications = $query->archivedTask($authuser->id)->advanceSearch($request->advfilter,'communications')->with('files','recipients','replies.recipients','replies.from','replies.files','from','tasks')->paginate($request->per_page);

        return response(['data' => $communications,'success'=>true,'message' => 'Data Retrived Successfully'], 200);

    }
     /**
     * Archive a Communication
     * @param Request $request, int $id
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2024, Prosanta Mitra
     * @return Response
     */
    public function communication_archive(Request $request,$id)
    {
        $communication=Communication::find($id);
        
       
        
        DB::beginTransaction();
        try {
            CommunicationArchive::where('user_id',Auth::user()->id)->where('communication_id',$id)->delete();

            CommunicationArchive::create([
                'is_archive'=>1,
                'communication_id'=>$id,
                'user_id'=>Auth::user()->id
            ]);
            DB::commit();
            return response(['data' => array(),'success'=>true,'message' => 'Communication Deleted Successfully'], 200);
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }
    }

    /**
     * Archive a Communication
     * @param Request $request, int $id
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2024, Prosanta Mitra
     * @return Response
     */
    public function communication_unarchive(Request $request,$id)
    {
        $communication=Communication::find($id);
        
        
        DB::beginTransaction();
        try {
            
            CommunicationArchive::where('user_id',Auth::user()->id)->where('communication_id',$id)->delete();

            DB::commit();
            return response(['data' => array(),'success'=>true,'message' => 'Communication Deleted Successfully'], 200);
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }
    }

    /********************For all Comments********************* */
    public function store_all_comments(Request $request)
    {
        $communication=new Communication;
        $communication->id=$request->id;
        $communication->master_id=$request->master_id;
        $communication->date=$request->date;
        $communication->main_id=$request->main_id;
        $communication->subject=$request->subject;
        $communication->comment=$request->comment;
        $communication->parent_id=$request->parent_id;
        $communication->type=$request->type;
        $communication->created_at=$request->created_at;
        $communication->updated_at=$request->updated_at;
        $communication->created_by=$request->created_by;
        $communication->updated_by=$request->updated_by;
        $communication->identifier='task';
        $from=User::where('id',$request->created_by)->first();
        if(isset($from->id))
            $communication->from_id=$from->id;

        $communication->save();
          
    }

    /**********************For comment Recipients*********************** */
    public function store_all_comment_recipients(Request $request)
    {
        $communication_recipients=new CommunicationRecipient;
        $communication_recipients->id=$request->id;
        $communication_recipients->master_id=$request->master_id;

        if($request->mail_type==0)
            $type='to';
        elseif ($request->mail_type==1) 
            $type='cc';
        else 
            $type='bcc';
        $communication_recipients->type=$type;
        $communication_recipients->created_at=$request->created_at;
        $communication_recipients->updated_at=$request->updated_at;
        $communication_recipients->created_by=$request->created_by;
        $communication_recipients->updated_by=$request->updated_by;
        $communication_recipients->identifier='task';
        $communication_recipients->communication_id=$request->comment_id;
    
        $from=Employee::where('id',$request->main_id)->where('user_id','>',0)->first();
        if(!isset($from->id))
            $from=Contact::where('id',$request->main_id)->where('type','individual')->where('user_id','>',0)->first();

        if(isset($from->id))
            $communication_recipients->user_id=$from->user_id;


        $communication_recipients->save();
    }

    /**********************For comment Reads********************** */
    public function store_all_comment_reads(Request $request)
    {
        $communication_reads=new CommunicationRead;
        $communication_reads->id=$request->id;
        $communication_reads->master_id=$request->master_id;

        $communication_reads->communication_id=$request->comment_id;
    
        $from=Employee::where('id',$request->emp_id)->where('user_id','>',0)->first();
        if(!isset($from->id))
            $from=Contact::where('id',$request->emp_id)->where('type','individual')->where('user_id','>',0)->first();

        if(isset($from->id))
            $communication_reads->user_id=$from->user_id;

        $communication_reads->is_read=1;
        $communication_reads->created_at=$request->created_at;
        $communication_reads->updated_at=$request->updated_at;
        $communication_reads->created_by=$request->created_by;
        $communication_reads->updated_by=$request->updated_by;
        $communication_reads->save();
    }

}
