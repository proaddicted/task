<?php

return [
    'name' => 'TaskManager'
];
