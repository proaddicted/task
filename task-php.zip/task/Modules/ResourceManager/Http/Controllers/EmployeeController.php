<?php

namespace Modules\ResourceManager\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;
use Modules\ResourceManager\Entities\Employee;
use Modules\ResourceManager\Transformers\EmployeeResource;
use App\Models\Link;
use App\Models\Phone;
use App\Models\Email;
use App\Models\Address;
use App\Models\MasterType;
use App\Models\Country;
use App\Models\State;
use App\Models\User;
use App\Models\Role;
use App\Models\Branch;
use Modules\ResourceManager\Entities\Department;
use Modules\ResourceManager\Entities\Designation;
use Modules\ResourceManager\Entities\EmployeeCompanyProfile;
use Modules\ResourceManager\Entities\EmployeeEmergencyDetail;
use Modules\ResourceManager\Entities\EmployeeQualification;
use Modules\ResourceManager\Entities\EmployeeTiming;
use Modules\ResourceManager\Entities\EmployeeBank;
use Modules\ResourceManager\Entities\EmployeeProfession;
use Modules\ResourceManager\Entities\Shift;
use App\Models\File;

class EmployeeController extends Controller
{
    use PermissionTrait,CommonTrait;

    public function headers()
    {
        $headers = array(
            array('column_name'=>'thumbnail','display_name'=>'Profile','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'full_name','display_name'=>'Name','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
            
            array('column_name'=>'employee_type','display_name'=>'Type','is_display'=>1,'is_default'=>1,'is_sortable'=>0 , 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'),
            array('column_name'=>'phone','display_name'=>'Phone','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'email','display_name'=>'Email','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'creator','display_name'=>'Created By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
            array('column_name'=>'editor','display_name'=>'Updated By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
            array('column_name'=>'updated_at','display_name'=>'Updated On','is_display'=>1,'is_default'=>1,'is_sortable'=>1), 
            array('column_name'=>'created_at','display_name'=>'Added On','is_display'=>1,'is_default'=>0,'is_sortable'=>1)          );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Fetch Data For Add/Edit Page
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function getlist()
    {
        $data['master_types'] = MasterType::where('status',1)->whereIn('identifier',['employee','title','phone','email','address'])->select('id','name','identifier')->get();
        $data['countries'] = Country::where('status',1)->select('id','name')->get();
        $data['states'] = State::where('status',1)->select('id','name')->get();
        $data['branches'] = Branch::where('status',1)->select('id','name')->get();
        $data['designations'] = Designation::where('status',1)->select('id','name')->get();
        $data['departments'] = Department::where('status',1)->select('id','name')->get();
        $data['employees'] = Employee::where('status',1)->select('id','fname','mname','lname','profile')->get();
        $data['assignable_users'] = User::with('roles')->where('status',1)->whereRaw(' id not in ( select user_id from employees where status = 1 and user_id > 0 and deleted_at is null )')->select('id','name','password','email','is_superadmin','status')->get();
        $data['roles']=Role::where('status',1)->select('name','id','display_name')->CheckRoleAccess()->get();
        $data['shifts']=Shift::with('shift_timing')->where('status',1)->select('name','id')->get();
        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    /**
     * Display a listing of the resource.
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $query = QueryBuilder::for(Employee::class)->allowedFilters(['fname','lname','mname',AllowedFilter::exact('branch_id')->ignore(null),AllowedFilter::exact('manager_id')->ignore(null),AllowedFilter::exact('hr_manager_id')->ignore(null),AllowedFilter::exact('department_id')->ignore(null),
        AllowedFilter::exact('employee_type_id')->ignore(null),
        AllowedFilter::exact('phone')->ignore(null),AllowedFilter::exact('email')->ignore(null)])->defaultSort('fname')->allowedSorts('fname','lname','mname','created_at','phone','email','updated_at');

        $query->search(!empty($request->search)?$request->search:"");

        $employees = $query->with('employee_type','creator','editor')->advanceSearch($request->advfilter,'employees')->checkPermission('created_by')->paginate($request->per_page);

        $this->saveAdvanceSearchData($request);

        return response(['data' => $employees,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if(!$this->checkStoreAccess())
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403); 

        $validator = Validator::make($request->all(), [
            'fname' => 'required',
            'lname' => 'required'

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            $employee = Employee::create($request->except('phone','email','link','address','profile'));

            if($profile = $this->base64_upload($request->input('profile'),'employee'))
                $employee->profile = $profile;

            if($request->input('phone') != null && count($request->input('phone'))>0)
            {
                $employee->phones()->delete();

                foreach ($request->input('phone') as $data) 
                {
                        
                        $data['identifier']="employee";
                        if(intval($data['id']) > 0)
                        {
                            if($object = Phone::withTrashed()->find($data['id']))
                            {
                                $object->restore();
                                $object->fill($data);
                            }
                            else
                                $object = new Phone($data);
                        }
                        else
                            $object = new Phone($data);
                        
                        
                        $employee->phones()->save($object);
                        
                        if($data['is_default']==1)
                            $employee->phone = $data['phone_no'];
                }
            }

            if($request->input('email') != null && count($request->input('email'))>0)
            {
                $employee->emails()->delete();

                foreach ($request->input('email') as $data) 
                {
                        
                        $data['identifier']="employee";
                        if(intval($data['id']) > 0)
                        {
                            if($object = Email::withTrashed()->find($data['id']))
                            {
                                $object->restore();
                                $object->fill($data);
                            }
                            else
                                $object = new Email($data);
                        }
                        else
                            $object = new Email($data);
                        
                        
                        $employee->emails()->save($object);
                        
                        if($data['is_default']==1)
                            $employee->email = $data['email'];
                }
            }

            if($request->input('link') != null && count($request->input('link'))>0)
            {
                $employee->links()->delete();

                foreach ($request->input('link') as $data) 
                {
                        
                        $data['identifier']="employee";
                        if(intval($data['id']) > 0)
                        {
                            if($object = Link::withTrashed()->find($data['id']))
                            {
                                $object->restore();
                                $object->fill($data);
                            }
                            else
                                $object = new Link($data);
                        }
                        else
                            $object = new Link($data);
                        
                        
                        $employee->links()->save($object);
                        
                      
                }
            }

            if($request->input('address') != null && count($request->input('address'))>0)
            {
                $employee->address()->delete();

                foreach ($request->input('address') as $data) 
                {
                        
                        $data['identifier']="employee";
                        if(intval($data['id']) > 0)
                        {
                            if($object = Address::withTrashed()->find($data['id']))
                            {
                                $object->restore();
                                $object->fill($data);
                            }
                            else
                                $object = new Address($data);
                        }
                        else
                            $object = new Address($data);
                        
                        
                        $employee->address()->save($object);
                        
                      
                }
            }
            $employee->save();
            
            DB::commit();
            
            return response(['data' => new EmployeeResource($employee),'success'=>true,'message' => 'Employee Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return response(['data' =>new EmployeeResource(Employee::findOrFail($id)),'success'=>true,'message' => 'Employee Retrived Successfully'], 200);
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $employee=Employee::find($id);
        
        if(!$this->checkUpdateAccess($employee))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        $validator = Validator::make($request->all(), [
            'fname' => 'required',
            'lname' => 'required'

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            
            $employee->update($request->except('phone','email','link','addresse'));
            
            if($profile = $this->base64_upload($request->input('profile'),'employee'))
                $employee->profile = $profile;

            if($request->input('phone') != null && count($request->input('phone'))>0)
            {
                $employee->phones()->delete();

                foreach ($request->input('phone') as $data) 
                {
                        
                        $data['identifier']="employee";
                        if(intval($data['id']) > 0)
                        {
                            if($object = Phone::withTrashed()->find($data['id']))
                            {
                                $object->restore();
                                $object->fill($data);
                            }
                            else
                                $object = new Phone($data);
                        }
                        else
                            $object = new Phone($data);
                        
                        
                        $employee->phones()->save($object);
                        
                        if($data['is_default']==1)
                            $employee->phone = $data['phone_no'];
                }
            }

            if($request->input('email') != null && count($request->input('email'))>0)
            {
                $employee->emails()->delete();

                foreach ($request->input('email') as $data) 
                {
                        
                        $data['identifier']="employee";
                        if(intval($data['id']) > 0)
                        {
                            if($object = Email::withTrashed()->find($data['id']))
                            {
                                $object->restore();
                                $object->fill($data);
                            }
                            else
                                $object = new Email($data);
                        }
                        else
                            $object = new Email($data);
                        
                        
                        $employee->emails()->save($object);
                        
                        if($data['is_default']==1)
                            $employee->email = $data['email'];
                }
            }

            if($request->input('link') != null && count($request->input('link'))>0)
            {
                $employee->links()->delete();

                foreach ($request->input('link') as $data) 
                {
                        
                        $data['identifier']="employee";
                        if(intval($data['id']) > 0)
                        {
                            if($object = Link::withTrashed()->find($data['id']))
                            {
                                $object->restore();
                                $object->fill($data);
                            }
                            else
                                $object = new Link($data);
                        }
                        else
                            $object = new Link($data);
                        
                        
                        $employee->links()->save($object);
                        
                      
                }
            }

            if($request->input('address') != null && count($request->input('address'))>0)
            {
                $employee->address()->delete();

                foreach ($request->input('address') as $data) 
                {
                        
                        $data['identifier']="employee";
                        if(intval($data['id']) > 0)
                        {
                            if($object = Address::withTrashed()->find($data['id']))
                            {
                                $object->restore();
                                $object->fill($data);
                            }
                            else
                                $object = new Address($data);
                        }
                        else
                            $object = new Address($data);
                        
                        
                        $employee->address()->save($object);
                        
                      
                }
            }
            $employee->save();

            DB::commit();
            
            return response(['data' => new EmployeeResource($employee),'success'=>true,'message' => 'Employee Updated Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $employee=Employee::find($id);
        
        if(!$this->checkDeleteAccess($employee))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);
        
        DB::beginTransaction();
        try {
            
            $employee->delete();
            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Employee Deleted Successfully'], 200);
    }

    /**
     * Bulk Action function of footer (pass 6  for delete and 3 for update)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function actionall()
    {
        
        $access = request()->action == 'delete' ? 6 : 3;

        if(!$this->checkBulkAcess( $access))
            return response(['data' => array(),'success'=>false,'message' =>"You Don't Have Access For Bulk Action"], 200);

        DB::beginTransaction();
        
        try {
           
            if($access == 6)
                {
                    Employee::whereIn('id',request()->ids)->get()->each(function($employee) 
                    {
                        $employee->delete();
                    });
                }
            elseif($access == 3)  
                Employee::whereIn('id',request()->ids)->update([request()->column => request()->status]);

            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Updated successfully'], 200);
    }

    /**
     * Assign User to Employee 
     * @param $id, Request $request 
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function assign_user(Request $request,$id)
    {
        $employee = Employee::find($id);
        
        if($employee->user_id > 0)
            return response(['data' => array(),'success'=>false,'message' =>"User Already Assigned"], 403);
        if(!$this->checkUpdateAccess($employee))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        DB::beginTransaction();
        try {
           
            if($request->userid > 0)
            {
                
                if($user = User::find($request->userid))
                {
                   
                    $validator = Validator::make($request->all(), [
                        'name' => 'required',
                        'email' => 'required|email|unique:users,email,'.$user->id,
            
                    ]);
            
                    if ($validator->fails()) {
                        //
                        return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
                    }

                    $user->name = $request->name;
                    
                    $user->email = $request->email;
        
                    if($request->password != $user->password)
                        $user->password = Hash::make($request->password);
                    
                    $user->is_superadmin = $request->is_superadmin==true?1:0;
        
                    if($user->profile != null)
                        $employee->profile = $user->profile;
                    
                    $user->status = $request->status; 
                    $user->type = 'employee';   
                    $user->save();

                    if(isset($request->role_id) && count($request->role_id) > 0)
                    {
                        $user->roles()->detach();
                        $user->roles()->attach($request->role_id,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id]);
                    }
                
                    $employee->user_id = $user->id;
                    $employee->save();
                }
               
            }
            else
            {
                $validator = Validator::make($request->all(), [
                    'name' => 'required',
                    'password' => 'required',
                    'email' => 'required|email|unique:users,email',
        
                ]);
        
                if ($validator->fails()) {
                    //
                    return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
                }
                //echo "new"; exit;
                $user = new User();
                $user->name = $request->name;
                $user->email = $request->email;
                $user->password = Hash::make($request->password);
                $user->is_superadmin = $request->is_superadmin==true?1:0;

                if($employee->profile != null)
                    $user->profile = $employee->profile;
                else
                {
                    if($profile = $this->base64_upload($request->input('image'),'users'))
                    {
                        $user->profile = $profile;
                        $employee->profile = $profile;
                    } 
                }
                
                $user->status = $request->status;
                $user->type = 'employee';
                $user->save();

                $user->roles()->attach($request->role_id,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id]); 

                $employee->user_id = $user->id;
                $employee->save();
            }

            DB::commit();

            return response(['data' => $employee,'success'=>true,'message' => 'Data Retrived Successfully'], 200);

        }catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }    

    }

     /**
     * Update Company Profile of Employee 
     * @param $id, Request $request 
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function company_profile_update(Request $request,$id)
    {
        $employee = Employee::find($id);

        if(!$this->checkUpdateAccess($employee))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        $validator = Validator::make($request->all(), [
            'companyprofile.*.start_date' => 'required',
            'companyprofile.*.manager_id' => 'required'

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }
        DB::beginTransaction();
        try {    

            if($request->input('companyprofile') != null && count($request->input('companyprofile'))>0)
            {
                $employee->companyprofiles()->delete();

                foreach ($request->input('companyprofile') as $data) 
                {
                        
                      
                        if(intval($data['id']) > 0)
                        {
                            if($object = EmployeeCompanyProfile::withTrashed()->find($data['id']))
                            {
                                $object->restore();
                                $object->fill($data);
                            }
                            else
                                $object = new EmployeeCompanyProfile($data);
                        }
                        else
                            $object = new EmployeeCompanyProfile($data);
                        
                        
                        $employee->companyprofiles()->save($object);
                        
                        $employee->manager_id = isset($data['manager_id'])?$data['manager_id']:0; 
                        $employee->hr_manager_id = isset($data['hr_manager_id'])?$data['hr_manager_id']:0; 
                        $employee->branch_id = isset($data['branch_id'])?$data['branch_id']:0;
                        $employee->department_id = isset($data['department_id'])?$data['department_id']:0; 
                        
                        $employee->save();
                     
                }
            }

            DB::commit();

            return response(['data' => $employee,'success'=>true,'message' => 'Data Retrived Successfully'], 200);

        }catch (Exception $ex) {

            
            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }  

    }
    /**
     * Show Company Profile Data of Employee 
     * @param $id, Request $request 
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function fetch_company_profile(Request $request,$id)
    {
        $employee = Employee::with('companyprofiles')->find($id);
        return response(['data' => $employee,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    /**
     * Revoke User Information from Employee  
     * @param $id, Request $request 
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function revoke_user(Request $request,$id)
    {
        $employee = Employee::find($id);
        if(!$this->checkUpdateAccess($employee))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        DB::beginTransaction();
        try {

            if($user = User::find($employee->user_id))
            {
                $user->status = 0;
                $user->save();
            }   

            DB::commit();

            return response(['data' => $employee,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
            
        }catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }    
    }
    /**
     * Fetch Employee Timing Information  
     * @param $id, Request $request 
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function fetch_timing(Request $request,$id)
    {
        $employee = Employee::with('employee_timings')->find($id);
        return response(['data' => $employee,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
        
    }

    /**
     * Fetch Employee Timing Information  
     * @param $id, Request $request 
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function timing_update(Request $request,$id)
    {
        $employee = Employee::find($id);

        if(!$this->checkUpdateAccess($employee))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        DB::beginTransaction();
        try { 
            if($request->input('timing') != null && count($request->input('timing'))>0)
            {
            
                $employee->employee_timings()->delete();

                foreach ($request->input('timing') as $key=>$data) 
                {
                     $data['shift_id']=$request->shift_id;
                     $data['is_overridden']=$request->is_overridden;


                     if($data['type']==1)
                        $data['is_holiday']=1;
                     
                     if(isset($data['week']))
                        $data['week']=json_encode($data['week']);
                                          
                     if(intval($data['id']) > 0)
                        {
                            if($object = EmployeeTiming::withTrashed()->find($data['id']))
                                {
                                    $object->restore();
                                    $object->fill($data);
                                }
                            else
                                $object = new EmployeeTiming($data);
                        }
                     else
                         $object = new EmployeeTiming($data);

                     $employee->employee_timings()->save($object);
                    
                }
            }

            DB::commit();
            return response(['data' => $employee,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
        }catch (Exception $ex) {

            
            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }     
    }
    /**
     * Update Company Profile of Employee 
     * @param $id, Request $request 
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function emergency_details_update(Request $request,$id)
    {
        $employee = Employee::find($id);

        // if(!$this->checkUpdateAccess($employee))
        //     return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        $validator = Validator::make($request->all(), [
            'emergencydetail.*.name' => 'required',
            'emergencydetail.*.phone' => 'required'

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }
        DB::beginTransaction();
        try {    

            if($request->input('emergencydetail') != null && count($request->input('emergencydetail'))>0)
            {
                $employee->emergency_details()->delete();

                foreach ($request->input('emergencydetail') as $data) 
                {
                        
                      
                        if(intval($data['id']) > 0)
                        {
                            if($object = EmployeeEmergencyDetail::withTrashed()->find($data['id']))
                            {
                                $object->restore();
                                $object->fill($data);
                            }
                            else
                                $object = new EmployeeEmergencyDetail($data);
                        }
                        else
                            $object = new EmployeeEmergencyDetail($data);
                        
                        
                        $employee->emergency_details()->save($object);
                        
                       
                        
                        $employee->save();
                     
                }
            }

            DB::commit();

            return response(['data' => $employee->emergency_details,'success'=>true,'message' => 'Data Retrived Successfully'], 200);

        }catch (Exception $ex) {

            
            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }  

    }
     /**
     * Update Qualification of Employee 
     * @param $id, Request $request 
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function qualification_update(Request $request,$id)
    {
        $employee = Employee::find($id);

        // if(!$this->checkUpdateAccess($employee))
        //     return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        $validator = Validator::make($request->all(), [
            'qualification.*.degree' => 'required',
            'qualification.*.college' => 'required'

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }
        DB::beginTransaction();
        try {    

            if($request->input('qualification') != null && count($request->input('qualification'))>0)
            {
                $employee->qualifications()->delete();

                foreach ($request->input('qualification') as $data) 
                {
                        
                      
                        if(intval($data['id']) > 0)
                        {
                            if($object = EmployeeQualification::withTrashed()->find($data['id']))
                            {
                                $object->restore();
                                $object->fill($data);
                            }
                            else
                                $object = new EmployeeQualification($data);
                        }
                        else
                            $object = new EmployeeQualification($data);
                        
                        
                        $employee->qualifications()->save($object);
                        
                       
                        
                        $employee->save();
                     
                }
            }

            DB::commit();

            return response(['data' => $employee->qualifications,'success'=>true,'message' => 'Data Retrived Successfully'], 200);

        }catch (Exception $ex) {

            
            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        } 
    }

    /**
     * Update Bank Details of Employee 
     * @param $id, Request $request 
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function bank_update(Request $request,$id)
    {
        $employee = Employee::find($id);

        // if(!$this->checkUpdateAccess($employee))
        //     return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        $validator = Validator::make($request->all(), [
            'bank.*.account_no' => 'required',
            'bank.*.ifsc_code' => 'required'

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }
        DB::beginTransaction();
        try {    

            if($request->input('bank') != null && count($request->input('bank'))>0)
            {
                $employee->banks()->delete();

                foreach ($request->input('bank') as $data) 
                {
                        
                      
                        if(intval($data['id']) > 0)
                        {
                            if($object = EmployeeBank::withTrashed()->find($data['id']))
                            {
                                $object->restore();
                                $object->fill($data);
                            }
                            else
                                $object = new EmployeeBank($data);
                        }
                        else
                            $object = new EmployeeBank($data);
                        
                        
                        $employee->banks()->save($object);
                        
                       
                        
                        $employee->save();
                     
                }
            }

            DB::commit();

            return response(['data' => $employee->banks,'success'=>true,'message' => 'Data Retrived Successfully'], 200);

        }catch (Exception $ex) {

            
            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        } 
    }

    /**
     * Update Professional Details of Employee 
     * @param $id, Request $request 
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function profession_update(Request $request,$id)
    {
        $employee = Employee::find($id);

        // if(!$this->checkUpdateAccess($employee))
        //     return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        $validator = Validator::make($request->all(), [
            'profession.*.company' => 'required'
        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }
        DB::beginTransaction();
        try {    

            if($request->input('profession') != null && count($request->input('profession'))>0)
            {
                $employee->professions()->delete();

                foreach ($request->input('profession') as $data) 
                {
                        
                      
                        if(intval($data['id']) > 0)
                        {
                            if($object = EmployeeProfession::withTrashed()->find($data['id']))
                            {
                                $object->restore();
                                $object->fill($data);
                            }
                            else
                                $object = new EmployeeProfession($data);
                        }
                        else
                            $object = new EmployeeProfession($data);
                        
                        
                        $employee->professions()->save($object);
                        
                       
                        
                        $employee->save();
                     
                }
            }

            DB::commit();

            return response(['data' => $employee->professions,'success'=>true,'message' => 'Data Retrived Successfully'], 200);

        }catch (Exception $ex) {

            
            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        } 
    }
     /**
     * Fetch Details For Employee View Page
     * @param $id, Request $request 
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2023, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function view(Request $request,$id)
    {
        $employee = Employee::with('emails.email_type','phones.phone_type','links','address.address_type','address.country','address.state','files','emergency_details','qualifications','banks','professions')->find($id);

        return response(['data' => $employee,'success'=>true,'message' => 'Data Retrived Successfully'], 200);

    }
   
}
