<?php

namespace Modules\ResourceManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;

class ShiftTiming extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;

    protected $fillable = ['shift_id','in','out','lunch','grace','is_holiday','max_in','week','type','day'];

    protected $appends = ['display_week'];


    public function getDisplayWeekAttribute()
    {
      return $this->attributes['display_week'] = json_decode($this->attributes['week'],true);
    }
    
   
}
