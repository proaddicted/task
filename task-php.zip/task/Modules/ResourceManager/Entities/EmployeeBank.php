<?php

namespace Modules\ResourceManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;

class EmployeeBank extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait;

    protected $fillable = ['account_type','is_default','account_name','account_no','bank','branch','ifsc_code','upi','remarks','status'];
    
    protected $searchableColumns = ['account_name','account_no','phone'];

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }
}
