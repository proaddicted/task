<?php

namespace Modules\ResourceManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;

class EmployeeCompanyProfile extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait;
    protected $fillable = ['start_date','end_date','emp_id','status','designation_id','department_id','branch_id','manager_id','hr_manager_id','remarks'];
    
    protected $searchableColumns = ['start_date','end_date'];

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }
}
