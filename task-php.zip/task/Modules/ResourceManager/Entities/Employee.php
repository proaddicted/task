<?php

namespace Modules\ResourceManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use App\Models\Phone;
use App\Models\Email;
use App\Models\Link;
use App\Models\Address;
use App\Models\File;
use App\Models\MasterType;
use Modules\ResourceManager\Entities\EmployeeCompanyProfile;
use Modules\ResourceManager\Entities\EmployeeTiming;
use Modules\ResourceManager\Entities\EmployeeEmergencyDetail;
use Modules\ResourceManager\Entities\EmployeeQualification;
use Modules\ResourceManager\Entities\EmployeeBank;
use Modules\ResourceManager\Entities\EmployeeProfession;
use Modules\AttendanceManager\Entities\DailyAttendance;

class Employee extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;

    protected $fillable = ['prefix','fname','lname','mname','status','employee_type_id','dob','phone','email','profile','manager_id','hr_manager_id','branch_id','department_id','user_id'];

    protected $searchableColumns = ['fname','lname','mname','phone','email'];
    
    protected $appends = ['full_name','thumbnail'];

    

    public function emails()
    {
        return $this->hasMany(Email::class,"main_id","id")->where('identifier','employee')->whereNull('deleted_at');
    }
    public function phones()
    {
        return $this->hasMany(Phone::class,"main_id","id")->where('identifier','employee')->whereNull('deleted_at');
    }
    public function links()
    {
        return $this->hasMany(Link::class,"main_id","id")->where('identifier','employee')->whereNull('deleted_at');
    }
    public function files()
    {
        return $this->hasMany(File::class,"main_id","id")->where('identifier','employee')->whereNull('deleted_at');
    }
    public function address()
    {
        return $this->hasMany(Address::class,"main_id","id")->where('identifier','employee')->whereNull('deleted_at');
    }
    public function companyprofiles()
    {
        return $this->hasMany(EmployeeCompanyProfile::class,"emp_id","id")->whereNull('deleted_at')->orderBy('created_at','desc');
    }
    public function emergency_details()
    {
        return $this->hasMany(EmployeeEmergencyDetail::class,"emp_id","id")->whereNull('deleted_at');
    }
    public function qualifications()
    {
        return $this->hasMany(EmployeeQualification::class,"emp_id","id")->whereNull('deleted_at');
    }
    public function banks()
    {
        return $this->hasMany(EmployeeBank::class,"emp_id","id")->whereNull('deleted_at');
    }
    public function professions()
    {
        return $this->hasMany(EmployeeProfession::class,"emp_id","id")->whereNull('deleted_at');
    }
    
    public function employee_timings()
    {
		return $this->hasMany(EmployeeTiming::class,"emp_id","id")->whereNull('deleted_at')->orderBy('day','asc');
    }
    public function employee_type()
    {
        return $this->belongsTo(MasterType::class,'employee_type_id');
    }
    public function daily_attendances()
    {
		return $this->hasMany(DailyAttendance::class,"emp_id","id")->whereNull('deleted_at')->orderBy('date','desc');
    }
    public function getThumbnailAttribute()
    {
       
        if(!empty($this->attributes['profile']))
            return  $this->attributes['thumbnail'] =  env('APP_URL').'storage/'. $this->attributes['profile'];
        else
            return  $this->attributes['thumbnail'] =  null;
    }
    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }
    public function getFullNameAttribute()
    {
        $full_name="";
        $full_name .=empty($this->attributes['prefix'])?'':$this->attributes['prefix'] . ' ';
        $full_name .=empty($this->attributes['fname'])?'':$this->attributes['fname'] . ' ';
        $full_name .=empty($this->attributes['mname'])?'':$this->attributes['mname'] . ' ';
        $full_name .=empty($this->attributes['lname'])?'':$this->attributes['lname'];
        
        return $this->attributes['full_name'] = $full_name ;
    }

    protected static function boot() 
    {
        parent::boot();
        
        self::creating(function($model){
          		            
		
        });

        self::created(function($model){
            
        });

        self::updating(function($model){
            
        });

        self::updated(function($model){
            
        });

        self::deleting(function($model){
           
        });

        self::deleted(function($model){
            $model->phones()->delete();
            $model->emails()->delete();
            $model->links()->delete();
            $model->address()->delete();
            $model->companyprofiles()->delete();
            $model->employee_timings()->delete();
            $model->emergency_details()->delete();
            $model->qualifications()->delete();
            $model->professions()->delete();
        });

       
    }
}
