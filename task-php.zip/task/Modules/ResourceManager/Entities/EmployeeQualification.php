<?php

namespace Modules\ResourceManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;

class EmployeeQualification extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait;

    protected $fillable = ['degree','university','college','start_date','end_date','marks','remarks','status'];
    
    protected $searchableColumns = ['degree','university','college'];

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }
}
