<?php

namespace Modules\ResourceManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Modules\ResourceManager\Entities\ShiftTiming;

class Shift extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;

    protected $fillable = ['name','description','status'];
    protected $searchableColumns = ['name','description'];

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }

    public function shift_timing()
    {
		return $this->hasMany(ShiftTiming::class,"shift_id","id")->whereNull('deleted_at')->orderBy('day','asc');
    }


    protected static function boot() 
    {
        parent::boot();
        
        self::creating(function($model){
          		            
		
        });

        self::created(function($model){
            
        });

        self::updating(function($model){
            
        });

        self::updated(function($model){
            
        });

        self::deleting(function($model){
           
        });

        self::deleted(function($model){
            $model->shift_timing()->delete();
        });

       
    }
   
}
