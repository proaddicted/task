<?php

return [
    'name' => 'ResourceManager'
];
