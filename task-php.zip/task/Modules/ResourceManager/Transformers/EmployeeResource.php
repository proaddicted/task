<?php

namespace Modules\ResourceManager\Transformers;

use Illuminate\Http\Resources\Json\JsonResource;

class EmployeeResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request
     * @return array
     */
    public function toArray($request)
    {
        $main = parent::toArray($request);
        return array_merge($main,['emails'=>$this->emails,'phones'=>$this->phones,'address'=>$this->address,'links'=>$this->links]);
    }
}
