<?php

namespace Modules\ResourceManager\Transformers;

use Illuminate\Http\Resources\Json\JsonResource;

class ShiftResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request
     * @return array
     */
    public function toArray($request)
    {
        $main = parent::toArray($request);
        return array_merge($main,['shift_timing'=>$this->shift_timing]);
    }
}
