<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEmployeeTimingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('employee_timings', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('master_id')->nullable();
            $table->unsignedBigInteger('shift_id')->nullable();
            $table->unsignedBigInteger('emp_id')->nullable();
            $table->tinyInteger('is_overriden')->default(0);
            $table->string('in')->nullable();
            $table->string('out')->nullable();
            $table->string('lunch')->nullable();
            $table->string('grace')->nullable()->default(0);
            $table->tinyInteger('day')->default(0);
            $table->tinyInteger('type')->default(0);
            $table->tinyInteger('is_holiday')->default(0);
            $table->text('week')->nullable();
            $table->softDeletes();
            $table->timestamps();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->unsignedBigInteger('deleted_by')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('employee_timings');
    }
}
