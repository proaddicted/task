<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:api')->get('/resourcemanager', function (Request $request) {
//     return $request->user();
// });
Route::middleware(['auth:api','masterauth'])->group(function () {

    Route::resource('salary_head',SalaryHeadController::class);
    Route::get('salary_head_headers',[Modules\ResourceManager\Http\Controllers\SalaryHeadController::class,'headers']);
    Route::any('salary_head_actionall',[Modules\ResourceManager\Http\Controllers\SalaryHeadController::class,'actionall']);


    Route::resource('department',DepartmentController::class);
    Route::any('department_getlist',[Modules\ResourceManager\Http\Controllers\DepartmentController::class,'getlist']);
    Route::any('department_headers',[Modules\ResourceManager\Http\Controllers\DepartmentController::class,'headers']);
    Route::any('department_actionall',[Modules\ResourceManager\Http\Controllers\DepartmentController::class,'actionall']);


    Route::resource('designation',DesignationController::class);
    Route::get('designation_getlist',[Modules\ResourceManager\Http\Controllers\DesignationController::class,'getlist']);
    Route::get('designation_headers',[Modules\ResourceManager\Http\Controllers\DesignationController::class,'headers']);
    Route::any('designation_actionall',[Modules\ResourceManager\Http\Controllers\DesignationController::class,'actionall']);

    Route::resource('shift',ShiftController::class);
    Route::get('shift_headers',[Modules\ResourceManager\Http\Controllers\ShiftController::class,'headers']);
    Route::any('shift_actionall',[Modules\ResourceManager\Http\Controllers\ShiftController::class,'actionall']);

    Route::resource('employee',EmployeeController::class);
    Route::get('employee_getlist',[Modules\ResourceManager\Http\Controllers\EmployeeController::class,'getlist']);
    Route::get('employee_headers',[Modules\ResourceManager\Http\Controllers\EmployeeController::class,'headers']);
    Route::any('employee_actionall',[Modules\ResourceManager\Http\Controllers\EmployeeController::class,'actionall']);
    Route::any('employee_assign_user/{id}/',[Modules\ResourceManager\Http\Controllers\EmployeeController::class,'assign_user']);
    Route::any('employee_company_profile_update/{id}/',[Modules\ResourceManager\Http\Controllers\EmployeeController::class,'company_profile_update']);
    Route::get('employee_fetch_company_profile/{id}/',[Modules\ResourceManager\Http\Controllers\EmployeeController::class,'fetch_company_profile']);
    Route::any('employee_revoke_user/{id}/',[Modules\ResourceManager\Http\Controllers\EmployeeController::class,'revoke_user']);
    Route::any('employee_timing_update/{id}/',[Modules\ResourceManager\Http\Controllers\EmployeeController::class,'timing_update']);
    Route::get('employee_fetch_timing/{id}/',[Modules\ResourceManager\Http\Controllers\EmployeeController::class,'fetch_timing']);
    Route::get('employee_view/{id}/',[Modules\ResourceManager\Http\Controllers\EmployeeController::class,'view']);
    Route::any('employee_emergency_details_update/{id}/',[Modules\ResourceManager\Http\Controllers\EmployeeController::class,'emergency_details_update']);
    Route::any('employee_qualification_update/{id}/',[Modules\ResourceManager\Http\Controllers\EmployeeController::class,'qualification_update']);
    Route::any('employee_bank_update/{id}/',[Modules\ResourceManager\Http\Controllers\EmployeeController::class,'bank_update']);
    Route::any('employee_profession_update/{id}/',[Modules\ResourceManager\Http\Controllers\EmployeeController::class,'profession_update']);
    
    
    
});    