<?php

namespace Modules\LeaveManager\Transformers;

use Illuminate\Http\Resources\Json\JsonResource;

class LeaveApplicationResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request
     * @return array
     */
    public function toArray($request)
    {
        $main = parent::toArray($request);
        return array_merge($main,['files'=>$this->files,'employees'=>$this->employees,'leave_types'=>$this->leave_types,'assignEmployees'=>$this->assignEmployees]);
    }
}
