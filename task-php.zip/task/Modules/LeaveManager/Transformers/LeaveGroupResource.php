<?php

namespace Modules\LeaveManager\Transformers;

use Illuminate\Http\Resources\Json\JsonResource;

class LeaveGroupResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request
     * @return array
     */
    public function toArray($request)
    {
        $main = parent::toArray($request);

        return array_merge($main,['employees'=>$this->employees,'leave_group_elements'=>$this->leave_group_elements]);
    }
}
