<?php

use Illuminate\Http\Request;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:api')->get('/leavemanager', function (Request $request) {
//     return $request->user();
// });
Route::any('store_all_leaves',[Modules\LeaveManager\Http\Controllers\LeaveApplicationController::class,'store_all_leaves']);

Route::middleware(['auth:api','masterauth'])->group(function () {
    Route::resource('leave_types',LeaveTypeController::class);
    Route::get('leave_types_headers',[Modules\LeaveManager\Http\Controllers\LeaveTypeController::class,'headers']);
    Route::any('leave_types_actionall',[Modules\LeaveManager\Http\Controllers\LeaveTypeController::class,'actionall']);

    Route::resource('leave_group',LeaveGroupController::class);
    Route::get('leave_group_getlist',[Modules\LeaveManager\Http\Controllers\LeaveGroupController::class,'getlist']);
    Route::get('leave_group_headers',[Modules\LeaveManager\Http\Controllers\LeaveGroupController::class,'headers']);
    Route::any('leave_group_actionall',[Modules\LeaveManager\Http\Controllers\LeaveGroupController::class,'actionall']);

    Route::resource('leave_location',LeaveLocationController::class);
    Route::get('leave_location_getlist',[Modules\LeaveManager\Http\Controllers\LeaveLocationController::class,'getlist']);
    Route::get('leave_location_headers',[Modules\LeaveManager\Http\Controllers\LeaveLocationController::class,'headers']);
    Route::any('leave_location_actionall',[Modules\LeaveManager\Http\Controllers\LeaveLocationController::class,'actionall']);

    Route::resource('leave_application',LeaveApplicationController::class);
    Route::get('leave_application_getlist',[Modules\LeaveManager\Http\Controllers\LeaveApplicationController::class,'getlist']);
    Route::get('leave_application_headers',[Modules\LeaveManager\Http\Controllers\LeaveApplicationController::class,'headers']);
    Route::any('leave_application_actionall',[Modules\LeaveManager\Http\Controllers\LeaveApplicationController::class,'actionall']);
    Route::any('get_leavetypes_by_employee/{id}/',[Modules\LeaveManager\Http\Controllers\LeaveApplicationController::class,'get_leavetypes_by_employee']);
    Route::any('leave_application_status_change_logs/{id}/',[Modules\LeaveManager\Http\Controllers\LeaveApplicationController::class,'change_log']);
    Route::get('leave_application_view/{id}/',[Modules\LeaveManager\Http\Controllers\LeaveApplicationController::class,'view']);
    Route::any('leave_application_excel_export',[Modules\LeaveManager\Http\Controllers\LeaveApplicationController::class,'export']);

}); 