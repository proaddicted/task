<?php

namespace Modules\LeaveManager\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;
use Modules\LeaveManager\Entities\LeaveGroup;
use Modules\LeaveManager\Entities\LeaveGroupElement;
use App\Models\MasterType;
use Modules\LeaveManager\Entities\LeaveType;
use Modules\LeaveManager\Transformers\LeaveGroupResource;
use Modules\ResourceManager\Entities\Employee;
use App\Traits\EmployeeTrait;
use App\Models\User;


class LeaveGroupController extends Controller
{
    use PermissionTrait,CommonTrait,EmployeeTrait;

    public function getlist()
    {

        $data['employees'] = User::whereRaw(' id not in (select user_id from leave_group_users where deleted_at is null)')->select('id','name','profile')->get();
        $data['leave_types'] = LeaveType::where('status',1)->select('id','name')->get();

        $data['frequency']= $this->frequency;
        $data['lapse_or_paid']= $this->lapse_or_paid;
        $data['carry_forward']= $this->carry_forward;

        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    public function headers()
    {
        $headers = array(
           
            array('column_name'=>'name','display_name'=>'Name','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'employees','display_name'=>'Employees','is_display'=>1,'is_default'=>1,'is_sortable'=>1,'multi_employee'=>1),
            array('column_name'=>'leave_group_elements','display_name'=>'Leave Types','is_display'=>1,'is_default'=>1,'is_sortable'=>0,'is_multiple'=>1,'child_column'=>'name'),
            array('column_name'=>'creator','display_name'=>'Created By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
            array('column_name'=>'editor','display_name'=>'Updated By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
            array('column_name'=>'updated_at','display_name'=>'Updated On','is_display'=>1,'is_default'=>1,'is_sortable'=>1), 
            array('column_name'=>'created_at','display_name'=>'Added On','is_display'=>1,'is_default'=>0,'is_sortable'=>1)          );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    
    public function index(Request $request)
    {
        $query = QueryBuilder::for(LeaveGroup::class)->allowedFilters(['name'])->defaultSort('name')->allowedSorts('name','updated_at');

        $query->search(!empty($request->search)?$request->search:"");

        $leave_group = $query->with('employees','leave_group_elements','creator','editor')->advanceSearch($request->advfilter,'leave_groups')->checkPermission('created_by')->paginate($request->per_page);

        $this->saveAdvanceSearchData($request);

        return response(['data' => $leave_group,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    
    public function create()
    {
        //
    }

    
    public function store(Request $request)
    {
        if(!$this->checkStoreAccess())
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403); 

        $validator = Validator::make($request->all(), [
            'name' => 'required',
        ]);

        if ($validator->fails()) {
            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            $leave_group = LeaveGroup::create($request->except('leave_group_elements', 'employees'));

            $leave_group->leave_group_elements()->attach($request->leave_group_elements,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);

            $leave_group->employees()->detach();

            if($request->input('employee_id') && count($request->input('employee_id')) > 0)
            {
                $employee_id = [];
                foreach ($request->input('employee_id') as $key => $value) 
                {
                    if($emp = Employee::where('user_id',$value)->first())
                        $employee_id[$key] = ['user_id'=>$value,'main_id'=>$emp->id];
                    else
                        $employee_id[$key] = ['user_id'=>$value,'main_id'=>0];
                }
                $leave_group->employees()->attach($request->input('employee_id'),['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
            }
            
            DB::commit();
            return response(['data' => new LeaveGroupResource($leave_group),'success'=>true,'message' => 'Leave Groups Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    
    public function show($id)
    {
        return response(['data' =>new LeaveGroupResource(LeaveGroup::findOrFail($id)),'success'=>true,'message' => 'Leave Groups Retrived Successfully'], 200);
    }

    
    public function edit($id)
    {
        // return view('leavemanager::edit');
    }

    
    public function update(Request $request, $id)
    {
        $leave_group=LeaveGroup::find($id);
        
        if(!$this->checkUpdateAccess($leave_group))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        $validator = Validator::make($request->all(), [
            'name' => 'required'

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            
            $leave_group->update($request->except('leave_group_elements','employees'));

            if(isset($request->leave_group_elements) && count($request->leave_group_elements) > 0)
            {
                $leave_group->leave_group_elements()->detach();
            
                $leave_group->leave_group_elements()->attach($request->leave_group_elements,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);
            }

            if($request->input('employee_id') && count($request->input('employee_id')) > 0)
            {
                $leave_group->employees()->detach();
                $employee_id = [];
                foreach ($request->input('employee_id') as $key => $value)
                {
                    if($emp = Employee::where('user_id',$value)->first())
                        $employee_id[$key] = ['user_id'=>$value,'main_id'=>$emp->id];
                    else
                        $employee_id[$key] = ['user_id'=>$value,'main_id'=>0];
                }
                $leave_group->employees()->attach($request->input('employee_id'),['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);
            }
            
            DB::commit();
            
            return response(['data' => new LeaveGroupResource($leave_group),'success'=>true,'message' => 'Leave Groups Updated Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    
    public function destroy($id)
    {
        $leave_group=LeaveGroup::find($id);
        
        if(!$this->checkDeleteAccess($leave_group))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);
        
        DB::beginTransaction();
        try {
            
            $leave_group->delete();
            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Leave Groups Deleted Successfully'], 200);
    
    }

    public function actionall()
    {
        
        $access = request()->action == 'delete' ? 6 : 3;

        if(!$this->checkBulkAcess( $access))
            return response(['data' => array(),'success'=>false,'message' =>"You Don't Have Access For Bulk Action"], 200);

        DB::beginTransaction();
        
        try {
           
            if($access == 6 && request()->action == 'delete')
            {
                LeaveGroup::whereIn('id',request()->ids)->get()->each(function($leave_group) 
                {
                    $leave_group->delete();
                });
            }
            elseif($access == 3 && request()->action == 'update')  
                LeaveGroup::whereIn('id',request()->ids)->update([request()->column => request()->status]);
            elseif($access == 3 && request()->action == 'assign-employee')
            {
                LeaveGroup::whereIn('id',request()->ids)->get()->each(function($leave_group)
                {
                    $leave_group->emp_id = request()->emp_id;
                    $leave_group->save();
                });
            }      

            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Updated successfully'], 200);
    }
}
