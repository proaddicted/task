<?php

namespace Modules\LeaveManager\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;
use Modules\LeaveManager\Entities\LeaveLocation;
use Modules\LeaveManager\Entities\LeaveLocationElement;
use App\Models\MasterType;
use App\Models\Branch;
use Modules\LeaveManager\Entities\LeaveType;
use Modules\LeaveManager\Transformers\LeaveLocationResource;

class LeaveLocationController extends Controller
{
    use PermissionTrait,CommonTrait;

    public function getlist()
    {
        $data['branches'] = Branch::where('status',1)->select('id','name')->get();
        $data['leave_types'] = LeaveType::where('status',1)->select('id','name')->get();

        $data['frequency']= $this->frequency;
        $data['lapse_or_paid']= $this->lapse_or_paid;
        $data['carry_forward']= $this->carry_forward;

        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    public function headers()
    {
        $headers = array(
           
            array('column_name'=>'branch','display_name'=>'Location','is_display'=>1,'is_default'=>1,'is_sortable'=>0 , 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'),
            array('column_name'=>'leave_location_elements','display_name'=>'Leave Types','is_display'=>1,'is_default'=>1,'is_sortable'=>0,'is_multiple'=>1,'child_column'=>'name'),
            array('column_name'=>'creator','display_name'=>'Created By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
            array('column_name'=>'editor','display_name'=>'Updated By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
            array('column_name'=>'updated_at','display_name'=>'Updated On','is_display'=>1,'is_default'=>1,'is_sortable'=>1), 
            array('column_name'=>'created_at','display_name'=>'Added On','is_display'=>1,'is_default'=>0,'is_sortable'=>1)          );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    public function index(Request $request)
    {
        $query = QueryBuilder::for(LeaveLocation::class)->allowedFilters(['branch_id'])->defaultSort('branch_id')->allowedSorts('branch','updated_at');

        $query->search(!empty($request->search)?$request->search:"");

        $leave_location = $query->with('branch','leave_location_elements','creator','editor')->advanceSearch($request->advfilter,'leave_locations')->checkPermission('created_by')->paginate($request->per_page);

        $this->saveAdvanceSearchData($request);

        return response(['data' => $leave_location,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    
    public function create()
    {
        //
    }

    
    public function store(Request $request)
    {
        if(!$this->checkStoreAccess())
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403); 

        $validator = Validator::make($request->all(), [
            'branch_id' => 'required'
        ]);

        if ($validator->fails()) {
            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            $leave_location = LeaveLocation::create($request->except('leave_location_elements'));

            $leave_location->leave_location_elements()->attach($request->leave_location_elements,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);
            
            DB::commit();
            return response(['data' => new LeaveLocationResource($leave_location),'success'=>true,'message' => 'Leave Locations Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

   
    public function show($id)
    {
        return response(['data' =>new LeaveLocationResource(LeaveLocation::findOrFail($id)),'success'=>true,'message' => 'Leave Locations Retrived Successfully'], 200);
    }

   
    public function edit($id)
    {
        // return view('leavemanager::edit');
    }


    public function update(Request $request, $id)
    {
        $leave_location=LeaveLocation::find($id);
        
        if(!$this->checkUpdateAccess($leave_location))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        $validator = Validator::make($request->all(), [
            'branch_id' => 'required'

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            
            $leave_location->update($request->except('leave_location_elements'));            

            if(isset($request->leave_location_elements) && count($request->leave_location_elements) > 0)
            {
                $leave_location->leave_location_elements()->detach();
            
                $leave_location->leave_location_elements()->attach($request->leave_location_elements,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
            }

            DB::commit();
            
            return response(['data' => new LeaveLocationResource($leave_location),'success'=>true,'message' => 'Leave Locations Updated Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }


    public function destroy($id)
    {
        $leave_location=LeaveLocation::find($id);
        
        if(!$this->checkDeleteAccess($leave_location))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);
        
        DB::beginTransaction();
        try {
            
            $leave_location->delete();
            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Leave Locations Deleted Successfully'], 200);
    
    }

    public function actionall()
    {
        
        $access = request()->action == 'delete' ? 6 : 3;

        if(!$this->checkBulkAcess( $access))
            return response(['data' => array(),'success'=>false,'message' =>"You Don't Have Access For Bulk Action"], 200);

        DB::beginTransaction();
        
        try {
           
            if($access == 6 && request()->action == 'delete')
            {
                LeaveLocation::whereIn('id',request()->ids)->get()->each(function($leave_location) 
                {
                    $leave_location->delete();
                });
            }
            elseif($access == 3 && request()->action == 'update')  
                LeaveLocation::whereIn('id',request()->ids)->update([request()->column => request()->status]);
            elseif($access == 3 && request()->action == 'assign-employee')
            {
                LeaveLocation::whereIn('id',request()->ids)->get()->each(function($leave_location)
                {
                    $leave_location->emp_id = request()->emp_id;
                    $leave_location->save();
                });
            }      

            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Updated successfully'], 200);
    }
}
