<?php

namespace Modules\LeaveManager\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Exception;
use Carbon\Carbon;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;
use Modules\LeaveManager\Entities\LeaveType;
use Modules\LeaveManager\Entities\LeaveGroup;
use Modules\ResourceManager\Entities\Employee;
use Modules\LeaveManager\Entities\LeaveApplication;
use Modules\LeaveManager\Entities\LeaveApplicationStatusChangeLog;
use Modules\LeaveManager\Transformers\LeaveApplicationResource;
use App\Models\TempFile;
use App\Models\File;
use App\Traits\EmployeeTrait;
use App\Models\User;
use Modules\AttendanceManager\Entities\Holiday;
use App\Models\MasterType;
use Illuminate\Support\Facades\Notification;  //19/07/2024 Jyoti
use Illuminate\Support\Facades\Mail;          //19/07/2024 Jyoti
use App\Mail\MailChimp;                       //19/07/2024 Jyoti
use App\Models\NotificationLog;               //19/07/2024 Jyoti
use App\Models\NotificationTemplate;          //19/07/2024 Jyoti
use App\Notifications\SendNotification;       //19/07/2024 Jyoti
use Modules\TaskManager\Entities\Task;        //19/07/2024 Jyoti

use App\Exports\LeaveApplicationExcel;   // 05-09-2024 Jyoti    
use Maatwebsite\Excel\Facades\Excel;     // 05-09-2024 Jyoti



class LeaveApplicationController extends Controller
{
    use PermissionTrait,CommonTrait,EmployeeTrait;       //19/07/2024 Jyoti
    public $notification_batch_id=0,$template_body='';   //19/07/2024 Jyoti
    
    public function getlist()
    {
        $user = Auth::user();
        if($user->is_superadmin == 0)
        {
            $employee_info = $this->employee_info($user);
            $data['employees'] = User::where('type','employee')->whereIn('id',$employee_info->hierarchy_users)->select('id','name','profile')->get();
        } 
        else
        {
            $data['employees'] = User::where('type','employee')->select('id','name','profile')->get();
        }   
        $data['all_employees'] = User::where('type','employee')->select('id','name','profile')->get();
        $data['leave_types'] = LeaveType::select('id','name')->where('status',1)->get();
        $data['is_paid_nonpaid']= $this->is_paid_nonpaid;
        $data['statuses'] = $this->leave_application_status;
        $data['holidays'] = Holiday::where('status',1)->get();
        $data['master_types'] = MasterType::where('status',1)->whereIn('identifier',['employee','leave_type','file-stage','file-source','file-source-1','file-source-2','file-source-3'])->select('id','name','identifier')->get();
        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    public function headers()
    {
        $headers = array(
            array('column_name'=>'employees','display_name'=>'Name','is_display'=>1,'is_default'=>1,'is_sortable'=>0, 'is_multiple'=>1,'is_belongs'=>1,'child_column'=>'name'),
            array('column_name'=>'leave_type','display_name'=>'Leave Type','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'),
            array('column_name'=>'start_date','display_name'=>'Start Date','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'end_date','display_name'=>'End Date','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'no_of_days','display_name'=>'No Of Days','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'is_halfday','display_name'=>'Half Day','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'assign_employees','display_name'=>'Assign Employees','is_display'=>1,'is_default'=>1,'is_sortable'=>0,'is_multiple'=>1,'child_column'=>'name', 'multi_employee'=>1),
            array('column_name'=>'status_name','display_name'=>'Status','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'paid_nonpaid_name','display_name'=>'Paid/NonPaid','is_display'=>1,'is_default'=>1,'is_sortable'=>1, 'is_multiple'=>0,'is_belongs'=>0),
            array('column_name'=>'creator','display_name'=>'Created By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
            array('column_name'=>'editor','display_name'=>'Updated By','is_display'=>1,'is_default'=>0,'is_sortable'=>0, 'is_multiple'=>0,'is_belongs'=>1,'child_column'=>'name'), 
            array('column_name'=>'updated_at','display_name'=>'Updated On','is_display'=>1,'is_default'=>1,'is_sortable'=>1), 
            array('column_name'=>'created_at','display_name'=>'Added On','is_display'=>1,'is_default'=>0,'is_sortable'=>1)  
        );
        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    

    //  05-09-2024 Jyoti
    public function export(Request $request)
    {
        // dd($request->search);
        parse_str($request->filter, $output); 
        $result = ['per_page' => $request->per_page, 'page' => $request->page, 'search' => $request->search, 'sort' => $request->sort, 'filter' => isset($output['filter'])?$output['filter']:[], 'advfilter' => isset($output['advfilter'])?$output['advfilter']:[], 'page_url' =>$request->page_url];
        
        $excel_name='LeaveApplication';
            $headings=[
                'Employee Name',
                'Leave Type',
                'Start Date', 
                'End Date', 
                'No of Days',
                'Half Day',
                'Assign Emoloyees', 
                'Description',
                'Status',
                'Created At',
                'Updated At',
                'Added By',
                'Updated By' 

            ];
            
        $saved_excel_name=$excel_name.'_'.date('d-m-Y H_i_s').'.xlsx';

        $save_file=Excel::store(new LeaveApplicationExcel($result,$headings),$saved_excel_name);

        if($save_file && file_exists(storage_path('/app/'.$saved_excel_name)))
        {
            $file = storage_path('/app/'.$saved_excel_name);
            return  response()->file($file);
        }
        else
            return response(['data' => array(),'success'=>false,'message' => "Invalid File Path"], 500);   
    }
    // 05-09-2024 Jyoti
    
    public function index(Request $request)
    {
        $query = QueryBuilder::for(LeaveApplication::class)->allowedFilters(['leave_type_id','description',AllowedFilter::exact('employee_id')->ignore(null),AllowedFilter::exact('user_type_id')->ignore(null)])->defaultSort('leave_type_id')->allowedSorts('name','leave_type','is_halfday','status_name','start_date','end_date','description','updated_by','created_by','updated_at','created_at');
        $query->search(!empty($request->search)?$request->search:"");
        $leave_applications = $query->with('employees','assignEmployees','leave_type','files','statusChangeLogs.editor','creator','editor')->advanceSearch($request->advfilter,'leave_applications')->leaveCheckPermission()->paginate($request->per_page);
        $this->saveAdvanceSearchData($request);
        return response(['data' => $leave_applications,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    
    public function create()
    {  
        //
    }

    public function store(Request $request)
    {
        $not=DB::table('notifications')->max('batch_id');
        $this->notification_batch_id=$not+1;
        if(!$this->checkStoreAccess())
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403); 
        $validator = Validator::make($request->all(), [
            'leave_type_id' => 'required',
            'start_date' => 'required',
            'end_date' => 'required',
            'no_of_days' => 'required',
            'description' => 'required'
        ]);
        if ($validator->fails()) {
            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }
        DB::beginTransaction();
        try {
            $leave_application = LeaveApplication::create($request->except('assignEmployees'));
            $leave_application->is_halfday = $request->is_halfday==true?1:0;

            if($request->is_halfday>0 && $request->first_second_half>0)
                $leave_application->is_halfday = $request->first_second_half;

            $leave_application->save();
            if($request->input('files') && count($request->input('files')) > 0)
            {
                foreach ($request->input('files') as $data) 
                { 
                    $data['identifier']=isset($data['identifier'])?$data['identifier']:"leave_application";
                    if(intval($data['id']) > 0 || intval($data['temp_id']) > 0)
                    {
                        if($object = File::withTrashed()->find($data['id']))
                        {
                            $object->restore();
                            $object->fill($data);
                        }
                        else
                        {
                            if($tempobject = TempFile::find($data['temp_id']))
                            {
                                $object = new File($data);
                            }
                        }  
                        $leave_application->files()->save($object);
                    }
                }
            }
            $leave_application->assignEmployees()->detach();
            if($request->input('assignEmployee_id') && count($request->input('assignEmployee_id')) > 0)
            {
                $leave_application->assignEmployees()->attach($request->input('assignEmployee_id'),['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]); 
            }
            //22/07/2024 Jyoti
            $url = env('APP_FRONT_URL');
            $leave_application_url = '<p><a style="text-decoration: none;" target="_blank" href="'.$url.'apps/leave-manager/leave-application/leave-application-view/'.$leave_application->id.'" rel="noopener">Click here to task details</a></p>';
            //22/07/2024 Jyoti

            $employee_id = $request->employee_id;
            $tasks = Task::whereHas('employees', function ($q) use ($employee_id){
                $q->where('task_users.user_id',$employee_id);
            })->with('services','contacts','companies','employees','files','supervisor')->whereBetween('start_date',[$request->start_date,$request->end_date])->whereIn('type',['meeting','call','todo','crd','help-ticket','regular-ticket','department-task'])->where('status',0)->get()->toArray();

            // $task_list ='';
            // $task_list .= '<table class="font-family: arial; sans-serif; border-collapse: collapse; width: 100%;">';
            // $task_list .= '<tbody>';
            //                 foreach($tasks as $key => $task)
            //                     {
            // $task_list .= '<tr class=" border: 1px solid #dddddd; text-align: left; padding: 8px;">';
            //                         foreach($task['companies'] as $key => $company){
            //                             $task_list .= '<td>'.$company['fname'].'</td>';
            //                         }
            //                         $task_list .= '<td>'.$task['type'].'</td>';
            //                         $task_list .= '<td>'.$task['start_date'].'</td>';
            //                         $task_list .= '<td>'.$task['due_date'].'</td>';
            //                         $task_list .= '<td>'.$task['description'].'</td>';
            //                         foreach($task['employees'] as $key => $employee){
            //                             $task_list .= '<td>'.$employee['name'].'</td>';
            //                         }
            // $task_list .= ' </tr> ';
            // }
            // $task_list .= '</tbody>
            //                 </table>';
            // echo  $task_list; exit;
            
            //19/07/2024 Jyoti
            if($template = NotificationTemplate::where('name','leave-application-notification-assign-task')->where('status',1)->first())
            {
                $user=User::find($request->employee_id);
                $requestee=User::find($leave_application->created_by);
                $notification_data['template'] = $template;
                $notification_data['name'] = $leave_application->name;
                $notification_data['host'] =isset($user->name)?$user->name:'';
                $notification_data['agenda'] = $leave_application->description;
                $notification_data['type_name'] = $leave_application->leave_type->name;
                $notification_data['requestee_name'] = isset($requestee->name)?$requestee->name:'';
                $notification_data['start_date'] = date('d/m/Y H:i A',strtotime($leave_application->start_date));
                $notification_data['end_date'] = date('d/m/Y H:i A',strtotime($leave_application->end_date));
                $notification_data['leave_application_url'] = $leave_application_url; //22/07/2024 Jyoti
                // $notification_data['task_list'] = $task_list;

                $assignEmployee_id=[];
                if($request->assignEmployee_id!=null && count($request->assignEmployee_id)>0){
                    foreach($request->assignEmployee_id as $key => $assinEmp){
                        if(isset($assinEmp))
                        {
                            $getassinEmp=User::find($assinEmp);
                            if($getassinEmp!=null)
                                $assignEmployee_id[]=array('email'=>$getassinEmp->email,'name'=>$getassinEmp->name,'mail_type'=>'to');
                        }
                        Notification::send($getassinEmp, new SendNotification($notification_data,$leave_application,$assignEmployee_id,$request->type,$this->notification_batch_id));
                        if(isset($notification_data['template']) && isset($notification_data['template']['email_body']))
                        $this->template_body=$notification_data['template']['email_body'];
                    }
                    $this->sendMailFunc($this->notification_batch_id,$this->template_body,$leave_application->id);
                }
                $taskEmployeesId = [];
                foreach($tasks as $key => $task)
                {
                    foreach($task['employees'] as $key => $employee){
                        $taskEmployees_id = $employee['id'];
                        if(isset($taskEmployees_id))
                        {
                            $getTaskEmp=User::find($taskEmployees_id);
                            if($getTaskEmp!=null)
                                $taskEmployeesId[]=array('email'=>$getTaskEmp->email,'name'=>$getTaskEmp->name,'mail_type'=>'to');
                        }
                        Notification::send($getTaskEmp, new SendNotification($notification_data,$leave_application,$taskEmployeesId,$request->type,$this->notification_batch_id));
                        if(isset($notification_data['template']) && isset($notification_data['template']['email_body']))
                        $this->template_body=$notification_data['template']['email_body'];
                    }
                    $this->sendMailFunc($this->notification_batch_id,$this->template_body,$leave_application->id);
                }
            }
            if($template = NotificationTemplate::where('name','leave-application-notification-manager')->where('status',1)->first())
            {
                $user=User::find($request->employee_id);
                $requestee=User::find($leave_application->created_by);
                $notification_data['template'] = $template;
                $notification_data['name'] = $leave_application->name;
                $notification_data['host'] =isset($user->name)?$user->name:'';
                $notification_data['agenda'] = $leave_application->description;
                $notification_data['type_name'] = $leave_application->leave_type->name;
                $notification_data['requestee_name'] = isset($requestee->name)?$requestee->name:'';
                $notification_data['start_date'] = date('d/m/Y H:i A',strtotime($leave_application->start_date));
                $notification_data['end_date'] = date('d/m/Y H:i A',strtotime($leave_application->end_date));
                $hierarchy_info = Employee::where('user_id',$user->id)->select('id','manager_id', 'hr_manager_id')->first();
                $hierarchy_id=[];
                if(isset($hierarchy_info->id))
                {
                    $company_profile_users=[$hierarchy_info->manager_id,$hierarchy_info->hr_manager_id];
                    if(count($company_profile_users))
                    {
                        foreach(array_unique($company_profile_users) as $key => $hierarchy){
                            if(intval($hierarchy)>0)
                            {
                                $gethierarchy=User::find($hierarchy);
                                if($gethierarchy)
                                {
                                    $hierarchy_id[]=array('email'=>$gethierarchy->email,'name'=>$gethierarchy->name,'mail_type'=>'to');
                                   
                                    Notification::send($gethierarchy, new SendNotification($notification_data,$leave_application,$hierarchy_id,$request->type,$this->notification_batch_id));
                                    if(isset($notification_data['template']) && isset($notification_data['template']['email_body']))
                                    $this->template_body=$notification_data['template']['email_body'];
                                }
                            }
                        }
                        $this->sendMailFunc($this->notification_batch_id,$this->template_body,$leave_application->id);
                    }
                }
            }
            //19/07/2024 Jyoti
            DB::commit();
            return response(['data' => new LeaveApplicationResource($leave_application),'success'=>true,'message' => 'Leave Application Created Successfully'], 200);
        }
        catch (Exception $ex) {
            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    //19/07/2024 Jyoti
    public function sendMailFunc($batch_id,$template_body,$leave_application_id)
    {
       /* $notifications=NotificationLog::where('batch_id',$this->notification_batch_id)->where('status',0)->get()->toArray();
        if(count($notifications)>0)
         Mail::send(new MailChimp($notifications,$template_body,$leave_application_id,'leave',User::find(Auth::user()->id)));*/
    }
    //19/07/2024 Jyoti
    
    public function show($id)
    {
        return response(['data' =>new LeaveApplicationResource(LeaveApplication::findOrFail($id)),'success'=>true,'message' => 'Leave Aplication Retrived Successfully'], 200);
    }
    
    public function edit($id)
    {    
        //
    }
    
    public function update(Request $request, $id)
    {
        $leave_application=LeaveApplication::find($id);
        if(!$this->checkUpdateAccess($leave_application))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);
        $validator = Validator::make($request->all(), [
            'leave_type_id' => 'required',
            'start_date' => 'required',
            'end_date' => 'required',
            'no_of_days' => 'required',
            'description' => 'required'
        ]);
        if ($validator->fails()) {
            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }
        DB::beginTransaction();
        try {
            $leave_application->update($request->except('assignEmployees'));
            $leave_application->is_halfday = $request->is_halfday==true?1:0;
            $leave_application->save();
            if($request->input('files') && count($request->input('files')) > 0)
            {
                foreach ($request->input('files') as $data) 
                {                    
                    $data['identifier']=isset($data['identifier'])?$data['identifier']:"leave_application";
                    if(intval($data['id']) > 0 || intval($data['temp_id']) > 0)
                    {
                        if($object = File::withTrashed()->find($data['id']))
                        {
                            $object->restore();
                            $object->fill($data);
                        }
                        else
                        {
                            if($tempobject = TempFile::find($data['temp_id']))
                            {
                                
                                $object = new File($data);
                            }
                        }                            
                        $leave_application->files()->save($object);
                    }
                }
            }
            if($request->input('assignEmployee_id') && count($request->input('assignEmployee_id')) > 0)
            {
                $leave_application->assignEmployees()->detach();
                $leave_application->assignEmployees()->attach($request->input('assignEmployee_id'),['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);
            }
            DB::commit();
            return response(['data' => new LeaveApplicationResource($leave_application),'success'=>true,'message' => 'Leave Application Updated Successfully'], 200);
        }
        catch (Exception $ex) {
            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }
    
    public function destroy($id)
    {
        $leave_application=LeaveApplication::find($id);
        if(!$this->checkDeleteAccess($leave_application))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);
        DB::beginTransaction();
        try {
            $leave_application->delete();
            DB::commit();
        } catch (Exception $ex) {
            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }
        return response(['data' => array(),'success'=>true,'message' => 'Leave Application Deleted Successfully'], 200);
    }

    public function actionall()
    {        
        $access = request()->action == 'delete' ? 6 : 3;
        if(!$this->checkBulkAcess( $access))
            return response(['data' => array(),'success'=>false,'message' =>"You Don't Have Access For Bulk Action"], 200);
        DB::beginTransaction();
        try {
            if($access == 6 && request()->action == 'delete')
            {
                LeaveApplication::whereIn('id',request()->ids)->get()->each(function($leave_application) 
                {
                    $leave_application->delete();
                });
            }
            elseif($access == 3 && request()->action == 'update')  
                LeaveApplication::whereIn('id',request()->ids)->update([request()->column => request()->status]);
            elseif($access == 3 && request()->action == 'assign-employee')
            {
                LeaveApplication::whereIn('id',request()->ids)->get()->each(function($leave_application)
                {
                    $leave_application->emp_id = request()->emp_id;
                    $leave_application->save();
                });
            }      
            DB::commit();
        } catch (Exception $ex) {
            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }
        return response(['data' => array(),'success'=>true,'message' => 'Updated successfully'], 200);
    }

    public function get_leavetypes_by_employee(Request $request,$id)
    {
        $leave_group = LeaveGroup::whereHas('employees', function ($q) use ($id){
            $q->where('leave_group_users.user_id',$id);
        })->where('status',1)->with('leave_group_elements','employees')->get();
        if(isset($leave_group) && count($leave_group) > 0) {
            $leave_groupp = $leave_group[0]['leave_group_elements']->toArray();
            if(count( $leave_groupp)){
                foreach ( $leave_groupp as $key => $value) {
                    $half_day_count = LeaveApplication::select( DB::raw('SUM(CAST(is_halfday AS UNSIGNED)) AS total_half_days'))->where('is_halfday','>',0)->where('leave_type_id',$value['id'])->where('employee_id',$id)->where('status',2)->get()->toArray();
                    if ($half_day_count[0]['total_half_days'] > 0)
                        $half_full_day= (round($half_day_count[0]['total_half_days'] / 2,1));
                    else
                        $half_full_day = 0;
                    $aproved_leaves=LeaveApplication::select( DB::raw('SUM(CAST(no_of_days AS UNSIGNED)) AS total_days'))->where('leave_type_id',$value['id'])->where('employee_id',$id)->where('status',2)->get()->toArray();
                    if(count($aproved_leaves)>0)
                    $leave_groupp[$key]['leave_remain'] = floatval(($value['pivot']['no_of_days'] + $half_full_day) - $aproved_leaves[0]['total_days']);
                     else
                    $leave_groupp[$key]['leave_remain'] = floatval($value['pivot']['no_of_days']);
                }  
            }
         } else {
            $leave_groupp = [];
         }
        return response(['data' => $leave_groupp, 'dd'=> $leave_groupp,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    public function change_log(Request $request,$id)
    {
        DB::beginTransaction();
        try {
            $leave_application=LeaveApplication::find($id);

            LeaveApplicationStatusChangeLog::create(['column_name'=>request()->column_name,'new_value'=>request()->column_value,'old_value'=>$leave_application->{request()->column_name},'leave_application_id'=>$request->id,'remarks'=>request()->remarks]);

            $leave_application->update([$request->column_name => $request->column_value]);

            //28/07/2024 Jyoti
            if($request->column_name=='end_date' && $leave_application->start_date!=null)
            {
                $start = Carbon::parse( $leave_application->start_date);
                $end =  Carbon::parse($request->column_value);
                $days = $end->diffInDays($start)+1;
                $leave_application->update(['no_of_days' => $days]);
            }
            elseif ($request->column_name=='start_date' && $leave_application->end_date!=null) {
                $start = Carbon::parse( $request->column_value);
                $end =  Carbon::parse($leave_application->end_date);
                $days = $end->diffInDays($start)+1;
                $leave_application->update(['no_of_days' => $days]);
            }
            elseif ($request->column_name=='status' && $leave_application->status_name=='Approved')
            {
                if($template = NotificationTemplate::where('name','leave-approved-notification')->where('status',1)->first())
                {
                    $user_id=[];
                    $user=User::find($leave_application->employee_id);
                    $notification_data['template'] = $template;
                    $notification_data['host'] =isset($user->name)?$user->name:'';
                    $notification_data['type_name'] = $leave_application->leave_type->name;
                    $notification_data['start_date'] = date('d/m/Y H:i A',strtotime($leave_application->start_date));
                    $notification_data['end_date'] = date('d/m/Y H:i A',strtotime($leave_application->end_date));

                    $user_id[]=array('email'=>$user->email,'name'=>$user->name,'mail_type'=>'to');
                    Notification::send($user, new SendNotification($notification_data,$leave_application,$user_id,$request->type,$this->notification_batch_id));
                    if(isset($notification_data['template']) && isset($notification_data['template']['email_body']))
                    $this->template_body=$notification_data['template']['email_body'];

                    $this->sendMailFunc($this->notification_batch_id,$this->template_body,$leave_application->id);
                }
                if($template = NotificationTemplate::where('name','leave-approved-notification-to-assignemployee')->where('status',1)->first())
                {
                    // $url = env('APP_FRONT_URL');
                    // $leave_application_url = '<p><a style="text-decoration: none;" target="_blank" href="'.$url.'apps/leave-manager/leave-application/leave-application-view/'.$leave_application->id.'" rel="noopener">Click here to task details</a></p>';

            
                    // echo "<pre>"; print_r($assignEmps); echo "</pre>"; exit;

                    $user=User::find($leave_application->employee_id);
                    $notification_data['template'] = $template;
                    $notification_data['name'] = $leave_application->name;
                    $notification_data['host'] =isset($user->name)?$user->name:'';
                    $notification_data['type_name'] = $leave_application->leave_type->name;
                    $notification_data['start_date'] = date('d/m/Y H:i A',strtotime($leave_application->start_date));
                    $notification_data['end_date'] = date('d/m/Y H:i A',strtotime($leave_application->end_date));
                    // $notification_data['leave_application_url'] = $leave_application_url;

                    $assignEmps = DB::table('leave_application_users')->where('leave_application_id', $leave_application->id)->get();

                    $assignEmployee_id=[];
                    if($assignEmps!=null && count($assignEmps)>0){
                    foreach($assignEmps as $assignEmp){
                    if(isset($assignEmp))
                        {
                            $getassinEmp = User::find($assignEmp->user_id);                            
                            if($getassinEmp!=null)
                                $assignEmployee_id[]=array('email'=>$getassinEmp->email,'name'=>$getassinEmp->name,'mail_type'=>'to');
                        }
                        Notification::send($getassinEmp, new SendNotification($notification_data,$leave_application,$assignEmployee_id,$request->type,$this->notification_batch_id));
                        if(isset($notification_data['template']) && isset($notification_data['template']['email_body']))
                        $this->template_body=$notification_data['template']['email_body'];
                    }
                        $this->sendMailFunc($this->notification_batch_id,$this->template_body,$leave_application->id);
                    }
                }
            }
            //28/07/2024 Jyoti

            DB::commit();
            return response(['data' => $leave_application,'success'=>true,'message' => 'File Updated Successfully'], 200);

        } catch (Exception $ex) {
            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }
    }

    public function view(Request $request,$id)
    {
        
        $leave_application = LeaveApplication::with('employees','assignEmployees','statusChangeLogs','lapseOrPaid','leave_type','communications.from','communications.replies','communications.replies.from','communications.replies.files','communications.replies.recipients','communications.files','communications.recipients','files.file_sources','statusChangeLogs.editor')->find($id);
        return response(['data' => $leave_application,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
}
