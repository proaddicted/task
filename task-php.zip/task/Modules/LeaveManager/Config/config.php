<?php

return [
    'name' => 'LeaveManager'
];
