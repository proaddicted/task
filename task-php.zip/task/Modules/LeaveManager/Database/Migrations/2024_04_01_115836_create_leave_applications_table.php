<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateLeaveApplicationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('leave_applications', function (Blueprint $table) {
            $table->bigIncrements('id'); //Common For Each Table In Project
            $table->unsignedBigInteger('master_id')->nullable(); //Common For Each Table In Project
            $table->string('name')->nullable();
            $table->unsignedBigInteger('employee_id')->nullable();
            $table->unsignedBigInteger('leave_type_id')->nullable();
            $table->date('start_date')->nullable();
            $table->date('end_date')->nullable();
            $table->string('no_of_days')->nullable();
            $table->longText('description')->nullable();
            $table->softDeletes(); //Common For Each Table In Project
            $table->timestamps(); //Common For Each Table In Project
            $table->unsignedBigInteger('created_by')->nullable(); //Common For Each Table In Project
            $table->unsignedBigInteger('updated_by')->nullable(); //Common For Each Table In Project
            $table->unsignedBigInteger('deleted_by')->nullable(); //Common For Each Table In Project
            $table->tinyInteger('status')->default(0); //Common For Each Table In Project
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('leave_applications');
    }
}
