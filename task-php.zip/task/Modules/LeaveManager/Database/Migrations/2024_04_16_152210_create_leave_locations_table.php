<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateLeaveLocationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('leave_locations', function (Blueprint $table) {
            $table->bigIncrements('id'); //Common For Each Table In Project
            $table->unsignedBigInteger('master_id')->nullable(); //Common For Each Table In Project
            $table->unsignedBigInteger('branch_id')->nullable();
            $table->string('policy')->nullable();
            $table->softDeletes(); //Common For Each Table In Project
            $table->timestamps(); //Common For Each Table In Project
            $table->unsignedBigInteger('created_by')->nullable(); //Common For Each Table In Project
            $table->unsignedBigInteger('updated_by')->nullable(); //Common For Each Table In Project
            $table->unsignedBigInteger('deleted_by')->nullable(); //Common For Each Table In Project
            $table->tinyInteger('status')->default(0); //Common For Each Table In Project
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('leave_locations');
    }
}
