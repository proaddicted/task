<?php

namespace Modules\LeaveManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use Modules\ResourceManager\Entities\Employee;
use App\Traits\EmployeeTrait;
use App\Models\User;



class LeaveGroup extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;

    protected $fillable = ['name','policy','status'];

    protected $searchableColumns = ['name'];

    protected $appends = [];

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }

    public function leave_group_elements()
    {
        return $this->belongsToMany(LeaveType::class,'leave_group_elements','main_id','leave_type_id')->withPivot('frequency_id','lapse_or_paid_id','carry_forward_id','no_of_days','min_emp_days')->wherePivot('deleted_at',NULL)->withTimestamps();
    }

    public function employees()
    {
        return $this->belongsToMany(User::class,"leave_group_users","leave_group_id","user_id")->wherePivot('deleted_at',NULL)->withTimestamps()->withPivot('user_id','leave_group_id');
    }
    

}
