<?php

namespace Modules\LeaveManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use Modules\LeaveManager\Entities\LeaveType;
use App\Models\Branch;

class LeaveLocation extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;

    protected $fillable = ['branch_id','policy','status'];

    protected $searchableColumns = ['branch.name','description'];

    protected $appends = [];

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }

    public function branch()
    {
        return $this->belongsTo(Branch::class,'branch_id');
    }
    
    public function leave_location_elements()
    {
        return $this->belongsToMany(LeaveType::class,'leave_location_elements','main_id','leave_type_id')->withPivot('frequency_id','lapse_or_paid_id','carry_forward_id','no_of_days','min_emp_days')->wherePivot('deleted_at',NULL)->withTimestamps();
    }
}
