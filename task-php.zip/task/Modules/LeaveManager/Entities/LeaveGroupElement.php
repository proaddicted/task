<?php

namespace Modules\LeaveManager\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use Modules\LeaveManager\Entities\LeaveType;

class LeaveGroupElement extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;

    protected $fillable = ['main_id','leave_type_id','frequency_id','lapse_or_paid_id','carry_forward_id','no_of_days','min_emp_days'];

    protected $searchableColumns = ['no_of_days'];

    protected $appends = [];

    public function leave_type()
    {
        return $this->belongsTo(LeaveType::class,'leave_type_id');
    }

}

