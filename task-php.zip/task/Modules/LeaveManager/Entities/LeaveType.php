<?php

namespace Modules\LeaveManager\Entities;

use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;

class LeaveType extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;

    protected $fillable = ['name','remarks','status'];

    protected $searchableColumns = ['name'];

    protected $appends = [];

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }
    

}