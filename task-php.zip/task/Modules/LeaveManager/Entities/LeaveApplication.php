<?php

namespace Modules\LeaveManager\Entities;

use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use App\Traits\CommonTrait;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use Modules\ResourceManager\Entities\Employee;
use Modules\LeaveManager\Entities\LeaveType;
use Modules\LeaveManager\Entities\LeaveGroupElement;
use App\Traits\EmployeeTrait;
use App\Models\File;
use App\Models\User;
use Modules\TaskManager\Entities\Communication;
use Illuminate\Support\Facades\Auth;




class LeaveApplication extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait,CommonTrait;

    protected $fillable = ['name','employee_id','leave_type_id','start_date','end_date','no_of_days','is_halfday','time','is_paid','first_second_half','description','assignEmployees','status','paid_nonpaid_name'];

    protected $searchableColumns = ['name','start_date','end_date'];

    protected $appends = ['status_name','paid_nonpaid_name'];

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }

    public function setPaidNonPaidAttribute($value)
    {
        $this->attributes['is_paid'] = (int) $value;
    }
    
    public function employees()
    {
        return $this->belongsTo(User::class,'employee_id');
    }

    public function assignEmployees()
    {
        return $this->belongsToMany(User::class,"leave_application_users","leave_application_id","user_id")->wherePivot('deleted_at',NULL)->withTimestamps()->withPivot('user_id','leave_application_id');
    }

    public function leave_type()
    {
        return $this->belongsTo(LeaveType::class,'leave_type_id');
    }

    public function files()
    {
        return $this->hasMany(File::class,"main_id","id")->where('identifier','leave_application')->whereNull('deleted_at');
    }
    public function communications()
    {
        return $this->hasMany(Communication::class, 'main_id','id')->where('identifier','leave_application')->where('parent_id',0)->orderBy('date','desc');
    }

    public function statusChangeLogs()
    {
        return $this->hasMany(LeaveApplicationStatusChangeLog::class, 'leave_application_id','id')->whereNull('deleted_at');
    }

    public function lapseOrPaid()
    {
        return $this->belongsTo(LeaveGroupElement::class,'leave_type_id');
    }

    public function updator()
    {
        return $this->belongsTo(User::class,'updated_by');
    }

    public function getStatusNameAttribute()
    {
        if(isset($this->attributes['status']))
        {
            $statuses=array_column($this->leave_application_status,'name', 'id'); 
        
            return $this->attributes['status_name'] = $statuses[$this->attributes['status']];
        }
               
    }

    public function getPaidNonpaidNameAttribute()
    {
        if(isset($this->attributes['is_paid']))
        {
            $is_paid_nonpaid=array_column($this->is_paid_nonpaid,'name', 'id'); 
        
            return $this->attributes['paid_nonpaid_name'] = $is_paid_nonpaid[$this->attributes['is_paid']];
        }
               
    }

    public function scopeleaveCheckPermission($query)
    {
        $user = Auth::user();
        if($user->is_superadmin == 0)
        {
            $employee_info = $this->employee_info($user);
            $res = $this->checkAccessType(5);
    
           // $this->result  = $res;
            if(count($res) > 0)
            {
                
                if($res[0]->access == 0)     /* No Access */
                    $query->whereRaw('1=2');
                elseif($res[0]->access == 1) /* Self Access */
                {
                    $query->whereHas('employees', function ($q) use ($user){
                        $q->where('employee_id',$user->id);
                    })->orWhereHas('assignEmployees', function ($q) use ($user){
                        $q->where('leave_application_users.user_id',$user->id);
                    });
                }
                elseif($res[0]->access == 2) /* Hierarchy Access */
                {
                    
                    $query->whereHas('employees', function ($q) use ($employee_info){
                        $q->whereIn('employee_id',$employee_info->hierarchy_users);
                    });
                   // $query->whereIn($column,$employee_info->hierarchy_users);
                }
                elseif($res[0]->access == 3) /* Branch Access */
                {
                   
                    $query->whereHas('employees', function ($q) use ($employee_info){
                        $q->whereIn('employee_id',$employee_info->branch_users);
                    });
                }
                elseif($res[0]->access == 4) /* Department Access */
                {
                   
                    $query->whereHas('employees', function ($q) use ($employee_info){
                        $q->whereIn('employee_id',$employee_info->branch_users);
                    });
                } 
                elseif($res[0]->access == 5) /* All Access */
                    $query->whereRaw('1=1');
                else
                    $query->whereRaw('1=2');    
            }
            else
                $query->whereRaw('1=2');

       }

        return $query;
    }
    

}
